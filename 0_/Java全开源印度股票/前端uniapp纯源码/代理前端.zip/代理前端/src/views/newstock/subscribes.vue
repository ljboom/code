<template>
    <page-header-wrapper>
        <a-card :bordered="false">
            <a-card :bordered="false">
                <div class="table-page-search-wrapper">
                    <a-form layout="inline">
                        <a-row :gutter="48">
                            <a-col :md="12" :lg="6" :sm="24">
                                <a-form-item label="用户姓名">
                                    <a-input v-model="queryParam.userName" style="width: 100%" placeholder="请输入姓名" />
                                </a-form-item>
                            </a-col>
                            
                            <a-col :md="12" :lg="6" :sm="24">
                                <a-form-item label="手机号">
                                    <a-input v-model="queryParam.mobile" style="width: 100%"
                                        placeholder="请输入手机号" />
                                </a-form-item>
                            </a-col>
                            <a-col :md="12" :lg="6" :sm="24">
                                <a-form-item label="新股名称">
                                    <a-input v-model="queryParam.stockname" style="width: 100%" placeholder="请输入新股名称" />
                                </a-form-item>
                            </a-col>
                            <a-col :md="12" :lg="6" :sm="24">
                                <a-form-item label="显示状态">
                                    <a-select v-model="queryParam.status" placeholder="请选择状态" :default-value="{ key: '1' }">
                                        <a-select-option :value="1">已认购</a-select-option>
                                        <a-select-option :value="2">未中签</a-select-option>
                                        <a-select-option :value="3">已中签</a-select-option>
                                        <a-select-option :value="4">已缴纳</a-select-option>
                                        <a-select-option :value="5">已转持仓</a-select-option>
                                    </a-select>
                                </a-form-item>
                            </a-col>
                        </a-row>
                        <a-row :gutter="48">
                            <a-col :md="12" :lg="8" :sm="24">
                                <a-form-item>
                                    <span class="table-page-search-submitButtons">
                                        <a-button @click="getqueryParam" icon="redo">
                                            重置</a-button>
                                        <a-button type="primary" icon="search" style="margin-left: 8px"
                                            @click="queryParam.pageNum = 1, getlist()">查询
                                        </a-button>
                                    </span>
                                </a-form-item>
                            </a-col>
                        </a-row>
                    </a-form>
                </div>
            </a-card>
            <a-table bordered :loading="loading" :pagination="pagination" :columns="columns" :data-source="datalist"
                rowKey="id">
                <span slot="deAmt" slot-scope="text,record">
                    <template>
                        <a-tag :color="record.deAmt > 0 ? 'red' : record.deAmt < 0 ? 'green' : ''">{{ record.deAmt }}
                        </a-tag>
                    </template>
                </span>
            </a-table>
        </a-card>
    </page-header-wrapper>
</template>
<script>
import { subscribesList } from '@/api/home'
import moment from 'moment'
export default {
    name: 'fundrecords',
    data() {
        return {
            columns: [
                {
                    title: '用户名称（ID）',
                    dataIndex: 'realName',
                    align: "center",
                    width: 180,
                    customRender: (text, row, index) => {
                        return `${row.realName}（${row.userId}）`
                    }
                },
                {
                    title: '用户手机号',
                    dataIndex: 'phone',
                    align: "center",
                    width: 180,
                },
                {
                    title: '新股名称',
                    dataIndex: 'new_name',
                    align: "center",
                },
                {
                    title: '新股代码',
                    dataIndex: 'new_code',
                    align: "center",
                    width: 180,
                },
                {
                    title: '买入价格',
                    dataIndex: 'buyPrice',
                    align: "center",
                },
                {
                    title: '买入数量',
                    dataIndex: 'applyNums',
                    align: "center",
                },
                {
                    title: '保证金',
                    dataIndex: 'bond',
                    align: "center",
                },
                {
                    title: '中签数量',
                    dataIndex: 'applyNumber',
                    align: "center",
                },
                {
                    title: '状态',
                    dataIndex: 'status',
                    align: "center",
                    customRender: (text, row, index) => {
                        if(row.status == 1){
                            return '已认购';
                        }else if(row.status == 2){
                            return '未中签';
                        }else if(row.status == 3){
                            return '已中签'
                        }else if(row.status == 4){
                            return '已缴纳'
                        }else if(row.status == 5){
                            return '已转持仓'
                        }else{
                            return '--'
                        }
                    }
                },
                {
                    title: '新股模式',
                    dataIndex: 'type',
                    align: "center",
                    customRender: (text, row, index) => {
                        if(row.type == 1){
                            return '新股申购'
                        }else{
                            return '线下配售'
                        }
                    }
                },
                {
                    title: '申购时间',
                    dataIndex: 'addTime',
                    align: "center",
                    width: 180,
                    customRender: (text, row, index) => {
                        return text ? moment(text).format('YYYY-MM-DD HH:mm:ss') : ''
                    }
                },
            ],
            //表头
            pagination: {
                total: 0,
                pageSize: 10,//每页中显示10条数据
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50", "100"],//每页中显示的数据
                onShowSizeChange: (current, pageSize) => this.onSizeChange(current, pageSize), // 改变每页数量时更新显示
                onChange: (page, pageSize) => this.onPageChange(page, pageSize),//点击页码事件
                showTotal: total => `共有 ${total} 条数据`,  //分页中显示总的数据
            },
            loading: false,
            queryParam: {
                pageNum: 1,
                pageSize: 10,
                agentId: undefined,
                positionId: '',
                userId: '',
                userName: '',
            },
            datalist: [],
        }
    },
    created() {
        this.getlist()
    },
    methods: {
        getqueryParam() {
            this.queryParam = {
                pageNum: 1,
                pageSize: 10,
                agentId: undefined,
                positionId: '',
                userId: '',
                realName: '',
            }
        },
        onChangeRangeDate(value, dateString) {
            this.queryParam.beginTime = dateString[0]
            this.queryParam.endTime = dateString[1]
        },
        getlist() {
            var that = this;
            this.loading = true
            subscribesList(this.queryParam).then(res => {
                this.datalist = res.data.list
                this.pagination.total = res.data.total
                setTimeout(() => {
                    that.loading = false
                }, 500)
            })
        },
        onPageChange(page, pageSize) {
            this.queryParam.pageNum = page
            this.getlist()
        },
        onSizeChange(current, pageSize) {
            this.queryParam.pageNum = current
            this.queryParam.pageSize = pageSize
            this.getlist()
        },
    }
}
</script>
<style scoped>
.greens {
    color: #52c41a;
}

.reds {
    color: #f5222d;
}
</style>