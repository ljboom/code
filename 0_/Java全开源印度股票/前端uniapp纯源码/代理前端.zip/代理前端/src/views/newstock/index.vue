<template>
    <page-header-wrapper>
        <a-card :bordered="false">
            <a-card :bordered="false">
                <div class="table-page-search-wrapper">
                    <a-form layout="inline">
                        <a-row :gutter="48">
                            <a-col :md="12" :lg="6" :sm="24">
                                <a-form-item label="新股模式">
                                    <a-select v-model="queryParam.ptype" placeholder="请选择持仓类型">
                                        <a-select-option :value="''">全部</a-select-option>
                                        <a-select-option :value="1">新股申购</a-select-option>
                                        <a-select-option :value="2">线下配售</a-select-option>
                                    </a-select>
                                </a-form-item>
                            </a-col>
                            <a-col :md="12" :lg="6" :sm="24">
                                <a-form-item label="显示状态">
                                    <a-select v-model="queryParam.zt" placeholder="请选择状态" :default-value="{ key: '0' }">
                                        <a-select-option :value="0">显示</a-select-option>
                                        <a-select-option :value="1">隐藏</a-select-option>
                                    </a-select>
                                </a-form-item>
                            </a-col>
                            <a-col :md="12" :lg="6" :sm="24">
                                <a-form-item label="新股代码">
                                    <a-input v-model="queryParam.code" style="width: 100%"
                                        placeholder="请输入新股代码" />
                                </a-form-item>
                            </a-col>
                            <a-col :md="12" :lg="6" :sm="24">
                                <a-form-item label="新股名称">
                                    <a-input v-model="queryParam.name" style="width: 100%" placeholder="请输入新股名称" />
                                </a-form-item>
                            </a-col>
                            <a-col :md="12" :lg="6" :sm="24">
                                <a-form-item label="市场类型">
                                    <a-select v-model="queryParam.stockType" placeholder="请选择市场类型" >
                                        <a-select-option :value="1">港股</a-select-option>
                                        <a-select-option :value="1">美股</a-select-option>
                                        <a-select-option :value="2">泰股</a-select-option>
                                        <a-select-option :value="3">马来</a-select-option>
                                        <a-select-option :value="4">越南</a-select-option>
                                    </a-select>
                                    
                                </a-form-item>
                            </a-col>
                        </a-row>
                        <a-row :gutter="48">
                            <a-col :md="12" :lg="8" :sm="24">
                                <a-form-item>
                                    <span class="table-page-search-submitButtons">
                                        <a-button @click="getqueryParam" icon="redo">
                                            重置</a-button>
                                        <a-button type="primary" icon="search" style="margin-left: 8px"
                                            @click="queryParam.pageNum = 1, getlist()">查询
                                        </a-button>
                                    </span>
                                </a-form-item>
                            </a-col>
                        </a-row>
                    </a-form>
                </div>
            </a-card>
            <a-table bordered :loading="loading" :pagination="pagination" :columns="columns" :data-source="datalist"
                rowKey="id">
                <span slot="deAmt" slot-scope="text,record">
                    <template>
                        <a-tag :color="record.deAmt > 0 ? 'red' : record.deAmt < 0 ? 'green' : ''">{{ record.deAmt }}
                        </a-tag>
                    </template>
                </span>
            </a-table>
        </a-card>
    </page-header-wrapper>
</template>
<script>
import { newStockList } from '@/api/home'
import moment from 'moment'
export default {
    name: 'fundrecords',
    data() {
        return {
            columns: [
                {
                    title: '新股名称/新股代码',
                    dataIndex: 'name',
                    align: "center",
                    width: 180,
                    customRender: (text, row, index) => {
                        return `${row.name}（${row.code}）`
                    }
                },
                {
                    title: '最小购买数量',
                    dataIndex: 'minTotal',
                    align: "center",
                },
                {
                    title: '最大购买数量',
                    dataIndex: 'maxTotal',
                    align: "center",
                },
                {
                    title: '价格',
                    dataIndex: 'price',
                    align: "center",
                    width: 180,
                },
                {
                    title: '是否显示',
                    dataIndex: 'zt',
                    align: "center",
                    customRender: (text, row, index) => {
                        if(row.zt == 0){
                            return '显示'
                        }else{
                            return '隐藏'
                        }
                    }
                },
                {
                    title: '新股模式',
                    dataIndex: 'type',
                    align: "center",
                    customRender: (text, row, index) => {
                        if(row.type == 1){
                            return '新股申购'
                        }else{
                            return '线下配售'
                        }
                    }
                },
                {
                    title: '股票类型',
                    dataIndex: 'stockType',
                    align: "center",
                },
                {
                    title: '申购开始时间',
                    dataIndex: 'subscribeTime',
                    align: "center",
                    width: 180,
                    customRender: (text, row, index) => {
                        return text ? moment(text).format('YYYY-MM-DD HH:mm:ss') : ''
                    }
                },
            ],
            //表头
            pagination: {
                total: 0,
                pageSize: 10,//每页中显示10条数据
                showSizeChanger: true,
                pageSizeOptions: ["10", "20", "50", "100"],//每页中显示的数据
                onShowSizeChange: (current, pageSize) => this.onSizeChange(current, pageSize), // 改变每页数量时更新显示
                onChange: (page, pageSize) => this.onPageChange(page, pageSize),//点击页码事件
                showTotal: total => `共有 ${total} 条数据`,  //分页中显示总的数据
            },
            loading: false,
            queryParam: {
                pageNum: 1,
                pageSize: 10,
                agentId: undefined,
                positionId: '',
                userId: '',
                userName: '',
            },
            datalist: []
        }
    },
    created() {
        this.getlist()
    },
    methods: {
        getqueryParam() {
            this.queryParam = {
                pageNum: 1,
                pageSize: 10,
                agentId: undefined,
                positionId: '',
                userId: '',
                realName: '',
            }
        },
        onChangeRangeDate(value, dateString) {
            this.queryParam.beginTime = dateString[0]
            this.queryParam.endTime = dateString[1]
        },
        getlist() {
            var that = this;
            this.loading = true
            newStockList(this.queryParam).then(res => {
                this.datalist = res.data.list
                this.pagination.total = res.data.total
                setTimeout(() => {
                    that.loading = false
                }, 500)
            })
        },
        onPageChange(page, pageSize) {
            this.queryParam.pageNum = page
            this.getlist()
        },
        onSizeChange(current, pageSize) {
            this.queryParam.pageNum = current
            this.queryParam.pageSize = pageSize
            this.getlist()
        },
    }
}
</script>
<style scoped>
.greens {
    color: #52c41a;
}

.reds {
    color: #f5222d;
}
</style>