<template>
    <div>
        <a-modal title="用户详情" :width="1000" :visible="userDialog" :footer="false" @cancel="userDialog = false">
            <a-descriptions bordered :title="currentDetails.realName ? currentDetails.realName : '未认证'" :column="{ xxl: 3, xl: 3, lg: 3, md: 3, sm: 2, xs: 1 }">
                <a-descriptions-item label="用户ID">
                    {{ currentDetails.id ? currentDetails.id : '--' }}
                </a-descriptions-item>
                <a-descriptions-item label="手机号码">
                    {{ currentDetails.phone ? currentDetails.phone : '--' }}
                </a-descriptions-item>
                <a-descriptions-item label="登录状态">
                    <a-tag :color="currentDetails.positionType == 1 ? 'red' : 'green'">
                        {{ currentDetails.isLogin == 1 ? '不可登录' : '正常' }}
                    </a-tag>
                </a-descriptions-item>
                <a-descriptions-item label="账号类型">
                    <a-tag :color="currentDetails.accountType == 1 ? 'blue' : 'green'">
                        {{ currentDetails.accountType == 1 ? '模拟用户' : '实盘用户' }}
                    </a-tag>
                </a-descriptions-item>
                <a-descriptions-item label="交易状态">
                    <a-tag :color="currentDetails.isLock == 1 ? 'red' : 'green'">
                        {{ currentDetails.isLock == 1 ? '不可交易' : '正常' }}
                    </a-tag>
                </a-descriptions-item>
                <a-descriptions-item label="所属代理">
                    {{ currentDetails.agentName ? currentDetails.agentName : '--' }}
                </a-descriptions-item>
                <a-descriptions-item label="真实姓名">
                    {{ currentDetails.realName ? currentDetails.realName : '--' }}
                </a-descriptions-item>
                <a-descriptions-item label="身份证号码">
                    {{ currentDetails.idCard ? currentDetails.idCard : '--' }}
                </a-descriptions-item>
                <a-descriptions-item label="注册ip">
                    {{ currentDetails.regIp ? currentDetails.regIp : '--' }}
                </a-descriptions-item>
                <a-descriptions-item label="注册地址">
                    {{ currentDetails.regAddress ? currentDetails.regAddress : '--' }}
                </a-descriptions-item>
                <a-descriptions-item label="注册时间">
                    {{ currentDetails.regTime | moment }}
                </a-descriptions-item>
            </a-descriptions>

            <a-descriptions style="margin-top:20px;" bordered title="账户资金" :column="{ xxl: 2, xl: 2, lg: 2, md: 2, sm: 2, xs: 1 }">
                <a-descriptions-item label="美股总资金($)">
                    {{ currentDetails.usUserAmt ? currentDetails.usUserAmt : '0.000' | formatDecimal }}
                </a-descriptions-item>
                <a-descriptions-item label="美股可用资金($)">
                    {{ currentDetails.usEnableAmt ? currentDetails.usEnableAmt : '0.000' | formatDecimal }}
                </a-descriptions-item>

                <a-descriptions-item label="港股总资金(HK$)">
                    {{ currentDetails.hkUserAmt ? currentDetails.hkUserAmt : '0.000' | formatDecimal }}
                </a-descriptions-item>
                <a-descriptions-item label="港股可用资金(HK$)">
                    {{ currentDetails.hkEnableAmt ? currentDetails.hkEnableAmt : '0.000' | formatDecimal }}
                </a-descriptions-item>

                <a-descriptions-item label="马来总资金(RM)">
                    {{ currentDetails.myUserAmt ? currentDetails.myUserAmt : '0.000' | formatDecimal }}
                </a-descriptions-item>
                <a-descriptions-item label="马来可用资金(RM)">
                    {{ currentDetails.myEnableAmt ? currentDetails.myEnableAmt : '0.000' | formatDecimal }}
                </a-descriptions-item>

                <a-descriptions-item label="泰股总资金(฿)">
                    {{ currentDetails.thUserAmt ? currentDetails.thUserAmt : '0.000' | formatDecimal }}
                </a-descriptions-item>
                <a-descriptions-item label="泰股可用资金(฿)">
                    {{ currentDetails.thEnableAmt ? currentDetails.thEnableAmt : '0.000' | formatDecimal }}
                </a-descriptions-item>

                <a-descriptions-item label="印股总资金(INR)">
                    {{ currentDetails.inUserAmt ? currentDetails.inUserAmt : '0.000' | formatDecimal }}
                </a-descriptions-item>
                <a-descriptions-item label="印股可用资金(INR)">
                    {{ currentDetails.inEnableAmt ? currentDetails.inEnableAmt : '0.000' | formatDecimal }}
                </a-descriptions-item>

            </a-descriptions>

        </a-modal>
    </div>
</template>
<script>
export default {
    components: {},
    props: {
        currentDetails: {
            type: Object,
        }
    },
    data() {
        return {
            userDialog: false
        }
    },
    filters: {
        formatDecimal(value) {
            if (typeof value === 'number') {
                return value.toFixed(3); // 使用 toFixed 方法保留 3 位小数
            }
            return value;
        }
    },
    methods: {

    }
}
</script>