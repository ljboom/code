package com.nq.controller.protol;

import cn.hutool.core.convert.impl.CurrencyConverter;
import com.nq.common.ServerResponse;
import com.nq.controller.AdminApiController;
import com.nq.service.IStockCoinService;
import com.nq.service.IUserService;
import com.nq.utils.CurrencyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.List;

/**
 * 股票货币转换
 */
@Controller
@RequestMapping({"/user/stock/"})
public class UserStockController {

    private static final Logger log = LoggerFactory.getLogger(UserStockController.class);

    @Autowired
    IStockCoinService coinService;

    @Autowired
    IUserService userService;

    /**
     * 获取货币汇率
     * @return
     */
    @RequestMapping({"coin/getStockCoinList"})
    @ResponseBody
    public ServerResponse getStockCoinList() {
        List selectCoin = coinService.getSelectCoin();
        return ServerResponse.createBySuccess(selectCoin);
    }

    @RequestMapping({"coin/transfer"})
    @ResponseBody
    public ServerResponse transfer(@RequestParam("formAmount") String formAmount,
                                   @RequestParam("toAmt") String toAmt,
                                   @RequestParam("formCode") String formCode,
                                   @RequestParam("toCode") String toCode, HttpServletRequest request) {
        ServerResponse transfer = coinService.transfer(formAmount, toAmt, formCode, toCode, request);
        return transfer;
    }

}
