package com.nq.service;

import com.nq.common.servlet.BaseService;
import com.nq.entity.FastbullNews;
import org.springframework.stereotype.Service;

public interface FastbullNewsService extends BaseService<FastbullNews> {
}
