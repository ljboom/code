package com.nq;


import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.nq.entity.FastbullNews;

public class Main {

    static String newUrl = "https://api.fastbull.com/fastbull-news-service/api/getMergeCalendarPage";

    public static void main(String[] args) {
        String startTimestamp = "1711296000000";
        String endTimestamp = "1711382399000";
        String types = "1,2,3";
        // 构建请求参数字符串
        String params = String.format("startTimestamp=%s&endTimestamp=%s&types=%s", startTimestamp, endTimestamp, types);
        // 发送 GET 请求
        String result = HttpUtil.get(newUrl + "?" + params);
        JSONObject jsonObject = JSON.parseObject(result).getJSONObject("bodyMessage");
        //获取新闻列表
        JSONArray mergeList = jsonObject.getJSONArray("mergeList");
        for (int i = 0; i < mergeList.size(); i++) {
            JSONObject mergeInfo = mergeList.getJSONObject(i);
            JSONObject calenderEventModel = mergeInfo.getJSONObject("calenderEventModel");
            FastbullNews eventModel = JSON.parseObject(calenderEventModel.toJSONString(), FastbullNews.class);

        }
        System.out.println(jsonObject);

    }
}
