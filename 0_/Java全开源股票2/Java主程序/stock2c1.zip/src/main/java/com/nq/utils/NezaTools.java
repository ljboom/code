package com.nq.utils;

import com.nq.pojo.User;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * 哪吒出海 tg:@roseccc
 */
@Slf4j
public class NezaTools {

    public static String ENABLE_AMT = "EnableAmt";
    public static String USER_AMT = "UserAmt";
    public static String FREEZ_AMT = "FreezAmt";
    public static String PROFIT_AND_LOSE = "ProfitAndLose";

    public static Map<String, String> builder(String filed){
        Map<String, String> PROPERTY_MAP = new HashMap<>();
        //可用额度
        PROPERTY_MAP.put("USD", "us" + filed);
        PROPERTY_MAP.put("JPY", "jp" + filed);
        PROPERTY_MAP.put("HKD", "hk" + filed);
        PROPERTY_MAP.put("MYR", "my" + filed);
        PROPERTY_MAP.put("THB", "th" + filed);
        PROPERTY_MAP.put("PHP", "ph" + filed);
        PROPERTY_MAP.put("IDR", "id" + filed);
        PROPERTY_MAP.put("KRW", "kr" + filed);
        PROPERTY_MAP.put("INR", "in" + filed);
        return PROPERTY_MAP;
    }

    public static void setPropertyValue(Object obj, String propertyName, Object value) {
        try {
            String methodName = "set" + propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1);
            Method method = obj.getClass().getMethod(methodName, value.getClass());
            method.invoke(obj, value);
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            // 在这里处理异常，或者将异常向上抛出
            log.error("额度转换失败",e);
        }
    }

    public static BigDecimal findByCodeMoney(User dbuser,String propertyName){
        BigDecimal result = new BigDecimal(0);
        if (propertyName != null) {
            try {
                Method method = dbuser.getClass().getMethod("get" + propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1));
                Object value = method.invoke(dbuser);
                if (value instanceof BigDecimal) {
                    result = (BigDecimal) value;
                } else if (value instanceof Number) {
                    result = BigDecimal.valueOf(((Number) value).doubleValue());
                }
            } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
                // 在这里处理异常，或者将异常向上抛出
                log.error("获取余额失败", e);
            }
        }
        return result;
    }

}
