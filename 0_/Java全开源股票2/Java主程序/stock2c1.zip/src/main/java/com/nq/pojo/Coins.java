package com.nq.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@TableName("coins")
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Coins {

    @TableId(type = IdType.INPUT)
    private Integer id;

    @TableField(value = "coin_name")
    private String coinName;

    @TableField(value = "coin_code")
    private String coinCode;

    @TableField(value = "default_rate")
    private Double defaultRate;

    @TableField(value = "is_use")
    private Boolean isUse;

    @TableField(value = "ico_img")
    private String icoImg;

    @TableField(value = "create_time")
    private Date createTime;

}
