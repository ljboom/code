package com.nq;

import cn.hutool.core.net.NetUtil;
import com.nq.utils.ip.ipUtil;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

@MapperScan(basePackages = "com.nq.dao")
@EnableScheduling
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
public class StockApplication {


    public static void main(String[] args) throws UnknownHostException, SocketException {
        ipUtil iputil = new ipUtil();
        InetAddress inetAddress = InetAddress.getLocalHost();
        String localMacAddress2 = NetUtil.getMacAddress(inetAddress);
//        if ("156.251.145.167".equals(iputil.getPublicIP()) && "36-d9-d9-02-1f-b7".equals(localMacAddress2)) {
            SpringApplication.run(StockApplication.class, args);
//        } else {
//            System.out.println("ip地址不在白名单内"+iputil.getPublicIP()+"mac地址不在白名单内"+localMacAddress2);
//        }
    }

}
