package com.nq.service.impl;


import com.github.pagehelper.PageHelper;

import com.github.pagehelper.PageInfo;

import com.google.common.collect.Lists;

import com.nq.common.ServerResponse;

import com.nq.controller.protol.UserStockController;
import com.nq.dao.StockCoinMapper;

import com.nq.dao.UserMapper;
import com.nq.pojo.StockCoin;

import com.nq.pojo.User;
import com.nq.service.IStockCoinService;

import com.nq.service.IStockFuturesService;

import com.nq.utils.NezaTools;
import com.nq.utils.PropertiesUtil;
import com.nq.utils.redis.JsonUtil;
import com.nq.utils.redis.RedisShardedPoolUtils;
import com.nq.vo.foreigncurrency.ExchangeVO;

import com.nq.vo.stockfutures.CoinAdminListVO;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Date;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.val;
import org.apache.commons.lang3.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;


@Service("iStockCoinService")

public class StockCoinServiceImpl implements IStockCoinService {

    private static final Logger log = LoggerFactory.getLogger(StockCoinServiceImpl.class);

    @Autowired
    StockCoinMapper stockCoinMapper;

    @Autowired
    IStockFuturesService iStockFuturesService;

    @Autowired
    UserMapper userMapper;

    public ServerResponse<PageInfo> listByAdmin(String coinName, String coinCode, int pageNum, int pageSize) {

        PageHelper.startPage(pageNum, pageSize);

        List<StockCoin> stockCoins = this.stockCoinMapper.listByAdmin(coinName, coinCode);

        List<CoinAdminListVO> coinAdminListVOS = Lists.newArrayList();

        for (StockCoin stockCoin : stockCoins) {

            CoinAdminListVO coinAdminListVO = assembleCoinAdminListVO(stockCoin);

            coinAdminListVOS.add(coinAdminListVO);

        }


        PageInfo pageInfo = new PageInfo(stockCoins);

        pageInfo.setList(coinAdminListVOS);


        return ServerResponse.createBySuccess(pageInfo);

    }

    private CoinAdminListVO assembleCoinAdminListVO(StockCoin stockCoin) {

        CoinAdminListVO coinAdminListVO = new CoinAdminListVO();

        coinAdminListVO.setId(stockCoin.getId());

        coinAdminListVO.setCoinName(stockCoin.getCoinName());

        coinAdminListVO.setCoinCode(stockCoin.getCoinCode());

        coinAdminListVO.setCoinGid(stockCoin.getCoinGid());

        coinAdminListVO.setDynamicRate(stockCoin.getDynamicRate());

        coinAdminListVO.setDefaultRate(stockCoin.getDefaultRate());

        coinAdminListVO.setIsUse(stockCoin.getIsUse());

        coinAdminListVO.setIcoImg(stockCoin.getIcoImg());

        coinAdminListVO.setAddTime(stockCoin.getAddTime());

        coinAdminListVO.setTDesc(stockCoin.gettDesc());


        String nowPrice = "";

        ExchangeVO exchangeVO = null;


        ServerResponse serverResponse = this.iStockFuturesService.queryExchangeVO(stockCoin.getCoinCode());

        if (serverResponse.isSuccess()) {

            exchangeVO = (ExchangeVO) serverResponse.getData();

            if (exchangeVO != null) {

                nowPrice = exchangeVO.getNowPrice();

            }

        }

        coinAdminListVO.setNowPrice(nowPrice);

        /*查询新浪实时汇率*/
        ServerResponse serverResponse1 = iStockFuturesService.getExchangeRate(coinAdminListVO.getCoinCode());
        if (serverResponse1.isSuccess()) {
            coinAdminListVO.setDefaultRate((BigDecimal) serverResponse1.getData());
        }


        return coinAdminListVO;

    }


    public ServerResponse add(StockCoin stockCoin) {

        if (StringUtils.isBlank(stockCoin.getCoinName()) ||

                StringUtils.isBlank(stockCoin.getCoinCode()) ||

                StringUtils.isBlank(stockCoin.getCoinGid())) {

            return ServerResponse.createByErrorMsg("参数不能为空");

        }


        StockCoin coinName = this.stockCoinMapper.selectCoinByName(stockCoin.getCoinName());

        if (coinName != null) {

            return ServerResponse.createByErrorMsg("名称不能重复");

        }

        StockCoin coinCode = this.stockCoinMapper.selectCoinByCode(stockCoin.getCoinCode());

        if (coinCode != null) {

            return ServerResponse.createByErrorMsg("代码不能重复");

        }

        StockCoin coinGid = this.stockCoinMapper.selectCoinByCode(stockCoin.getCoinGid());

        if (coinGid != null) {

            return ServerResponse.createByErrorMsg("gid不能重复");

        }


        stockCoin.setAddTime(new Date());


        int insertCount = this.stockCoinMapper.insert(stockCoin);

        if (insertCount > 0) {

            return ServerResponse.createBySuccessMsg("添加成功");

        }

        return ServerResponse.createByErrorMsg("添加失败");

    }


    public ServerResponse update(StockCoin stockCoin) {

        if (stockCoin.getId() == null) {

            return ServerResponse.createByErrorMsg("修改id不能为空");

        }


        StockCoin dbCoin = this.stockCoinMapper.selectByPrimaryKey(stockCoin.getId());

        if (dbCoin == null) {

            return ServerResponse.createByErrorMsg("基币不存在");

        }


        if (stockCoin.getCoinName() != null) {

            StockCoin coinName = this.stockCoinMapper.selectCoinByName(stockCoin.getCoinName());

            if (coinName != null && coinName.getId() != dbCoin.getId()) {

                return ServerResponse.createByErrorMsg("名称已存在");

            }

        }

        if (stockCoin.getCoinCode() != null) {

            StockCoin coinCode = this.stockCoinMapper.selectCoinByCode(stockCoin.getCoinCode());

            if (coinCode != null && coinCode.getId() != dbCoin.getId()) {

                return ServerResponse.createByErrorMsg("代码已存在");

            }

        }

        if (stockCoin.getCoinGid() != null) {

            StockCoin coinGid = this.stockCoinMapper.selectCoinByCode(stockCoin.getCoinGid());

            if (coinGid != null && coinGid.getId() != dbCoin.getId()) {

                return ServerResponse.createByErrorMsg("gid已存在");

            }

        }


        int updateCount = this.stockCoinMapper.updateByPrimaryKeySelective(stockCoin);

        if (updateCount > 0) {

            return ServerResponse.createBySuccessMsg("修改成功");

        }

        return ServerResponse.createByErrorMsg("修改失败");

    }


    public StockCoin selectCoinByCode(String coinCode) {
        return this.stockCoinMapper.selectCoinByCode(coinCode);
    }


    public List getSelectCoin() {
        return this.stockCoinMapper.getSelectCoin();
    }

    @Override
    public ServerResponse transfer(String formAmount, String toAmt, String formCode, String toCode, HttpServletRequest request) {

        if(StringUtils.isBlank(formAmount) || StringUtils.isBlank(toAmt) ||StringUtils.isBlank(formCode) || StringUtils.isBlank(toCode)){
            return ServerResponse.createByErrorMsg("无效参数");
        }

        //计算汇率
        List<StockCoin> coinList = stockCoinMapper.getSelectCoin();

        BigDecimal formRate = findByCodeRate(coinList, formCode);
        BigDecimal toRate = findByCodeRate(coinList, toCode);

        //兑换金额
        BigDecimal formMoney = new BigDecimal(formAmount);
        //兑换成功金额
        BigDecimal toMoney = convert(new BigDecimal(formAmount), formRate, toRate);

        //获取当前用户信息
        String cookie_name = PropertiesUtil.getProperty("user.cookie.name");
        String loginToken = request.getHeader(cookie_name);
        String userJson = RedisShardedPoolUtils.get(loginToken);
        User user = (User) JsonUtil.string2Obj(userJson, User.class);
        User dbuser = this.userMapper.selectByPrimaryKey(user.getId());

        //余额不足
        BigDecimal codeMoney = NezaTools.findByCodeMoney(dbuser, NezaTools.builder(NezaTools.ENABLE_AMT).get(formCode));
        if(formMoney.compareTo(codeMoney) > 0){
            return ServerResponse.createByErrorMsg("可用余额不足");
        }

        //开始修改余额
        User newUser = settingUser(dbuser, formMoney, toMoney, formCode, toCode);
        userMapper.updateById(newUser);
        //end

        return ServerResponse.createBySuccess();
    }

    private User settingUser(User dbUser,BigDecimal formAmount, BigDecimal toAmt, String formCode, String toCode){
        User result = dbUser;
        BigDecimal formMoney = NezaTools.findByCodeMoney(dbUser, NezaTools.builder(NezaTools.ENABLE_AMT).get(formCode));
        BigDecimal toMoney = NezaTools.findByCodeMoney(dbUser, NezaTools.builder(NezaTools.ENABLE_AMT).get(toCode));
        String formProperty = NezaTools.builder(NezaTools.ENABLE_AMT).get(formCode);
        String toProperty = NezaTools.builder(NezaTools.ENABLE_AMT).get(toCode);
        BigDecimal formSumMoney = NezaTools.findByCodeMoney(dbUser, NezaTools.builder(NezaTools.USER_AMT).get(formCode));
        BigDecimal toSumMoney = NezaTools.findByCodeMoney(dbUser, NezaTools.builder(NezaTools.USER_AMT).get(toCode));
        if (formProperty != null) {
            NezaTools.setPropertyValue(result,NezaTools.builder(NezaTools.USER_AMT).get(formCode), formSumMoney.subtract(formAmount));
            NezaTools.setPropertyValue(result,formProperty, formMoney.subtract(formAmount));
        }
        if (toProperty != null) {
            NezaTools.setPropertyValue(result,NezaTools.builder(NezaTools.USER_AMT).get(toCode), toSumMoney.add(toAmt));
            NezaTools.setPropertyValue(result,toProperty, toMoney.add(toAmt));
        }
        return result;
    }

    /**
     * 汇率计算
     * @param amount
     * @param exchangeRate1
     * @param exchangeRate2
     * @return
     */
    private BigDecimal convert(BigDecimal amount, BigDecimal exchangeRate1, BigDecimal exchangeRate2) {
        // 根据第一个汇率将金额转换为中间货币
        BigDecimal intermediateAmount = amount.divide(exchangeRate1, 10, BigDecimal.ROUND_HALF_UP);
        // 根据第二个汇率将中间货币转换为目标货币
        BigDecimal convertedAmount = intermediateAmount.multiply(exchangeRate2)
                .setScale(3, BigDecimal.ROUND_HALF_UP);
        return convertedAmount;
    }

    private BigDecimal findByCodeRate(List<StockCoin> coinList,String code){
        BigDecimal result = new BigDecimal("0");
        for(StockCoin stockCoin : coinList){
            if(stockCoin.getCoinCode().equals(code)){
                result = stockCoin.getDefaultRate();
                break;
            }
        }
        return result;
    }
}
