package com.nq.utils.task.news;

import cn.hutool.core.date.DateUtil;
import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.nq.common.Const;
import com.nq.entity.FastbullNews;
import com.nq.service.FastbullNewsService;
import com.nq.service.ISiteArticleService;
import com.nq.service.ISiteNewsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
//import org.springframework.scheduling.annotation.Scheduled;


@Component
public class NewsTask {
    private static final Logger log = LoggerFactory.getLogger(NewsTask.class);

    @Autowired
    ISiteNewsService iSiteNewsService;

    @Autowired
    ISiteArticleService iSiteArticleService;

    @Autowired
    private FastbullNewsService fastbullNewsService;

    @Scheduled(cron = "0 0 1 * * ?")
    public void weeklyTask() {

        List<Date> dates = new ArrayList<>();
        // 获取当前日期
        Date currentDate = new Date();

        // 计算本周的开始时间和结束时间
        Date weekStartTime = DateUtil.beginOfWeek(currentDate);
        Date weekEndTime = DateUtil.endOfWeek(currentDate);
        Date currentDay = new Date(weekStartTime.getTime());

        while (currentDay.compareTo(weekEndTime) <= 0) {
            dates.add(new Date(currentDay.getTime()));
            currentDay.setDate(currentDay.getDate() + 1);
        }

        // 打印日期列表
        for (Date date : dates) {
            //当天开始时间
            long startTime = date.getTime();
            //当天结束时间  23:59:59
            Date endDate = DateUtil.endOfDay(date);
            long endTime = endDate.getTime();
            String dateStr = DateUtil.format(date, "yyyy-MM-dd");

            String types = "1,2,3";
            // 构建请求参数字符串
            String params = String.format("startTimestamp=%s&endTimestamp=%s&types=%s", startTime, endTime, types);
            // 发送 GET 请求
            String result = HttpUtil.get(Const.NEWS_URL + "?" + params);
            JSONObject jsonObject = JSON.parseObject(result).getJSONObject("bodyMessage");
            //获取新闻列表
            JSONArray mergeList = jsonObject.getJSONArray("mergeList");
            for (int i = 0; i < mergeList.size(); i++) {
                JSONObject mergeInfo = mergeList.getJSONObject(i);
                JSONObject calenderEventModel = mergeInfo.getJSONObject("calenderEventModel");
                if(Objects.isNull(calenderEventModel)){
                    continue;
                }
                FastbullNews eventModel = JSON.parseObject(calenderEventModel.toJSONString(), FastbullNews.class);
                eventModel.setDateStr(dateStr);
                //查询是否已存在数据
                Long count = fastbullNewsService.lambdaQuery().eq(FastbullNews::getReleasedDate, eventModel.getReleasedDate()).count();
                if(count.intValue() > 0){
                    continue;
                }
                fastbullNewsService.save(eventModel);
            }
        }

    }

    /*
    * 新聞資訊抓取
    * */
    @Scheduled(cron = "0 0/30 9-20 * * ?")
//    @Scheduled(cron = "0 55 18 * * ?")
//    @Scheduled(cron = "0/5 * * * * ?")
    public void NewsInfoTask() {
        this.iSiteNewsService.grabNews();
        log.info("新聞資訊抓取完成");
    }

    /*
     * 新聞公告抓取
     * */
    @Scheduled(cron = "0 0/30 9-20 * * ?")
    public void ArtInfoTask() {
        this.iSiteArticleService.grabArticle();
    }
}
