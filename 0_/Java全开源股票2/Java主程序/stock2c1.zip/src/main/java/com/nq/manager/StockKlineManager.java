package com.nq.manager;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.NumberUtil;
import com.google.common.base.Joiner;
import com.neza.common.Constants;
import com.neza.entity.InvHistory;
import com.neza.entity.InvQuotes;
import com.neza.entity.StockInfo;
import com.neza.manager.InvestingManager;
import com.neza.manager.InvestingManagerImpl;
import com.nq.entity.Stock;
import com.nq.entity.StockKline;
import com.nq.service.IStockService;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * k数据转换
 */
@Component
public class StockKlineManager {

    @Autowired
    IStockService iStockService;

    /**
     * 数据转k
     * @return
     */
    public StockKline inv2stock(String secid, String beg,String klt){
        InvestingManager inves = new InvestingManagerImpl();
        String[] symbol = secid.split("\\.");
        DateTime dateTime = DateUtil.parse(beg, "yyyyMMdd");
        String begTime = String.valueOf(dateTime.getTime() / 1000);
        // 获取当前时间
        Date now = DateUtil.date();
        // 转换为当天开始的时间（即午夜12点）
        Date beginOfDay = DateUtil.beginOfDay(now);
        // 获取时间戳（毫秒单位）
        long timestampMillis = beginOfDay.getTime();
        // 转换为秒单位
        long timestampSeconds = timestampMillis / 1000;
        String endTime = String.valueOf(timestampSeconds);
        InvQuotes invQuotes = iStockService.getInvQuotes(symbol[0], symbol[1]);
        //如果是天数，只返回近5天的数据，因为太多了
        boolean number = NumberUtil.isNumber(klt);
        if(number){
            // 获取当前日期
            Date currentDate = DateUtil.date();
            // 获取当前日期前五天的日期
            Date dateBeforeFiveDays = DateUtil.offsetDay(currentDate, -5);
            // 将日期转换为秒时间戳
            begTime = String.valueOf(dateBeforeFiveDays.getTime() / 1000);
        }

        InvHistory invHistory = iStockService.getInvHistory(symbol[0], symbol[1], klt, begTime, endTime);
        List<String> klines = getKlines(invHistory);
        //起始下面这些数据返回都没什么作用，前端也不会截取
        StockKline stockKline = new StockKline();
        stockKline.setDlmkts("");
        stockKline.setFull(0);
        stockKline.setLt(1);
        stockKline.setRc(0);
        stockKline.setRt(17);
        stockKline.setSvr(0);
        //设置k数据
        Stock stock = new Stock();
        stock.setCode(invQuotes.getSymbols());
        stock.setKlines(klines);
        stock.setDecimal(2);
        stock.setDktotal(0);
        stock.setMarket(0);
        stock.setName(invQuotes.getShortName());
        stock.setPrePrice(Double.valueOf(invQuotes.getPrevClosePrice()));
        stock.setPreKPrice(Double.valueOf(invQuotes.getOpenPrice()));
        stock.setQtMiscType(0);
        stockKline.setData(stock);
        return stockKline;
    }

    /**
     * 数据格式化
     */
    private List<String> getKlines(InvHistory invHistory){
        int ksize = invHistory.getT().size();

        List<String> result = Lists.newArrayList();
        for(int i = 0; i < ksize; i++){
            List<String> kdata = Lists.newArrayList();
            //日期
            String dateStr = invHistory.getTs().get(i);
            kdata.add(dateStr);
            //开盘
            String openStr = double2Str(invHistory.getO().get(i));
            kdata.add(openStr);
            //收盘
            String closeStr = double2Str(invHistory.getC().get(i));
            kdata.add(closeStr);
            //最高
            String hstr = double2Str(invHistory.getH().get(i));
            kdata.add(hstr);
            //最低
            String lstr = double2Str(invHistory.getL().get(i));
            kdata.add(lstr);
            //成交量
            String vol = String.valueOf(invHistory.getV().get(i));
            kdata.add(vol);
            //成交金额 = 关盘 * 成交量
            String amount = String.valueOf(invHistory.getV().get(i) *  invHistory.getC().get(i).intValue());
            kdata.add(amount);
            //未知数据
            kdata.add("0.0");
            //涨幅百分比
            double zfbfb = 0.0;
            if(i>0){
                zfbfb = (invHistory.getO().get(i) - invHistory.getO().get(i - 1)) / invHistory.getO().get(i - 1) * 100;
            }
            kdata.add(double2Str(zfbfb));
            //振幅
            double zf = 0.0;
            if(i>0){
                zf = invHistory.getO().get(i) - invHistory.getO().get(i - 1);
            }
            kdata.add(double2Str(zf));
            kdata.add("0.0");
            String join = Joiner.on(",").join(kdata);
            result.add(join);
        }
        return result;
    }

    /**
     * 将double类型的数值格式化为保留两位小数的字符串。
     *
     * @param value 要格式化的double值。
     * @return 保留两位小数的字符串。
     */
    public static String double2Str(double value) {
        return String.format("%.2f", value);
    }

}
