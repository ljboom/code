package com.nq.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
@TableName("user")

@NoArgsConstructor
@AllArgsConstructor
@Data
public class User {
    @TableId(type = IdType.AUTO,value = "id")
    private Integer id;
    private Integer agentId;
    private String agentName;
    private String phone;
    private String userPwd;
    private String withPwd;
    private String nickName;
    private String realName;
    private String idCard;


    private Integer accountType;

    private BigDecimal userAmt;

    private BigDecimal enableAmt;

    private BigDecimal sumChargeAmt;

    private BigDecimal sumBuyAmt;

    private String recomPhone;
    private Integer isLock;
    private Integer isLogin;
    private Date regTime;
    private String regIp;
    private String regAddress;
    private String img1Key;
    private String img2Key;
    private String img3Key;
    private Integer isActive;
    private String authMsg;
    private BigDecimal userIndexAmt;
    private BigDecimal enableIndexAmt;
    private BigDecimal userFutAmt;
    private BigDecimal enableFutAmt;
    private String withdrawalPwd;
    /*总操盘金额*/
    private BigDecimal tradingAmount;

    private BigDecimal djzj;
    //能否购买涨停板 0不能 1能
    private Integer isBuyUp;

    private BigDecimal usUserAmt;
    private BigDecimal usEnableAmt;
    private BigDecimal hkUserAmt;
    private BigDecimal hkEnableAmt;
    private BigDecimal myUserAmt;
    private BigDecimal myEnableAmt;
    private BigDecimal thUserAmt;
    private BigDecimal thEnableAmt;
    private BigDecimal phUserAmt;
    private BigDecimal phEnableAmt;
    private BigDecimal idUserAmt;
    private BigDecimal idEnableAmt;
    private BigDecimal inUserAmt;
    private BigDecimal inEnableAmt;
    private BigDecimal krUserAmt;
    private BigDecimal krEnableAmt;
    private BigDecimal jpUserAmt;
    private BigDecimal jpEnableAmt;
    private BigDecimal usProfitAndLose;
    private BigDecimal usFreezAmt;
    private BigDecimal hkProfitAndLose;
    private BigDecimal hkFreezAmt;
    private BigDecimal myProfitAndLose;
    private BigDecimal myFreezAmt;
    private BigDecimal thProfitAndLose;
    private BigDecimal thFreezAmt;
    private BigDecimal phProfitAndLose;
    private BigDecimal phFreezAmt;
    private BigDecimal idProfitAndLose;
    private BigDecimal idFreezAmt;
    private BigDecimal inProfitAndLose;
    private BigDecimal inFreezAmt;
    private BigDecimal krProfitAndLose;
    private BigDecimal krFreezAmt;
    private BigDecimal jpProfitAndLose;
    private BigDecimal jpFreezAmt;

}
