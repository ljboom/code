package com.nq.entity;

import lombok.Data;

/**
 * 新闻采集实体类
 */
@Data
public class FastbullNews {

    private long releasedDate;
    private String country;
    private String eventId;
    private int star;
    private String eventContent;
    private String baseId;
    private String path;
    private String calendarId;
    private String countryCode;
    private String countryImg;
    private String speaker;
    private boolean isDetermine;
    private int langId;
    private String timeLabel;
    private String dateStr;

}
