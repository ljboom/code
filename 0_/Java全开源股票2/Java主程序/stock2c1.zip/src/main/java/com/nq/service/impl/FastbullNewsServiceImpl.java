package com.nq.service.impl;

import com.nq.common.servlet.BaseServiceImpl;
import com.nq.dao.FastbullNewsMapper;
import com.nq.entity.FastbullNews;
import com.nq.service.FastbullNewsService;
import org.springframework.stereotype.Service;

@Service
public class FastbullNewsServiceImpl extends BaseServiceImpl<FastbullNewsMapper, FastbullNews> implements FastbullNewsService {
}
