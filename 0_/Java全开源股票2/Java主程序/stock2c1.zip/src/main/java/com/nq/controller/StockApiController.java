package com.nq.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.digest.DigestUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.nq.common.Const;
import com.nq.entity.FastbullNews;
import com.nq.manager.StockKlineManager;
import com.nq.common.ServerResponse;
import com.nq.dao.StockMapper;
import com.nq.entity.StockKline;
import com.nq.pojo.Stock;
import com.nq.service.FastbullNewsService;
import com.nq.service.IStockService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.*;

@Controller
@RequestMapping({"/api/stock/"})
public class StockApiController {
    private static final Logger log = LoggerFactory.getLogger(StockApiController.class);

    @Autowired
    IStockService iStockService;

    @Autowired
    private StockMapper stockMapper;

    @Autowired
    private StockKlineManager stockKlineManager;

    @Autowired
    private FastbullNewsService fastbullNewsService;

    @RequestMapping({"findCalendarDataList.do"})
    @ResponseBody
    public ServerResponse findCalendarDataList(@RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
                                               @RequestParam(value = "pageSize", defaultValue = "10") int pageSize,
                                               @RequestParam(value = "year", defaultValue = "2024") int year,
                                               @RequestParam(value = "month", defaultValue = "03") int month,
                                               @RequestParam(value = "day", defaultValue = "25") int day) {

        Page<FastbullNews> page = new Page<>(pageNum, pageSize);

        String dateStr = String.format("%s-%02d-%02d",year,month,day);
        LambdaQueryWrapper<FastbullNews> lamqw = Wrappers.lambdaQuery();
        lamqw.eq(FastbullNews::getDateStr,dateStr);
        Page<FastbullNews> pages = fastbullNewsService.page(page, lamqw);
        return ServerResponse.createBySuccess(pages.getRecords());
    }

    @RequestMapping({"findCalendarEventList.do"})
    @ResponseBody
    public ServerResponse findCalendarEventList(@RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
                                               @RequestParam(value = "pageSize", defaultValue = "10") int pageSize,
                                               @RequestParam(value = "year", defaultValue = "2024") int year,
                                               @RequestParam(value = "month", defaultValue = "03") int month,
                                               @RequestParam(value = "day", defaultValue = "25") int day) {

        Page<FastbullNews> page = new Page<>(pageNum, pageSize);

        String dateStr = String.format("%s-%02d-%02d",year,month,day);
        LambdaQueryWrapper<FastbullNews> lamqw = Wrappers.lambdaQuery();
        lamqw.eq(FastbullNews::getDateStr,dateStr);
        Page<FastbullNews> pages = fastbullNewsService.page(page, lamqw);
        List<FastbullNews> records = pages.getRecords();
        Collections.shuffle(records);
        return ServerResponse.createBySuccess(records);
    }

    @RequestMapping({"findCalendarHolidayList.do"})
    @ResponseBody
    public ServerResponse findCalendarHolidayList(@RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
                                               @RequestParam(value = "pageSize", defaultValue = "10") int pageSize,
                                               @RequestParam(value = "year", defaultValue = "2024") int year,
                                               @RequestParam(value = "month", defaultValue = "03") int month,
                                               @RequestParam(value = "day", defaultValue = "25") int day) {

        Page<FastbullNews> page = new Page<>(pageNum, pageSize);

        String dateStr = String.format("%s-%02d-%02d",year,month,day);
        LambdaQueryWrapper<FastbullNews> lamqw = Wrappers.lambdaQuery();
        lamqw.eq(FastbullNews::getDateStr,dateStr);
        Page<FastbullNews> pages = fastbullNewsService.page(page, lamqw);
        List<FastbullNews> records = pages.getRecords();
        Collections.shuffle(records);
        return ServerResponse.createBySuccess(records);
    }

    /**
     * 采集新闻接口
     * @return
     */
    @RequestMapping({"news.do"})
    @ResponseBody
    public String initNews() {
        List<Date> dates = new ArrayList<>();
        // 获取当前日期
        Date currentDate = new Date();

        // 计算本周的开始时间和结束时间
        Date weekStartTime = DateUtil.beginOfWeek(currentDate);
        Date weekEndTime = DateUtil.endOfWeek(currentDate);
        Date currentDay = new Date(weekStartTime.getTime());

        while (currentDay.compareTo(weekEndTime) <= 0) {
            dates.add(new Date(currentDay.getTime()));
            currentDay.setDate(currentDay.getDate() + 1);
        }

        // 打印日期列表
        for (Date date : dates) {
            //当天开始时间
            long startTime = date.getTime();
            //当天结束时间  23:59:59
            Date endDate = DateUtil.endOfDay(date);
            long endTime = endDate.getTime();
            String dateStr = DateUtil.format(date, "yyyy-MM-dd");

            String types = "1,2,3";
            // 构建请求参数字符串
            String params = String.format("startTimestamp=%s&endTimestamp=%s&types=%s", startTime, endTime, types);
            // 发送 GET 请求
            String result = HttpUtil.get(Const.NEWS_URL + "?" + params);
            JSONObject jsonObject = JSON.parseObject(result).getJSONObject("bodyMessage");
            //获取新闻列表
            JSONArray mergeList = jsonObject.getJSONArray("mergeList");
            for (int i = 0; i < mergeList.size(); i++) {
                JSONObject mergeInfo = mergeList.getJSONObject(i);
                JSONObject calenderEventModel = mergeInfo.getJSONObject("calenderEventModel");
                if(Objects.isNull(calenderEventModel)){
                    continue;
                }
                FastbullNews eventModel = JSON.parseObject(calenderEventModel.toJSONString(), FastbullNews.class);
                eventModel.setDateStr(dateStr);
                //查询是否已存在数据
                Long count = fastbullNewsService.lambdaQuery().eq(FastbullNews::getReleasedDate, eventModel.getReleasedDate()).count();
                if(count.intValue() > 0){
                    continue;
                }
                fastbullNewsService.save(eventModel);
            }
        }
        return "ok";
    }

    /**
     * 马来，泰国，印度 k线接口
     * @param
     * @return
     */
    @RequestMapping({"kline"})
    @ResponseBody
    public StockKline kline(
            @RequestParam("beg") String beg,
            @RequestParam("klt") String klt,
            @RequestParam("secid") String secid) {
        return stockKlineManager.inv2stock(secid,beg,klt);
    }

    //采集股票数据
    @RequestMapping({"collect"})
    @ResponseBody
    public String collect(@RequestParam("type") String type) {
        //构建s参数的key
        String key = "asdehwenfdsnfnsfdojiojfonojfoajawjefosjfdsj";

        String urlForm = "https://pi.exgco.com/api/stock/getStock.do?pageNum=%s&pageSize=15&stockType=%s&keyWords=&s=%s";

        int pageNum = 419;
        while(true) {
            String s = pageNum + "15" + type + key;
            String sMd5 = DigestUtil.md5Hex(s);

            String url = String.format(urlForm, pageNum, type, sMd5);

            String body = HttpRequest.get(url)
                    .setHttpProxy("127.0.0.1",7890)
                    .header("Origin", "https://a.exgco.com")
                    .header("Pragma", "no-cache")
                    .header("Referer", "https://a.exgco.com/")
                    .header("Sec-Fetch-Dest", "empty")
                    .header("Sec-Fetch-Mode", "cors")
                    .header("Sec-Fetch-Site", "same-site")
                    .header("User-Agent", "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1")
                    .execute().body();

            JSONObject resultJs = JSON.parseObject(body).getJSONObject("data");

            //股票数据
            JSONArray list = resultJs.getJSONArray("list");
            if(CollUtil.isEmpty(list)){
                break;
            }

            for (int i = 0; i < list.size(); i++) {
                JSONObject stockInfo = list.getJSONObject(i);
                Stock stock = JSON.parseObject(stockInfo.toJSONString(), Stock.class);
                String spell = StrUtil.removeAll(stock.getStockName().toLowerCase(), " ");
                stock.setStockSpell(spell);
                stock.setStockType(type);
                stock.setIsLock(0);
                stock.setIsShow(0);
                stock.setSpreadRate(new BigDecimal("0"));
                stock.setDataBase(0);
                stockMapper.insert1(stock);
            }

            System.out.println("数据写入成功:" + list.size() + "/正在采集页数:" + pageNum);

            pageNum++;

            ThreadUtil.sleep(2000);
        }

        return "采集完成";
    }

    //查询 股票指数、大盘指数信息
    @RequestMapping({"getMarket.do"})
    @ResponseBody
    public ServerResponse getMarket() {
        return this.iStockService.getMarket();
    }

    //查询官网PC端交易 所有股票信息及指定股票信息
    @RequestMapping({"getStock.do"})
    @ResponseBody
    public ServerResponse getStock(@RequestParam(value = "pageNum", defaultValue = "1") int pageNum, @RequestParam(value = "pageSize", defaultValue = "10") int pageSize, @RequestParam(value = "stockPlate", required = false) String stockPlate, @RequestParam(value = "stockType", required = false) String stockType, @RequestParam(value = "keyWords", required = false) String keyWords, HttpServletRequest request) {
        return this.iStockService.getStock(pageNum, pageSize, keyWords, stockPlate, stockType, request);
    }

    //通过股票代码查询股票信息
    @RequestMapping({"getSingleStock.do"})
    @ResponseBody
    public ServerResponse getSingleStock(@RequestParam("code") String code, HttpServletRequest request) {
        return this.iStockService.getSingleStock(code, request);
    }
    //美股股票代码查询股票信息
    @RequestMapping({"getSingleStockByCode.do"})
    @ResponseBody
    public ServerResponse getSingleStockByCode(@RequestParam("code") String code, @RequestParam("stockType") String stockType) {
        return this.iStockService.getSingleStockByCode(code,stockType);
    }

    @RequestMapping({"getMinK.do"})
    @ResponseBody
    public ServerResponse getMinK(@RequestParam("code") String code, @RequestParam("time") Integer time, @RequestParam("ma") Integer ma, @RequestParam("size") Integer size) {
        return this.iStockService.getMinK(code, time, ma, size);
    }

    /*查询股票日线*/
    @RequestMapping({"getDayK.do"})
    @ResponseBody
    public ServerResponse getDayK(@RequestParam("code") String code) {
        return this.iStockService.getDayK_Echarts(code);
    }

    //查询股票历史数据数据
    @RequestMapping({"getMinK_Echarts.do"})
    @ResponseBody
    public ServerResponse getMinK_Echarts(@RequestParam("code") String code, @RequestParam("time") Integer time, @RequestParam("ma") Integer ma, @RequestParam("size") Integer size) {
        return this.iStockService.getMinK_Echarts(code, time, ma, size);
    }

    /*期货分时-k线*/
    @RequestMapping({"getFuturesMinK_Echarts.do"})
    @ResponseBody
    public ServerResponse getFuturesMinK_Echarts(@RequestParam("code") String code, @RequestParam("time") Integer time, @RequestParam("size") Integer size) {
        return this.iStockService.getFuturesMinK_Echarts(code, time, size);
    }

    /*指数分时-k线*/
    @RequestMapping({"getIndexMinK_Echarts.do"})
    @ResponseBody
    public ServerResponse getIndexMinK_Echarts(@RequestParam("code") String code, @RequestParam("time") Integer time, @RequestParam("size") Integer size) {
        return this.iStockService.getIndexMinK_Echarts(code, time, size);
    }

    /*查询期货日线*/
    @RequestMapping({"getFuturesDayK.do"})
    @ResponseBody
    public ServerResponse getFuturesDayK(@RequestParam("code") String code) {
        return this.iStockService.getFuturesDayK(code);
    }

    /*指数日线*/
    @RequestMapping({"getIndexDayK.do"})
    @ResponseBody
    public ServerResponse getIndexDayK(@RequestParam("code") String code) {
        return this.iStockService.getIndexDayK(code);
    }
//    //查询股票需要换数据源的股票
//    @RequestMapping({"stockDataBase.do"})
//    @ResponseBody
//    public ServerResponse stockDataBase() {
//        return this.iStockService.stockDataBase();
//    }
}
