package com.nq.dao;

import com.nq.common.servlet.BaseMapper;
import com.nq.pojo.Coins;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ICoinsMapper extends BaseMapper<Coins> {
}
