package com.nq.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class Stock {

    private String code;
    private int decimal;
    private int dktotal;
    private List<String> klines;
    private int market;
    private String name;
    private double preKPrice;
    private double prePrice;
    private int qtMiscType;

}
