package com.nq.pojo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserBank {

    private int id;
    private int userId;
    private String bankName;
    private String bankNo;
    private String bankAddress;
    private String bankImg;
    private String bankPhone;
    private Date addTime;
    private String bankType;
    private String marketType;
    private String accountName;
    private String currencyName;
    private String networkType;
    private String usdtAddress;

    public UserBank(Integer id, Integer userId, String bankName, String bankNo, String bankAddress, String bankImg, String bankPhone, Date addTime, String bankType, String marketType, String accountName, String currencyName, String networkType, String usdtAddress) {
        this.id = id;
        this.userId = userId;
        this.bankName = bankName;
        this.bankNo = bankNo;
        this.bankAddress = bankAddress;
        this.bankImg = bankImg;
        this.bankPhone = bankPhone;
        this.addTime = addTime;
        this.bankType = bankType;
        this.marketType = marketType;
        this.accountName = accountName;
        this.currencyName = currencyName;
        this.networkType = networkType;
        this.usdtAddress = usdtAddress;
    }

}
