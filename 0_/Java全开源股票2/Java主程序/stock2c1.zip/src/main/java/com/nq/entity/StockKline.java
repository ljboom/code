package com.nq.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * k 数据返回
 */
@NoArgsConstructor
@Data
public class StockKline {
    private Stock data;
    private String dlmkts;
    private int full;
    private int lt;
    private int rc;
    private int rt;
    private long svr;
}
