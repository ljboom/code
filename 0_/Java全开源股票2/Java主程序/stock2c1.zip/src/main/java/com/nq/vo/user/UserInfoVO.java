package com.nq.vo.user;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@NoArgsConstructor
@Data
public class UserInfoVO {
    private Integer id;
    private Integer agentId;
    private String agentName;
    private String phone;
    private String nickName;
    private String realName;
    private String idCard;
    private Integer accountType;
    private String recomPhone;
    private Integer isLock;
    private Date regTime;
    private String regIp;
    private String regAddress;
    private String img1Key;
    private String img2Key;
    private Integer status;
    private Object msg;
    private Boolean success;
    private String img3Key;
    private Integer isActive;
    private String authMsg;
    private BigDecimal userAmt;
    private BigDecimal enableAmt;
    private BigDecimal userIndexAmt;
    private BigDecimal enableIndexAmt;
    private BigDecimal userFuturesAmt;
    private BigDecimal enableFuturesAmt;
    private BigDecimal allProfitAndLose;
    private BigDecimal allFreezAmt;
    private BigDecimal allIndexProfitAndLose;
    private BigDecimal allIndexFreezAmt;
    private BigDecimal allFuturesProfitAndLose;
    private BigDecimal allFuturesFreezAmt;
    /**
     * 杠杆倍数,多个用/分割
     */
    private String siteLever;

    /*操盘金额*/
    private BigDecimal tradingAmount;

    /**
     *
     * 新股冻结资金
     */
    private BigDecimal djzj;

    private BigDecimal usUserAmt;
    private BigDecimal usEnableAmt;
    private BigDecimal hkUserAmt;
    private BigDecimal hkEnableAmt;
    private BigDecimal myUserAmt;
    private BigDecimal myEnableAmt;
    private BigDecimal thUserAmt;
    private BigDecimal thEnableAmt;
    private BigDecimal phUserAmt;
    private BigDecimal phEnableAmt;
    private BigDecimal idUserAmt;
    private BigDecimal idEnableAmt;
    private BigDecimal inUserAmt;
    private BigDecimal inEnableAmt;
    private BigDecimal krUserAmt;
    private BigDecimal krEnableAmt;
    private BigDecimal jpUserAmt;
    private BigDecimal jpEnableAmt;
    private BigDecimal userIndexAmtX;
    private BigDecimal enableIndexAmtX;
    private BigDecimal userFutAmt;
    private BigDecimal enableFutAmt;
    private BigDecimal allProfitAndLoseX;
    private BigDecimal allFreezAmtX;
    private BigDecimal usProfitAndLose;
    private BigDecimal usFreezAmt;
    private BigDecimal hkProfitAndLose;
    private BigDecimal hkFreezAmt;
    private BigDecimal myProfitAndLose;
    private BigDecimal myFreezAmt;
    private BigDecimal thProfitAndLose;
    private BigDecimal thFreezAmt;
    private BigDecimal phProfitAndLose;
    private BigDecimal phFreezAmt;
    private BigDecimal idProfitAndLose;
    private BigDecimal idFreezAmt;
    private BigDecimal inProfitAndLose;
    private BigDecimal inFreezAmt;
    private BigDecimal krProfitAndLose;
    private BigDecimal krFreezAmt;
    private BigDecimal jpProfitAndLose;
    private BigDecimal jpFreezAmt;
}

