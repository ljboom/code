package com.nq.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.beans.ConstructorProperties;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SitePay {
    private Integer id;
    private Integer cType;
    private String formUrl;
    private String formCode;
    private String channelType;
    private String channelName;

    private String channelDesc;
    private String channelAccount;
    private String channelImg;
    private Integer channelMinLimit;
    private Integer channelMaxLimit;
    private Integer isShow;
    private Integer isLock;
    /*累计充值金额*/
    private BigDecimal totalPrice;

    private String bankUser;
    private String bankAccount;
    private String bankName;
    private String bankBranch;
    private String bankCode;

    public SitePay(Integer id, Integer cType, String formUrl, String formCode, String channelType, String channelName,
                   String bankName, String bankCode, String bankBranch, String bankUser, String bankAccount,
                   String channelDesc, String channelAccount, String channelImg, Integer channelMinLimit,
                   Integer channelMaxLimit, Integer isShow, Integer isLock, BigDecimal totalPrice) {
        this.id = id;
        this.cType = cType;
        this.formUrl = formUrl;
        this.formCode = formCode;
        this.channelType = channelType;
        this.channelName = channelName;
        this.bankName = bankName;
        this.bankCode = bankCode;
        this.bankBranch = bankBranch;
        this.bankUser = bankUser;
        this.bankAccount = bankAccount;
        this.channelDesc = channelDesc;
        this.channelAccount = channelAccount;
        this.channelImg = channelImg;
        this.channelMinLimit = channelMinLimit;
        this.channelMaxLimit = channelMaxLimit;
        this.isShow = isShow;
        this.isLock = isLock;
        this.totalPrice = totalPrice;
    }

}

