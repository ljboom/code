package com.nq;

import cn.hutool.core.date.DateUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DateTest {

    public static void main(String[] args) {

        List<Date> dates = new ArrayList<>();
        // 获取当前日期
        Date currentDate = new Date();

        // 计算本周的开始时间和结束时间
        Date weekStartTime = DateUtil.beginOfWeek(currentDate);
        Date weekEndTime = DateUtil.endOfWeek(currentDate);
        Date currentDay = new Date(weekStartTime.getTime());

        while (currentDay.compareTo(weekEndTime) <= 0) {
            dates.add(new Date(currentDay.getTime()));
            currentDay.setDate(currentDay.getDate() + 1);
        }

        // 打印日期列表
        for (Date date : dates) {
            //当天开始时间
            long startTime = date.getTime();
            //当天结束时间  23:59:59
            Date endDate = DateUtil.endOfDay(date);
            long endTime = endDate.getTime();
            String dateStr = DateUtil.format(date, "yyyy-MM-dd");

            System.out.println(dateStr + "=>" + startTime + "=>" + endTime);
        }


    }
}
