package com.nq.dao;

import com.nq.common.servlet.BaseMapper;
import com.nq.entity.FastbullNews;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface FastbullNewsMapper extends BaseMapper<FastbullNews> {
}
