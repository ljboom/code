package com.nq.service.impl;

import com.nq.common.servlet.BaseServiceImpl;
import com.nq.dao.ICoinsMapper;
import com.nq.pojo.Coins;
import com.nq.service.ICoinsService;
import org.springframework.stereotype.Service;

@Service
public class ICoinsServiceImpl extends BaseServiceImpl<ICoinsMapper, Coins> implements ICoinsService {
}
