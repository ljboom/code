package com.nq.controller.backend;

import com.nq.common.ServerResponse;
import com.nq.pojo.Coins;
import com.nq.service.ICoinsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * 货币汇率设置
 */

@Controller
@RequestMapping({"/admin/coin1/"})
public class AdminSiteCoinController {

    @Autowired
    private ICoinsService coinsService;

    @RequestMapping({"list1.do"})
    @ResponseBody
    public ServerResponse list(@RequestParam(value = "pageNum", defaultValue = "1") int pageNum, @RequestParam(value = "pageSize", defaultValue = "10") int pageSize) {
        List<Coins> list = coinsService.list();
        return ServerResponse.createBySuccess(list);
    }

}
