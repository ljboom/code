package com.nq.common;

public class Const {
  public static final String CURRENT_USER = "currentUser";

  public static final String NEWS_URL = "https://api.fastbull.com/fastbull-news-service/api/getMergeCalendarPage";

  public static void main(String[] args) {}
}

