package com.nq.controller.backend;


import com.nq.common.ServerResponse;
import com.nq.dao.StockSubscribeMapper;
import com.nq.pojo.StockSubscribe;
import com.nq.pojo.UserStockSubscribe;
import com.nq.service.IStockSubscribeService;
import com.nq.service.IUserStockSubscribeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping({"/admin/subscribe/"})
public class AdminStockSubscribeController {
    private static final Logger log = LoggerFactory.getLogger(AdminStockSubscribeController.class);
    @Autowired
    IUserStockSubscribeService iUserStockSubscribeService;
    @Autowired
    IStockSubscribeService iStockSubscribeService;

    /**
     * 
     * @param pageNum
     * @param pageSize
     * @param request
     * @return
     */
    @RequestMapping({"list.do"})
    @ResponseBody
    public ServerResponse list(@RequestParam(value = "pageNum", defaultValue = "1") int pageNum, @RequestParam(value = "pageSize", defaultValue = "10") int pageSize,@RequestParam(value = "name", required = false) String name,@RequestParam(value = "code", required = false) String code,@RequestParam(value = "zt", required = false) Integer zt,@RequestParam(value = "isLock", required = false) Integer isLock,@RequestParam(value = "type", required = false) Integer type, HttpServletRequest request) {
        return this.iStockSubscribeService.list(pageNum, pageSize,name,code,zt,isLock,type,request);
    }
    /** 
    * @Description:  新增新股
    * @Param:  
    * @return:  
    * @Author: tf
    * @Date: 2022/10/25 
    */
    @RequestMapping({"add.do"})
    @ResponseBody
    public ServerResponse add(StockSubscribe model, HttpServletRequest request) {
        return this.iStockSubscribeService.add(model, request);

    }
    /**
    * @Description:  修改新股
    * @Param:
    * @return:
    * @Author: tf
    * @Date: 2022/10/25
    */
    @RequestMapping({"update.do"})
    @ResponseBody
    public ServerResponse update(StockSubscribe model, HttpServletRequest request) {
        return this.iStockSubscribeService.update(model, request);

    }
    /**
    * @Description:  删除新股
    * @Param:
    * @return:
    * @Author: tf
    * @Date: 2022/10/25
    */
    @RequestMapping({"del.do"})
    @ResponseBody
    public ServerResponse del(@RequestParam("id") Integer id, HttpServletRequest request) {
        return this.iStockSubscribeService.del(id, request);

    }

    //申购信息列表查询
    @RequestMapping({"getStockSubscribeList.do"})
    @ResponseBody
    public ServerResponse getStockSubscribeList(@RequestParam(value = "pageNum", defaultValue = "1") int pageNum, @RequestParam(value = "pageSize", defaultValue = "12") int pageSize, @RequestParam(value = "keyword", defaultValue = "") String keyword, HttpServletRequest request) {
        return this.iUserStockSubscribeService.getList(pageNum, pageSize, keyword, request);
    }


    //申购信息-添加 修改
    @RequestMapping({"saveStockSubscribe.do"})
    @ResponseBody
    public ServerResponse saveStockSubscribe(UserStockSubscribe model, HttpServletRequest request) {
        return this.iUserStockSubscribeService.save(model, request);
    }

//    //添加产品管理 股票信息
//    @RequestMapping({"add.do"})
//    @ResponseBody
//    public ServerResponse add(@RequestParam(value = "stockName", required = false) String stockName, @RequestParam(value = "stockCode", required = false) String stockCode, @RequestParam(value = "stockType", required = false) String stockType, @RequestParam(value = "stockPlate", required = false) String stockPlate, @RequestParam(value = "isLock", required = false) Integer isLock, @RequestParam(value = "isShow", required = false) Integer isShow) {
//        return this.iStockService.addStock(stockName, stockCode, stockType, stockPlate, isLock, isShow);
//    }


    //发送站内信
    @RequestMapping({"sendMsg.do"})
    @ResponseBody
    public ServerResponse sendMsg(UserStockSubscribe model, HttpServletRequest request) {
        return this.iUserStockSubscribeService.sendMsg(model, request);
    }
    //新股申购-删除
    @RequestMapping({"delStockSubscribe.do"})
    @ResponseBody
    public ServerResponse delStockSubscribe(@RequestParam("id") int id, HttpServletRequest request) {
        return this.iUserStockSubscribeService.del(id, request);
    }

    //大宗交易

}
