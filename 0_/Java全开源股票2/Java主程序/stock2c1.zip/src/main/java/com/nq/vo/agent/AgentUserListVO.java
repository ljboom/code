
package com.nq.vo.agent;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@NoArgsConstructor
@Data
public class AgentUserListVO {
    private Integer id;
    private Integer agentId;
    private String agentName;
    private String phone;

    private String realName;

    private String idCard;

    private Integer accountType;

    private Integer isLock;

    private Integer isLogin;

    private String regAddress;

    private Integer isActive;

    private String bankName;

    private String bankNo;

    private String bankAddress;

    private BigDecimal userAmt;
    private BigDecimal enableAmt;
    private BigDecimal forceLine;
    private BigDecimal allProfitAndLose;
    private BigDecimal allFreezAmt;
    private BigDecimal userIndexAmt;
    private BigDecimal enableIndexAmt;
    private BigDecimal indexForceLine;
    private BigDecimal allIndexFreezAmt;
    private BigDecimal allIndexProfitAndLose;
    private BigDecimal userFuturesAmt;
    private BigDecimal enableFuturesAmt;
    private BigDecimal futuresForceLine;
    private BigDecimal allFuturesFreezAmt;
    private BigDecimal allFuturesProfitAndLose;

    //多钱包
    private BigDecimal usUserAmt;
    private BigDecimal usEnableAmt;
    private BigDecimal hkUserAmt;
    private BigDecimal hkEnableAmt;
    private BigDecimal myUserAmt;
    private BigDecimal myEnableAmt;
    private BigDecimal thUserAmt;
    private BigDecimal thEnableAmt;
    private BigDecimal phUserAmt;
    private BigDecimal phEnableAmt;
    private BigDecimal idUserAmt;
    private BigDecimal idEnableAmt;
    private BigDecimal inUserAmt;
    private BigDecimal inEnableAmt;
    private BigDecimal krUserAmt;
    private BigDecimal krEnableAmt;
    private BigDecimal jpUserAmt;
    private BigDecimal jpEnableAmt;
    private BigDecimal userIndexAmtX;
    private BigDecimal enableIndexAmtX;
    private BigDecimal userFutAmt;
    private BigDecimal enableFutAmt;
    private BigDecimal allProfitAndLoseX;
    private BigDecimal allFreezAmtX;
    private BigDecimal usProfitAndLose;
    private BigDecimal usFreezAmt;
    private BigDecimal hkProfitAndLose;
    private BigDecimal hkFreezAmt;
    private BigDecimal myProfitAndLose;
    private BigDecimal myFreezAmt;
    private BigDecimal thProfitAndLose;
    private BigDecimal thFreezAmt;
    private BigDecimal phProfitAndLose;
    private BigDecimal phFreezAmt;
    private BigDecimal idProfitAndLose;
    private BigDecimal idFreezAmt;
    private BigDecimal inProfitAndLose;
    private BigDecimal inFreezAmt;
    private BigDecimal krProfitAndLose;
    private BigDecimal krFreezAmt;
    private BigDecimal jpProfitAndLose;
    private BigDecimal jpFreezAmt;

}
