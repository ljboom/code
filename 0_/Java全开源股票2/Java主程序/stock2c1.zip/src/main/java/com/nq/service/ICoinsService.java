package com.nq.service;

import com.nq.common.servlet.BaseService;
import com.nq.pojo.Coins;

public interface ICoinsService extends BaseService<Coins> {
}
