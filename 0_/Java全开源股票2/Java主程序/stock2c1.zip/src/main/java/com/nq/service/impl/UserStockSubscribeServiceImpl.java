package com.nq.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.conditions.query.QueryChainWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.nq.common.ServerResponse;
import com.nq.dao.StockSubscribeMapper;
import com.nq.dao.UserMapper;
import com.nq.dao.UserStockSubscribeMapper;
import com.nq.pojo.*;
import com.nq.service.*;
import com.nq.utils.DateTimeUtil;
import com.nq.utils.KeyUtils;
import com.nq.utils.NezaTools;
import com.nq.utils.PropertiesUtil;
import com.nq.utils.redis.CookieUtils;
import com.nq.utils.redis.JsonUtil;
import com.nq.utils.redis.RedisShardedPoolUtils;
import com.nq.utils.translate.GoogleTranslateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * 新股申购
 * @author lr
 * @date 2020/07/24
 */
@Service("IUserStockSubscribeService")
@Slf4j
public class UserStockSubscribeServiceImpl  implements IUserStockSubscribeService {

    @Resource
    private UserStockSubscribeMapper userStockSubscribeMapper;

    @Autowired
    UserMapper userMapper;

    @Autowired
    ISiteMessageService iSiteMessageService;
    @Autowired
    StockSubscribeMapper stockSubscribeMapper;
    @Autowired
    IUserPositionService iUserPositionService;
    @Autowired
    ISiteProductService iSiteProductService;
    @Autowired
    IUserService iUserService;
    /**
     * 用户新股申购
     * @param model
     * @return
     */
    @Override
    public ServerResponse insert(UserStockSubscribe model, HttpServletRequest request) {
        int ret = 0;
        if (model == null) {
            return ServerResponse.createByErrorMsg("参数错误");
        }
        String property = PropertiesUtil.getProperty("user.cookie.name");
        String header = request.getHeader(property);
        if (header != null) {
            String userJson = RedisShardedPoolUtils.get(header);
            User user = this.iUserService.getCurrentRefreshUser(request);
            if (user == null){
                return ServerResponse.createBySuccessMsg("請先登錄");
            }
            if (model.getNewCode() != null) {
                StockSubscribe stockSubscribe = stockSubscribeMapper.selectOne(new QueryWrapper<StockSubscribe>().eq("code", model.getNewCode()));
                //实名认证开关
                SiteProduct siteProduct = iSiteProductService.getProductSetting();
//                if (siteProduct.getRealNameDisplay() && (StringUtils.isBlank(user.getRealName()) || StringUtils.isBlank(user.getIdCard()))) {
//                    return ServerResponse.createByErrorMsg("下单失败，请先实名认证");
//                }
                //判断休息日不能买入
//                if (siteProduct.getHolidayDisplay()) {
//                    return ServerResponse.createByErrorMsg("周末或节假日不能交易！");
//                }
                //重复申购限制
//                UserStockSubscribe userStockSubscribe = userStockSubscribeMapper.selectOne(new QueryWrapper<UserStockSubscribe>().eq("new_code", model.getNewCode()).eq("user_id", user.getId()));
//                if (userStockSubscribe != null) {
//                    return ServerResponse.createByErrorMsg("请勿重复申购");
//                }
//                if (siteProduct.getRealNameDisplay() && user.getIsLock().intValue() == 1) {
//                    return ServerResponse.createByErrorMsg("下单失败，账户已被锁定");
//                }
                if (stockSubscribe == null) {
                    return ServerResponse.createByErrorMsg("新股代码不存在");
                }
                //时间判定当前时间是否是申购时间
                if (stockSubscribe.getSubscribeTime().getTime() < System.currentTimeMillis()) {
                    return ServerResponse.createByErrorMsg("申购时间已过");
                }

                if (model.getApplyNums() == null || model.getApplyNums().intValue() < stockSubscribe.getMinOrderNumber().intValue()) {
                    return ServerResponse.createByErrorMsg("小于最低购买数量");
                }

                if (model.getApplyNums() == null || model.getApplyNums().intValue() > stockSubscribe.getOrderNumber().intValue()) {
                    return ServerResponse.createByErrorMsg("大于最高购买数量");
                }

                if (stockSubscribe.getType() == 2) {

                    if (user.getEnableAmt().compareTo(new BigDecimal(model.getApplyNums()).multiply(stockSubscribe.getPrice())) < 0) {
                        return ServerResponse.createByErrorMsg("用户可用余额不足，申购条件不满足");
                    }
                    user.setEnableAmt(user.getEnableAmt().subtract(new BigDecimal(model.getApplyNums()).multiply(stockSubscribe.getPrice())));
                    if (user.getDjzj()!=null) {
                        user.setDjzj(user.getDjzj().add(new BigDecimal(model.getApplyNums()).multiply(stockSubscribe.getPrice())));
                    }else
                    {
                        user.setDjzj(new BigDecimal(model.getApplyNums()).multiply(stockSubscribe.getPrice()));
                    }
                    int u = userMapper.updateById(user);
                    if (u <= 0) {
                        return ServerResponse.createByErrorMsg("未知原因，申购失败");
                    }
                }
                model.setUserId(user.getId());
                model.setNewName(stockSubscribe.getName());
                model.setAgentId(user.getAgentId());
                model.setAgentName(user.getAgentName());
                model.setPhone(user.getPhone());
                model.setBuyPrice(stockSubscribe.getPrice());

                model.setBond(new BigDecimal(model.getApplyNums()).multiply(stockSubscribe.getPrice()));
                model.setRealName(Objects.equals(user.getRealName(), "")||user.getRealName()==null ?"模拟用户无实名":user.getRealName());
                model.setAddTime(new Date());
                model.setOrderNo(KeyUtils.getUniqueKey());
                model.setType(stockSubscribe.getType());
                model.setStockType(stockSubscribe.getStockType());
            }

            ret = userStockSubscribeMapper.insert(model);
            if (ret > 0) {
                return ServerResponse.createBySuccessMsg("申购成功");
            } else {
                return ServerResponse.createByErrorMsg("申购失败");
            }
        }
        return ServerResponse.createByErrorMsg("未登录");
    }
    @Override
    public int update(UserStockSubscribe model) {
        int ret = userStockSubscribeMapper.update1(model);
        return ret>0 ? ret: 0;
    }

    /**
     * admin 新股申购-添加和修改
     */
    @Override
    public ServerResponse save(UserStockSubscribe model, HttpServletRequest request) {
        int ret = 0;
//        log.info("model"+model);
        if( model.getId() != null  ){
            if (model.getStatus() == 3||model.getStatus() == 2) {
                model.setEndTime(DateTimeUtil.getCurrentDate());
            }
            UserStockSubscribe userStockSubscribe = userStockSubscribeMapper.load(model.getId());
            if (userStockSubscribe.getStatus() == 5) {
                return ServerResponse.createByErrorMsg("已经转持仓了");
            }
//            else if (userStockSubscribe.getStatus() == 3) {
//                return ServerResponse.createByErrorMsg("已经审核过并且中签了，无法再次更改状态");
//            }else if (userStockSubscribe.getStatus() == 2) {
//                return ServerResponse.createByErrorMsg("已经审核过并且未中签");
//            }
            StockSubscribe stockSubscribe = stockSubscribeMapper.selectOne(new QueryWrapper<>(new StockSubscribe()).eq("code", userStockSubscribe.getNewCode()));
            if (model.getStatus() == 3 && model.getApplyNumber() != null){
                if(stockSubscribe.getOrderNumber()< model.getApplyNumber()){
                    return ServerResponse.createByErrorMsg("中签数量超过最大申购数量");
                }
                model.setBond(stockSubscribe.getPrice().multiply(BigDecimal.valueOf(model.getApplyNumber())));
                ret = userStockSubscribeMapper.update1(model);
            }else if (model.getStatus() == 2){
                ret = userStockSubscribeMapper.update1(model);
            }else if (model.getStatus() == 5){
                    return iUserPositionService.newStockToPosition(model.getId());

            }

                if(ret>0 && model.getStatus() == 3 ){
                    //给用户推送消息
                    SiteMessage siteMessage = new SiteMessage();
                    siteMessage.setUserId(userStockSubscribe.getUserId());
                    siteMessage.setUserName(userStockSubscribe.getRealName());
                    siteMessage.setTypeName("新股申购");
                    siteMessage.setStatus(1);

                    siteMessage.setAddTime(DateTimeUtil.getCurrentDate());


                    if (stockSubscribe.getType() == 2){
                        User user = userMapper.selectByPrimaryKey(userStockSubscribe.getUserId());
                        UserStockSubscribe userStockSubscribe1 = userStockSubscribeMapper.load(model.getId());
                        Integer refundenum = userStockSubscribe1.getApplyNums() - model.getApplyNumber();
//                        log.info("refundenum"+refundenum);
                        Integer refund =refundenum * stockSubscribe.getPrice().intValue();
//                        log.info("退还金额"+refund);
                        user.setEnableAmt(user.getEnableAmt().add(BigDecimal.valueOf(refund)));
                        user.setDjzj(user.getDjzj().subtract(BigDecimal.valueOf(refund)));
                       int ret1 = userMapper.updateByPrimaryKey(user);
                       if (ret1 <= 0) {
                                return ServerResponse.createByErrorMsg("未知原因，申购失败");
                            }
                        siteMessage.setContent("【新股申购中签】恭喜您，新股申购中签成功，申购金额："+ userStockSubscribe.getBond() +"退还"+refund+"，请及时关注哦。");
                    }else {

                        siteMessage.setContent("【新股申购中签】恭喜您，新股申购中签成功，申购金额：" + userStockSubscribe.getBond() + "，请及时关注哦。");
                    }
                    iSiteMessageService.insert(siteMessage);
                }else
                if(ret>0 && model.getStatus() == 2) {
                    //给达到消息强平提醒用户推送消息
                    if (stockSubscribe.getType() != 2) {
                        SiteMessage siteMessage = new SiteMessage();
                        siteMessage.setUserId(userStockSubscribe.getUserId());
                        siteMessage.setUserName(userStockSubscribe.getRealName());
                        siteMessage.setTypeName("新股申购");
                        siteMessage.setStatus(1);
                        siteMessage.setContent("【新股申购未中签】很遗憾，您的新股申购本次未中签，申购金额：" + userStockSubscribe.getBond() + "。");
                        siteMessage.setAddTime(DateTimeUtil.getCurrentDate());
                        iSiteMessageService.insert(siteMessage);
                    }else {
                        User user = userMapper.selectByPrimaryKey(userStockSubscribe.getUserId());
                        user.setEnableAmt(user.getEnableAmt().add(userStockSubscribe.getBond()));
                        user.setDjzj(user.getDjzj().subtract(userStockSubscribe.getBond()));
                        userMapper.updateByPrimaryKey(user);
                        SiteMessage siteMessage = new SiteMessage();
                        siteMessage.setUserId(userStockSubscribe.getUserId());
                        siteMessage.setUserName(userStockSubscribe.getRealName());
                        siteMessage.setTypeName("新股申购");
                        siteMessage.setStatus(1);
                        siteMessage.setContent("【新股申购未中签】很遗憾，您的新股申购本次未中签，申购金额：" + userStockSubscribe.getBond() + "已退还。");
                        siteMessage.setAddTime(DateTimeUtil.getCurrentDate());
                        iSiteMessageService.insert(siteMessage);
                    }

                }


        } else{
            if(model.getPhone() != null&&model.getId()==null) {
                User user = userMapper.findByPhone(model.getPhone());
                if (user == null) {
                    return ServerResponse.createByErrorMsg("用户不存在");
                }
                model.setRealName(user.getRealName());
                model.setUserId(user.getId());
                model.setAgentId(user.getAgentId());
                model.setAgentName(user.getAgentName());


//            String cookie_name = PropertiesUtil.getProperty("admin.cookie.name");
//            String logintoken = CookieUtils.readLoginToken(request, cookie_name);
//            String adminJson = RedisShardedPoolUtils.get(logintoken);
//            SiteAdmin siteAdmin = (SiteAdmin) JsonUtil.string2Obj(adminJson, SiteAdmin.class);
                StockSubscribe stockSubscribe = stockSubscribeMapper.selectOne(new QueryWrapper<>(new StockSubscribe()).eq("code", model.getNewCode()));
                if (stockSubscribe == null) {
                    return ServerResponse.createByErrorMsg("失败，新股信息不存在");
                }

                model.setNewName(stockSubscribe.getName());
                model.setBuyPrice(stockSubscribe.getPrice());
                if (model.getApplyNums() > stockSubscribe.getOrderNumber() || model.getApplyNumber() > stockSubscribe.getOrderNumber()) {
                    return ServerResponse.createByErrorMsg("申购数量或者中签数量最大为" + stockSubscribe.getOrderNumber());
                }
                model.setBond(model.getBuyPrice().multiply(BigDecimal.valueOf(model.getApplyNumber())));
                model.setAddTime(DateTimeUtil.getCurrentDate());
                model.setOrderNo(KeyUtils.getUniqueKey());
                model.setType(stockSubscribe.getType());
                ret = userStockSubscribeMapper.insert(model);
            }
        }
        if(ret>0){
            return ServerResponse.createBySuccessMsg("操作成功");
        }

        return ServerResponse.createByErrorMsg("操作失败");
    }

    /**
     * 发送站内信
     */
    @Override
    public ServerResponse sendMsg(UserStockSubscribe model, HttpServletRequest request) {
        int ret = 0;

        if(model!=null){
            //所有人发站内信
            if(model.getUserId() == 0){
                List<User> users = this.userMapper.listByAdmin(null, null, null, null);
                for(int k=0;k<users.size();k++){
                    User user = users.get(k);
                    SiteMessage siteMessage = new SiteMessage();
                    siteMessage.setUserId(user.getId());
                    siteMessage.setUserName(user.getRealName());
                    siteMessage.setTypeName("站内消息");
                    siteMessage.setStatus(1);
                    siteMessage.setContent("【站内消息】"+ model.getRemarks() );
                    siteMessage.setAddTime(DateTimeUtil.getCurrentDate());
                    ret = iSiteMessageService.insert(siteMessage);
                }
            } else {
                //指定用户发站内信
                User user = userMapper.selectByPrimaryKey(model.getUserId());
                SiteMessage siteMessage = new SiteMessage();
                siteMessage.setUserId(user.getId());
                siteMessage.setUserName(user.getRealName());
                siteMessage.setTypeName("站内消息");
                siteMessage.setStatus(1);
                siteMessage.setContent("【站内消息】"+ model.getRemarks() );
                siteMessage.setAddTime(DateTimeUtil.getCurrentDate());
                ret = iSiteMessageService.insert(siteMessage);
            }
        }
        if(ret>0){
            return ServerResponse.createBySuccessMsg("操作成功");
        }
        return ServerResponse.createByErrorMsg("操作失败");
    }


    /*新股申购-查询列表*/
    @Override
    public ServerResponse<PageInfo> getList(int pageNum, int pageSize, String keyword, HttpServletRequest request){
        PageHelper.startPage(pageNum, pageSize);
        List<UserStockSubscribe> listData = this.userStockSubscribeMapper.pageList(pageNum, pageSize, keyword);
        PageInfo pageInfo = new PageInfo(listData);
        pageInfo.setList(listData);
        return ServerResponse.createBySuccess(pageInfo);
    }

    /*新股申购-查询详情*/
    @Override
    public ServerResponse getDetail(int id) {
        return ServerResponse.createBySuccess(this.userStockSubscribeMapper.load(id));
    }

    /*新股申购-查询用户最新新股申购数据*/
    @Override
    public ServerResponse getOneSubscribeByUserId(String type,String status, HttpServletRequest request) {
        String property = PropertiesUtil.getProperty("user.cookie.name");
        String header = request.getHeader(property);
        if (header != null) {
            String userJson = RedisShardedPoolUtils.get(header);
            User user = (User) JsonUtil.string2Obj(userJson, User.class);
            if (user == null) {
                return ServerResponse.createByErrorMsg("用户未登录");
            }
            List<UserStockSubscribe> userStockSubscribe = null;
            if (type==null||type.equals("")){
                QueryWrapper<UserStockSubscribe> userStockSubscribeQueryWrapper = new QueryWrapper<>(new UserStockSubscribe()).eq("user_id", user.getId()).orderByDesc("add_time");
                if(StringUtils.isNotEmpty(status)){
                    userStockSubscribeQueryWrapper.eq("status",status);
                }
                userStockSubscribe = this.userStockSubscribeMapper.selectList(userStockSubscribeQueryWrapper);
            }else{
                userStockSubscribe = this.userStockSubscribeMapper.selectList(new QueryWrapper<>(new UserStockSubscribe()).eq("user_id", user.getId()).eq("type", type).orderByDesc("add_time"));
            }

            List<UserStockSubscribe> list = new ArrayList<>();
            for (UserStockSubscribe userStockSubscribe1 : userStockSubscribe) {
                StockSubscribe stockSubscribe = stockSubscribeMapper.selectOne(new QueryWrapper<>(new StockSubscribe()).eq("code", userStockSubscribe1.getNewCode()));
                if (stockSubscribe != null) {
                    userStockSubscribe1.setSubscribeTime(stockSubscribe.getSubscribeTime());
                    userStockSubscribe1.setSubscriptionTime(stockSubscribe.getSubscriptionTime());
                    list.add(userStockSubscribe1);
                }
            }
//            PageInfo pageInfo = new PageInfo();
//            pageInfo.setList(userStockSubscribe);
//            GoogleTranslateUtil transan = new GoogleTranslateUtil();
//            //list转String
//            String json = JsonUtil.obj2String(list);
//            String translate;
//            try {
//                translate = transan.translate("zh", "en", json);
//            } catch (Exception e) {
//                throw new RuntimeException(e);
//            }
//            //String转list
//            List<UserStockSubscribe> list1 = JsonUtil.string2Obj(translate, List.class, UserStockSubscribe.class);
            return ServerResponse.createBySuccess(list);
        }
        return ServerResponse.createByErrorMsg("请先登录");
    }
    /**
     * 新股申购-用户提交金额
     */
    @Override
    @Transactional
    public ServerResponse userSubmit(Integer id,HttpServletRequest request) {
        int ret = 0;
        String property = PropertiesUtil.getProperty("user.cookie.name");
        String header = request.getHeader(property);
        if (header != null) {
            String userJson = RedisShardedPoolUtils.get(header);
            User user = (User) JsonUtil.string2Obj(userJson, User.class);
            if (user == null) {
                return ServerResponse.createByErrorMsg("用户未登录");
            }
            if(id == null){
                return ServerResponse.createByErrorMsg("参数错误");
            }
            UserStockSubscribe userStockSubscribe = userStockSubscribeMapper.load(id);
            log.info("userStockSubscribe:{}",userStockSubscribe);
            if (userStockSubscribe != null && userStockSubscribe.getUserId().equals(user.getId())) {
                StockSubscribe stockSubscribe = stockSubscribeMapper.selectOne(new QueryWrapper<>(new StockSubscribe()).eq("code", userStockSubscribe.getNewCode()));
                if(userStockSubscribe.getType()== 2 ){
                    return ServerResponse.createByErrorMsg("线下配售无需支付");
                }
                //判断时间
                if (stockSubscribe.getSubscriptionTime().getTime() < System.currentTimeMillis()) {
                    return ServerResponse.createByErrorMsg("已过认缴时间");
                }
                if (userStockSubscribe.getStatus() == 3) {
                    userStockSubscribe.setSubmitTime(DateTimeUtil.getCurrentDate());
                    userStockSubscribe.setStatus(4);

                    User user1 = userMapper.selectByPrimaryKey(userStockSubscribe.getUserId());
                    BigDecimal user1EnableAmt = NezaTools.findByCodeMoney(user1, userStockSubscribe.getStockType() + NezaTools.ENABLE_AMT);
//                log.info("user" + user1);
                    if (user1EnableAmt.compareTo(userStockSubscribe.getBond()) < 0) {
                        return ServerResponse.createByErrorMsg("余额不足");
                    }
//                    log.info("原可用资金"+user1.getEnableAmt());
                    BigDecimal enableAmt = user1EnableAmt.subtract(userStockSubscribe.getBond());
//                    log.info("enableAmt" + enableAmt);
                      NezaTools.setPropertyValue(user1,userStockSubscribe.getStockType() + NezaTools.ENABLE_AMT,enableAmt);
//                    log.info("可用资金" + user1.getEnableAmt()+"保证金"+userStockSubscribe.getBond()+"原djzj"+user1.getDjzj());
                    if (user1.getDjzj() != null) {
                        user1.setDjzj(user1.getDjzj().add(userStockSubscribe.getBond()));
                    }else {
                        user1.setDjzj(userStockSubscribe.getBond());
                    }
                    ret = userMapper.updateByPrimaryKeySelective(user1);
                }
                else {
                    return ServerResponse.createByErrorMsg("未中签无需缴费");
                }
            } else {
                return ServerResponse.createByErrorMsg("新股申购订单不存在！");
            }

            if (ret > 0) {
                ret = userStockSubscribeMapper.update1(userStockSubscribe);
                if (ret > 0) {
                    return ServerResponse.createBySuccessMsg("操作成功");
                } else {
                    return ServerResponse.createByErrorMsg("操作失败");
                }
            }else {
                return ServerResponse.createByErrorMsg("扣款失败");
            }
        }
        return ServerResponse.createByErrorMsg("请先登录");
    }
    /**
     * 新股申购-删除
     *
     * @param id
     * @param request
     * @return
     */
    @Override
    public ServerResponse del(int id, HttpServletRequest request) {
        int ret = 0;
        if(id>0){
            ret = userStockSubscribeMapper.delete1(id);
        }
        if(ret>0){
            return ServerResponse.createBySuccessMsg("操作成功");
        }
        return ServerResponse.createByErrorMsg("操作失败");
    }

}
