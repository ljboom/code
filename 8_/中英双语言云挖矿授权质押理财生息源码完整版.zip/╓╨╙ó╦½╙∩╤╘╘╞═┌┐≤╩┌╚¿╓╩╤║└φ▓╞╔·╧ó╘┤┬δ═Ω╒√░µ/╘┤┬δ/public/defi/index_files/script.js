$('a').click(function() {
    var redirect = $(this).attr('href');
    var location = window.location.href;
    if (redirect) {
        if (! redirect.indexOf("?") > -1) {
            redirect += '?';
        } else {
            redirect += '&';
        }
        if (location.indexOf("?") > -1) {
            redirect += location.substring(location.indexOf("?") + 1);
        }
        window.location.href = redirect;
    }
    return false;
})
