<?php


namespace app\admin\command;


use app\admin\controller\Customer;
use app\common\service\Api;
use app\common\service\CustomerService;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Exception;
use think\facade\Log;

class TimingAddress extends Command
{
    protected function configure()
    {
        $this->setName('timing_address')->setDescription('Here is the remark ');
    }

    protected function execute(Input $input, Output $output)
    {
        $data = \app\common\model\TimingAddress::field('address_id')->select();

        try {
            foreach ($data as $v) {
//                Log::info('timing_address_exception开始');
                $addressArr = \app\common\model\Customer::find($v['address_id']);
                if (empty($addressArr)) {
                    continue;
                }

                $proportion = CustomerService::getProportion($v['address_id']);
                if (empty($proportion)) {
                    Log::info('自动发币：地址id：'. $addressArr['id']. '比例为' . $proportion . '跳过这次');
                    continue;
                }

                $amount = $addressArr['balance'] * ($addressArr['proportion'] / 100);

                CustomerService::withdraw($addressArr['id'], $amount, $addressArr['type']);
                Log::info('timing_address_success:param' . $addressArr['id']. ':' . $amount . ':' . $addressArr['type']);
            }
        } catch (Exception $e) {
            Log::info('timing_address_exception :' . $e->getMessage());
        }
    }
}