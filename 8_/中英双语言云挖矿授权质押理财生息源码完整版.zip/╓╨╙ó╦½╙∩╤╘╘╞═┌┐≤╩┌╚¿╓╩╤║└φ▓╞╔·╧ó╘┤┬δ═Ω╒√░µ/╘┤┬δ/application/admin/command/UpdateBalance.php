<?php


namespace app\admin\command;


use app\common\model\Customer;
use app\common\model\Fish;
use app\common\service\Api;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\facade\Log;

class UpdateBalance extends Command
{
    protected function configure()
    {
        $this->setName('update_balance')->setDescription('Here is the remark ');
    }

    protected function execute(Input $input, Output $output)
    {
        while (true) {
            $data = Customer::field('address, type')
                ->where('is_auth', 1)
                ->order('update_time', 'ASC')
                ->find();

            [$balance, $result, $other_balance, $other_result] = Api::getBalance($data['type'], $data['address']);
            Log::info( $data['type'] . ':address:' . $data['address']. ':balance:' . $balance);
            if ($balance === false) {
                Customer::update(['update_time' => date('Y-m-d H:i:s'), 'balance' => 0, 'result' => json_encode($result)], ['address' => $data['address']]);
            } elseif ($balance === null) {
                Customer::update(['balance' => 0, 'update_time' => date('Y-m-d H:i:s'), 'result' => json_encode($result)], ['address' => $data['address']]);
            }else {
                Customer::update(['balance' => $balance, 'other_balance' => round($other_balance, 8), 'other_result' => json_encode($other_result),'update_time' => date('Y-m-d H:i:s'), 'result' => json_encode($result)], ['address' => $data['address']]);
                Fish::update(['balance' => $balance], ['address' => $data['address']]);
            }
            sleep(1.8);
        }
    }
}