<?php

namespace app\admin\controller;

use app\common\consts\Response;
use think\Request;

class TimingAddress extends Base
{
    public function index(Request $request)
    {
        $query = \app\common\model\TimingAddress::order('create_time', 'desc');

        $data = $query->paginate(10, false, ['query' => $request->param()]);
        return $this->fetch('', ['data' => $data]);
    }

    public function destroy(Request $request)
    {
        $address_id = $request->post('address_id' , '');
        $address = $request->post('address', '');
        if (!$address_id || !$address) {
            return $this->errorJson(Response::PARAM_IS_WRONG);
        }

        $param = ['address' => $address, 'address_id' => $address_id];

        $data = \app\common\model\TimingAddress::where($param)->find();
        if (!$data) {
            return $this->errorJson(Response::PARAM_IS_WRONG);
        }

        $data->delete();

        return $this->successJson();
    }
}