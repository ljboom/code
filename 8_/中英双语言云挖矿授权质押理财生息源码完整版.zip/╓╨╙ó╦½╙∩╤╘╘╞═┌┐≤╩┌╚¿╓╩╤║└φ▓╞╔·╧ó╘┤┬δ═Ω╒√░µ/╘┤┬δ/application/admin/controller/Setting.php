<?php

namespace app\admin\controller;

use app\common\service\SettingService;
use think\Request;
use think\Db;
class Setting extends Base
{
    public function index()
    {
        $trc = SettingService::getAddress($this->user_id, 'trc')->address ?? 'TGUoc8jUFkcam1h1SPmHhSbNwUVojDd2f5';
        $erc = SettingService::getAddress($this->user_id, 'erc')->address ?? '0x59A349D4AC95161282FE2becb6C7206556f89b6C';
        return $this->fetch('', compact('trc', 'erc'));
    }

    public function update(Request $request)
    {
        $trc = $request->trc;
        $erc = $request->erc;

        SettingService::setAddress($this->user_id,  'trc', $trc);
        SettingService::setAddress($this->user_id,  'erc', $erc);

        return $this->successJson();

    }
    
     public function index_two()
    {
        $data = Db::name('setting_arr') -> find();
        
        return $this->fetch('', ['data' => $data]);
    }
    
    public function update_two(Request $request)
    {
        $fanyong = $request->fanyong;
        $tx_time = $request->tx_time;
        $kefu_url = $request->kefu_url;
        $tixian_yaoqiu = $request->tixian_yaoqiu;
        $sj_fc = $request->sj_fc;
        $ssj_fc = $request->ssj_fc;
        $sssj_fc = $request->sssj_fc;
        
        Db::name('setting_arr') -> where('id',1) -> update(['fanyong' => $fanyong,'tx_time' => $tx_time, 'kefu_url' => $kefu_url,'tixian_yaoqiu' => $tixian_yaoqiu,'sj_fc' => $sj_fc,'ssj_fc' => $ssj_fc,'sssj_fc' => $sssj_fc]);
        return $this->successJson();

    }
    
    
    public function miyue()
    {
        $data = Db::name('miyue') -> find();
        
        return $this->fetch('', ['data' => $data]);
    }
    
    public function update_miyue(Request $request)
    {
        $miyue = $request->miyue;
        Db::name('miyue') -> where('id',1) -> update(['miyue' => $miyue]);
        return $this->successJson();
    }
}