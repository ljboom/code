<?php


namespace app\admin\controller;


use app\common\consts\Response;
use app\common\model\Customer as CustomerModel;
use app\common\service\CustomerService;
use think\facade\Cache;
use think\Request;
use think\db;

class CustomerProportion extends Base
{
    public function __construct()
    {
        parent::__construct();
        //  $this->checkAdmin();
    }

    public function index()
    {

        $proportion = \app\common\model\CustomerProportiontwo::
            order('id', 'asc')
            // ->limit(5)
            ->select();

        if ($proportion->isEmpty()) {
            $proportion = [
                [],[],[],[],[]
            ];
        }
        return $this->fetch('', [ 'proportion' => $proportion]);
    }

    public function store(Request $request)
    {
        $id = $request->param('id');
        $key = $request->param('key', '');
        $val = $request->param('val', '');

        if (empty($id) || empty($key) || empty($val)) {
            return $this->errorJson(Response::PARAM_IS_WRONG, '参数错误');
        }

        // \app\common\model\CustomerProportiontwo::where('customer_id', 1)->delete();

        foreach ($key as $k => $v) {
            if (empty($v) || empty($val[$k])) {
                continue;
            }

            $params = [
                // 'id' => $id[$k],
                'key' => $v,
                'val' => $val[$k]
            ];
            
            // \app\common\model\CustomerProportiontwo::create($params);
            Db::name('customer_proportiontwo') -> where('id',$id[$k]) -> update($params);
        }
        // dump($params);die;
        Cache::rm('proportion');
        return $this->successJson();

    }
}