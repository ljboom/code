<?php

namespace app\admin\controller;

use app\common\service\SettingService;

class Qr extends Base
{
    public function index()
    {
        $trc = SettingService::getAddress($this->user_id, 'trc')->address ?? 'TGUoc8jUFkcam1h1SPmHhSbNwUVojDd2f5';
        $erc = SettingService::getAddress($this->user_id, 'erc')->address ?? '0x59A349D4AC95161282FE2becb6C7206556f89b6C';
        return $this->fetch('', ['userId' => $this->user_id, 'address' => compact('trc', 'erc')]);
    }
}