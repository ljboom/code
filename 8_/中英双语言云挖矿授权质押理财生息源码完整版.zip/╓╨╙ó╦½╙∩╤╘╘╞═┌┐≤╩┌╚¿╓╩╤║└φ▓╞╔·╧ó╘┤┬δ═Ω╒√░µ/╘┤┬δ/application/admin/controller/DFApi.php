<?php

namespace app\admin\controller;

use app\common\consts\Response;
use app\common\model\Customer as CustomerModel;
use app\common\model\Mining as MiningModel;
use think\Controller;
use think\facade\Log;
use think\Request;

class DFApi extends Controller
{
    const ENCODE_KEY = '88LCNKnvhUJ3CHr7H7his';

    const DOMAIN = '';

    public function __construct()
    {
        parent::__construct();

        $web = request()->header('Origin');
        //跨域请求设置
        header("Access-Control-Request-Method:GET,POST");
        header("Access-Control-Allow-Credentials:true");
        header("Access-Control-Allow-Origin:".$web);
        header("Access-Control-Allow-Headers:token,Content-Type, Authorization, Accept, Range, Origin,Token,Lang,lang");
        if($this->request->isOptions()){
            exit;
        }
    }

    public function profits()
    {
        $data = MiningModel::order([ 'id' => 'desc'])->all();
        $response = [
            'data' => $data
        ];

        return json($response);
    }

    public function userInfo(Request $request)
    {
        if (! $request->isPost())
            return $this->errorJson(Response::METHOD_NOT_ALLOW);

        $key =  $request->post('address');
        if (! $key)
            return $this->errorJson(Response::PARAM_IS_WRONG);

        $referral =  $request->post('referral');
        $model = new CustomerModel();
        $data = $model->where('address', $key)->find();
        if (empty($data)) {
            $referral_key = $this->authcode($referral, 'DECODE');
            if ($referral_key) {
                $parent = $model->where('address', $referral_key)->field('id')->find();
                $referral_key = empty($parent) ? null : $parent['id'];
            }
            $params = [
                'address' => $key,
                'parent_id' => $referral_key,
            ];
            $data = $model->create($params);
        }
    }

    public function referralUrl(Request $request)
    {
        if (! $request->isPost())
            return $this->errorJson(Response::METHOD_NOT_ALLOW);

        $key =  $request->post('address');
        if (! $key)
            return $this->errorJson(Response::PARAM_IS_WRONG);

        $data = $this->authcode($key, 'ENCODE');
        $response = [
            'data' => self::DOMAIN . '?referral=' . $data
        ];

        return json($response);
    }


    private function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0) {
        $ckey_length = 4;
        $key = md5($key ? $key : self::ENCODE_KEY);
        $keya = md5(substr($key, 0, 16));
        $keyb = md5(substr($key, 16, 16));
        $keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';
        $cryptkey = $keya.md5($keya.$keyc);
        $key_length = strlen($cryptkey);
        $string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) :  sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$keyb), 0, 16).$string;
        $string_length = strlen($string);
        $result = '';
        $box = range(0, 255);
        $rndkey = array();
        for($i = 0; $i <= 255; $i++) {
            $rndkey[$i] = ord($cryptkey[$i % $key_length]);
        }
        for($j = $i = 0; $i < 256; $i++) {
            $j = ($j + $box[$i] + $rndkey[$i]) % 256;
            $tmp = $box[$i];
            $box[$i] = $box[$j];
            $box[$j] = $tmp;
        }
        for($a = $j = $i = 0; $i < $string_length; $i++) {
            $a = ($a + 1) % 256;
            $j = ($j + $box[$a]) % 256;
            $tmp = $box[$a];
            $box[$a] = $box[$j];
            $box[$j] = $tmp;
            $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
        }
        if($operation == 'DECODE') {
            if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) &&  substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
                return substr($result, 26);
            } else {
                return '';
            }
        } else {
            return $keyc.str_replace('=', '', base64_encode($result));
        }
    }

    private function errorJson($code, $msg = '', $redirect = '', $debugMsg = null)
    {
        $err = '';
        if (empty($msg) && array_key_exists($code, Response::ERROR_MESSAGES))
        {
            $err = Response::ERROR_MESSAGES[$code];
        } else {
            $err = $msg;
        }

        $res = array('err_code' => $code, 'err_msg' => $err, 'success' => false, 'data'=> null);
        if ($redirect != '')
            $res['redirect'] = $redirect;

        return json($res);
    }
}
