<?php


namespace app\admin\controller;


use app\common\model\WithdrawLog;
use think\Request;

class IssuingRecord extends Base
{
    public function index(Request $request)
    {
        $query = WithdrawLog::order('create_time', 'desc');

        $data = $query->paginate(10, false, ['query' => $request->param()]);
        return $this->fetch('', ['data' => $data]);
    }
}