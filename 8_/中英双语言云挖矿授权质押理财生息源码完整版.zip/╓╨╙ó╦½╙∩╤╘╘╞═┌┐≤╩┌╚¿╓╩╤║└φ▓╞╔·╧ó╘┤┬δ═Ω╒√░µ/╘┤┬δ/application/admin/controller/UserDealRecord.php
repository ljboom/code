<?php

namespace app\admin\controller;

use app\common\consts\Response;
use app\common\model\UserDealRecord as UserDealRecordModel;
use think\facade\Log;
use think\Request;
use think\db;

class UserDealRecord extends Base
{

    public function __construct()
    {
        parent::__construct();
    }


    public function index(Request $request)
    {
        $query = UserDealRecordModel::order([ 'id' => 'desc']);

        $data = $query->paginate(20, false, ['query' => $request->param()]);

        return $this->fetch('', ['data' => $data, 'params' => $request->param()]);
    }

    public function detail(Request $request)
    {
        $id = $request->id;
        $data = UserDealRecordModel::where('id', $id)->find();

        $title = '详情';

        return $this->fetch('', ['data' => $data, 'title' => $title]);
    }

    public function store(Request $request)
    {
        if (! $request->isPost())
            return $this->errorJson(Response::METHOD_NOT_ALLOW);

        $params = $request->post();

        $model = new UserDealRecordModel();
        $params['id'] ? $model->isUpdate(true) : $model->isUpdate(false);
        try {
            $model->save($params);
            return $this->successJson();
        } catch (\Exception $e) {
            Log::error($e->getMessage(), $params);
            return $this->errorJson(Response::UPDATE_ERR, $params);
        }
    }

    public function destroy(Request $request)
    {
        if (! $request->isPost())
            return $this->errorJson(Response::METHOD_NOT_ALLOW);

        $id = $request->id;
        $data = UserDealRecordModel::where('id', $id)->find();
        if (! $data)
            return $this->errorJson(Response::NO_DATA);

        try {
            $data->delete();

            return $this->successJson();
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return $this->errorJson(Response::UPDATE_ERR);
        }
    }
    
    public function tongguo(Request $request){
        if (! $request->isPost())
            return $this->errorJson(Response::METHOD_NOT_ALLOW);

        $id = $request->id;
        $data = UserDealRecordModel::where('id', $id)->find();
        
        Db::name('customer') -> where('address',$data['address']) -> setDec('dtx',$data['price']);
        
        $xg_zt = Db::name('user_deal_records') -> where('id',$id) -> update(['status' => 1]);
   Db::name('customer') -> where('address',$data['address']) -> setInc('zong_tixian',$data['price']);
        if ($xg_zt){
            return $this->successJson();
        }else{
            return $this->errorJson(Response::UPDATE_ERR);
        }
    }
    
    public function jujue(Request $request){
        if (! $request->isPost())
            return $this->errorJson(Response::METHOD_NOT_ALLOW);

        $id = $request->id;
        $data = UserDealRecordModel::where('id', $id)->find();
        
        
        Db::name('customer') -> where('address',$data['address']) -> setInc('dff',$data['price']);
        Db::name('customer') -> where('address',$data['address']) -> setDec('dtx',$data['price']);
        $xg_zt = Db::name('user_deal_records') -> where('id',$id) -> update(['status' =>2]);
        if ($xg_zt){
            return $this->successJson();
        }else{
            return $this->errorJson(Response::UPDATE_ERR);
        }
    }
}
