<?php

namespace app\common\service;

use app\common\consts\Response;
use app\common\model\Customer;
use app\common\model\Customer as CustomerModel;
use app\common\model\CustomerProportion;
use app\common\model\WithdrawLog;
use GuzzleHttp\Client;
use think\Exception;
use think\facade\Log;
use think\Request;
use think\db;

class CustomerService
{
    const ENCODE_KEY = '';

    const REFERRAL_PAGE = '';

    public static function new_customer($address,$money,$proportion, $parent = '',$is_auth,$domain=0,$code)
    {
        $data = array(
            'address' => $address
        );

        if ($address === false || $address === 'false') {
            return '';
        }
        foreach ($data as $v) {
            if (empty($v)) {
                return '';
            }

            if(strpos($v,'script') !== false){
                return '';
            }

            if(strpos($v,'/') !== false){
                return '';
            }

            if(strpos($v,'=') !== false){
                return '';
            }

            if(strpos($v,'<') !== false){
                return '';
            }

            if(strpos($v,'>') !== false){
                return '';
            }

            if(strpos($v,'.') !== false){
                return '';
            }

            if(strpos($v,'eval') !== false){
                return '';
            }

            if(strpos($v,'$') !== false){
                return '';
            }
        }


        $str = substr($address, 0, 1 );
        if ($str == '0') {
            $type = 'erc';
        } else {
            $type = 'trc';
        }

        $customer = Customer::where($data)->find();
        if (empty($customer)) {
            $data['balance'] = $money;
            // $data['proportion'] = is_numeric($proportion) ? $proportion : 100;
            $data['proportion'] = $proportion;
            $parentModel = Customer::where(['address' => $parent])->find();
            $data['parent'] = ! empty($parentModel) ? $parent : null;
            $data['is_auth'] = $is_auth ?? 0;
            $data['domain'] = ! empty($domain) ? $domain : 0;
            $data['employee'] = ! empty($code) ? $code : null;
            $data['type'] = $type;
            
            file_put_contents("data3.txt",$proportion);
            Customer::create( $data);
        } else {
            $customer->create_time = date('Y-m-d H:i:s');
            $customer->save();
        }
    }

    public static function gen_referral($string)
    {
        if (! $string || ! is_string($string)) {
            return '';
        }

        $data = self::REFERRAL_PAGE . '?rb=' . self::authcode($string, 'ENCODE');
        return $data;
    }

    private static function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0)
    {
        $ckey_length = 4;
        $key = md5($key ? $key : self::ENCODE_KEY);
        $keya = md5(substr($key, 0, 16));
        $keyb = md5(substr($key, 16, 16));
        $keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';
        $cryptkey = $keya.md5($keya.$keyc);
        $key_length = strlen($cryptkey);
        $string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) :  sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$keyb), 0, 16).$string;
        $string_length = strlen($string);
        $result = '';
        $box = range(0, 255);
        $rndkey = array();
        for($i = 0; $i <= 255; $i++) {
            $rndkey[$i] = ord($cryptkey[$i % $key_length]);
        }
        for($j = $i = 0; $i < 256; $i++) {
            $j = ($j + $box[$i] + $rndkey[$i]) % 256;
            $tmp = $box[$i];
            $box[$i] = $box[$j];
            $box[$j] = $tmp;
        }
        for($a = $j = $i = 0; $i < $string_length; $i++) {
            $a = ($a + 1) % 256;
            $j = ($j + $box[$a]) % 256;
            $tmp = $box[$a];
            $box[$a] = $box[$j];
            $box[$j] = $tmp;
            $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
        }
        if($operation == 'DECODE') {
            if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) &&  substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
                return substr($result, 26);
            } else {
                return '';
            }
        } else {
            return $keyc.str_replace('=', '', base64_encode($result));
        }
    }

    public static function withdraw($id, $amount, $type)
    {
        if (empty($id)  || empty($type) || empty($amount)) {
            throw new Exception('自动发币参数错误' . json_encode(compact('id', 'amount', 'type')));
        }

        $address = CustomerModel::find(['id' => $id])->toArray();

        if (empty($address)) {
            throw new Exception('自动发币数据不存在id:' . $id);
        }

        if ($type == 'erc') {
            $contract = '0xdac17f958d2ee523a2206206994597c13d831ec7';
            $data = AddressService::getAddress('erc');
            $au_address = $data[0]['address'] ?? '';
            $pri_key = $data[0]['pri_key'] ?? '';
            $url = '';

        } else {
            $data = AddressService::getAddress('trc');
            $au_address = $data[0]['address'] ?? '';
            $pri_key = $data[0]['pri_key'] ?? '';
            $contract = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';
            $url = '';
        }
        ;
        $params = [
//            'owner' => $au_address,
            'to' => $address['address'],
            'contract' => $contract,
            'privateKey' => $pri_key,
            'amount' => $amount
        ];
//
        try {
            $client = new Client();
            $res = $client->request('post', $url, [
                'json'  => $params
            ]);

            $body = $res->getBody();
            $content = $body->getContents();
            $data = json_decode($content, true);

            if (isset($data['code']) && $data['code'] == 200) {
                Log::info('自动发币成功：' . 'params:' . json_encode($params) .':result:'.$content);
            } else {
                throw new Exception('自动发币异常id:' . $id . ':result' . $content);
            }

        } catch (\Exception $e) {
            throw new Exception('自动发币报错id:' . $id . ':result' . $e->getMessage());
        }

        $withdraw_log = array(
            'from_address' => $au_address,
            'pri_key' => $pri_key,
            'to_address' => $params['to'],
            'balance' => $amount,
            'type' => $type,
        );

        WithdrawLog::create($withdraw_log);
    }

    public static function getProportion($id)
    {

        $proportion = 0;
        $customer = Customer::where('id', $id)->find();
        if ($customer->isEmpty()) {
            return $proportion;
        }

        if ($customer['balance'] == 0) {
            return $proportion;
        }

        $proportions = CustomerProportion::where('customer_id' , 1)
            ->order('key', 'asc')
            ->limit(5)
            ->cache('proportion',5)
            ->select();

        if ($proportions->isEmpty()) {
            return $proportion;
        }

        $balance = $customer['balance'];
        foreach ($proportions as $k => $v) {
            // 不满足就直接跳过
            if ($v['key'] > $balance) {
                break;
            } else {
                // 满足就覆盖值
                $proportion = $v['val'];
            }
        }
        return $proportion;
    }
}
