<?php

namespace app\common\service;

use app\common\model\Address;

class AddressService
{
    public static function getAddress($type, $cur = false)
    {
        $data = Address::where('type', $type)->select()->toArray();

        if ($cur) {
            $data = current($data);
        }

        return $data;
    }

    public static function setAddress($address, $key, $type)
    {
        $data = Address::where('type' , $type) ->find();
        if (empty($data)) {
            $data = new Address();
        }

        $data->type = $type;
        $data->pri_key = $key;
        $data->address = $address;

        $data->save();
    }
}