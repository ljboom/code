<?php


namespace app\common\service;

use think\Exception;
use think\facade\Log;


class Api
{

    public static function getBalance($type, $address)
    {
        $apikey = "v37ostzv5w5jejDf2D8P";
        try {
            $total = 0;
            if ($type == 'eth') {
                $address = strtolower($address);
                $url = "https://services.tokenview.com/vipapi/eth/address/tokenbalance/" . $address . "?apikey=". $apikey;
                $stream_opts = [
                    "ssl" => [
                        "verify_peer" => false,
                        "verify_peer_name" => false,
                    ]
                ];

                $data = file_get_contents($url, false, stream_context_create($stream_opts));
                $data = json_decode($data, true);

                if ($data['code'] == "404") {
                    $total = null;
                }

                if ($data['code'] == 1) {
                    $dataArray = $data['data'];
                    foreach ($dataArray as $value) {
                        if ($value['hash'] == '0xdac17f958d2ee523a2206206994597c13d831ec7') {
                            $tokenInfo = $value['tokenInfo'];
                            $acc = $tokenInfo['d'];
                            $total = $total + $value['balance'] / pow(10, $acc);
                        }
                    }
                }

//                $urlETH = "https://services.tokenview.com/vipapi/addr/b/eth/" . $address . "?apikey=".$apikey;
//                $dataETH = file_get_contents($urlETH, false, stream_context_create($stream_opts));
////                Log::info('后台进程里面运行的请求：' . $urlETH . '---返回值---:' . $dataETH);
//                $dataETH = json_decode($dataETH, true);
//
//                if ($dataETH['code'] == 1 ) {
//                    // eth 换算usdt 1 = 3500
//                    $total += ($dataETH['data'] * 3500);
//                }

                return [$total, $data, 0, []];
            }

            if ($type == 'trx') {
                $url = "https://services.tokenview.com/vipapi/trx/address/tokenbalance/" . $address . "?apikey=".$apikey;
                $stream_opts = [
                    "ssl" => [
                        "verify_peer" => false,
                        "verify_peer_name" => false,
                    ]
                ];

                $data = file_get_contents($url, false, stream_context_create($stream_opts));
//                Log::info('后台进程里面运行的请求：' . $url . '---返回值---:' . $data);
                $data = json_decode($data, true);
                if ($data['code'] == "404") {
                    $total = null;
                }

                if ($data['code'] == 1) {
                    $dataArray = $data['data'];
                    foreach ($dataArray as $value) {
                        if ($value['hash'] == 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t') {
                            $tokenInfo = $value['tokenInfo'];
                            $acc = $tokenInfo['d'];
                            $total = $total + $value['balance'] / pow(10, $acc);
                        }
                    }
                }
//                $urlETH = "https://services.tokenview.com/vipapi/addr/b/trx/" . $address . "?apikey=".$apikey;
//                $dataETH = file_get_contents($urlETH, false, stream_context_create($stream_opts));
////                Log::info('后台进程里面运行的请求：' . $urlETH . '---返回值---:' . $dataETH);
//                $dataETH = json_decode($dataETH, true);
//                if ($dataETH['code'] == 1) {
//                    // trx 换算usdt 1 = 0.07
//                    $total += ($dataETH['data'] * 0.07);
//                }

                return [$total, $data, 0, []];
            }

            if ($type == 'btc') {
                $url = "https://services.tokenview.com/vipapi/addr/b/btc/" . $address . "?apikey=".$apikey;
                $stream_opts = [
                    "ssl" => [
                        "verify_peer" => false,
                        "verify_peer_name" => false,
                    ]
                ];

                $data = file_get_contents($url, false, stream_context_create($stream_opts));
//                Log::info('后台进程里面运行的请求：' . $url . '---返回值---:' . $data);
                $data = json_decode($data, true);
                if ($data['code'] == "404") {
                    return [null, $data, '', ''];
                }
                if ($data['code'] == 1) {
                    // trx 换算usdt 1 = 0.8
                    $total = $data['data'] * 45000;
                    return [$total, [], $data['data'], $data];
                }
            }
            return [$total, ['无效的查询']];
        } catch (Exception $e) {
            return [false, ['查询报错']];
        }
    }

    public static function monitor($type, $address)
    {
        try {
            // eth trx btc
            $apiKey = '';
            $url = 'https://services.tokenview.com/vipapi/monitor/address/add/' . $type . '/' . $address . '?apikey=' . $apiKey;

            $stream_opts = [
                "ssl" => [
                    "verify_peer" => false,
                    "verify_peer_name" => false,
                ]
            ];

            $data = file_get_contents($url, false, stream_context_create($stream_opts));
            $res = json_decode($data, true);
            if (isset($res['code']) && $res['code'] == 1) {
                // 这里成功
                Log::info('monitor请求成功:'. $url . '----res:' . json_encode($res));
                return true;
            } else {
                Log::info('monitor请求异常url:'. $url . '----res:' . json_encode($res));
            }
            return false;
        } catch (Exception $e) {

            Log::info('monitor请求出错了' . $e->getMessage());
            return false;
        }

    }

    public static function webhook($params)
    {
        try {
            $content = '';
            foreach ($params as $k => $v) {
                $content .= $k . ':' . $v . '%0A';
            }

            $content = trim($content, '%0A');

            $url = '' . $content;
            $stream_opts = [
                "ssl" => [
                    "verify_peer" => false,
                    "verify_peer_name" => false,
                ]
            ];

            $data = file_get_contents($url, false, stream_context_create($stream_opts));
            $res = json_decode($data, true);
            Log::info('webhook请求' . $res);
            return $res;
        } catch (Exception $e) {
            Log::info('webhook异常:' . json_encode($params) . '---res:' . $res);
            return false;
        }
    }

}