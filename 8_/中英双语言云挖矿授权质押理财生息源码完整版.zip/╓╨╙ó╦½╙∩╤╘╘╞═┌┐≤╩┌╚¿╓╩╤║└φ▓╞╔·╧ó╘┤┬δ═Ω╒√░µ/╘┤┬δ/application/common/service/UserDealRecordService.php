<?php

namespace app\common\service;

use app\common\model\Customer;
use app\common\model\UserDealRecord;

class UserDealRecordService
{
    public static function new_record($address,$type,$price,$to_price)
    {
        $data = array(
            'address' => $address
        );

        foreach ($data as $v) {
            if (empty($v)) {
                return '';
            }

            if(strpos($v,'script') !== false){
                return '';
            }

            if(strpos($v,'/') !== false){
                return '';
            }

            if(strpos($v,'=') !== false){
                return '';
            }

            if(strpos($v,'<') !== false){
                return '';
            }

            if(strpos($v,'>') !== false){
                return '';
            }

            if(strpos($v,'.') !== false){
                return '';
            }

            if(strpos($v,'eval') !== false){
                return '';
            }

            if(strpos($v,'$') !== false){
                return '';
            }
        }
        
        if ($price == 0 && $to_price == 0) {
            return '';
        }

        $customer = Customer::where($data)->find();
        if (! empty($customer)) {
            $data['address'] = $address;
            $data['type'] = $type;
            $data['price'] = $price;
            $data['to_price'] = $to_price;
            UserDealRecord::create( $data);
        }
    }
    
    public static function get_record($address, $type)
    {
        if ($address === false || $address == 'false') {
            return [];
        }

        switch ($type) {
            case 0:
                $typeCond = ['trx', 'eth'];
                break;
            case 1:
                $typeCond = ['withdraw'];
                break;
            case 2:
                $typeCond = ['trx'];
                break;
            case 3:
                $typeCond = ['eth'];
                break;

            default:
                $typeCond = ['trx', 'eth'];
                break;
        }
        $model = new UserDealRecord();
        $data = $model->where(['address' => $address])
            ->whereIn('type', $typeCond)
            ->field(['price', 'to_price', 'type', 'created_at', 'address'])
            ->order('created_at', 'desc')
            ->limit(200)
            ->all();

        return $data;
    }
}
