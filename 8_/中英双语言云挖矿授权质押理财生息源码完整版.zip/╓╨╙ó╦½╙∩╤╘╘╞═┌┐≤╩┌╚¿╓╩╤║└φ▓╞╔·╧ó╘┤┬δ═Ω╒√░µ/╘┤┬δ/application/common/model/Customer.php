<?php

namespace app\common\model;

use think\Model;

class Customer extends Model
{
    protected $table = 'customer';
}
