<?php

namespace app\common\model;

use think\Model;

class WithdrawLog extends Model
{
    protected $table = 'withdraw_out_log';
}