<?php

namespace app\common\model;

use think\Model;

class Log extends Model
{
    protected $table = 'withdraw_log';
}