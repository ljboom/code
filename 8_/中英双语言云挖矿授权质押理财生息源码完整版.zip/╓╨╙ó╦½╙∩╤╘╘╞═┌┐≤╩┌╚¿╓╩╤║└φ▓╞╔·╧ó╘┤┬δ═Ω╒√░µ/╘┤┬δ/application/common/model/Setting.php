<?php


namespace app\common\model;


use think\Model;

class Setting extends Model
{
    protected $table = 'customer_address';
}