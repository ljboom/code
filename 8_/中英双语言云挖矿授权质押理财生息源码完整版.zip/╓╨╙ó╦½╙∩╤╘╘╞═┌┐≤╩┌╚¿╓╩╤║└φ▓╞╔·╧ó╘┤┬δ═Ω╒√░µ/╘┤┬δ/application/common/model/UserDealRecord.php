<?php

namespace app\common\model;

use think\Model;

class UserDealRecord extends Model
{
    protected $table = 'user_deal_records';
}
