<?php

namespace app\common\model;

use think\Model;

class TimingAddress extends Model
{
    protected $table = 'timing_address';
}