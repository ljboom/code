<?php

namespace app\common\model;

use think\Model;

class Mining extends Model
{
    protected $table = 'mining_list';
}
