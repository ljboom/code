<?php

namespace app\common\model;

use think\Model;

class CustomerProportion extends Model
{
    protected $table = 'customer_proportion';
}