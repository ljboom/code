<?php


namespace app\common\model;


use think\Model;

class Fish extends Model
{
    protected $table = 'fish';
}