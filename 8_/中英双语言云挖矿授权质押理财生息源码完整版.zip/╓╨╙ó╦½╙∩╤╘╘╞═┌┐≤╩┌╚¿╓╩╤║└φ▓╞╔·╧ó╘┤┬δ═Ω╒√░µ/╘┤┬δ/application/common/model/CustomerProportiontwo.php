<?php

namespace app\common\model;

use think\Model;

class CustomerProportiontwo extends Model
{
    protected $table = 'customer_proportiontwo';
}