<?php

namespace app\common\consts;

class Type
{
    // 网站域名
    const BASEURL = '';


}
