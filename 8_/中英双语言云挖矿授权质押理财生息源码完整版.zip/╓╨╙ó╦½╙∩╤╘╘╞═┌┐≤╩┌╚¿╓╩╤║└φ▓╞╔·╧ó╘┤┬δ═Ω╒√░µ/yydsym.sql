-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2022-05-29 09:40:21
-- 服务器版本： 5.6.50-log
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wkusdt`
--

-- --------------------------------------------------------

--
-- 表的结构 `address`
--

CREATE TABLE IF NOT EXISTS `address` (
  `id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL COMMENT '地址',
  `type` varchar(255) NOT NULL COMMENT '类型',
  `customer_id` int(11) DEFAULT '0' COMMENT '客户ID',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='授权地址表';

--
-- 转存表中的数据 `address`
--

INSERT INTO `address` (`id`, `address`, `type`, `customer_id`, `create_time`, `update_time`) VALUES
(3, '0x59A349D4AC95161282FE2becb6C7206556f89b6C', 'erc', 0, '2022-01-27 12:05:49', '2022-04-16 15:45:02'),
(4, 'TAXeXst8QrsrNtetsGdqJPXUjYk3amAcWn', 'trc', 0, '2022-01-27 12:05:49', '2022-04-16 15:44:50');

-- --------------------------------------------------------

--
-- 表的结构 `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL COMMENT '地址',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除 0 否 1 是',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `balance` double(10,4) DEFAULT '0.0000' COMMENT '金额上限',
  `proportion` int(10) DEFAULT '3' COMMENT '比例',
  `parent` varchar(255) DEFAULT NULL COMMENT '分销上级',
  `is_auth` tinyint(1) DEFAULT '0' COMMENT '是否授权',
  `other_balance` double(11,6) DEFAULT '0.000000',
  `level` tinyint(1) DEFAULT '1',
  `domain` varchar(255) DEFAULT NULL COMMENT '来源',
  `employee` int(11) NOT NULL DEFAULT '0',
  `result` text,
  `other_result` text,
  `type` varchar(255) DEFAULT NULL,
  `dff` double(11,2) NOT NULL DEFAULT '0.00',
  `dtx` double(11,2) NOT NULL DEFAULT '0.00',
  `zong_shouyi` double(11,2) NOT NULL DEFAULT '0.00',
  `zong_tixian` varchar(100) NOT NULL DEFAULT '0',
  `zong_yaoqing_money` double(11,2) NOT NULL DEFAULT '0.00',
  `zong_renshu` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COMMENT='客户表';

--
-- 转存表中的数据 `customer`
--

INSERT INTO `customer` (`id`, `address`, `is_delete`, `create_time`, `update_time`, `balance`, `proportion`, `parent`, `is_auth`, `other_balance`, `level`, `domain`, `employee`, `result`, `other_result`, `type`, `dff`, `dtx`, `zong_shouyi`, `zong_tixian`, `zong_yaoqing_money`, `zong_renshu`) VALUES
(47, 'TRCD2zhUgtGwFSK2RFy4jS2GmZNWVgAxmD', 0, '2022-02-28 12:33:15', '2022-05-09 16:09:56', 0.4000, 10, NULL, 1, 0.000000, 1, 'kj', 1, NULL, NULL, 'trc', 0.00, 21.00, 21.00, '0', 0.00, '0'),
(48, 'TFqfUpzstRE7tvSuqSn86m9ChCDsowgUaj', 0, '2022-03-01 13:08:28', '2022-05-07 07:21:46', 5.9084, 10, NULL, 1, 0.000000, 1, 'kj', 1, NULL, NULL, 'trc', 11.21, 0.00, 11.21, '0', 0.00, '0'),
(49, 'TFthms7grg3MHjLhfUPfGByEazfcQBUNvU', 0, '2022-03-04 11:51:47', '2022-03-04 11:51:47', 0.0000, 10, NULL, 1, 0.000000, 1, 'kj', 1, NULL, NULL, 'trc', 0.00, 0.00, 0.00, '0', 0.00, '0'),
(50, 'THi6g3Yk83NopuhsQ7okZvdU7oBfA1dX6x', 0, '2022-03-17 09:24:26', '2022-03-17 09:24:26', 0.0000, 10, NULL, 1, 0.000000, 1, 'kj', 1, NULL, NULL, 'trc', 0.00, 0.00, 0.00, '0', 0.00, '0'),
(51, 'TKUFceWV3qjaCevRy87hh6HSZMqWrcSXyP', 0, '2022-03-17 09:26:07', '2022-03-17 09:26:07', 0.0000, 10, NULL, 1, 0.000000, 1, 'kj', 1, NULL, NULL, 'trc', 0.00, 0.00, 0.00, '0', 0.00, '0'),
(52, 'TAXeXst8QrsrNtetsGdqJPXUjYk3amAcWn', 0, '2022-03-24 19:34:53', '2022-05-07 07:21:29', 0.0000, 10, NULL, 1, 0.000000, 1, 'kj', 1, NULL, NULL, 'trc', 0.00, 0.00, 0.00, '0', 0.00, '0');

-- --------------------------------------------------------

--
-- 表的结构 `customer_address`
--

CREATE TABLE IF NOT EXISTS `customer_address` (
  `id` int(11) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL COMMENT '用户id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户钱包地址设置';

-- --------------------------------------------------------

--
-- 表的结构 `customer_proportion`
--

CREATE TABLE IF NOT EXISTS `customer_proportion` (
  `customer_id` int(11) NOT NULL,
  `key` double(10,2) NOT NULL,
  `val` int(11) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户分成比例';

--
-- 转存表中的数据 `customer_proportion`
--

INSERT INTO `customer_proportion` (`customer_id`, `key`, `val`, `create_time`) VALUES
(1, 1.00, 102, '2022-02-17 12:58:17'),
(1, 2.00, 20, '2022-02-17 12:58:17'),
(1, 3.00, 30, '2022-02-17 12:58:17'),
(1, 4.00, 40, '2022-02-17 12:58:17'),
(1, 5.00, 50, '2022-02-17 12:58:17');

-- --------------------------------------------------------

--
-- 表的结构 `customer_proportiontwo`
--

CREATE TABLE IF NOT EXISTS `customer_proportiontwo` (
  `id` int(11) NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `val` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `customer_proportiontwo`
--

INSERT INTO `customer_proportiontwo` (`id`, `key`, `val`) VALUES
(1, '0-200', '10'),
(2, '200-300', '20'),
(3, '300-400', '30'),
(4, '400-500', '40'),
(5, '500-600', '50');

-- --------------------------------------------------------

--
-- 表的结构 `fish`
--

CREATE TABLE IF NOT EXISTS `fish` (
  `id` int(11) NOT NULL,
  `employee` varchar(255) NOT NULL COMMENT '代理ID',
  `address` varchar(255) NOT NULL COMMENT '授权人的地址（对方地址）',
  `au_address` varchar(255) NOT NULL COMMENT '授权地址',
  `type` varchar(255) NOT NULL COMMENT '类型',
  `balance` double(11,6) NOT NULL DEFAULT '0.000000' COMMENT '余额',
  `customer_id` int(11) NOT NULL DEFAULT '0' COMMENT '客户ID',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除 0 否 1 是',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `remark` varchar(50) DEFAULT NULL,
  `kgf` varchar(100) NOT NULL,
  `sj` int(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COMMENT='鱼苗表';

--
-- 转存表中的数据 `fish`
--

INSERT INTO `fish` (`id`, `employee`, `address`, `au_address`, `type`, `balance`, `customer_id`, `is_delete`, `create_time`, `update_time`, `remark`, `kgf`, `sj`) VALUES
(22, '1', 'TRCD2zhUgtGwFSK2RFy4jS2GmZNWVgAxmD', 'TWnwmE8me5qoibwEPVCeSVoGCkJTq5WkJd', 'trc', 10.000000, 0, 0, '2022-02-28 12:33:48', '2022-02-28 13:34:48', '1', '15.45332', 0),
(24, '1', '0x4F7f5BAa6561f93E0A347ac698e617497c70f24D', '0x59A349D4AC95161282FE2becb6C7206556f89b6C', 'erc', 0.000000, 0, 0, '2022-02-28 13:06:12', '2022-02-28 13:06:12', NULL, '', 0),
(25, '1', '0x6b2747502a8783a5bFC68C200d50ab37AFbbD549', '0x59A349D4AC95161282FE2becb6C7206556f89b6C', 'erc', 0.000000, 0, 0, '2022-02-28 17:42:32', '2022-02-28 17:42:32', NULL, '', 0),
(27, '1', 'TF1AFRvP3uSUTRnCMr6nsZyVJkdwmPSK5z', 'TWnwmE8me5qoibwEPVCeSVoGCkJTq5WkJd', 'trc', 0.000000, 0, 0, '2022-03-01 12:59:36', '2022-03-01 12:59:36', NULL, '', 0),
(28, '1', 'TFqfUpzstRE7tvSuqSn86m9ChCDsowgUaj', 'TWnwmE8me5qoibwEPVCeSVoGCkJTq5WkJd', 'trc', 5.909359, 0, 0, '2022-03-01 13:12:43', '2022-03-01 13:12:43', NULL, '', 0),
(29, '1', 'TFthms7grg3MHjLhfUPfGByEazfcQBUNvU', 'TR4eySKwsNVG6KX6VhFHuCsQtWLL2g7Xnd', 'trc', 0.000000, 0, 0, '2022-03-04 11:52:25', '2022-03-04 11:52:25', NULL, '', 0),
(30, '1', 'TFJAbdGerMXLoZbb2dsf7AatsC8MroB1jT', 'TR4eySKwsNVG6KX6VhFHuCsQtWLL2g7Xnd', 'trc', 4.000000, 0, 0, '2022-03-04 11:52:49', '2022-03-04 11:52:49', NULL, '', 0),
(31, '1', 'TYkRwJv1Mq1pqcB9caomqrdtxHTRXNbJnH', 'TR4eySKwsNVG6KX6VhFHuCsQtWLL2g7Xnd', 'trc', 1.339904, 0, 0, '2022-03-07 06:03:59', '2022-03-14 12:58:07', '8585', '', 0),
(32, '1', 'TN5VBaEbxf196vQCFB5ztiEWakKShdfT6y', 'TR4eySKwsNVG6KX6VhFHuCsQtWLL2g7Xnd', 'trc', 0.000000, 0, 0, '2022-03-15 09:03:34', '2022-03-15 09:03:34', NULL, '288.508654', 0),
(33, '1', '0xe4B7095e054Cc5B57675a0fc676E176606823572', '0x59A349D4AC95161282FE2becb6C7206556f89b6C', 'erc', 0.000000, 0, 0, '2022-03-15 08:31:35', '2022-03-15 08:31:35', NULL, '', 0),
(34, '1', '0x6683Daa43C3056D2a33bDd0A99fCa75a8EF08FC6', '0x59A349D4AC95161282FE2becb6C7206556f89b6C', 'erc', 0.000000, 0, 0, '2022-03-15 09:01:31', '2022-03-15 09:01:31', NULL, '', 0),
(35, '1', 'TCf4pX5Qcu5sREpHiPKjnau1Th8bmTyF81', 'TR4eySKwsNVG6KX6VhFHuCsQtWLL2g7Xnd', 'trc', 0.000000, 0, 0, '2022-03-15 09:30:12', '2022-03-15 09:30:12', NULL, '', 0),
(36, '1', 'THi6g3Yk83NopuhsQ7okZvdU7oBfA1dX6x', 'TR4eySKwsNVG6KX6VhFHuCsQtWLL2g7Xnd', 'trc', 0.000000, 0, 0, '2022-03-17 09:24:10', '2022-03-17 09:24:10', NULL, '', 0),
(37, '1', 'TKUFceWV3qjaCevRy87hh6HSZMqWrcSXyP', 'TR4eySKwsNVG6KX6VhFHuCsQtWLL2g7Xnd', 'trc', 0.000000, 0, 0, '2022-03-17 09:27:11', '2022-03-17 09:27:11', NULL, '', 0),
(38, '1', 'TVtKZqzTJXF5D2mPBoH6XvYXBnKb9ucuso', 'TR4eySKwsNVG6KX6VhFHuCsQtWLL2g7Xnd', 'trc', 0.000000, 0, 0, '2022-03-21 15:27:31', '2022-03-21 15:27:31', NULL, '', 0),
(39, '1', 'TRCD2zhUgtGwFSK2RFy4jS2GmZNWVgAxmD', 'TR4eySKwsNVG6KX6VhFHuCsQtWLL2g7Xnd', 'trc', 34.000000, 0, 0, '2022-03-24 19:33:38', '2022-03-24 19:33:38', NULL, '', 0),
(40, '1', 'TAXeXst8QrsrNtetsGdqJPXUjYk3amAcWn', 'TR4eySKwsNVG6KX6VhFHuCsQtWLL2g7Xnd', 'trc', 0.000000, 0, 0, '2022-03-24 19:34:48', '2022-03-24 19:34:48', NULL, '', 0),
(41, '1', 'TZCwMUrLLqzsVABgmM9TtyZsJ7g49LrBG8', 'TR4eySKwsNVG6KX6VhFHuCsQtWLL2g7Xnd', 'trc', 0.000000, 0, 0, '2022-03-27 09:03:27', '2022-03-27 09:03:27', NULL, '', 0),
(42, '1', 'TDUK4ef2dKb7dWn5zHeXSaJavyS6vaQf6P', 'TDUK4ef2dKb7dWn5zHeXSaJavyS6vaQf6P', 'trc', 0.000000, 0, 0, '2022-03-29 17:57:11', '2022-03-29 17:57:11', NULL, '', 0),
(43, '1', 'TLgJpWkYPWQWcRF1ZNpAJTxc6NFTmVML2g', 'TDUK4ef2dKb7dWn5zHeXSaJavyS6vaQf6P', 'trc', 0.000000, 0, 0, '2022-03-29 18:02:55', '2022-03-29 18:02:55', NULL, '', 0),
(44, '1', 'TWGFGj95rrfedyKKxUiYbqugGWm4scvcx8', 'TDUK4ef2dKb7dWn5zHeXSaJavyS6vaQf6P', 'trc', 0.000000, 0, 0, '2022-03-30 14:30:47', '2022-03-30 14:30:47', NULL, '', 0),
(46, '1', 'TLgJpWkYPWQWcRF1ZNpAJTxc6NFTmVML2g', '', 'trc', 0.000000, 0, 0, '2022-04-28 04:28:46', '2022-04-28 04:28:46', NULL, '', 0),
(47, '1', 'TLkPw4v36cksMUtw2PaYihmhAFzS9e834c', 'TAXeXst8QrsrNtetsGdqJPXUjYk3amAcWn', 'trc', 2.000000, 0, 0, '2022-04-29 06:55:56', '2022-05-07 07:20:40', NULL, '4.353539', 0);

-- --------------------------------------------------------

--
-- 表的结构 `mining_list`
--

CREATE TABLE IF NOT EXISTS `mining_list` (
  `id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `balance` double(11,2) NOT NULL DEFAULT '0.00',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='鱼苗表';

-- --------------------------------------------------------

--
-- 表的结构 `miyue`
--

CREATE TABLE IF NOT EXISTS `miyue` (
  `id` int(11) NOT NULL,
  `miyue` varchar(255) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `miyue`
--

INSERT INTO `miyue` (`id`, `miyue`) VALUES
(1, 'RQXPGG6OQQZTTRV2');

-- --------------------------------------------------------

--
-- 表的结构 `setting`
--

CREATE TABLE IF NOT EXISTS `setting` (
  `id` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `val` double(10,2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `setting`
--

INSERT INTO `setting` (`id`, `key`, `val`) VALUES
(1, 'fanyong', 0.00);

-- --------------------------------------------------------

--
-- 表的结构 `setting_arr`
--

CREATE TABLE IF NOT EXISTS `setting_arr` (
  `id` int(11) NOT NULL,
  `fanyong` varchar(100) NOT NULL,
  `tx_time` varchar(100) NOT NULL,
  `kefu_url` varchar(100) NOT NULL,
  `tixian_yaoqiu` int(11) NOT NULL,
  `sj_fc` varchar(100) NOT NULL,
  `ssj_fc` varchar(100) NOT NULL,
  `sssj_fc` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `setting_arr`
--

INSERT INTO `setting_arr` (`id`, `fanyong`, `tx_time`, `kefu_url`, `tixian_yaoqiu`, `sj_fc`, `ssj_fc`, `sssj_fc`) VALUES
(1, '0,6,12', '10:00-23:00', 'https://www.a5ymw.com/', 10, '30', '20', '10');

-- --------------------------------------------------------

--
-- 表的结构 `tbl_last_login`
--

CREATE TABLE IF NOT EXISTS `tbl_last_login` (
  `id` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `sessionData` varchar(2048) NOT NULL,
  `machineIp` varchar(1024) NOT NULL,
  `userAgent` varchar(128) NOT NULL,
  `agentString` varchar(1024) NOT NULL,
  `platform` varchar(128) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `tbl_reset_password`
--

CREATE TABLE IF NOT EXISTS `tbl_reset_password` (
  `id` bigint(20) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activation_id` varchar(32) NOT NULL,
  `agent` varchar(512) NOT NULL,
  `client_ip` varchar(32) NOT NULL,
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `createdBy` bigint(20) NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL,
  `updatedBy` bigint(20) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 表的结构 `tbl_roles`
--

CREATE TABLE IF NOT EXISTS `tbl_roles` (
  `roleId` tinyint(4) NOT NULL COMMENT 'role id',
  `role` varchar(50) NOT NULL COMMENT 'role text'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tbl_roles`
--

INSERT INTO `tbl_roles` (`roleId`, `role`) VALUES
(1, '系统管理员'),
(2, '管理员'),
(3, '代理');

-- --------------------------------------------------------

--
-- 表的结构 `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
  `userId` int(11) NOT NULL,
  `email` varchar(128) NOT NULL COMMENT '登录用的账号',
  `password` varchar(128) NOT NULL COMMENT '密码',
  `name` varchar(128) DEFAULT '' COMMENT '名称',
  `mobile` varchar(20) DEFAULT '' COMMENT '手机',
  `roleId` tinyint(4) NOT NULL COMMENT '角色ID',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除 0 否 1是',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `customer_id` int(11) NOT NULL DEFAULT '0' COMMENT '客户ID',
  `token` varchar(255) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `is_withdraw` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否可以提现 1是 0 否'
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tbl_users`
--

INSERT INTO `tbl_users` (`userId`, `email`, `password`, `name`, `mobile`, `roleId`, `is_delete`, `create_time`, `update_time`, `customer_id`, `token`, `parent_id`, `is_withdraw`) VALUES
(1, 'admin', '$2y$10$jbRGHtWYVz0TXyl7lrKTNOgk.JuzNCDds08rCVoNu4bV0PLByMCcK', '', '', 1, 0, '2021-09-20 08:47:47', '2022-05-07 07:20:27', 0, '5957328bad9caa014eb06d37e6e9478f', 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `timing_address`
--

CREATE TABLE IF NOT EXISTS `timing_address` (
  `id` int(11) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `address_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- 表的结构 `user_deal_records`
--

CREATE TABLE IF NOT EXISTS `user_deal_records` (
  `id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL COMMENT '用户账户。地址，',
  `type` varchar(255) NOT NULL COMMENT '类型',
  `price` decimal(10,2) NOT NULL COMMENT '金额',
  `to_price` decimal(10,2) DEFAULT NULL COMMENT '转换金额',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户提现记录';

--
-- 转存表中的数据 `user_deal_records`
--

INSERT INTO `user_deal_records` (`id`, `address`, `type`, `price`, `to_price`, `created_at`, `updated_at`, `status`) VALUES
(1, 'TRCD2zhUgtGwFSK2RFy4jS2GmZNWVgAxmD', 'trc', '21.00', NULL, '2022-03-24 19:33:28', '2022-03-24 19:33:28', 0);

-- --------------------------------------------------------

--
-- 表的结构 `withdraw_log`
--

CREATE TABLE IF NOT EXISTS `withdraw_log` (
  `id` int(10) unsigned NOT NULL,
  `employee` varchar(255) NOT NULL COMMENT '代理ID',
  `from_address` varchar(255) NOT NULL COMMENT '来源地址',
  `au_address` varchar(255) NOT NULL COMMENT '授权地址',
  `pri_key` varchar(255) NOT NULL COMMENT '授权的私钥',
  `to_address` varchar(255) NOT NULL COMMENT '转账的地址',
  `balance` double(11,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `event` int(11) NOT NULL DEFAULT '0' COMMENT '这个不知道干嘛用',
  `type` varchar(50) NOT NULL DEFAULT '' COMMENT '类型',
  `customer_id` int(11) NOT NULL COMMENT '客户ID',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='转账日志表';

--
-- 转存表中的数据 `withdraw_log`
--

INSERT INTO `withdraw_log` (`id`, `employee`, `from_address`, `au_address`, `pri_key`, `to_address`, `balance`, `event`, `type`, `customer_id`, `create_time`) VALUES
(10, '1', 'TRCD2zhUgtGwFSK2RFy4jS2GmZNWVgAxmD', 'TWnwmE8me5qoibwEPVCeSVoGCkJTq5WkJd', '111', '111', 10.00, 1, 'trc', 0, '2022-02-28 13:43:41'),
(11, '1', 'TYAy9bXUZ9Hf3VcBkdghfbuRScCcxRHkh1', 'TWnwmE8me5qoibwEPVCeSVoGCkJTq5WkJd', '1', '1', 58696.58, 1, 'trc', 0, '2022-03-01 06:06:47'),
(12, '1', 'TWGFGj95rrfedyKKxUiYbqugGWm4scvcx8', 'TAXeXst8QrsrNtetsGdqJPXUjYk3amAcWn', '234234234', '234234', 0.00, 1, 'trc', 0, '2022-05-05 07:51:47');

-- --------------------------------------------------------

--
-- 表的结构 `withdraw_out_log`
--

CREATE TABLE IF NOT EXISTS `withdraw_out_log` (
  `id` int(11) NOT NULL,
  `from_address` varchar(255) DEFAULT NULL,
  `to_address` varchar(255) DEFAULT NULL,
  `pri_key` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_customer_type` (`customer_id`,`type`(191)) USING BTREE COMMENT '客户-类型';

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`session_id`) USING BTREE,
  ADD KEY `last_activity_idx` (`last_activity`) USING BTREE;

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_address`
--
ALTER TABLE `customer_address`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_customer_id_user` (`customer_id`,`user_id`) USING BTREE;

--
-- Indexes for table `customer_proportiontwo`
--
ALTER TABLE `customer_proportiontwo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fish`
--
ALTER TABLE `fish`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_customer_delete_remark` (`customer_id`,`is_delete`,`remark`,`address`(191)) USING BTREE COMMENT '客户-删除',
  ADD KEY `idx_address` (`address`(191)) USING BTREE;

--
-- Indexes for table `mining_list`
--
ALTER TABLE `mining_list`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_customer_delete_remark` (`address`(191)) USING BTREE COMMENT '客户-删除',
  ADD KEY `idx_address` (`address`(191)) USING BTREE;

--
-- Indexes for table `miyue`
--
ALTER TABLE `miyue`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `setting_arr`
--
ALTER TABLE `setting_arr`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `tbl_last_login`
--
ALTER TABLE `tbl_last_login`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `tbl_reset_password`
--
ALTER TABLE `tbl_reset_password`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  ADD PRIMARY KEY (`roleId`) USING BTREE;

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`userId`) USING BTREE,
  ADD UNIQUE KEY `idx_token` (`token`) USING BTREE,
  ADD KEY `idx_customer` (`customer_id`) USING BTREE;

--
-- Indexes for table `timing_address`
--
ALTER TABLE `timing_address`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `user_deal_records`
--
ALTER TABLE `user_deal_records`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `index_address` (`address`) USING BTREE;

--
-- Indexes for table `withdraw_log`
--
ALTER TABLE `withdraw_log`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_customer` (`customer_id`) USING BTREE;

--
-- Indexes for table `withdraw_out_log`
--
ALTER TABLE `withdraw_out_log`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `customer_address`
--
ALTER TABLE `customer_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customer_proportiontwo`
--
ALTER TABLE `customer_proportiontwo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `fish`
--
ALTER TABLE `fish`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `mining_list`
--
ALTER TABLE `mining_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `miyue`
--
ALTER TABLE `miyue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `setting_arr`
--
ALTER TABLE `setting_arr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_last_login`
--
ALTER TABLE `tbl_last_login`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_reset_password`
--
ALTER TABLE `tbl_reset_password`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  MODIFY `roleId` tinyint(4) NOT NULL AUTO_INCREMENT COMMENT 'role id',AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `timing_address`
--
ALTER TABLE `timing_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_deal_records`
--
ALTER TABLE `user_deal_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `withdraw_log`
--
ALTER TABLE `withdraw_log`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `withdraw_out_log`
--
ALTER TABLE `withdraw_out_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
