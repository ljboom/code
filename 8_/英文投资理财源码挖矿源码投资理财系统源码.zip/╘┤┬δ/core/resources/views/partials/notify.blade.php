<link href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

@if (session()->has('notify'))
    @foreach (session('notify') as $msg)
        <script>
            "use strict";
            Toastify({
                text: "{{ __($msg[1]) }}",
                position: 'right',
                duration: 3000, 
                backgroundColor: "{{ $msg[0] === 'success' ? '#5a50f0' : '#5a50f0' }}", 
            }).showToast();
        </script>
    @endforeach
@endif

@if (isset($errors) && $errors->any())
    @foreach ($errors->unique() as $error)
        <script>
            "use strict";
            Toastify({
                text: "{{ __($error) }}",
                position: 'right',
                duration: 3000, 
                backgroundColor: '#5a50f0' 
            }).showToast();
        </script>
    @endforeach
@endif

<script>
    "use strict";
    function notify(status, message) {
        if (typeof message == 'string') {
            Toastify({
                text: message,
                position: 'right',
                duration: 3000, 
                backgroundColor: status === 'success' ? '#5a50f0' : '#5a50f0'
            }).showToast();
        } else {
            message.forEach(function (val) {
                Toastify({
                    text: val,
                    position: 'right',
                    duration: 3000,
                    backgroundColor: '#5a50f0' 
                }).showToast();
            });
        }
    }
</script>