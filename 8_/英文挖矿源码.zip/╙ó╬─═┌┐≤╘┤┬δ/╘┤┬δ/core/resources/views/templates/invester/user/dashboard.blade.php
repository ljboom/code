@extends($activeTemplate.'layouts.master')
@section('content')
   @php
        $content = getContent('footer.content',true);
    @endphp
    <!-- Top Modal -->
    <div class="page">
        <div class="container">
            <div class="header">
                <div class="logo"><img src="{{ asset(getImage(getFilePath('logoIcon').'/logo_2.png')) }}" class="w-100"></div>
                <marquee>{{ __($content->data_values->content) }}</marquee>
                <div class="welcome" id="intro-modal-open"><img src="{{asset ('core/img/icon-speaker.png')}}" class="w-100"></div>
            </div>
            <div class="banner" onclick="window.location.href=''">
                <img src="{{asset ('core/img/home-banner.jpg')}}" class="w-100">
            </div>
            <div class="balance-box">
                <div class="left">
                    <div class="title">
                        <img src="{{asset ('core/img/icon-mobile.png')}}">
                        Balance ({{ $general->cur_text }})
                    </div>
                    <div class="amt">{{ showAmount(auth()->user()->interest_wallet) }}</div>
                </div>
                <div class="right">
                    <button class="btn-balance" onclick="window.location.href='{{route ('user.deposit.index')}}'">
                        Recharge
                        <img src="{{asset ('core/img/icon-recharge.png')}}">
                    </button>
                    <button class="btn-balance" onclick="window.location.href='{{route ('user.withdraw')}}'">
                        Withdraw
                        <img src="{{asset ('core/img/icon-withdraw.png')}}">
                    </button>
                </div>
            </div>
            <div class="invite-banner button-addon2" >
               <a href="{{ route('user.transfer.balance') }}"> <img     src="{{asset ('core/img/invite-banner.png')}}"  class="w-100"></a>
            </div>


            <div class="info-row">
                <div class="icon"><img src="{{asset ('core/img/icon-envelop2.png')}}" class="w-100"></div>
                <div class="title">Dynamic Information</div>
                <div class="checkin" onclick="window.location.href='{{route ('user.invest.log')}}"><img src="{{asset ('core/img/icon-checkin.png')}}" class="w-100"></div>
            </div>
            <div class="marquee-wrapper">
                <div class="container">
                    <div class="marquee-block">
                        <div class="marquee-inner to-left">
                            <span>
                                <div class="marquee-item">
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 84**65 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info2.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 92**25 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 65**18 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="marquee-item">-->
                                <!--    <div class="white-box">-->
                                <!--        <div class="icon"><img src="https://intuitive.fyi/img/icon-info1.png"></div>-->
                                <!--        <div class="matter">-->
                                <!--            <p>Congratulations to 70**18 Invest Intuitive Robots successfully</p>-->
                                <!--            <h6>2023-09-10 12:50:06</h6>-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--    <div class="white-box">-->
                                <!--        <div class="icon"><img src="https://intuitive.fyi/img/icon-info2.png"></div>-->
                                <!--        <div class="matter">-->
                                <!--            <p>Congratulations to 70**18 Invest Intuitive Robots successfully</p>-->
                                <!--            <h6>2023-09-10 12:50:06</h6>-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--    <div class="white-box">-->
                                <!--        <div class="icon"><img src="https://intuitive.fyi/img/icon-info1.png"></div>-->
                                <!--        <div class="matter">-->
                                <!--            <p>Congratulations to 70**18 Invest Intuitive Robots successfully</p>-->
                                <!--            <h6>2023-09-10 12:50:06</h6>-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--</div>-->
                                <!--<div class="marquee-item">-->
                                <!--    <div class="white-box">-->
                                <!--        <div class="icon"><img src="https://intuitive.fyi/img/icon-info1.png"></div>-->
                                <!--        <div class="matter">-->
                                <!--            <p>Congratulations to 70**18 Invest Intuitive Robots successfully</p>-->
                                <!--            <h6>2023-09-10 12:50:06</h6>-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--    <div class="white-box">-->
                                <!--        <div class="icon"><img src="https://intuitive.fyi/img/icon-info2.png"></div>-->
                                <!--        <div class="matter">-->
                                <!--            <p>Congratulations to 70**18 Invest Intuitive Robots successfully</p>-->
                                <!--            <h6>2023-09-10 12:50:06</h6>-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--    <div class="white-box">-->
                                <!--        <div class="icon"><img src="https://intuitive.fyi/img/icon-info1.png"></div>-->
                                <!--        <div class="matter">-->
                                <!--            <p>Congratulations to 70**18 Invest Intuitive Robots successfully</p>-->
                                <!--            <h6>2023-09-10 12:50:06</h6>-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--</div>-->
                                <div class="marquee-item">
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 72**21 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 84**81 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 90**01 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="marquee-item">
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 96**54 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 96**12 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 72**70 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                </div>
                            </span>
                            <span>
                                <div class="marquee-item">
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 66**41 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 81**00 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 92**99 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="marquee-item">
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 61**01 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 94**22 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 90**62 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="marquee-item">
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 84**49 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 81**18 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 86**11 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="marquee-item">
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 99**28 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    <div class="white-box">
                                        <div class="icon"><img src="{{asset ('core/img/icon-info1.png')}}"></div>
                                        <div class="matter">
                                            <p>Congratulations to 94**22 Invest Intuitive Robots successfully</p>
                                            <h6></h6>
                                        </div>
                                    </div>
                                    
<div class="sticky-group">
    <div class="sticky-icon" onclick="window.location.href='https://wa.me/+923042324661'"><img src="{{asset ('core/img/icon-telegram.png')}}" class="w-100"></div>
   
</div>

                                </div>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <style>

    .sticky-group { width: 45px; height: fit-content; position: fixed; right: 25px; bottom: 180px; }
    .sticky-group .sticky-icon { width: 45px; height: 45px; margin-bottom: 15px; }
    .sticky-group .sticky-icon:last-child { margin-bottom: 0; }

    .footer-nav { width: 100%; max-width: 991px; height: 65px; background-color: #080034; border-radius: 17px 17px 0 0; box-shadow: 0 0 1rem 0 rgba(0,0,0,.1); position: fixed; z-index: 100; transform: translateX(-50%); left: 50%; bottom: 0; display: flex; flex-direction: row; align-items: center; justify-content: start; flex-wrap: wrap; }
    .footer-nav .nav { width: 20%; height: 100%; position: relative; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .footer-nav .nav img { width: 21px; height: 21px; margin-bottom: 3px; }
    .footer-nav .nav span { font-size: 12px; font-weight: 400; color: transparent; }
    .footer-nav .nav.active span { background: linear-gradient(270deg,#f8b6b8,#815af3); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .footer-nav .nav.center { top: -27px; }
    .footer-nav .nav.center img { width: 54px; height: 54px; }
    .footer-nav .nav.center.active img { width: 78px; height: 78px; }
</style>






@endsection
  <script>



        function setCookie(cname, cvalue, exdays) {
            const d = new Date();
            d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
            let expires = "expires=" + d.toUTCString();
            document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
        }

        function getCookie(cname) {
            let name = cname + "=";
            let decodedCookie = decodeURIComponent(document.cookie);
            let ca = decodedCookie.split(';');
            for (let i = 0; i < ca.length; i++) {
                let c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
        }

        var intro = document.getElementById('intro-modal-open');
        var intromodback = document.getElementById('intro-modal-back');
        var intromod = document.getElementById('intro-modal');
        var intromodclose = document.getElementById('top-modal-open');

        var topmodback = document.getElementById('top-modal-back');
        var topmod = document.getElementById('top-modal');
        var topmodclose = document.getElementById('top-modal-close');

        $(document).ready(function() {


            // document.getElementById("con1").style.display = "flex";
            // $('.loaderClass1').delay(3000).fadeOut(300);




            let user = getCookie("username");
            if (user != "") {
                $(intromodback).removeClass('show');
                $(intromod).removeClass('show');
            } else {

                $(intromodback).addClass('show');

                $(intromod).addClass('show');
            }


        });


        $(intromodclose).on('click', function(){
            $(intromodback).removeClass('show');
            $(intromod).removeClass('show');

            $(topmodback).addClass('show');
            $(topmod).addClass('show');
        });


        $(intro).on('click', function(){
            $(intromodback).addClass('show');
            $(intromod).addClass('show');
        });

        $(topmodclose).on('click', function(){
            $(topmodback).removeClass('show');
            $(topmod).removeClass('show');
        });
    </script>

<script>
    $(".button-addon2").on('click', function() {
        var target = $("#link");

        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val(target.val()).select();
        document.execCommand("copy");
        $temp.remove();

        document.getElementById("con").style.display = "flex";
        showLoader("Copy Link");


    });
    $(".button-addon3").on('click', function() {
        var target = $("#link1");

        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val(target.val()).select();
        document.execCommand("copy");
        $temp.remove();

        $(".button-addon3").text('Copied');
        window.setTimeout(function() {
            $(".button-addon3").text('Copy Link');
        }, 2000);
    });


    function submites() {


        document.getElementById("con").style.display = "flex";




        $.ajax({
            url: "https://intuitive.fyi/check",
            data: {

                "_token": "7gSnKsyjrjrOln20WX996woBTi8VSjdqLrVFAnkZ"
            },
            dataType: "json",
            type: "post",
            success: function(response) {
                if (response.status) {

                    showLoader(response.message);


                } else {


                    showLoader(response.message);

                }
            }
        });
    }


    function showLoader(message) {


        document.getElementById("loaderId").innerHTML = message
        $('.loaderClass').delay(3000).fadeOut(500);

        setTimeout(function() {
            location.reload();
        }, 1000);



    }
</script>