@extends($activeTemplate.'layouts.app')
@section('panel')




    @include($activeTemplate.'partials.sidebar')



            @yield('content')




<div class="footer-nav">
    <div class="nav active" onclick="window.location.href='{{route ('user.home')}}'">
        <img src="{{asset ('core/img/nav-home-active.png')}}">
        <span>Home</span>
    </div>
    <div class="nav " onclick="window.location.href='{{route ('plan')}}'">
        <img  src="{{asset ('core/img/nav-lease.png')}}">
        <span>Lease</span>
    </div>
    <div class="nav center" onclick="window.location.href='{{route ('user.invest.log')}}'">
        <img src="{{asset ('core/img/nav-device.png')}}">
    </div>
    <div  class="nav " onclick="window.location.href='{{ route('user.referrals') }}'">
        <img  src="{{asset ('core/img/nav-team.png')}}">
        <span>Team</span>
    </div>

    <div class="nav " onclick="window.location.href='{{ route('user.profile.setting') }}'">
        <img  src="{{asset ('core/img/nav-mine.png')}}">
        <span>Mine</span>
    </div>
</div>


    <input type="hidden" id="link" class="form-control" value="https://intuitive.fyi/Intuitive/robotics/new/invite/users/register/5b2JaV">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>

@endsection
