@extends($activeTemplate . 'layouts.frontend')
@section('content')


<style>
    @import  url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap');
    html, body { width: 100%; min-height: 100vh; margin: 0; background: #ffffff; font-family: 'Roboto', sans-serif; font-size: 14.5px; font-family: 300; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; text-rendering: optimizeLegibility; text-shadow: rgba(0,0,0,.01) 0 0 1px; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); }

    .container { width: 100%; max-width: 991px; padding: 70px 15px 15px; position: relative; z-index: 2 !important; }
    .header { width: 100%; height: 40px; background: #fff; line-height: 40px; font-size: 16px; font-weight: 600; color: #121212; text-align: center; position: fixed; top: 0; left: 0; z-index: 10; }
    .header i { font-size: 20px; color: #121212; position: absolute; left: 12px; top: 0px; }
    .header i.right { right: 12px; left: auto; }

    .hl-box { width: 100%; height: fit-content; background: rgb(8, 0, 52); border: 1px solid #e1e1e1; border-radius: 10px; padding: 10px; font-size: 13.9px; font-weight: 400; color: #ffffff; margin-bottom: 15px; }

    .headings { margin-bottom: 15px; }
    .headings h4 { font-size: 20px; line-height: 25px; font-weight: 400; color: #646464; margin-bottom: 3px; }
    .headings h6 { font-size: 13px; line-height: 16px; font-weight: 400; color: #25addf; margin-bottom: 0; }

    .recharge-form .btns-block { display: flex; flex-direction: row; align-items: center; justify-content: space-between; margin-bottom: 10px; }
    button.btn.amount-btn { width: 100%; height: 45px; border: 0PX; background: linear-gradient(270deg,#f8b6b8,#815af3); color: rgba(255,255,255,0.8); padding: 0px 10px; border-radius: 15px; font-size: 15px; font-weight: 400; margin-left: 12px; }
    button.btn.amount-btn:first-child { margin-left: 0; }

    .recharge-form input.form-control { border: 1px solid #e1e1e1; border-left: 0; background-color: #fff; height: 50px; line-height: 50px; padding: 0px 10px; border-radius: 8px; color: #121212; }
    .recharge-form .input-group-text { border: 1px solid #e1e1e1; background-color: #fff; height: 50px; font-size: 20px; line-height: 50px; padding: 0px 10px; border-radius: 8px; color: #25addf; border-right: 0px; }
    form.login-form input.form-control::placeholder { color: #646464; }
    input:focus { box-shadow: none !important; }

    .button-group-bc { display: flex; flex-direction: row; align-items: center; justify-content: space-between; margin-bottom: 15px; }
    .recharge-form button.btn.bank-card { width: calc(50% - 5px); height: 56px; background: #fff; border: 1px solid #e1e1e1; border-radius: 10px; margin-left: 10px; padding: 0 10px; display: flex; flex-direction: row; align-items: center; justify-content: start; font-size: 16px; font-weight: 400; color: #646464; }
    .recharge-form button.btn.bank-card img { height: 30px; margin-right: 10px; }
    .recharge-form button.btn.bank-card.selected { border: 1px solid #25addf; font-weight: 500; position: relative;  }
    .recharge-form button.btn.bank-card.selected::after { content: ''; display: block; width: 20px; height: 10px; border-left: 4px solid #65c37a; border-bottom: 4px solid #65c37a; position: absolute; transform: rotate(-45deg); right: 20px; top: 18px; }
    .recharge-form button.btn.bank-card:first-child { margin-left: 0; }

    button.btn.recharge-btn { width: 100%; height: 50px; line-height: 50px; font-size: 16px; font-weight: 500; text-transform: uppercase; color: #ffffff; background: linear-gradient(270deg,#f8b6b8,#815af3); border: 0px; border-radius: 8px; padding: 0; }

    .video-block { width: 100%; background: linear-gradient(to bottom, #FFE393,#FCC12D); padding: 10px; border-radius: 5px; height: auto; overflow: hidden; }

    nav.data-tabs a.nav-link { background-color: transparent !important; position: relative; font-size: 14px; line-height: 14px; font-weight: 400; padding: 0; height: 30px; color: #ffffff; }
    nav.data-tabs a.nav-link.active { color: #FFE393;}
    nav.data-tabs a.nav-link.active::after { content: ''; width: 50px; height: 3px; background-color: #FFE393; position: absolute; bottom: 0; transform: translate(-50%, -50%); left: 50%; }

    .tab-content-top { display: flex; align-items: center; justify-content: space-around; }
    .quantity-box { width: 30%; font-size: 12px; color: #41D3FF; border-radius: 20px; border: 1px solid #41D3FF !important; padding: 7px; text-align: center; }
    .tab-content hr { width: 100%; height: 10px; background: rgb(19,37,60); }

    .text-yellow { color:#FFE393; }
    .text-grey { color: #8d8e90; }
    .text-orange { color: #FFAD41; }
    .text-green { color: #41D3FF;}

    .invite-list .item { width: 100%; border-radius: 5px; height: 120px; background: linear-gradient(to bottom, #0C2467,#000000); padding: 10px; margin-bottom: 10px; }
    .invite-list .item h6.small { font-size: 12px; }

    .footer-nav { position: fixed; z-index: 100; left: 0px; bottom: 0px; width: 100%; height: 70px; background: transparent url(images/footer-nav-bg.png) no-repeat left bottom; background-size: 100% 100%; display: flex; justify-content: space-between; align-items: center; }
    .footer-nav .nav-item { text-align: center; color: #848484; font-size: 12px; font-weight: 600; line-height: 12px; margin-top: 20px; width: 20%; }
    .footer-nav .nav-item img { height: 25px; margin: 0 auto 4px; filter: grayscale(100%); }
    .footer-nav .nav-item.center { margin-top: 4px; }
    .footer-nav .nav-item.center img { height: 42px; filter: grayscale(0); }
    .footer-nav .nav-item.active { color: #3dcbfa; }
    .footer-nav .nav-item.active img { filter: grayscale(0); }

    /* .modal-backdrop.fade.show { display: none; } */
    .modal-fullscreen-xl { padding: 0 !important; }
    .modal-fullscreen-xl button.btn-close { color: #ffffff; }
    .modal-fullscreen-xl .modal-dialog { width: 100%; max-width: none; height: 100%; margin: 0; }
    .modal-fullscreen-xl .modal-content { height: 100%; border: 0; border-radius: 0; }
    .modal-fullscreen-xl .modal-body { overflow-y: auto; padding: 0; }

    .modal.video-modal .modal-header, .modal.video-modal .modal-body {  background: rgb(6, 25, 49); border: 0px; display: block; text-align: center; }
    .modal.video-modal .modal-header button { background-color: transparent; border: 0; padding: 0; color: #ffffff; font-size: 20px; position: absolute; left: 15px; }
    .modal.video-modal .modal-body { padding: 10px; }
    .modal.video-modal .modal-body .vdo-block { width: 100%; padding: 10px; border-radius: 10px; background-color: #000000; overflow: hidden; }
</style>
</head>

<body>



    <link href="{{ asset('assets/global/css/bootstrap.min.css') }}" rel="stylesheet">

    <link href="{{ asset('assets/global/css/all.min.css') }}" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('assets/global/css/line-awesome.min.css') }}" />

    <link rel="stylesheet" href="{{ asset($activeTemplateTrue . 'css/lib/animate.css') }}">

    <!-- Plugin Link -->
    <link rel="stylesheet" href="{{ asset($activeTemplateTrue . 'css/lib/slick.css') }}">
    <link rel="stylesheet" href="{{ asset($activeTemplateTrue . 'css/lib/magnific-popup.css') }}">
    <link rel="stylesheet" href="{{ asset($activeTemplateTrue . 'css/lib/apexcharts.css') }}">

    <!-- Main css -->
    <link rel="stylesheet" href="{{ asset($activeTemplateTrue . 'css/main.css') }}">

    @stack('style-lib')

    <link rel="stylesheet" href="{{ asset($activeTemplateTrue . 'css/custom.css') }}">

    <link rel="stylesheet" href="{{ asset($activeTemplateTrue . 'css/color.php') }}?color=5e8cf1">


    <div class="dashboard-inner">
        <div class="mb-4">
            <h3 class="mb-2">@lang('Change Password')</h3>
        </div>

        <div class="card custom--card">
            <div class="card-body">

                <form action="" method="post">
                    @csrf
                    <div class="form-group">
                        <label class="form-label">@lang('Current Password')</label>
                        <input type="password" class="form-control form--control" name="current_password" required autocomplete="current-password">
                    </div>
                    <div class="form-group">
                        <label class="form-label">@lang('Password')</label>
                        <input type="password" class="form-control form--control" name="password" required autocomplete="current-password">
                        @if ($general->secure_password)
                            <div class="input-popup">
                                <p class="error lower">@lang('1 small letter minimum')</p>
                                <p class="error capital">@lang('1 capital letter minimum')</p>
                                <p class="error number">@lang('1 number minimum')</p>
                                <p class="error special">@lang('1 special character minimum')</p>
                                <p class="error minimum">@lang('6 character password')</p>
                            </div>
                        @endif
                    </div>
                    <div class="form-group">
                        <label class="form-label">@lang('Confirm Password')</label>
                        <input type="password" class="form-control form--control" name="password_confirmation" required autocomplete="current-password">
                    </div>
                    <div class="form-group mt-3">
                        <button type="submit" class="btn recharge-btn">@lang('Submit')</button>
                    </div>
                </form>

            </div>
        </div>


    </div>
@endsection

@if ($general->secure_password)
    @push('script-lib')
        <script src="{{ asset('assets/global/js/secure_password.js') }}"></script>
    @endpush
@endif
