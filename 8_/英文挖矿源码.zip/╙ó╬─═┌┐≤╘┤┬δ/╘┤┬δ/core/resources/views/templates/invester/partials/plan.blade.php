
<!-- Bootstrap -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">

<style>
    @import  url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap');
    html, body { width: 100%; max-width: 991px; margin: 0 auto; font-family: 'Roboto', sans-serif; font-size: 15px; font-weight: 400; color: #333; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; text-rendering: optimizeLegibility; text-shadow: rgba(0,0,0,.01) 0 0 1px; position: relative; }
    .page { width: 100%; height: 100vh; background: #f8f7fb; position: relative; top: 0; left: 0; z-index: 5; }
    .header { width: 100%; height: fit-content; padding: 25px 15px 5px; font-size: 22px; line-height: 22px; font-weight: 500; color: #333c40; }
    .banner { width: 100%; height: 115px; background: #080034; border-radius: 0 0 17px 17px; padding: 15px; position: relative; }
    .banner .banner-inner { width: 100%; height: 100%; position: relative; background: linear-gradient(270deg,rgba(248,182,184,0),#815af3 50%,rgba(248,182,184,0)); display: flex; flex-direction: row; align-items: center; justify-content: start; }
    .banner .banner-inner::after { content: ''; display: block; width: 2px; height: 25px; background-color: rgba(255,255,255,0.3); position: absolute; transform: translate(-50%, -50%); left: 50%; top: 50%; }
    .banner .banner-inner .part { width: 50%; display: block; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .banner p { font-size: 21px; font-weight: 500; color: #ffd631; line-height: 25px; margin-bottom: 5px; }
    .banner h6 { font-family: 'Times New Roman', Times, serif; font-size: 14px; line-height: 16px; font-weight: 400; color: #fff; margin-bottom: 0; }

    .container { width: 100%; max-width: 991px; padding: 15px 15px 75px; }

    .title { font-size: 14px; font-weight: 600; padding-left: 25px; color: #000; margin-bottom: 15px; position: relative; }
    .title img { width: 20px; height: 20px; position: absolute; left: 0; top: 0; }

    .product { width: 100%; padding-bottom: 15px; margin-bottom: 15px; border-bottom: 1px solid rgba(0,0,0,.2); display: flex; flex-direction: row; align-items: center; justify-content: start; }
    .product .product-img { display: block; width: 84px; border: 3px solid #fff; border-radius: 7px; overflow: hidden; margin-right: 15px; }
    .product .right { width: calc(100% - 105px); display: block; }
    .product .heading { font-size: 15px; line-height: 18px; font-weight: 700; color: #000; margin-bottom: 6px; }
    .product p { font-size: 12.5px; line-height: 16px; font-weight: 400; color: #333841; margin-bottom: 6px; }
    .product p span { font-size: 13px; font-weight: 700; color: #ff0000; }
    .product button.btn-lease { width: 100%; height: 30px; color: #fff; font-size: 16px; background: linear-gradient(270deg,#f8b6b8,#815af3); padding: 0; border: 0; outline: 0; box-shadow: none; border-radius: 4px; }

    .footer-nav { width: 100%; max-width: 991px; height: 65px; background-color: #080034; border-radius: 17px 17px 0 0; box-shadow: 0 0 1rem 0 rgba(0,0,0,.1); position: fixed; z-index: 100; transform: translateX(-50%); left: 50%; bottom: 0; display: flex; flex-direction: row; align-items: center; justify-content: start; flex-wrap: wrap; }
    .footer-nav .nav { width: 20%; height: 100%; position: relative; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .footer-nav .nav img { width: 21px; height: 21px; margin-bottom: 3px; }
    .footer-nav .nav span { font-size: 12px; font-weight: 400; color: transparent; }
    .footer-nav .nav.active span { background: linear-gradient(270deg,#f8b6b8,#815af3); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .footer-nav .nav.center { top: -27px; }
    .footer-nav .nav.center img { width: 54px; height: 54px; }
    .footer-nav .nav.center.active img { width: 78px; height: 78px; }
</style>

</head>

<body>
    <div class="page">
        <div class="header">Lease</div>
        <div class="banner">
            <div class="banner-inner">
                <div class="part">
                    <p>{{ $general->cur_text }} {{ showAmount(auth()->user()->interest_wallet) }}</p>
                    <h6>Lease income</h6>
                </div>
                <div class="part" onclick="window.location.href=''">
                    <p> {{ $general->cur_text }} {{ showAmount(auth()->user()->deposit_wallet) }} </p>
                    <h6>Recharge Wallet</h6>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="title">
                <img src="{{asset ('core/img/lease-title-icon.png')}}">
                Lease list
            </div>




                        






@foreach ($plans as $plan)



            <div class="product">
                <div class="product-img"><img src="{{asset ('core/img/1694401846images (26) (22).jpeg')}}" class="w-100" height="80"></div>
                <div class="right">
                    <div class="heading">{{ __($plan->name) }}</div>
                    <p>Project Amount: <span>         @if ($plan->fixed_amount == 0)
                                {{ __($general->cur_sym) }}{{ showAmount($plan->minimum) }} -
                                {{ __($general->cur_sym) }}{{ showAmount($plan->maximum) }}
                            @else
                                {{ __($general->cur_sym) }}{{ showAmount($plan->fixed_amount) }}
                            @endif</span></p>
                    <p>Daily earning: <span> {{ $plan->interest_type != 1 ? $general->cur_sym : '' }}{{ showAmount($plan->interest) }}{{ $plan->interest_type == 1 ? '%' : '' }}</span></p>
                    <p>Total earning: <span>      @if ($plan->lifetime == 0)
                                @if ($plan->capital_back == 1)
                                    @lang('capital') +
                                @endif
                                {{ __($plan->interest * $plan->repeat_time) }}{{ $plan->interest_type == 1 ? '%' : ' ' . __($general->cur_text) }}
                            @else
                                @lang('Unlimited')
                            @endif</span></p>
                            
                            
                            
                            
                            
                            
                            
                                  <p>Cycle: <span>     @lang('')  @lang('') @if ($plan->lifetime == 0)
                            {{ __($plan->repeat_time) }} {{ __($plan->time_name) }}
                        @else
                            @lang('LIFETIME')
                        @endif</span></p>
                            
                            
                            
                    

      
                                <form action="{{ route('user.invest.submit') }}" method="post">
                @csrf
                <input type="hidden" name="plan_id">
                    
                    <button class="btn-lease investModal"  data-bs-toggle="modal" type="submit" 
                data-plan="{{ $plan }}" data-bs-target="#investModal" >Lease</button>
                
                
                
                
                
                
                </div>
            </div>


                    

@endforeach







                                        

        </div>
    </div>







    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    <script>
        var intro = document.getElementById('intro-modal-open');
        var intromodback = document.getElementById('intro-modal-back');
        var intromod = document.getElementById('intro-modal');
        var intromodclose = document.getElementById('top-modal-open');

        var topmodback = document.getElementById('top-modal-back');
        var topmod = document.getElementById('top-modal');
        var topmodclose = document.getElementById('top-modal-close');

        $(intro).on('click', function(){
            $(intromodback).addClass('show');
            $(intromod).addClass('show');
        });
        $(intromodclose).on('click', function(){
            $(intromodback).removeClass('show');
            $(intromod).removeClass('show');

            $(topmodback).addClass('show');
            $(topmod).addClass('show');
        });
        $(topmodclose).on('click', function(){
            $(topmodback).removeClass('show');
            $(topmod).removeClass('show');
        });
    </script>
</body>
</html>




       
<div style="display:none;">


<div class="modal fade" id="investModal">
    <div class="modal-dialog modal-dialog-centered modal-content-bg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    @if (auth()->check())
                        @lang('Confirm to invest on') <span class="planName"></span>
                    @else
                        @lang('At first sign in your account')
                    @endif
                </h5>
                <button type="button" class="close" data-bs-dismiss="modal">
                    <i class="las la-times"></i>
                </button>
            </div>
            <form action="{{ route('user.invest.submit') }}" method="post">
                @csrf
                <input type="hidden" name="plan_id">
                @if(auth()->check())
                    <div class="modal-body">
                        <div class="form-group">
                            <h6 class="text-center investAmountRange"></h6>
                            <p class="text-center mt-1 interestDetails"></p>
                            <p class="text-center interestValidity"></p>

                            <label>@lang('Select Wallet')</label>
                            <select class="form-control form--control form-select" name="wallet_type" required>
                              
                                @if(auth()->user()->deposit_wallet > 0)
                                <option value="deposit_wallet">@lang('Deposit Wallet - '.$general->cur_sym.showAmount(auth()->user()->deposit_wallet))</option>
                                @endif
                          
                           
                            </select>
                            <code class="gateway-info rate-info d-none">@lang('Rate'): 1 {{ $general->cur_text }} = <span class="gateway-rate"></span> <span class="method_currency"></span></code>
                        </div>
                        <div class="form-group">
                            <label>@lang('Invest Amount')</label>
                            <div class="input-group">
                                <input type="number" step="any" class="form-control form--control" name="amount" required>
                                <div class="input-group-text">{{ $general->cur_text }}</div>
                            </div>
                            <code class="gateway-info d-none">@lang('Charge'): <span class="charge"></span> {{ $general->cur_text }}. @lang('Total amount'): <span class="total"></span> {{ $general->cur_text }}</code>
                        </div>
                    </div>
                @endif
                <div class="modal-footer">
                    @if (auth()->check())
                        <button type="button" class="btn btn--dark" data-bs-dismiss="modal">@lang('No')</button>
                        <button type="submit" class="btn btn--base">@lang('Yes')</button>
                    @else
                        <a href="{{ route('user.login') }}" class="btn btn--base w-100">@lang('At first sign in your account')</a>
                    @endif
                </div>
            </form>
        </div>
    </div>
</div>
</div>

@push('script')
<script>
    (function($){
        "use strict"
        $('.investModal').click(function(){
            var symbol = '{{ $general->cur_sym }}';
            var currency = '{{ $general->cur_text }}';
            $('.gateway-info').addClass('d-none');
            var modal = $('#investModal');
            var plan = $(this).data('plan');
            modal.find('[name=plan_id]').val(plan.id);
            modal.find('.planName').text(plan.name);
            let fixedAmount = parseFloat(plan.fixed_amount).toFixed(2);
            let minimumAmount = parseFloat(plan.minimum).toFixed(2);
            let maximumAmount = parseFloat(plan.maximum).toFixed(2);
            let interestAmount = parseFloat(plan.interest);

            if (plan.fixed_amount > 0) {
                modal.find('.investAmountRange').text(`Invest: ${symbol}${fixedAmount}`);
                modal.find('[name=amount]').val(parseFloat(plan.fixed_amount).toFixed(2));
                modal.find('[name=amount]').attr('readonly',true);
            }else{
                modal.find('.investAmountRange').text(`Invest: ${symbol}${minimumAmount} - ${symbol}${maximumAmount}`);
                modal.find('[name=amount]').val('');
                modal.find('[name=amount]').removeAttr('readonly');
            }

            if (plan.interest_type == '1') {
                modal.find('.interestDetails').html(`<strong> Interest: ${interestAmount}% </strong>`);
            } else {
                modal.find('.interestDetails').html(`<strong> Interest: ${interestAmount} ${currency}  </strong>`);
            }

            if (plan.lifetime == '0') {
                modal.find('.interestValidity').html(`<strong>  Every ${plan.time_name} for ${plan.repeat_time} times</strong>`);
            } else {
                modal.find('.interestValidity').html(`<strong>  Every ${plan.time_name} for life time </strong>`);
            }

        });

        $('[name=amount]').on('input',function(){
            $('[name=wallet_type]').trigger('change');
        })

        $('[name=wallet_type]').change(function () {
            var amount = $('[name=amount]').val();
            if($(this).val() != 'deposit_wallet' && $(this).val() != 'interest_wallet' && amount){
                var resource = $('select[name=wallet_type] option:selected').data('gateway');
                var fixed_charge = parseFloat(resource.fixed_charge);
                var percent_charge = parseFloat(resource.percent_charge);
                var charge = parseFloat(fixed_charge + (amount * percent_charge / 100)).toFixed(2);
                $('.charge').text(charge);
                $('.gateway-rate').text(parseFloat(resource.rate));
                $('.gateway-info').removeClass('d-none');
                if (resource.currency == '{{ $general->cur_text }}') {
                    $('.rate-info').addClass('d-none');
                }else{
                    $('.rate-info').removeClass('d-none');
                }
                $('.method_currency').text(resource.currency);
                $('.total').text(parseFloat(charge) + parseFloat(amount));
            }else{
                $('.gateway-info').addClass('d-none');
            }
        });
    })(jQuery);
</script>
@endpush


