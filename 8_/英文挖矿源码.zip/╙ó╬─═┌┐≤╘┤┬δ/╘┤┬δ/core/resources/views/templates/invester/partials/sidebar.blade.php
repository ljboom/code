@php
    $promotionCount = App\Models\PromotionTool::count();
@endphp

<!-- Bootstrap -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">

<style>
    @import  url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap');
    html, body { width: 100%; max-width: 991px; margin: 0 auto; font-family: 'Roboto', sans-serif; font-size: 15px; font-weight: 400; color: #333; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; text-rendering: optimizeLegibility; text-shadow: rgba(0,0,0,.01) 0 0 1px; position: relative; }
    .page { width: 100%; height: 100vh; background: #f8f7fb; position: relative; top: 0; left: 0; z-index: 5; }

    .container { width: 100%; max-width: 991px; padding: 25px 15px; }
    .header { width: 100%; margin-bottom: 5px; display: flex; flex-direction: row; align-items: center; justify-content: space-between; }
    .header .logo { width: 73px; margin-left: 15px; }
    .header .welcome { width: 20px; }

    .banner { width: 100%; height: fit-content; border-radius: 12px; overflow: hidden; box-shadow: 0 0.4rem 1.6rem -0.4rem rgba(0,0,0,.2); margin-bottom: 15px; }

    .balance-box { width: 100%; height: fit-content; background-color: #080034; border: 1px solid #000; border-radius: 10px; box-shadow: 0 0.4rem 1.6rem -0.4rem rgba(0,0,0,.2); padding: 10px 15px; margin-bottom: 15px; display: flex; flex-direction: row; align-items: start; justify-content: space-between; }
    .balance-box .left { width: calc(100% - 110px); }
    .balance-box .right { width: 110px; }
    .balance-box .title { font-size: 18px; font-weight: 600; color: #fff; padding-left: 32px; position: relative; }
    .balance-box .title img { width: 27px; height: 27px; position: absolute; left: 0; top: 0; }
    .balance-box .amt { font-family: 'Times New Roman', Times, serif; font-size: 32px; line-height: 32px; font-weight: 700; color: #ffd631; margin-top: 5px; }
    .balance-box .right button.btn-balance { width: 110px; height: 27px; background: linear-gradient(270deg,#f8b6b8,#815af3); border: 0; border-radius: 4px; outline: 0; box-shadow: none; font-size: 14px; font-weight: 600; color: #fff; padding: 0; margin-bottom: 12px; }
    .balance-box .right button.btn-balance:last-child { margin-bottom: 0px; }
    .balance-box .right button.btn-balance img { width: 19px; height: 19px; margin-left: 10px; }

    .invite-banner { width: calc(100% + 30px); height: fit-content; margin: 0 -15px -10px; }

    .info-row { width: 100%; height: fit-content; display: flex; flex-direction: row; align-items: center; justify-content: start; }
    .info-row .icon { width: 24px; height: 24px; margin-right: 7.5px; }
    .info-row .title { font-size: 16px; font-weight: 500; background: linear-gradient(270deg,#f8b6b8,#815af3); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .info-row .checkin { width: 70px; height: 70px; margin-left: auto; }

    /* Marquee */
    .marquee-wrapper { background: transparent; }
    .marquee-wrapper .container { overflow:hidden; }
    .marquee-inner span { float:left; width:50%; }
    .marquee-wrapper .marquee-block { --total-marquee-items: 5; height: 270px; width: calc(250px * (var(--total-marquee-items))); overflow: hidden; box-sizing: border-box; position: relative; margin: 0 auto; padding: 0 15px; }
    .marquee-inner { display: block; width: 200%; position: absolute; }
    .marquee-inner.to-left{ animation: marqueeLeft 25s linear infinite; }
    .marquee-inner.to-right { animation: marqueeRight 25s linear infinite; }
    .marquee-item { width: 250px; height: auto; display: inline-block; margin: 0 10px; float: left; transition: all .2s ease-out; }
    @keyframes  marqueeLeft { 0% { left: 0; } 100% { left: -100%; } }
    @keyframes  marqueeRight { 0% { left: -100%; } 100% { left: 0; } }

    .white-box { width: 250px; height: 75px; background-color: #fff; border-radius: 15px; padding: 10px 15px; margin-bottom: 15px; display: flex; flex-direction: row; align-items: center; justify-content: start; flex-wrap: wrap; }
    .white-box .icon { width: 30px; height: 30px; margin-right: 12px; }
    .white-box .icon img { width: 100%; height: 100%; }
    .white-box .matter { width: calc(100% - 42px); }
    .white-box p { font-size: 12px; font-weight: 600; line-height: 16px; color: #a37ef8; margin-bottom: 5px; }
    .white-box h6 { font-size: 12px; font-weight: 400; line-height: 16px; color: #000; margin-bottom: 0; }
    /* Marquee */

    .sticky-group { width: 45px; height: fit-content; position: fixed; right: 25px; bottom: 180px; }
    .sticky-group .sticky-icon { width: 45px; height: 45px; margin-bottom: 15px; }
    .sticky-group .sticky-icon:last-child { margin-bottom: 0; }

    .footer-nav { width: 100%; max-width: 991px; height: 65px; background-color: #080034; border-radius: 17px 17px 0 0; box-shadow: 0 0 1rem 0 rgba(0,0,0,.1); position: fixed; z-index: 100; transform: translateX(-50%); left: 50%; bottom: 0; display: flex; flex-direction: row; align-items: center; justify-content: start; flex-wrap: wrap; }
    .footer-nav .nav { width: 20%; height: 100%; position: relative; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .footer-nav .nav img { width: 21px; height: 21px; margin-bottom: 3px; }
    .footer-nav .nav span { font-size: 12px; font-weight: 400; color: transparent; }
    .footer-nav .nav.active span { background: linear-gradient(270deg,#f8b6b8,#815af3); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .footer-nav .nav.center { top: -27px; }
    .footer-nav .nav.center img { width: 54px; height: 54px; }
    .footer-nav .nav.center.active img { width: 78px; height: 78px; }

    /* IntroModal */
    .intro-modal-backdrop { width: 100%; max-width: 991px; height: 100%; background-color: rgba(0,0,0,0); position: fixed; transform: translateX(-50%); top: 0; left: 50%; z-index: 999; visibility: hidden; transition: all 0.3s ease-in-out; }
    .intro-modal-backdrop.show { background-color: rgba(0,0,0,0.6); visibility: visible; }
    .intro-modal { width: calc(100% - 40px); height: fit-content; margin: 0 20px; background-color: #080034; position: absolute; transform: translateY(-50%); top: 55%; padding: 15px 20px 20px; visibility: hidden; opacity: 0; transition: all 0.3s ease-in-out; }
    .intro-modal.show { visibility: visible; opacity: 1; top: 50%; }
    .intro-modal .top-img { width: 98px; margin: 0 auto 15px; }
    .intro-modal p { font-size: 16px; font-weight: 400; line-height: 19px; color: #fff; margin-bottom: 0; }
    .intro-modal button.btn-ok { width: calc(100% - 30px); height: 50px; background: linear-gradient(270deg,#f8b6b8,#815af3); border: 0; border-radius: 4px; outline: 0; box-shadow: none; padding: 0; font-size: 20px; font-weight: 500; color: #fff; margin: 40px 15px 20px; }
    /* IntroModal */
    /* TopModal */
    .top-modal-backdrop { width: 100%; max-width: 991px; height: 100%; background-color: rgba(0,0,0,0); position: fixed; transform: translateX(-50%); top: 0; left: 50%; z-index: 999; visibility: hidden; transition: all 0.3s ease-in-out; }
    .top-modal-backdrop.show { background-color: rgba(0,0,0,0.6); visibility: visible; }
    .top-modal { width: 100%; max-width: 991px; height: fit-content; background-color: #fff; border-radius: 0 0 15px 15px; padding: 40px 15px; position: fixed; transform: translateX(-50%); left: 50%; top: -200px; visibility: hidden; opacity: 0; transition: all 0.3s ease-in-out; }
    .top-modal.show { visibility: visible; opacity: 1; top: 0; }
    .top-modal .title { font-size: 18px; font-weight: 700; color: #666; margin-left: 10px; margin-bottom: 10px; }
    .top-modal .link-row { width: 100%; height: 50px; display: flex; flex-direction: row; align-items: center; justify-content: start; flex-wrap: wrap; border-bottom: 1px solid #eaeaea; }
    .top-modal .link-row .icon { width: 25px; margin-right: 15px; }
    .top-modal .link-row span { font-size: 16px; font-weight: 600; color: #030303; }
    .top-modal .link-row .arrow { width: 24px; margin-left: auto; }
    .top-modal .top-modal-close { width: 37px; position: absolute; top: 15px; right: 15px; }
    /* TopModal */
</style>

<style>
 

#con1 { display: none;  align-items: center; justify-content: center;
     
         position:absolute;
        max-width: 100%;
        height: auto;
        top: 57%;
        left: 50%;
        text-align: center;
        z-index: 999;
        transform: translate(-50%, -50%);
         
         
     }
    .loaderClass1 { height: 38px; width: fit-content; 
  padding: 0px 15px;
    background-color: rgba(0,0,0,1);
    font-size: 15px; font-weight: 300; 
    color: #ffffff; border-radius: 8px; 
    display: flex; align-items: center; z-index: 9999;
    
         
        
    }

.loaderClass1 .animation { width: 20px; height: 20px; background: url('https://intuitive.fyi/img/loading.gif')  no-repeat center center; background-size: 100% 100%; margin-right: 10px; }
   
  
     #con { display: none;  align-items: center; justify-content: center;
     
         position:absolute;
        max-width: 100%;
        height: auto;
        top: 57%;
        left: 50%;
        text-align: center;
        z-index: 999;
        transform: translate(-50%, -50%);
         
         
     }
    .loaderClass { height: 38px; width: fit-content; 
  padding: 0px 15px;
    background-color: rgba(0,0,0,1);
    font-size: 15px; font-weight: 300; 
    color: #ffffff; border-radius: 8px; 
    display: flex; align-items: center; z-index: 9999;
    
         
        
    }
    
    
    
    
    .loaderClass .animation { width: 20px; height: 20px; background: url('https://intuitive.fyi/img/loading.gif')  no-repeat center center; background-size: 100% 100%; margin-right: 10px; }
   
   
 .custom-toast {
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      background-color: black;
      color: white;
      padding: 10px 20px;
      border-radius: 5px;
      z-index: 9999;
      display: none;
        text-align: center;
      
      
    }
    @media (max-width: 767px) {
      .custom-toast {
        top: 50%; /* Center vertically */
        left: 50%; /* Center horizontally */
        transform: translate(-50%, -50%);
      }
    }
    
    .custom-toast.show {
      display: block;
     
    }

</style>
<style>
    #con1 {
        display: none;
        align-items: center;
        justify-content: center;

        position: fixed;
        max-width: 100%;
        height: auto;
        top: 50%;
        left: 50%;
       z-index: 999;
        transform: translate(-50%, -50%);


    }

    .loaderClass1 {
        height: 46px;
        width: fit-content;
        padding: 0px 20px;
        background-color: rgba(0, 0, 0, .5);
        font-size: 15px;
        font-weight: 400;
        color: #ffffff;
        border-radius: 8px;
        display: flex;
        align-items: center;
        z-index: 9999;
    }

    .loaderClass1 .animation1 {
        width: 20px;
        height: 20px;
        background: url("https://intuitive.fyi/img/loading.gif") no-repeat center center;
        background-size: 100% 100%;
        margin-right: 10px;
    }
</style>

</head>

<body>
    <div class="container" id="con">
        <div class="loaderClass" id="loaderId">
            <div class="animation"></div>Loading
        </div>
    </div>
    <!--<div class="container" id="con1">-->
    <!--    <div class="loaderClass1" id="loaderId1">-->
    <!--        <div class="animation1"></div>Loading-->
    <!--    </div>-->
    <!--</div>-->
    <!-- Intro Modal -->
 
    <!-- Intro Modal -->
 