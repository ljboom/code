@extends($activeTemplate . 'layouts.app')
@section('panel')
    
    @yield('content')

   
@endsection
