@extends($activeTemplate . 'layouts.frontend')
@section('content')



<!-- Bootstrap -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">

<style>
    @import  url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap');
    html, body { margin: 0; height: 100%; background: #fff; font-family: 'Roboto', sans-serif; font-size: 15px; font-weight: 400; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; text-rendering: optimizeLegibility; text-shadow: rgba(0,0,0,.01) 0 0 1px; position: relative; }
    .body-bg { width: 100%; height: 100vh; position: fixed; background:     ) no-repeat center center; background-attachment: fixed; background-size: 100% 100%; opacity: 0.1; z-index: 1; }

    .container { width: 100%; max-width: 991px; padding: 60px 15px 0; position: relative; z-index: 2 !important; }


    .header { width: 100%; height: 48px; background-color:  rgb(8, 0, 52); font-size: 16px; font-weight: 500; line-height: 18px; padding-top: 16px; text-align: center; color: #fff !important; position: relative; }
    .header .left-arrow { font-size: 20px; color: #000; position: absolute; left: 15px; top: 15px; }

    .hl-box .top-lg-nav { width: calc(100% - 30px); height: fit-content; padding: 15px 0; margin: 0; background-color: #ffffff; border-radius: 15px; box-shadow: 0px 2px 7px rgba(0,0,0,.15); transform: translate(-50%, -50%); position: absolute; left: 50%; bottom: calc(-50% + 30px); display: flex; flex-direction: row; align-items: center; justify-content: start; flex-wrap: wrap; z-index: 2; }
    .hl-box .top-lg-nav a { width: 50%; height: fit-content; display: flex; flex-direction: row; align-items: center; justify-content: center; text-decoration: none; padding: 0 15px; border-left: 1px solid #e1e1e1; }
    .hl-box .top-lg-nav a:first-child { border-left: 0; }
    .hl-box .top-lg-nav a h6 { font-size: 16px; line-height: 16px; font-weight: 400; color: #121212; margin-bottom: 0; }
    .hl-box .top-lg-nav a img { width: 35px; height: 35px; margin-right: 10px; }

    button.btn.btn-circle { width: 60px; height: 60px; outline: 0; border: 0; padding: 0; margin: 0 auto; margin-bottom: 10px; }
    button.btn.btn-circle img { width: 100%; }
    .d-block.border-lft { position: relative; }
    .d-block.border-lft::before { content: ''; display: block; width: 1px; height: 60px; background-color: #ffffff; position: absolute; left: 0; top: 0; }

    .data-box { width: 100%; font-size: 12px; background: #0C2467; border-radius: 5px; display: flex; flex-direction: row; align-items: start; justify-content: space-between; text-align: center; padding: 15px 20px; }
    .data-box h6.small { font-size: 14px !important; }
    .data-box p { font-size: 15px !important; }

    nav.data-tabs { width: 100%; height: 50px; background: transparent; border: 0px; margin-bottom: 10px; }
    nav.data-tabs a.nav-link { background-color: #FFF; position: relative; font-size: 15px; line-height: 40px; font-weight: 400; padding: 0; height: 40px; color: #121212; margin-bottom: 10px !important; border: 1px solid #e1e1e1; border-radius: 10px; margin-right: 10px; }
    nav.data-tabs a.nav-link:last-child { margin-right: 0; }
    nav.data-tabs a.nav-link.active { color: #fff; background: linear-gradient(270deg,#f8b6b8,#815af3); border-color: linear-gradient(270deg,#f8b6b8,#815af3); }

    .data-list { width: calc(100% - 30px); height: fit-content; margin: 0 15px; padding: 20px 0; background: #fff; display: flex; flex-direction: row; align-items: center; justify-content: start; border-bottom: 1px solid #f3f3f3; }
    .data-list  p { font-size: 18px; line-height: 22px; font-weight: 600; color: #121212; margin-bottom: 4px; }
    .data-list h6 { font-size: 13px; line-height: 13px; font-weight: 400; color: #a2a2a2; margin-bottom: 3px; }
    .data-list h3 { font-size: 24px; line-height: 24px; font-weight: 700; color: #f01a4a; margin-bottom: 0px; margin-left: auto; }

    .text-yellow { color:#FFE393; }
    .text-grey { color: #8d8e90; }
    .text-orange { color: #FFAD41; }
    .text-blue { color: #f01a4a !important; }

    .invite-list .item { width: 100%; border-radius: 5px; height: 120px; background: linear-gradient(to bottom, #0C2467,#000000); padding: 10px; margin-bottom: 10px; }
    .invite-list .item h6.small { font-size: 12px; }

    .footer-nav { position: fixed; z-index: 100; left: 0px; bottom: 0px; width: 100%; height: 70px; background: transparent url(https://intuitive.fyi/img/footer-nav-bg.png) no-repeat left bottom; background-size: 100% 100%; display: flex; justify-content: space-between; align-items: center; }
    .footer-nav .nav-item { text-align: center; color: #848484; font-size: 12px; font-weight: 600; line-height: 12px; margin-top: 20px; width: 20%; }
    .footer-nav .nav-item img { height: 25px; margin: 0 auto 4px; filter: grayscale(100%); }
    .footer-nav .nav-item.center { margin-top: 4px; }
    .footer-nav .nav-item.center img { height: 42px; filter: grayscale(0); }
    .footer-nav .nav-item.active { color: #3dcbfa; }
    .footer-nav .nav-item.active img { filter: grayscale(0); }

    .checkin-box { width: 100%; height: 64px; border-radius: 4px; border: 2px solid; padding: 15px 20px; border-image: linear-gradient(270deg,#f8b6b8,#815af3) 1 1; clip-path: inset(0 round 4px); display: flex; flex-direction: row; align-items: center; justify-content: start; }
    .checkin-box img { width: 27px; height: 27px; margin-right: 5px; }
    .checkin-box .text { display: block; }
    .checkin-box .text p { font-size: 14px; font-weight: 600; color: #000; line-height: 17px; margin-bottom: 5px; }
    .checkin-box .text h6 { font-size: 10px; font-weight: 400; line-height: 14px; color: #7b7b7d; margin-bottom: 0; }
    .checkin-box .amt { font-size: 17px; font-weight: 700; background: linear-gradient(270deg,#f8b6b8,#815af3); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-left: auto; }
</style>

</head>

<body>
    <div class="header">
        <div class="left-arrow" onclick="window.location.href='{{route ('user.home')}}'"><i style="color: #fff" class="bi bi-chevron-left"></i></div>
        My Bill
    </div>


    <div class="container">
        <!-- <div class="hl-box mt-5">
            <p class="font-weight-bold text-center mb-3">Available Balance (₹)</p>
            <h4 class="font-weight-bold text-yellow text-center mb-4">                10</h4>
            <div class="d-flex flex-row align-items-start justify-content-between">
                <div class="btn-block w-100 text-center">
                    <button class="btn btn-circle" onclick="window.location.href='https://intuitive.fyi/@/pages/user/account/recharge'"><img src="https://intuitive.fyi/img/btn-recharge.png" alt=""></button>
                    <p>Recharge</p>
                </div>
                <div class="d-block w-100 text-center border-lft">
                    <button class="btn btn-circle" onclick="window.location.href='https://intuitive.fyi/@/withdraw'"><img src="https://intuitive.fyi/img/btn-withdraw.png" alt=""></button>
                    <p>Withdraw</p>
                </div>
            </div>
        </div> -->

        <nav class="data-tabs">
            <div class="nav nav-pills nav-justified" id="nav-tab" role="tablist">
                <a class="nav-link active" id="nav-one-tab" data-toggle="tab" href="#nav-one" role="tab" aria-controls="nav-one" aria-selected="true">Recharge</a>
                <a class="nav-link" id="nav-two-tab"  href="{{route ('user.withdraw.history')}}"  aria-controls="nav-two" aria-selected="false">Withdraw</a>
                <a class="nav-link" id="nav-three-tab" data-toggle="tab" href="#nav-three" role="tab" aria-controls="nav-three" aria-selected="false">All</a>
                <a class="nav-link" id="nav-plan-tab" data-toggle="tab" href="#nav-plan" role="tab" aria-controls="nav-plan" aria-selected="false">Plan</a>
            </div>
        </nav>
        <div class="tab-content" id="nav-tabContent">
            <div class="tab-pane fade show active" id="nav-one" role="tabpanel" aria-labelledby="nav-one-tab">


                                            @forelse($deposits as $deposit)
                <div class="checkin-box">
                    <img src="{{asset ('core/img/icon-mobile.png')}}">
                    <div class="text">
                        <p>Recharge</p>
                        <h6>{{ showDateTime($deposit->created_at, 'M d Y g:i:a') }}</h6>
                        <h6 class="text-blue mb-0">
                                            <span class="badge badge-">   @php echo $deposit->statusBadge @endphp</span>
                                        </h6>
                    </div>
                    <div class="amt">{{ $general->cur_text }} {{ showAmount($deposit->amount) }} </div>
                </div>

<br/>



                                


            </div>
            
                   @empty
                <div class="accordion-body text-center bg-white">
                    <h4 class="text--muted"><i class="far fa-frown"></i> {{ __($emptyMessage) }}</h4>
                </div>
            @endforelse
        </div>
        <div class="mt-3">
            {{ $deposits->links() }}
        </div>
    </div>
            
            
            
            <div class="tab-pane fade" id="nav-two" role="tabpanel" aria-labelledby="nav-two-tab">
                                                            </div>
            <div class="tab-pane fade" id="nav-three" role="tabpanel" aria-labelledby="nav-three-tab">

                                
     
        


<br/>



                                
            </div>
            
            
            
    
            
            
            
            
            
            <div class="tab-pane fade" id="nav-plan" role="tabpanel" aria-labelledby="nav-plan-tab">

                                                
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

</body>
</html>










    {{-- APPROVE MODAL --}}
    <div id="detailModal" class="modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">@lang('Details')</h5>
                    <span type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <i class="las la-times"></i>
                    </span>
                </div>
                <div class="modal-body">
                    <ul class="list-group userData mb-2">
                    </ul>
                    <div class="feedback"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark btn--sm" data-bs-dismiss="modal">@lang('Close')</button>
                </div>
            </div>
        </div>
    </div>
@endsection


@push('script')
    <script>
        (function($) {
            "use strict";
            $('.detailBtn').on('click', function() {
                var modal = $('#detailModal');

                var userData = $(this).data('info');
                var html = '';
                if (userData) {
                    userData.forEach(element => {
                        if (element.type != 'file') {
                            html += `
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span>${element.name}</span>
                                <span">${element.value}</span>
                            </li>`;
                        }
                    });
                }

                modal.find('.userData').html(html);

                if ($(this).data('admin_feedback') != undefined) {
                    var adminFeedback = `
                        <div class="my-3">
                            <strong>@lang('Admin Feedback')</strong>
                            <p>${$(this).data('admin_feedback')}</p>
                        </div>
                    `;
                } else {
                    var adminFeedback = '';
                }

                modal.find('.feedback').html(adminFeedback);


                modal.modal('show');
            });
        })(jQuery);
    </script>
@endpush
