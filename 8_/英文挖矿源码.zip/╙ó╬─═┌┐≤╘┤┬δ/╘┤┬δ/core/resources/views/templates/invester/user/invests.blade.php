@extends($activeTemplate . 'layouts.master')
@section('content')
    
    
    
    
    <!-- Bootstrap -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">

<style>
    @import  url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap');
    html, body { width: 100%; max-width: 991px; margin: 0 auto; font-family: 'Roboto', sans-serif; font-size: 15px; font-weight: 400; color: #333; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; text-rendering: optimizeLegibility; text-shadow: rgba(0,0,0,.01) 0 0 1px; position: relative; }
    .page { width: 100%; height: 100vh; background: #f8f7fb; position: relative; top: 0; left: 0; z-index: 5; }
    .header { width: 100%; height: fit-content; padding: 25px 15px 5px; font-size: 22px; line-height: 22px; font-weight: 500; color: #333c40; }
    .banner { width: 100%; height: 115px; background: #080034; border-radius: 0 0 17px 17px; padding: 15px; position: relative; }
    .banner .banner-inner { width: 100%; height: 100%; position: relative; background: linear-gradient(270deg,rgba(248,182,184,0),#815af3 50%,rgba(248,182,184,0)); display: flex; flex-direction: row; align-items: center; justify-content: start; }
    .banner .banner-inner::after { content: ''; display: block; width: 2px; height: 25px; background-color: rgba(255,255,255,0.3); position: absolute; transform: translate(-50%, -50%); left: 50%; top: 50%; }
    .banner .banner-inner .part { width: 50%; display: block; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .banner p { font-size: 21px; font-weight: 500; color: #ffd631; line-height: 25px; margin-bottom: 5px; }
    .banner h6 { font-family: 'Times New Roman', Times, serif; font-size: 14px; line-height: 16px; font-weight: 400; color: #fff; margin-bottom: 0; }

    .header { width: 100%; height: 48px; background-color:  rgb(8, 0, 52); font-size: 16px; font-weight: 500; line-height: 18px; padding-top: 16px; text-align: center; color: #fff !important; position: relative; }
    .header .left-arrow { font-size: 20px; color: #000; position: absolute; left: 15px; top: 15px; }
    .container { width: 100%; max-width: 991px; padding: 15px 15px 75px; }

    .title { font-family: 'Times New Roman', Times, serif; color: #333c40; font-size: 20px; font-weight: 700; text-align: center; margin: 6px 0; }

    .nav.nav-pills { width: 100%; padding: 5px 33px; }
    .nav.nav-pills a.nav-link { height: 35px; margin: 0 12px; padding: 0; background-color: transparent; border-radius: 4px; border: 2px solid; border-image: linear-gradient(270deg,#f8b6b8,#815af3) 2 2; clip-path: inset(0 round 4px); font-size: 16px; line-height: 31px; font-weight: 600; background: linear-gradient(270deg,#f8b6b8,#815af3); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .nav.nav-pills a.nav-link.active { background: linear-gradient(270deg,#f8b6b8,#815af3); border: 0; clip-path: inset(0 round 0); color: #fff; -webkit-text-fill-color: #fff; line-height: 35px; }

    .no-content { width: fit-content; margin: 50px auto 0; text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .no-content img { width: 185px; height: 185px; margin-bottom: 10px; }
    .no-content span { font-size: 14px; font-weight: 400; color: rgba(0,0,0,.7); }

    .footer-nav { width: 100%; max-width: 991px; height: 65px; background-color: #080034; border-radius: 17px 17px 0 0; box-shadow: 0 0 1rem 0 rgba(0,0,0,.1); position: fixed; z-index: 100; transform: translateX(-50%); left: 50%; bottom: 0; display: flex; flex-direction: row; align-items: center; justify-content: start; flex-wrap: wrap; }
    .footer-nav .nav { width: 20%; height: 100%; position: relative; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .footer-nav .nav img { width: 21px; height: 21px; margin-bottom: 3px; }
    .footer-nav .nav span { font-size: 12px; font-weight: 400; color: transparent; }
    .footer-nav .nav.active span { background: linear-gradient(270deg,#f8b6b8,#815af3); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .footer-nav .nav.center { top: -27px; }
    .footer-nav .nav.center img { width: 54px; height: 54px; }
    .footer-nav .nav.center.active img { width: 78px; height: 78px; }


    .checkin-box { width: 100%; height: 64px; border-radius: 4px; border: 2px solid; padding: 15px 20px; border-image: linear-gradient(270deg,#f8b6b8,#815af3) 1 1; clip-path: inset(0 round 4px); display: flex; flex-direction: row; align-items: center; justify-content: start; }
    .checkin-box img { width: 27px; height: 27px; margin-right: 5px; }
    .checkin-box .text { display: block; }
    .checkin-box .text p { font-size: 14px; font-weight: 600; color: #000; line-height: 17px; margin-bottom: 5px; }
    .checkin-box .text h6 { font-size: 12px; font-weight: 400; line-height: 14px; color: #7b7b7d; margin-bottom: 0; }
    .checkin-box .amt { font-size: 17px; font-weight: 700; background: linear-gradient(270deg,#f8b6b8,#815af3); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-left: auto; }
</style>

</head>

<body>
    <div class="page">
        <div class="header">
            <div class="left-arrow" onclick="history.back()"><i style="color: #fff" class=""></i></div>
            My Device
        </div>
        
     
                         @forelse($invests as $invest)
                  
        
   
        <div class="banner">
            <div class="banner-inner">
                <div class="part">
                    <p>{{ __($invest->plan->name) }}</p>
                    <h6> device name</h6>
                </div>
                <div class="part" onclick="window.location.href='#'">
                    <p>{{ $general->cur_text }} {{ showAmount(auth()->user()->interest_wallet) }}</p>
                    <h6>Device income</h6>
                </div>
            </div>
        </div>
                      
            
        
        <div class="container">
            <div class="title">&mdash; Device List &mdash;</div>
            <nav class="tab-list">
                <div class="nav nav-pills nav-justified" id="nav-tab" role="tablist">
                    <a class="nav-link active" id="nav-one-tab" data-toggle="tab" href="#nav-one" role="tab" aria-controls="nav-one" aria-selected="true">Start Date {{ showDateTime($invest->created_at, 'M d, Y h:i A') }}</a>
                    
                                        <a class="nav-link active" id="nav-one-tab" data-toggle="tab" href="#nav-one" role="tab" aria-controls="nav-one" aria-selected="true">Next Return {{ showDateTime($invest->next_time, 'M d, Y h:i A') }})</a>
                    
                    
                    
                                        <a class="nav-link active" id="nav-one-tab" data-toggle="tab" href="#nav-one" role="tab" aria-controls="nav-one" aria-selected="true">Total Income {{ $general->cur_sym }}{{ showAmount($invest->interest) }} x {{ $invest->return_rec_time }} = {{ showAmount($invest->paid) }} {{ $general->cur_text }}</a>
                    
                    
                    
                </div>
            </nav>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-one" role="tabpanel" aria-labelledby="nav-one-tab">

                    <br/>
                     
                                <div class="plan-start plan-inner-div">
                            <p class="plan-label">@lang('Start Date')</p>
                            <p class="plan-value date">{{ showDateTime($invest->created_at, 'M d, Y h:i A') }}</p>
                        </div>
                        <div class="plan-inner-div">
                            <p class="plan-label">@lang('Next Return')</p>
                            <p class="plan-value">{{ showDateTime($invest->next_time, 'M d, Y h:i A') }}</p>
                        </div>
                        <div class="plan-inner-div text-end">
                            <p class="plan-label">@lang('Total Return')</p>
                            <p class="plan-value amount"> {{ $general->cur_sym }}{{ showAmount($invest->interest) }} x {{ $invest->return_rec_time }} = {{ showAmount($invest->paid) }} {{ $general->cur_text }}</p>
                        </div>
                    </div>                


                        
                        
                                                                                            
                </div>
                   
                <div class="tab-pane fade" id="nav-two" role="tabpanel" aria-labelledby="nav-two-tab">
                       @empty
                    <div class="no-content">
                        <img src="https://intuitive.fyi/img/no-content-img.png">
                        <span>No content yet!</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
 
    @endforelse

            <div class="mt-3">
                {{ $invests->links() }}
            </div>
        </div>
    </div>

    
@endsection
@push('style')
    <style>
        .custom-progress {
            max-width: 40px !important;
            max-height: 40px;
            transform: rotate(-90deg);
        }

        .custom-progress .bg-circle {
            stroke: #00000011;
            fill: none;
            stroke-width: 4px;
            position: relative;
            z-index: -1;
        }

        .custom-progress .progress-circle {
            fill: none;
            stroke: hsl(var(--base));
            stroke-width: 4px;
            z-index: 11;
            position: absolute;
        }

        .expired-time-circle {
            position: relative;
            border: none !important;
            height: 38px;
            width: 38px;
            margin-right: 7px;
        }

        .expired-time-circle::before {
            position: absolute;
            content: '';
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            border: 4px solid #dbdce1;
        }

        .expired-time-circle.danger-border .animation-circle {
            border-color: hsl(var(--base)) !important;
        }

        .animation-circle {
            position: absolute;
            top: 0;
            left: 0;
            border: 4px solid hsl(var(--base));
            height: 100%;
            width: 100%;
            border-radius: 150px;
            transform: rotateY(180deg);
            animation-name: clipCircle;
            animation-iteration-count: 1;
            animation-timing-function: cubic-bezier(0, 0, 1, 1);
            z-index: 1;
        }

        .account-wrapper .left .top {
            margin-top: 0;
        }

        .account-wrapper .left,
        .account-wrapper .right {
            width: 100%;
        }

        .account-wrapper .right {
            padding-left: 0;
            margin-top: 35px;
        }

        @keyframes clipCircle {
            0% {
                clip-path: polygon(50% 50%, 50% 0%, 50% 0%, 50% 0%, 50% 0%, 50% 0%, 50% 0%, 50% 0%, 50% 0%, 50% 0%);
                /* center, top-center*/
            }

            12.5% {
                clip-path: polygon(50% 50%, 50% 0%, 0% 0%, 0% 0%, 0% 0%, 0% 0%, 0% 0%, 0% 0%, 0% 0%, 0% 0%);
                /* center, top-center, top-left*/
            }

            25% {
                clip-path: polygon(50% 50%, 50% 0%, 0% 0%, 0% 50%, 0% 50%, 0% 50%, 0% 50%, 0% 50%, 0% 50%, 0% 50%);
                /* center, top-center, top-left, left-center*/
            }

            37.5% {
                clip-path: polygon(50% 50%, 50% 0%, 0% 0%, 0% 50%, 0% 100%, 0% 100%, 0% 100%, 0% 100%, 0% 100%, 0% 100%);
                /* center, top-center, top-left, left-center, bottom-left*/
            }

            50% {
                clip-path: polygon(50% 50%, 50% 0%, 0% 0%, 0% 50%, 0% 100%, 50% 100%, 50% 100%, 50% 100%, 50% 100%, 50% 100%);
                /* center, top-center, top-left, left-center, bottom-left, bottom-center*/
            }

            62.5% {
                clip-path: polygon(50% 50%, 50% 0%, 0% 0%, 0% 50%, 0% 100%, 50% 100%, 100% 100%, 100% 100%, 100% 100%, 100% 100%);
                /* center, top-center, top-left, left-center, bottom-left, bottom-center, bottom-right*/
            }

            75% {
                clip-path: polygon(50% 50%, 50% 0%, 0% 0%, 0% 50%, 0% 100%, 50% 100%, 100% 100%, 100% 50%, 100% 50%, 100% 50%);
                /* center, top-center, top-left, left-center, bottom-left, bottom-center, bottom-right, right-center*/
            }

            87.5% {
                clip-path: polygon(50% 50%, 50% 0%, 0% 0%, 0% 50%, 0% 100%, 50% 100%, 100% 100%, 100% 50%, 100% 0%, 100% 0%);
                /* center, top-center, top-left, left-center, bottom-left, bottom-center, bottom-right, right-center top-right*/
            }

            100% {
                clip-path: polygon(50% 50%, 50% 0%, 0% 0%, 0% 50%, 0% 100%, 50% 100%, 100% 100%, 100% 50%, 100% 0%, 50% 0%);
                /* center, top-center, top-left, left-center, bottom-left, bottom-center, bottom-right, right-center top-right, top-center*/
            }
        }

        .capital-back {
            font-size: 10px;
        }

        .closed-invest {
            max-width: 40px !important;
            max-height: 40px;
            text-align: center;
        }
    </style>
@endpush

@push('script')
    <script>
        let animationCircle = $('.animation-circle');
        animationCircle.css('animation-duration', function() {
            let duration = ($(this).data('duration'));
            return duration;
        });
    </script>
@endpush
