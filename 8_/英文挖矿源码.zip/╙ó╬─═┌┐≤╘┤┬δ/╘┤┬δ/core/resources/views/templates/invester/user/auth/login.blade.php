@extends($activeTemplate.'layouts.app')
@section('panel')
@php
    $authContent = getContent('authentication.content',true);
@endphp

     
<!-- Bootstrap -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">

<style>
    @import  url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap');
    html, body { background: rgb(8, 0, 52); width: 100%; max-width: 991px; margin: 0 auto; font-family: 'Roboto', sans-serif; font-size: 15px; font-weight: 400; color: #333; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; text-rendering: optimizeLegibility; text-shadow: rgba(0,0,0,.01) 0 0 1px; position: relative; }
    .page { width: 100%; height: 100vh; background: rgb(8, 0, 52); position: relative; top: 0; left: 0; z-index: 5; }

    .container { width: 100%; max-width: 991px; padding: 25px 30px; }
    .banner { width: 100%; height: fit-content; position: relative; z-index: -1; }
    .banner .top-center { width: 300px; margin: 0 auto; position: relative; }
    .banner .top-text { width: 106px; position: absolute; transform: translateX(-50%); left: 50%; bottom: 18px; }
    .banner .top-logo { width: 71px; position: absolute; left: 0px; top: 15px; }
    .banner p { font-size: 13.5px; font-weight: 400; color: #fff; text-align: center; position: absolute; bottom: -15px; }

    .tab-links { width: 200px; margin: 25px auto 10px; display: flex; flex-direction: row; align-items: center; justify-content: space-between; }
    .tab-links .link { font-family: 'Times New Roman', Times, serif; font-size: 16px; font-weight: 500; color: #fff; cursor: pointer; }
    .tab-links .link-active { height: 46px; }

    form.login-form { margin: 0; }
    form.login-form .form-group { margin-bottom: 10px; }
    form.login-form label { font-family: 'Times New Roman', Times, serif; font-weight: 600; font-size: 12px; color: #fff; margin: 0 0 5px 25px; }
    form.login-form .input-group { width: 100%; height: 44px; background-color: #fff; border-radius: 4px; }
    form.login-form .input-group-text { background: transparent; border: 0; height: 44px; padding: 12px 0; }
    form.login-form .input-group-prepend .input-group-text img { width: 20px; height: 20px; margin: 0 10px 0 15px; }
    form.login-form .input-group-prepend .input-group-text span { font-size: 18px; line-height: 20px; font-weight: 500; color: rgb(163, 126, 248); margin-right: 10px; }
    form.login-form .input-group-append .input-group-text button.btn.btn-send { width: 50px; height: 30px; background: linear-gradient(270deg, rgb(248, 182, 184), rgb(129, 90, 243)); border: 0; border-radius: 3px; padding: 0; font-size: 14px; font-weight: 700; color: #fff; margin: 0 15px 0 10px; }
    form.login-form input.form-control { height: 44px; line-height: 44px; background-color: transparent; border-radius: 0; border: 0; padding: 0; font-size: 16px; font-weight: 400; color: #000; }
    form.login-form input.form-control::placeholder { color: #323233; }
    form.login-form .input-group-append .input-group-text .eye-close, form.login-form .input-group-append .input-group-text .eye-open { width: 25px; height: 25px; margin: 0 15px 0 10px; background: transparent url(https://intuitive.fyi/img/icon-eye-close.png) no-repeat center center; background-size: 100% auto; }
    form.login-form .input-group-append .input-group-text .eye-open { background-image: url(icon-eye-open.png); }

    form.login-form button.btn.login-btn { width: 265px; height: 44px; font-family: 'Times New Roman', Times, serif; font-size: 20px; font-weight: 400; color: #fff; background: linear-gradient(270deg, rgb(248, 182, 184), rgb(129, 90, 243)); border: 0px; border-radius: 4px; padding: 0; margin: 20px 0 20px; }
    form.login-form input.form-control:focus { box-shadow: none; }

    .forgot-link { font-family: 'Times New Roman', Times, serif; font-size: 15px; font-weight: 600; color: #f8b6b8; cursor: pointer; text-align: right; margin-top: 20px; }

    .footer-img { width: 97%; height: auto; position: absolute; transform: translateX(-50%); left: 50%; bottom: 0; z-index: -1; }

    .form-check { margin: 10px 0; }
    .form-check .form-check-label { font-family: 'Roboto', sans-serif; font-size: 14px; font-weight: 400; line-height: 20px; color: #fff; margin: 0; }
    .form-check .form-check-label a.link { color: #ffd500; text-decoration: underline; }
    input[type=checkbox] { position: relative; background: transparent url(img/agree-uncheck.png) no-repeat left top; background-size: 100% 100%; cursor: pointer; margin-right: 3px; outline: 0; padding: 0 !important; vertical-align: middle; height: 20px; width: 20px; -webkit-appearance: none; opacity: 1; top: -3px; }
    input[type=checkbox]:hover { opacity: 1; }
    input[type=checkbox]:checked { opacity: 1; background-image: url(); }

</style>

<style>
 

#con1 { display: none;  align-items: center; justify-content: center;
     
         position:absolute;
        max-width: 100%;
        height: auto;
        top: 57%;
        left: 50%;
        text-align: center;
        z-index: 999;
        transform: translate(-50%, -50%);
         
         
     }
    .loaderClass1 { height: 38px; width: fit-content; 
  padding: 0px 15px;
    background-color: rgba(0,0,0,1);
    font-size: 15px; font-weight: 300; 
    color: #ffffff; border-radius: 8px; 
    display: flex; align-items: center; z-index: 9999;
    
         
        
    }

.loaderClass1 .animation { width: 20px; height: 20px; background: url('')  no-repeat center center; background-size: 100% 100%; margin-right: 10px; }
   
  
     #con { display: none;  align-items: center; justify-content: center;
     
         position:absolute;
        max-width: 100%;
        height: auto;
        top: 57%;
        left: 50%;
        text-align: center;
        z-index: 999;
        transform: translate(-50%, -50%);
         
         
     }
    .loaderClass { height: 38px; width: fit-content; 
  padding: 0px 15px;
    background-color: rgba(0,0,0,1);
    font-size: 15px; font-weight: 300; 
    color: #ffffff; border-radius: 8px; 
    display: flex; align-items: center; z-index: 9999;
    
         
        
    }
    
    
    
    
    .loaderClass .animation { width: 20px; height: 20px; background: url('')  no-repeat center center; background-size: 100% 100%; margin-right: 10px; }
   
   
 .custom-toast {
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      background-color: black;
      color: white;
      padding: 10px 20px;
      border-radius: 5px;
      z-index: 9999;
      display: none;
        text-align: center;
      
      
    }
    @media (max-width: 767px) {
      .custom-toast {
        top: 50%; /* Center vertically */
        left: 50%; /* Center horizontally */
        transform: translate(-50%, -50%);
      }
    }
    
    .custom-toast.show {
      display: block;
     
    }
</style>

</head>

<body>
    <div class="container" id="con">
        <div class="loaderClass" id="loaderId">
            <div class="animation"></div>Loading
        </div>
    </div>
    <div class="page">
        <div class="container">
            <div class="banner">
                <div class="top-center"><img src="{{asset ('core/img/login-top-img.png')}}" class="w-100"></div>
                <div class="top-text"><img src="{{asset ('core/img/login-welcome.png')}}" class="w-100"></div>
         
                <div class="top-logo"><img src="" class="w-100"></div>
            </div>
            <div class="tab-links">
                <div class="link-active"><img src="{{asset ('core/img/login-tab-img.png')}}" class="h-100"></div>
                <div class="link" onclick="window.location.href='{{route ('user.register')}}'">Register</div>
            </div>
          
                       <form action="{{ route('user.login') }}" method="POST"  class="login-form" id="store_datas">
                    @csrf

            
                      <div class="form-group">
                    <label for="">Username</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                                <img src="{{asset ('core/img/icon-user.png')}}">
                                <span></span>
                            </div>
                        </div>
                        <input  class="form-control" type="text" name="username" placeholder="Please enter Username">
                    </div>
                </div>
                <div class="form-group">
                    <label for="">Password</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                                <img src="{{asset ('core/img/icon-lock.png')}}">
                            </div>
                        </div>
                        <input type="password" class="form-control"   name="password" placeholder="Please enter your password">
                        <div class="input-group-append">
                            <div class="input-group-text" onclick="showHide()">
                                <div class="eye-close" id="toggle-eye"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--<div class="forgot-link" onclick="window.location.href='https://intuitive.fyi/@/setpwd'">Forgot password?</div>-->
                <div class="text-center"><button type="submit"   class="btn login-btn">Login</button></div>
            </form>
        </div>
        <div class="footer-img"><img src="{{asset ('core/img/register-footer-img.png')}}" class="w-100"></div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>







         
 
@endsection
