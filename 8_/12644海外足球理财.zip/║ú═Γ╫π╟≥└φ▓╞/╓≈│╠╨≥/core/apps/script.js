window.onload = function(){
    document.querySelector(".loading_img").style.display = "none";
}