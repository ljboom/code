@extends($activeTemplate . 'layouts.master')
@section('content')

  <link rel="stylesheet" href="{{asset ('core/img/style.css')}}">
<div class="wrapper mine-page">
    <section class="history_header">
        <a class="recharge_history" href="{{route ('user.deposit.history')}}"><h3 style="color:black;">Recharge</h3></a>
        <a class="withdraw_history" href="{{route ('user.withdraw.history')}}"><h3 style="color:black;">Withdraw</h3></a>
    </section>
  @forelse($deposits as $deposit)
    <section class="recharge">
                        <div class="history_container">
                            
                            
                            
            <div style="display: flex;justify-content: space-between">
                
                   
            <span class="history_icon">
                <img src="{{asset ('core/img/recharged.png')}}">
            </span>
                <span>
                <h4 class="h_h4">Recharge</h4>
                <p class="h_p">{{ showDateTime($deposit->created_at, 'M d Y @g:i:a') }}</p>
            </span>
            </div>
            <div>
                <h4 class="h_price">{{ showAmount($deposit->amount) }} {{ $general->cur_text }}</h4>
                                    <p class="h_status">   @php echo $deposit->statusBadge @endphp</p>
                            </div>
        </div>
        
        
        
        
        
        
        
           
  
        
        
        
        
        
                    </section>
                        @empty
                <div class="accordion-body text-center bg-white">
                    <h4 class="text--muted"><i class="far fa-frown"></i> {{ __($emptyMessage) }}</h4>
                </div>
            @endforelse
                    
     
</div>

     
        
   


    


    {{-- APPROVE MODAL --}}
    <div id="detailModal" class="modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">@lang('Details')</h5>
                    <span type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <i class="las la-times"></i>
                    </span>
                </div>
                <div class="modal-body">
                    <ul class="list-group userData mb-2">
                    </ul>
                    <div class="feedback"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark btn--sm" data-bs-dismiss="modal">@lang('Close')</button>
                </div>
            </div>
        </div>
    </div>
@endsection


@push('script')
    <script>
        (function($) {
            "use strict";
            $('.detailBtn').on('click', function() {
                var modal = $('#detailModal');

                var userData = $(this).data('info');
                var html = '';
                if (userData) {
                    userData.forEach(element => {
                        if (element.type != 'file') {
                            html += `
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span>${element.name}</span>
                                <span">${element.value}</span>
                            </li>`;
                        }
                    });
                }

                modal.find('.userData').html(html);

                if ($(this).data('admin_feedback') != undefined) {
                    var adminFeedback = `
                        <div class="my-3">
                            <strong>@lang('Admin Feedback')</strong>
                            <p>${$(this).data('admin_feedback')}</p>
                        </div>
                    `;
                } else {
                    var adminFeedback = '';
                }

                modal.find('.feedback').html(adminFeedback);


                modal.modal('show');
            });
        })(jQuery);
    </script>
@endpush
