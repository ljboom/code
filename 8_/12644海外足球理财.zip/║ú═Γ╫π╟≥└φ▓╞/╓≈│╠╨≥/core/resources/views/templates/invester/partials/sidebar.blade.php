@php
    $promotionCount = App\Models\PromotionTool::count();
@endphp
 <!-- === Css Area Start === -->
    <link rel="stylesheet" href="{{asset ('core/apps/owl.carousel.min.css')}}">
    <link rel="stylesheet" href="{{asset ('core/apps/owl.theme.default.min.css')}}">
    <link rel="stylesheet" href="{{asset ('core/apps/global.css')}}">
    <link rel="stylesheet" href="{{asset ('core/apps/animate.css')}}">
    <link rel="stylesheet" href="{{asset ('core/apps/style.css')}}">
    <style>
        .chckin {
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background: #0000003b;
            z-index: 999;
        }

        .checkin_container {
            width: 85%;
            height: 250px;
            background: #fff;
            top: 50%;
            left: 50%;
            position: absolute;
            transform: translate(-50%, -50%);
            border-top-left-radius: 100px;
            border-top-right-radius: 100px;
            border-bottom-left-radius: 20px;
            border-bottom-right-radius: 20px;
        }

        img.check_gift_image {
            width: 130px;
            position: absolute;
            left: 50%;
            transform: translate(-50%);
            top: -60px;
        }

        .checkin_container h3 {
            margin-top: 100px;
            font-size: 18px;
            color: #ff6700;
        }

        .checkin_container h2 {
            font-size: 44px;
            margin-top: 5px;
            color: #fa5a02;
            font-weight: revert;
        }

        .checkin_container p {
            font-size: 15px;
            margin-top: 12px;
            margin-right: 20px;
            margin-left: 20px;
            color: #984f11;
        }

        .checkin_close {
            width: 40px;
            height: 40px;
            position: absolute;
            bottom: -49px;
            left: 50%;
            transform: translate(-50%);
            background: #ffffff66;
            text-align: center;
            line-height: 54px;
            border-radius: 50px;
        }

        .checkin_close i {
            font-size: 25px;
            color: #000;
        }
    </style>
</head>
<body>