@extends($activeTemplate.'layouts.master')
@section('content')
   <link rel="stylesheet" href="{{asset ('core/img/setting.css')}}">





<div class="setting_container">
    <div class="setting_banner" style="background: url('https://perview.freelancerawais.online/footballbank/core/img/image/assets_bg.png');padding: 50px 0;padding-bottom: 180px">
        <h2>
            <span style="top: 54px" onclick="window.location.href='https://cfc.31-0.com/mine'"><i class="fa fa-chevron-left"></i></span>
            Award
        </h2>
    </div>

    <div class="setting_body" style="width: 92%;top: 120px;left: 50%;transform: translate(-50%);padding: 20px 10px 30px 10px;">
        <div class="service_header">

        </div>
        <style>
            .invitation_link {
                font-size: 16px;
                color: rgb(18, 87, 48);
            }
            .invitation_box {
                background: rgb(18 87 48 / 13%);
                overflow: hidden;
                border-radius: 5px;
                padding: 3px 0px;
                margin-top: 15px;
            }
            .invitation_btn {
                background: rgb(18, 87, 48);
                color: #fff;
                text-align: center;
                height: 100%;
                padding: 15px 0;
                font-size: 15px;
                border-radius: 0 8px 8px 0;
            }
        </style>

        <div class="row mt-1">
            <div class="col-12">
                <div class="title">
                    <h2>Invitation code</h2>
                    <h1 style="color: rgb(18, 87, 48);margin-top: 10px">{{ auth()->user()->username }} (<small><i>copy</i></small>)</h1>
                </div>

                <div class="title" style="margin-top: 20px">
                    <h2>Invitation link</h2>
                    <div style="position: relative" class="invitation_box">
                        <div class="invitation_link" style="width: 80%;float: left">
                           {{ route('home') }}?reference={{ auth()->user()->username }}
                        </div>
                        <div class="invitation_btn" style="width: 20%;float: left"  class="tooltiptext" id="myTooltip"      onclick="myFunction()" onmouseout="outFunc()">
                            Copy
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        
        
        
        
		<div id="appCapsule" class="pb-2">

			<div class="appContent pb-0 mt-4  mx-4 banyue">
				<section class="container dew">
					<div class="demo">
					
					<h3><font style="color:red;" >  </h3></font> 

				</section>
				
			</div>
	

		</div>



	
		</div>

	
	</div>
	<style>
.tooltip {
  position: relative;
  display: inline-block;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 140px;
  background-color: #555;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 5px;
  position: absolute;
  z-index: 1;
  bottom: 150%;
  left: 50%;
  margin-left: -75px;
  opacity: 0;
  transition: opacity 0.3s;
}

.tooltip .tooltiptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #555 transparent transparent transparent;
}

.tooltip:hover .tooltiptext {
  visibility: visible;
  opacity: 1;
}
</style>
	<div style="display:none;">
<input type="text" value="{{ route('home') }}?reference={{ auth()->user()->username }}" id="myInput">
</div>

	
	
	
	
<script>
function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  copyText.setSelectionRange(0, 99999);
  navigator.clipboard.writeText(copyText.value);
  
  var tooltip = document.getElementById("myTooltip");
  tooltip.innerHTML = "Copied: " + copyText.value;
}

function outFunc() {
  var tooltip = document.getElementById("myTooltip");
  tooltip.innerHTML = "Copy to clipboard";
}
</script>



        
        
        
        
        
        
        
        
        <style>
            .gift_box {
                width: 50px;
                height: 50px;
                margin: auto;
                background: #e5d900;
                text-align: center;
                line-height: 50px;
                border-radius: 50px;
                margin-top: 10px;
            }
            .r_item_kamal {
                background: #fff;
                position: absolute;
                top: 85px;
                border-radius: 10px 10px 0 0;
                padding: 19px 10px;
            }
            .r_item_kamal p {
                font-size: 14px;
                margin-left: 8px;
                color: #000000cf;
            }

        </style>
<!--        <div class="reword_item_banner" style="margin-top: 30px">-->
<!--            <div class="r_banner" style="position: relative">-->
<!--                <img style="width: 100%" src="https://cfc.31-0.com/public/footbal/assets/image/fund-banner.png">-->
<!--                <div class="r_item_kamal">-->
<!--                    <div style="display: flex;justify-content: space-between">-->
<!--                        <div>-->
<!--                            <div class="gift_box" style="text-align: center">-->
<!--                                <img src="https://cfc.31-0.com/public/footbal/assets/image/gift.png">-->
<!--                            </div>-->
<!--                        </div>-->
<!--                        <div>-->
<!--                            <p>Invite and register <span style="color: #12773d">30</span> users. you can get a special <span style="color: #12773d">VIP</span> and increment you daily income from <span style="color: #12773d">refer commission</span>, <span>and others commission</span> </p>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                    <div style="display: flex;justify-content: space-between;margin-top: 15px">-->
<!--                        <div>-->
<!--                            <h3 style="font-size: 18px"><span style="color: rgb(18, 87, 48)">0 </span> / 30</h3>-->
<!--                            <p style="margin-left: 0">Number of invites</p>-->
<!--                        </div>-->
<!--                        <div>-->
<!--                            <button-->
<!---->
<!--                                class="btn active"-->
<!--                                style="border: none"-->
<!--                                onclick="fillup_30_user()"-->
<!--                            >-->
<!--                                Receive-->
<!--                            </button>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->

        <hr>

      

    </div>
</div>









@endsection
@push('script')
<script>
    $('input[name=amount]').on('input',function(){
        var amo = parseFloat($(this).val());
        var calculation = amo + ( parseFloat({{ $general->f_charge }}) + ( amo * parseFloat({{ $general->p_charge }}) ) / 100 );
        if (calculation) {
            $('.calculation').text(calculation+' {{ $general->cur_text }} will cut from your selected wallet');
        }else{
            $('.calculation').text('');
        }
    });

    $('.findUser').on('focusout',function(e){
        var url = '{{ route('user.findUser') }}';
        var value = $(this).val();
        var token = '{{ csrf_token() }}';

        var data = {username:value,_token:token}
        $.post(url,data,function(response) {
            if (response.message) {
                $('.error-message').text(response.message);
            }else{
                $('.error-message').text('');
            }
        });
    });
</script>
@endpush
