@extends("$activeTemplate.layouts.$layout")
@section('content')



    @stack('style-lib')



                    @include($activeTemplate.'partials.plan', ['plans' => $plans])
    
@endsection
