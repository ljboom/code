@extends($activeTemplate . 'layouts.app')
@section('panel')
    @php
        $authContent = getContent('authentication.content', true);
    @endphp
     
    <link rel="icon" href="https://perview.freelancerawais.online/footballbank/core/apps/public/footbal/assets/image/favicon.ico">
    <!-- === Font awesome === -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- === Css Area Start === -->
    <link rel="stylesheet" href="https://perview.freelancerawais.online/footballbank/core/apps/public/footbal/assets/css/login.css">

    <body style="background-color:#00008B;">

    <style>
        .phone_code_container .phone_code_area {
            background: transparent;
        }
        .input_control {
            background: #00000014;
        }
        .phone_code {
            background: transparent;
        }
        .phone_code_container .phone_code_area {
            background: #00000014;
        }
        .phone_code {
            top: 30px;
        }
        .phone_code_container .phone_code_area {
            border-radius: 10px;
        }
        .login_container {
            width: 96%;
        }
        body {
    background-attachment: fixed !important;
}
    </style>
</head>
<body>
<script src="{{asset ('core/apps/public/assets/toast.js')}}"></script>
<script>
    
    
    </script>





















                   


                    <form action="{{ route('user.register') }}" method="POST" class="verify-gcaptcha account-form">
                        @csrf








<div class="loader">
    <img class="loading_img" src="{{asset ('core/apps/public/footbal/assets/image/loding.jpg')}}" style="position: fixed;z-index: 999;width: 100px;top: 50%;left: 50%;transform: translate(-50%, -50%);">
</div>
<div class="login_container">
    <div class="login_text">
        <h2 class="register_header" style="padding-top:50px">Complete registration to receive cash rewards</h2>
        <div class="dollor_img" style="top:78px;">
            <img class="shot" src="{{asset ('core/apps/public/footbal/assets/image/regidter_shot.png')}}">
        </div>
    </div>

    <div style="margin-top:35%;">
                 <div class="regi-form">
                <div class="register-form-container phone_code_container">
                    <div class="phone_input input">
                        
                           <input type="text"  placeholder="Please enter Username" class="input_control"  name="username" value="{{ old('username') }}" required>
                        
                        
                        

                        <div class="phone_code"></div>
                    </div>

                    <div class="password_input input">
                        <input type="email"  placeholder="Enter Your Email" class="input_control" name="email" value="{{ old('email') }}" required>
                        
                        
                        
                       
                    </div>


   <div class="form-group    " style="display:none;" >
                                    <label class="form-label">@lang('Country')</label>
                                    <select name="country" class="form--control form-select">
                                        @foreach ($countries as $key => $country)
                                            <option data-mobile_code="{{ $country->dial_code }}" value="{{ $country->country }}" data-code="{{ $key }}">
                                                {{ __($country->country) }}</option>
                                        @endforeach
                                    </select>
                                </div>




                    <div class="password_input input">
                        
                        
                         <input type="hidden" name="mobile_code">
                                        <input type="hidden" name="country_code">
                                        <input type="number" name="mobile" value="{{ old('mobile') }}" placeholder="Enter confirm Mobile Number" class="input_control" required>
                        

                    </div>

        <div class="password_input input">
                        

                        
                        
                                      <input type="password" placeholder="Enter  Password" class="input_control"  name="password" required>
                                    @if ($general->secure_password)
                                        <div class="input-popup">
                                            <p class="error lower">@lang('1 small letter minimum')</p>
                                            <p class="error capital">@lang('1 capital letter minimum')</p>
                                            <p class="error number">@lang('1 number minimum')</p>
                                            <p class="error special">@lang('1 special character minimum')</p>
                                            <p class="error minimum">@lang('6 character password')</p>
                                        </div>
                                    @endif
                        
                        
                        
                        
                        
                        
                        
                        

                    </div>



        <div class="password_input input">
                        
                        
                 <input type="password" placeholder="Enter confirm Password" class="input_control" name="password_confirmation" required>
    
                        

                    </div>
             
                
                
                
                
      @if (session()->get('reference') != null)
                            

  
            

        <div class="password_input input">
                        
                        
                 <input type="text" name="referBy" class="input_control"  value="{{ session()->get('reference') }}" disabled>
    
                        

                    </div>
                         
@endif
          <div class="term_condition">
                        <h5 class="term_condition_text">
                            <span class="term_condition_check"><i class="fa fa-check"></i></span>
                            <span class="term_condition_agr">Agree to the</span>
                            <span class="term_condition_under"><a href="">user registration agreement</a></span>
                        </h5>
                    </div>
                </div>
            </div>
                
      
            <div class="login_btn_input input" style="padding-top: 35px">
                <button class="login_btn">Sign up</button>
            </div>
            <div class="go_regi_or_login">
                <a href="{{route ('user.login')}}">Log in</a>
            </div>

            <div style="height:60px"></div>
        </form>
    </div>
</div>
<script>
    window.onload = function(){
        document.querySelector(".loading_img").style.display = "none";
    }
</script>
</body>
</html>

    
    
    



@endsection

@if ($general->secure_password)
    @push('script-lib')
        <script src="{{ asset('assets/global/js/secure_password.js') }}"></script>
    @endpush
@endif

@push('script')
    <script>
        "use strict";
        (function($) {
            @if ($mobileCode)
                $(`option[data-code={{ $mobileCode }}]`).attr('selected', '');
            @endif
            $('select[name=country]').change(function() {
                $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
                $('input[name=country_code]').val($('select[name=country] :selected').data('code'));
                $('.mobile-code').text('+' + $('select[name=country] :selected').data('mobile_code'));
            });
            $('input[name=mobile_code]').val($('select[name=country] :selected').data('mobile_code'));
            $('input[name=country_code]').val($('select[name=country] :selected').data('code'));
            $('.mobile-code').text('+' + $('select[name=country] :selected').data('mobile_code'));
            $('.checkUser').on('focusout', function(e) {
                var url = '{{ route('user.checkUser') }}';
                var value = $(this).val();
                var token = '{{ csrf_token() }}';
                if ($(this).attr('name') == 'mobile') {
                    var mobile = `${$('.mobile-code').text().substr(1)}${value}`;
                    var data = {
                        mobile: mobile,
                        _token: token
                    }
                }
                if ($(this).attr('name') == 'email') {
                    var data = {
                        email: value,
                        _token: token
                    }
                }
                if ($(this).attr('name') == 'username') {
                    var data = {
                        username: value,
                        _token: token
                    }
                }
                $.post(url, data, function(response) {
                    if (response.data != false && response.type == 'email') {
                        $('#existModalCenter').modal('show');
                    } else if (response.data != false) {
                        $(`.${response.type}Exist`).text(`${response.type} already exist`);
                    } else {
                        $(`.${response.type}Exist`).text('');
                    }
                });
            });
        })(jQuery);
    </script>
@endpush
