@extends($activeTemplate.'layouts.app')
@section('panel')



    @include($activeTemplate.'partials.sidebar')



            @yield('content')
<!-- menu area -->
<div class="menu-area">
    <ul class="menu">
        <li class="menu-item active">
            <a href="{{route ('user.home')}}">
                    <span class="menu-content">
                        <span class="menu-icon">
                            <img src="{{asset ('core/img/hom.png')}}">
                           <img src="{{asset ('core/img/hom.png')}}"
                                 class="image-active">
                        </span>
                        <span class="menu-name">home</span>
                    </span>
            </a>
        </li>
        <li class="menu-item">
            <a href="{{route ('user.invest.log')}}">
                    <span class="menu-content">
                        <span class="menu-icon">
                            <img src="{{asset ('core/img/notice.png')}}">
                            <img src="{{asset ('core/img/motic-active.png')}}"
                                 class="image-active">
                        </span>
                        <span class="menu-name">order</span>
                    </span>
            </a>
        </li>
        <li class="menu-item">
            <a href="{{route ('user.deposit.history')}}">
                    <span class="menu-content">
                        <span class="menu-icon">
                            <img src="{{asset ('core/img/stock.png')}}">
                            <img src="{{asset ('core/img/stock-active.png')}}"
                                 class="image-active">
                        </span>
                        <span class="menu-name">fund</span>
                    </span>
            </a>
        </li>
        <li class="menu-item">
            <a href="{{ route('user.referrals') }}">
                    <span class="menu-content">
                        <span class="menu-icon">
                            <img src="{{asset ('core/img/apps.png')}}">
                            <img src="{{asset ('core/img/apps-active.png')}}"
                                 class="image-active">
                        </span>
                        <span class="menu-name">team</span>
                    </span>
            </a>
        </li>
        <li class="menu-item">
            <a href="{{ route('user.twofactor') }}">
                    <span class="menu-content">
                        <span class="menu-icon">
                            <img src="{{asset ('core/img/profile.png')}}">
                            <img src="{{asset ('core/img/profile-active.png')}}"
                                 class="image-active">
                        </span>
                        <span class="menu-name">mine</span>
                    </span>
            </a>
        </li>
    </ul>
</div>



@endsection
