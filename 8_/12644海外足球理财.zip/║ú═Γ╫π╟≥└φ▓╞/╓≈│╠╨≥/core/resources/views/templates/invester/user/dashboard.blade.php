@extends($activeTemplate.'layouts.master')
@section('content')
       @php
        $content = getContent('footer.content',true);
    @endphp
   
<script src="{{asset ('core/apps/toast.js')}}"></script>
<script>
    
    
            message('Login Success')
    </script>
































<div class="loader">
    <img class="loading_img" src="{{asset ('core/apps/public/footbal/assets/image/loding.jpg')}}"
         style="position: fixed;z-index: 999;width: 100px;top: 50%;left: 50%;transform: translate(-50%, -50%);">
</div>

<div class="wrapper">
    <!-- notice section -->
    <section class="notice-section">
        <div class="container">
            <div class="notice-area">
                <img src="{{asset ('core/img/notice-img.png')}}">
                <marquee   direction="left" scrollamount="3"    >
        {{ __($content->data_values->content) }}
                </marquee>
            </div>
        </div>
    </section>
   <!-- slider section -->
    <section class="slider-section">
        <div class="container">
            <div class="slider-area">
                <div class="owl-carousel owl-theme owl-loaded">
                                            <div class="single-slider">
                            <img src="{{asset ('core/img/16858678404nL.jpg')}}" alt="">
                        </div>
                                          
                                    </div>
            </div>
        </div>
    </section>


</body>
</html>
    <!-- purchase section -->
    <!--<section class="user-purchase-section">-->
    <!--    <div class="container">-->
    <!--        <div class="purchase-area">-->
    <!--            <marquee behavior="scroll" direction="up">-->
    <!--                <div class="single-purchase">-->
    <!--                    <div class="icon">-->
    <!--                        <img src="https://cfc.31-0.com/public/footbal/assets/image/content/mike.png">-->
    <!--                    </div>-->
    <!--                    <div class="info">-->
    <!--                        <p>User 317$$$$630 purchase 1500.00 product</p>-->
    <!--                        <p><span>19/05/2023</span> <span>15:08:24</span></p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="single-purchase">-->
    <!--                    <div class="icon">-->
    <!--                        <img src="https://cfc.31-0.com/public/footbal/assets/image/content/mike.png">-->
    <!--                    </div>-->
    <!--                    <div class="info">-->
    <!--                        <p>User 317$$$$630 successfully recharge 1500</p>-->
    <!--                        <p><span>19/05/2023</span> <span>15:08:24</span></p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="single-purchase">-->
    <!--                    <div class="icon">-->
    <!--                        <img src="https://cfc.31-0.com/public/footbal/assets/image/content/mike.png">-->
    <!--                    </div>-->
    <!--                    <div class="info">-->
    <!--                        <p>User 317$$$$630 purchase 1500.00 product</p>-->
    <!--                        <p><span>19/05/2023</span> <span>15:08:24</span></p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="single-purchase">-->
    <!--                    <div class="icon">-->
    <!--                        <img src="https://cfc.31-0.com/public/footbal/assets/image/content/mike.png">-->
    <!--                    </div>-->
    <!--                    <div class="info">-->
    <!--                        <p>User 317$$$$630 successfully recharge 1500</p>-->
    <!--                        <p><span>19/05/2023</span> <span>10:08:24</span></p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="single-purchase">-->
    <!--                    <div class="icon">-->
    <!--                        <img src="https://cfc.31-0.com/public/footbal/assets/image/content/mike.png">-->
    <!--                    </div>-->
    <!--                    <div class="info">-->
    <!--                        <p>User 317$$$$630 purchase 1500.00 product</p>-->
    <!--                        <p><span>19/05/2023</span> <span>11:08:24</span></p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="single-purchase">-->
    <!--                    <div class="icon">-->
    <!--                        <img src="https://cfc.31-0.com/public/footbal/assets/image/content/mike.png">-->
    <!--                    </div>-->
    <!--                    <div class="info">-->
    <!--                        <p>User 317$$$$630 successfully recharge 1500</p>-->
    <!--                        <p><span>19/05/2023</span> <span>04:08:24</span></p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="single-purchase">-->
    <!--                    <div class="icon">-->
    <!--                        <img src="https://cfc.31-0.com/public/footbal/assets/image/content/mike.png">-->
    <!--                    </div>-->
    <!--                    <div class="info">-->
    <!--                        <p>User 367$$$$680 successfully recharge 1500</p>-->
    <!--                        <p><span>19/06/2023</span> <span>07:08:24</span></p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--                <div class="single-purchase">-->
    <!--                    <div class="icon">-->
    <!--                        <img src="https://cfc.31-0.com/public/footbal/assets/image/content/mike.png">-->
    <!--                    </div>-->
    <!--                    <div class="info">-->
    <!--                        <p>User 417$$$$600 successfully recharge 1500</p>-->
    <!--                        <p><span>19/03/2023</span> <span>04:08:24</span></p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </marquee>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->
    <!-- assets section -->
    <section class="assets-section">
        <div class="container">
            <div class="assets-area">
                <div class="single-assets">
                    <p>Total assets</p>
                    <p>{{ showAmount(auth()->user()->interest_wallet) }} {{ $general->cur_text }} <i class="fa-solid fa-angle-right"></i></p>
                </div>
                <div class="single-assets">
                    <p>Total Recharge</p>
                    <p>{{ showAmount(auth()->user()->deposit_wallet) }}  {{ $general->cur_text }}<i class="fa-solid fa-angle-right"></i></p>
                </div>
            </div>
        </div>
    </section>
    <!-- remainder section -->
    <section class="reminder-section">
        <div class="container">
            <div class="reminder-area">
                <img src="{{asset ('core/img/time.f05135e1.png')}}">
                <p>Welcome To Our Website
</p>
            </div>
        </div>
    </section>
  
      @php
        $plans = App\Models\Plan::where('status', 1)
            ->where('featured', 1)
            ->get();
        $gatewayCurrency = null;
        if (auth()->check()) {
            $gatewayCurrency = App\Models\GatewayCurrency::whereHas('method', function ($gate) {
                $gate->where('status', 1);
            })
                ->with('method')
                ->orderby('method_code')
                ->get();
        }
    @endphp

    @include($activeTemplate . 'partials.plan', ['plans' => $plans])
        
                   
   
<div class="easy-access">
    <div class="spinner" onclick="checkin()">
        <img class="spin-round" src="{{asset ('core/img/spinner-round.png')}}">
        <img class="spin-indicator" src="{{asset ('core/img/spinner.png')}}">
    </div>
    <div class="telegram">
        <a href="https://wa.me/+918194092853">
            <img src="{{asset ('core/img/telegram.png')}}">
        </a>
    </div>
</div>


<div class="chckin" style="display: none">
    <div class="checkin_container" style="text-align: center">
        <img class="check_gift_image" src="{{asset ('core/img/Lovepik_com-400303719-colorful-football.png')}}">
        <h3> Earn Money By Small Plans </h3>
 <p> We Are Recommend this Platoform </p>
        <div class="checkin_close" onclick="close_check_in()">
            <i class="fa fa-close"></i>
        </div>
    </div>
</div>

<style>
    .noticed {
        width: 100%;
        height: 100%;
        position: fixed;
        background: #0000005c;
        top: 0;
        z-index: 999;
        left: 0;
    }

    .noticed_container {
        width: 92%;
        background: #fff;
        height: 400px;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        border-radius: 12px;
    }

    .noticed_header {
        height: 100px;
        width: 100%;
    }

    .noticed_body {
        height: 200px;
        width: 100%;
        padding: 0px 10px;
        overflow: scroll;
    }

    .noticed_footer {
        height: 100px;
        width: 100%;
    }

    img.noticed_image {
        width: 100%;
        position: absolute;
        left: 76px;
        top: -144px;
    }

    .noticed_header_text h3 {
        font-size: 25px;
        margin: 19px 0 0 15px;
    }

    .noticed_header_text p {
        margin: 6px 0 0 15px;
        font-size: 17px;
        color: #0000009e;
    }
    .noticed_main_text {
        font-size: 18px;
    }
    .noticed_footer a {
        display: block;
        margin: 22px 16px;
        padding: 15px 0;
        text-align: center;
        font-size: 18px;
    }
    .noticed_icon {
        font-size: 25px;
        width: 40px;
        height: 40px;
        position: absolute;
        left: 50%;
        transform: translate(-50%);
        margin-top: 21px;
        background: #ffffffa1;
        text-align: center;
        line-height: 44px;
        border-radius: 50px;
    }
</style>

<div style="display: none" class="noticed">
    <div class="noticed_container">
        <div class="noticed_header">
            <div style="display: flex;justify-content: space-between;">
                <div class="noticed_header_text">
                    <h3>Announcement</h3>
                    <p>Latest news release</p>
                </div>
                <div>
                    <img class="noticed_image"
                         src="{{asset ('core/img/Lovepik_com-400303719-colorful-football.png')}}">
                </div>
            </div>
        </div>
  
        <div class="noticed_body">
            <div class="noticed_main_text">
                <p>
                    {{ __($content->data_values->content) }}
                    

                </p>
                
             
                
                <p style="padding:20px 0;">
                    <a href="{{ route('ticket.index') }}"></a>
                </p>
            </div>
        </div>
        <div class="noticed_footer">
            <a href="{{ route('ticket.index') }}" class="btn active">Contact Customer Service</a>
            <div class="noticed_icon" onclick="close_noticed()">
                <i class="fa fa-close"></i>
            </div>
        </div>
    </div>
</div>

<script src="{{asset ('core/apps/jquery-3.7.0.min.js')}}"></script>
<script src="{{asset ('core/apps/owl.carousel.min.js')}}"></script>
<script src="{{asset ('core/apps/script.js')}}"></script>


<script>
    window.onload = function() {
        var notice = '1';
        if(notice == true){
            document.querySelector('.noticed').style.display = 'block';
        }
        
        document.querySelector('.loading_img').style.display = 'none';
    }
    
        

    function close_noticed(){
        document.querySelector('.noticed').style.display = 'none';
    }

    function checkin() {
        document.querySelector('.chckin').style.display = 'block';
        var URL = ''
        fetch(URL, {
            method: 'post',
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Requested-With": "XMLHttpRequest",
                "X-CSRF-Token": document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
        }).then(function (response) {
            return response.json();
        }).then(function (res) {
            message(res.message)
        })
            .catch(function (error) {
                console.log(error)
            });
    }

    function close_check_in() {
        document.querySelector('.chckin').style.display = 'none';
    }

    function open_purchase_modal(div) {
        document.getElementById(div).style.display = 'block';
    }

    function buy_modal_close(div) {
        document.getElementById(div).style.display = 'none';
    }

    $(document).ready(function () {
        $(".owl-carousel").owlCarousel({
            items: 1,
            loop: true,
            autoplay: true,
            autoplaySpeed: 500,
        });
    });
</script>
</body>
</html>

@endsection

@push('script')
<script src="{{ asset($activeTemplateTrue.'/js/lib/apexcharts.min.js') }}"></script>

<script>

    // apex-line chart
    var options = {
        chart: {
            height: 350,
            type: "area",
            toolbar: {
                show: false
            },
            dropShadow: {
                enabled: true,
                enabledSeries: [0],
                top: -2,
                left: 0,
                blur: 10,
                opacity: 0.08,
            },
            animations: {
                enabled: true,
                easing: 'linear',
                dynamicAnimation: {
                    speed: 1000
                }
            },
        },
        dataLabels: {
            enabled: false
        },
        series: [
            {
                name: "Price",
                data: [
                    @foreach($chartData as $cData)
                        {{ getAmount($cData->amount) }},
                    @endforeach

                ]
            }
        ],
        fill: {
            type: "gradient",
            colors: ['#4c7de6', '#4c7de6', '#4c7de6'],
            gradient: {
                shadeIntensity: 1,
                opacityFrom: 0.6,
                opacityTo: 0.9,
                stops: [0, 90, 100]
            }
        },
        xaxis: {
            title: "Value",
            categories: [
                @foreach($chartData as $cData)
                "{{ Carbon\Carbon::parse($cData->date)->format('d F') }}",
                @endforeach
            ]
        },
        grid: {
            padding: {
                left: 5,
                right: 5
            },
            xaxis: {
                lines: {
                    show: false
                }
            },
            yaxis: {
                lines: {
                    show: false
                }
            },
        },
    };

    var chart = new ApexCharts(document.querySelector("#chart"), options);

    chart.render();

    @if($isHoliday)
        function createCountDown(elementId, sec) {
            var tms = sec;
            var x = setInterval(function () {
                var distance = tms * 1000;
                var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                var days = `<span>${days}d</span>`;
                var hours = `<span>${hours}h</span>`;
                var minutes = `<span>${minutes}m</span>`;
                var seconds = `<span>${seconds}s</span>`;
                document.getElementById(elementId).innerHTML = days +' '+ hours + " " + minutes + " " + seconds;
                if (distance < 0) {
                    clearInterval(x);
                    document.getElementById(elementId).innerHTML = "COMPLETE";
                }
                tms--;
            }, 1000);
        }

        createCountDown('counter', {{\Carbon\Carbon::parse($nextWorkingDay)->diffInSeconds()}});
    @endif

    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })

</script>
@endpush
