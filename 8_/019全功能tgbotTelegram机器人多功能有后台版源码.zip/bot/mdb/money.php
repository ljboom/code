<?php
namespace bot\mdb;

use think\Model;

class money extends Model {
    //数据表名
    protected $name = 'money_set';
    // 模型数据不区分大小写
    protected $strict = true;
    // 数据转换为驼峰命名
    protected $convertNameToCamel = false;
    //自动时间戳
    protected $autoWriteTimestamp = true; 
    // 设置json类型字段
    protected $json = ['json'];
    // 设置JSON数据返回数组
    protected $jsonAssoc = true;
}