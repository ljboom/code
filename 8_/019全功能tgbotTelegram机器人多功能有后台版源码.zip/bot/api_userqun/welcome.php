<?php
namespace bot\api_userqun;

use app\model;                          #模型  
use bot\mdb;                            #模型2  
use think\facade\Db;                    #数据库
use think\facade\Cache;                 #缓存
use support\Redis;                      #redis
use Webman\RedisQueue\Client as RQamsg; #异步队列
use Webman\RedisQueue\Redis as   RQmsg; #同步队列 

//对应类文件
use plugin\tgbot\app\controller\Base;
use plugin\tgbot\app\controller\Template;

use GuzzleHttp\Pool;
use GuzzleHttp\Client as Guzz_Client;
use GuzzleHttp\Psr7\Request as Guzz_Request; 
use GuzzleHttp\Promise as Guzz_Promise;  

#这是通用的用户进出群消息  - 都会触发里面的代码  - 你可以新建N个文件干不同的事
class welcome  { 
    /**
     * 【参数解答】
     * $message['bot']          =   机器人配置信息
     * $message['msgId']        =   聊天消息唯一ID
     * 
     * $message['chatType']     =   群组频道类型
     * $message['chatId']       =   群组ID
     * $message['chatUser']     =   群组用户名(@xxx)
     * $message['chatName']     =   群组=群名称
     * 
     * $message['status']       =   事件类型:new 新入群  exit退出群
     * 
     * $message['formId']       =   事件成员ID
     * $message['formUser']     =   事件成员用户名
     * $message['formName']     =   事件成员昵称
     * $message['fromVip']      =   事件成员是否是电报VIP 0否 1是
     * $message['fromLang']     =   事件成员电报客户端语言(多语言需要)
     * 
     * $message['isBot']        =   是否为机器人
     * 
     * $message['time']         =   消息到达-服务器时间戳  
     * $message['tgTime']       =   消息到达-电报官方时间戳 
     * 
     * $ret支持回调参数：sendText(文本消息) sendPhoto(发送照片)  sendVideo(发送视频)  anniu(消息按钮)   [ jianpan(回复键盘) && jianpanText(文字消息) || jianpanPhoto(照片消息)]
     */ 
    public function index($message){ 
        $ret['key']=pathinfo(basename(__FILE__), PATHINFO_FILENAME); //自动定义文件key 用于鉴权机器人是否有权使用该模块 
        $ret['level']=100; //优先级 (当存在多个模块都返回了文本消息或按钮时生效)数值大排上面 ，数值小排下面
        if(!isset($message['bot']['appStore'][$ret['key']])){
            return $ret;
        }
        #-----------------以上核心代码勿动 level 视情况调整改动--------------------------
        if($message['chatType'] != "supergroup"){//判断是不是群
            return $ret;
        }
        switch ($message['status']) {
            default: 
                break;
                
            case 'new':  
                if(!Redis::setnx("{$message['chatId']}_{$message['formId']}_userqun1",1)){
                    break;
                }
                Redis::expire("{$message['chatId']}_{$message['formId']}_userqun1",1);
                #优先级1先考虑群的设置
                $welcome_set = model\welcome_set::where('bot',$message['chatId'])->cache("welcome_{$message['chatId']}")->find();
                if(!$welcome_set){
                    #优先级2获取机器人设置
                    $welcome_set = model\welcome_set::where('bot',$message['bot']['API_BOT'])->cache("welcome_{$message['bot']['API_BOT']}")->find();
                    if(!$welcome_set){
                        #最后3获取全局设置
                        $welcome_set = model\welcome_set::where('bot',0)->cache("welcome_0")->find(); 
                    }     
                }   
                if(!empty($welcome_set['json']['开启欢迎'])){ 
                    
                    $welcome_set['value'] = str_replace('{id}', "<code>{$message['formId']}</code>", $welcome_set['value']);
                    $welcome_set['value'] = str_replace('{user}', "@{$message['formUser']}", $welcome_set['value']);
                    $welcome_set['value'] = str_replace('{name}', "<code>{$message['formName']}</code>", $welcome_set['value']);
                    $welcome_set['value'] = str_replace('{qunname}', "<code>{$message['chatName']}</code>", $welcome_set['value']);
                    $welcome_set['value'] = str_replace('{qunuser}', "@{$message['chatUser']}", $welcome_set['value']);
                    $ret['sendText'] =  $welcome_set['value'];  
                    
                    if($welcome_set['json']['欢迎类型'] == 2){
                        $ret['sendPhoto'] =  $welcome_set['json']['图片地址']; 
                    }else if($welcome_set['json']['欢迎类型'] == 3 ){
                        $ret['sendVideo'] =  $welcome_set['json']['视频地址'];  
                    }
                    
                }   
                return $ret; 
                break;
            
             
        }
         
        
        return $ret;  
    }
     
    
    
    
 
}