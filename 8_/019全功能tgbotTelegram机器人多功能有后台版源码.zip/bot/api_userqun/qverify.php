<?php
namespace bot\api_userqun;

use app\model;                          #模型  
use bot\mdb;                          #模型  
use think\facade\Db;                    #数据库
use think\facade\Cache;                 #缓存
use support\Redis;                      #redis
use Webman\RedisQueue\Client as RQamsg; #异步队列
use Webman\RedisQueue\Redis as   RQmsg; #同步队列 

//对应类文件
use plugin\tgbot\app\controller\Base;
use plugin\tgbot\app\controller\Template;

use GuzzleHttp\Pool;
use GuzzleHttp\Client as Guzz_Client;
use GuzzleHttp\Psr7\Request as Guzz_Request; 
use GuzzleHttp\Promise as Guzz_Promise;  

#这是通用的用户进出群消息  - 都会触发里面的代码  - 你可以新建N个文件干不同的事
class qverify  { 
    /**
     * 【参数解答】
     * $message['bot']          =   机器人配置信息
     * $message['msgId']        =   聊天消息唯一ID
     * 
     * $message['chatType']     =   群组频道类型
     * $message['chatId']       =   群组ID
     * $message['chatUser']     =   群组用户名(@xxx)
     * $message['chatName']     =   群组=群名称
     * 
     * $message['status']       =   事件类型:new新入群 exit退出群
     * 
     * $message['formId']       =   事件成员ID
     * $message['formUser']     =   事件成员用户名
     * $message['formName']     =   事件成员昵称
     * $message['fromVip']      =   事件成员是否是电报VIP 0否 1是
     * $message['fromLang']     =   事件成员电报客户端语言(多语言需要)
     * 
     * $message['isBot']        =   是否为机器人
     * 
     * $message['time']         =   消息到达-服务器时间戳  
     * $message['tgTime']       =   消息到达-电报官方时间戳 
     * 
     * $ret支持回调参数：sendText(文本消息) sendPhoto(发送照片)  sendVideo(发送视频)  anniu(消息按钮)   [ jianpan(回复键盘) && jianpanText(文字消息) || jianpanPhoto(照片消息)]
     */ 
    public function index($message){ 
        $ret['key']=pathinfo(basename(__FILE__), PATHINFO_FILENAME); //自动定义文件key 用于鉴权机器人是否有权使用该模块 
        $ret['level']=1; //优先级 (当存在多个模块都返回了文本消息或按钮时生效)数值大排上面 ，数值小排下面
        if(!isset($message['bot']['appStore'][$ret['key']])){
            return $ret;
        } 
        #-----------------以上核心代码勿动 level 视情况调整改动--------------------------
        if($message['chatType'] != "supergroup"){//判断是不是群
            return $ret;
        }
        
        switch ($message['status']) {
            default: 
                break;
                
            case 'new':  
                $qverify_set =  model\qverify_set::where('id',1)->cache("qverify_set")->find(); 
                if(empty($qverify_set) || empty($qverify_set['json']['验证功能'])){
                    break;
                }
                
                if(!Redis::setnx("{$message['chatId']}_{$message['formId']}_userqun2",1)){
                    break;
                }
                Redis::expire("{$message['chatId']}_{$message['formId']}_userqun2",1);
                $verify = Db::name("qverify")->where("bot",$message['bot']['API_BOT'])->select()->toArray();
                if(empty($verify) || count($verify) < 8){
                    $verify = Db::name("qverify")->select()->toArray();
                }  
                $verify = array_column($verify, null, 'id');
                $okify = null; 
                $ok = array_rand($verify, 1); 
                $okify = $verify[$ok];
                unset($verify[$ok]);
                $randomKeys = array_rand($verify, 7);
                $verify[$ok] = $okify;
                array_push($randomKeys,$ok);
                shuffle($randomKeys);   
                $a1=[];
                $a2=[];
                
                if(Cache::get("lang_{$message['formId']}") == "en"){
                    $lang = "en"; 
                }else{
                    $lang = $qverify_set['json']['默认语言'];
                }
                
                $ret['sendText'] =  trans('验证提示', ['%verify%' => $verify[$ok][$lang]],"qverify"); 
                
                foreach ($randomKeys as $ify) { 
                    if(count($a1) < 4){ 
                        if($ify == $ok){
                            array_push($a1,["text"=> $verify[$ify]['tu'] , "callback_data"=>"qverify_正确_{$message['formId']}"]);
                        }else{
                            array_push($a1,["text"=> $verify[$ify]['tu'] , "callback_data"=>"qverify_错误_{$message['formId']}"]);
                        }
                        
                    }else{
                        if($ify == $ok){
                            array_push($a2,["text"=> $verify[$ify]['tu'] , "callback_data"=>"qverify_正确_{$message['formId']}"]);
                        }else{
                            array_push($a2,["text"=> $verify[$ify]['tu'] , "callback_data"=>"qverify_错误_{$message['formId']}"]);
                        } 
                    }
                }
                $ret['anniu'] =[];
                
                array_push($ret['anniu'],$a1);
                array_push($ret['anniu'],$a2);
                $base = new Base();
                   $Permissions['can_send_messages'] = false;
                   $Permissions['can_send_audios'] = false;
                   $Permissions['can_send_documents'] = false;
                   $Permissions['can_send_photos'] = false;
                   $Permissions['can_send_videos'] = false;
                   $Permissions['can_send_video_notes'] = false;
                   $Permissions['can_send_voice_notes'] = false;
                   $Permissions['can_send_polls'] = false;
                   $Permissions['can_send_other_messages'] = false;
                   $Permissions['can_add_web_page_previews'] = false;
                   $Permissions['can_change_info'] = false;
                   $Permissions['can_invite_users'] = false;
                   $Permissions['can_pin_messages'] = false;
                   $Permissions['can_manage_topics'] = false; 
                   $permiss = json_encode($Permissions,true);
                   $base->sendUrl("/restrictChatMember?chat_id={$message['chatId']}&user_id={$message['formId']}&permissions={$permiss}&use_independent_chat_permissions=false");  
                  
                  if(!empty($qverify_set['json']['验证超时'])){
                      
                      /*以下代码为超时踢出群任务
                        定义一个时间，到时间后对应机器人会自动执行对应的url  
                        该任务功能可以帮助你定时做任何事（但只能执行1次 最快60秒才执行）
                        
                        参数：(执行时间 , url , 标识-用于后续主动删除 )*/
                      $base = new Base();
                      $base->task(time() + ($qverify_set['json']['验证时限']*60) , "/unbanChatMember?chat_id={$message["chatId"]}&user_id={$message["formId"]}&revoke_messages=true" , $message["formId"]); 
                  } 
                   
                break;
            
             
        }
         
        
        return $ret;  
    }
     
    
    
    
 
}