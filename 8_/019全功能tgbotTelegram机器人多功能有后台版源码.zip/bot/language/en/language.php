<?php
return [
    '请选择你国家的语言' => "<b>Please choose your preferred language below</b>\nThis robot is developed in a modular manner, and the developers of some modules may not provide support for multiple languages, so some functions may not support multilingual display", 
    '语言切换成功' => "语言切换成功,请重新发送机器人命令 /start", 
    '中文' => "🇨🇳 Chinese", 
];