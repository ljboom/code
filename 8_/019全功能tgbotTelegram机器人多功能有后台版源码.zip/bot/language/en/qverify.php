<?php
return [
    '语言包键名' => "Here are the corresponding values. You can add N key names corresponding to N values. When calling, call the key names to obtain the corresponding values. After the development is completed, copy this file to the en directory, and then translate the corresponding values into other languages. The framework has a multi-language system that automatically reads the corresponding key name and obtains the value according to the user's current language.", 
    '验证提示' => "\nPlease click <b>%verify%</b> below to complete the group verification within <b>10 minutes</b>!",
   ];