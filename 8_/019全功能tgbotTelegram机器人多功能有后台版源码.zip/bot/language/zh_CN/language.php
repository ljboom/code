<?php
return [
    '请选择你国家的语言' => "<b>请在下方选择你喜欢的国家语言</b>\n本机器人模块化开发,可能部分模块的开发者未提供支持多语言,因此可能存在部分功能不支持多语言显示", 
    '语言切换成功' => "Language switching is successful\nplease contact the robot again /start", 
    '中文' => "🇨🇳 中文",  
];