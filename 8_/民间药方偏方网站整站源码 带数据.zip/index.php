<?php
set_time_limit(0);
$prescription = trim($_GET['q']);
$id = intval($_GET['id']);

$r_num = 0; //结果个数
$lan = 2;
$pf = "";
$pf_l = "";

if($prescription!=""){
    $dreamdb=file("pfdata/pft.dat");//读取偏方文件
    $count=count($dreamdb);//计算行数

    for($i=0; $i<$count; $i++) {
        $keyword=explode(" ",$prescription);//拆分关键字
        $dreamcount=count($keyword);//关键字个数
        for ($ai=0; $ai<$dreamcount; $ai++) {
            $found = preg_match("/{$keyword[$ai]}/i", $dreamdb[$i]);
            if(($found)){
                $detail=explode("\t",$dreamdb[$i]);
                if(fmod($r_num,$lan)==0) $pf_l .= "<tr>";
                $pf_l .= '<td width="'.(100/$lan).'%">[<a href="./?q='.urlencode($detail[1]).'" class="lan">'.$detail[1].'</a>';
                if(trim($detail[2],"\r\n")!="") $pf_l .= '|<a href="./?q='.urlencode($detail[2]).'" class="lan">'.trim($detail[2],"\r\n").'</a>';
                $pf_l .= '] <img src="i/dot.gif" /> <a href="?id='.($i+1).'">'.$detail[0].'</a></td>';
                if(fmod($r_num,$lan)+1==$lan) $pf_l .= "</tr>";
                $r_num++;
                break;
            }
        }
    }
    $pf_l = '<table width="700" cellpadding="2" cellspacing="0" style="border:1px solid #B2D0EA;"><tr><td style="background:#EDF7FF;padding:0 5px;color:#014198;" height="26" valign="middle" colspan="5"><b><a href="./">民间偏方</a>：找到 <a href="./?q='.urlencode($prescription).'"><font color="#c60a00">'.$prescription.'</font></a> 的相关偏方'.$r_num.'个</b></td></tr><tr><td><table cellpadding="5" cellspacing="10" width="100%">'.$pf_l.'</table></td></tr></table>';
}elseif($id>0){
    $dreamdb=file("pfdata/pf.dat");//读取偏方文件
    $count=count($dreamdb);//计算行数

    $detail=explode("\t",$dreamdb[$id-1]);
    $pf = '<table width="700" cellpadding=2 cellspacing=0 style="border:1px solid #B2D0EA;"><tr><td style="background:#EDF7FF;padding:0 5px;color:#014198;" height="26" valign="middle"><b><a href="./">民间偏方</a> / <a href="./?q='.urlencode($detail[1]).'">'.$detail[1].'</a> / <a href="./?q='.urlencode($detail[2]).'">'.trim($detail[2],"\r\n").'</a> / '.$detail[0].'</b></td><td style="background:#EDF7FF;padding:0 5px;color:#014198;" align="right">';
    if($id>1 && $id<=$count) $pf .= '<a href="?id='.($id-1).'">上一个</a> ';
    $pf .= '<a href="./">查看全部</a>';
    if($id>=1 && $id<$count) $pf .= ' <a href="?id='.($id+1).'">下一个</a>';
    $pf .= '</td></tr><tr><td align="center" colspan="2"><h3>'.$detail[0].'</h3></td></tr><tr><td style="padding:5px;line-height:21px;" colspan="2"><p>'.$detail[3].'</p></td></tr></table>';
}else{
    $dreamdb=file("pfdata/pft.dat");//读取偏方文件
    $count=count($dreamdb);//计算行数

    $pfl = rand(0,intval($count/30));

    for($i=$pfl*30; $i<$pfl*30+30; $i++) {
        if($i>=$count-1) break;
        $detail=explode("\t",$dreamdb[$i]);
        if(fmod($r_num,$lan)==0) $pf_l .= "<tr>";
        $pf_l .= '<td width="'.(100/$lan).'%">[<a href="./?q='.urlencode($detail[1]).'" class="lan">'.$detail[1].'</a>';
        if(trim($detail[2],"\r\n")!="") $pf_l .= '|<a href="./?q='.urlencode($detail[2]).'" class="lan">'.trim($detail[2],"\r\n").'</a>';
        $pf_l .= '] <img src="i/dot.gif" /> <a href="?id='.($i+1).'">'.$detail[0].'</a></td>';
        if(fmod($r_num,$lan)+1==$lan) $pf_l .= "</tr>";
        $r_num++;
    }
    $pf_l = '<table width="700" cellpadding="2" cellspacing="0" style="border:1px solid #B2D0EA;"><tr><td style="background:#EDF7FF;padding:0 5px;color:#014198;" height="26" valign="middle" colspan="5"><b>推荐民间偏方'.$r_num.'个</b></td></tr><tr><td><table cellpadding="5" cellspacing="10" width="100%">'.$pf_l.'</table></td></tr></table>';
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <?
    if($prescription){
        echo "<title>".$prescription."中医药方实用查询 - 民间药方大全 dkewl.com</title>";
        echo '<meta name="keywords" content="'.$prescription.',民间药方,中医偏方,中药偏方,秘方大全" />';
    }elseif($id>0 && $id<=$count){
        echo "<title>".$detail[0]." - ".$detail[2]." - ".$detail[1]." - 民间药方大全 mjyf6.cn</title>";
        echo '<meta name="keywords" content="'.$detail[0].",".$detail[2].",".$detail[1].',偏方,民间偏方大全" />';
    }else{
        echo "<title>民间药方大全 dkewl.com - 收集各种中医偏方,中药偏方,民间秘方,小偏方</title>";
        echo '<meta name="keywords" content="民间药方,中医偏方,中药偏方,秘方大全" />';
        echo '<meta name="description" content="民间偏方大全www.dkewl.com，收集各种中医药方，中药秘方，小偏方，有减肥偏方，美容偏方，咳嗽偏方，鼻炎偏方，牛皮癣偏方，止咳偏方，牙疼偏方，感冒偏方，咳嗽偏方，痔疮偏方，糖尿病偏方，生发偏方，冻疮偏方，高血压偏方，胃病偏方，便秘偏方等。" />';
    }
    ?>
    <link href="i/common.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div align="center">
<table cellspacing="0" cellpadding="0" width="700" border="0"><tr><td align="left" style="padding:10px 0"><a href="https://www.dkewl.com/"><img src="i/logo.png" alt="民间药方" /></a></td></tr></table>
<center>
<script type="text/javascript"><!--
google_ad_client = "pub-7582550094097104";
/* 728x90, 创建于 08-2-9 */
google_ad_slot = "3751220310";
google_ad_width = 728;
google_ad_height = 0;
//-->
</script>
</center>
<table cellspacing="4" cellpadding="0" style="background-color:#f7f7f7;border-bottom:1px solid #dfdfdf;" width="978">
<tr><td align="left"> //////////////////////////////////////////// <a href="/">首页</a> ///// <a href="./">民间偏方</a> ///// <a href="./mingfang">中草药名方</a>//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////<? if($prescription) echo ' &gt; 关于 <strong>'. $prescription.'</strong> 的偏方'; ?></td><td align="right"><a href="javascript:;" onClick="window.external.AddFavorite(document.location.href,document.title);">收藏本页</a></td></tr></table>
<br>
<style type="text/css">
h3{font-size:24px;padding:15px 10px 5px 10px;color:#014198;}
p{padding: 10px;}
a.lan,a.lan:visited{color:#999;}
</style>
<table width="700" cellpadding="2" cellspacing="0" style="border:1px solid #B2D0EA;" id="top"><tr><td style="background:#EDF7FF;padding:0 5px;color:#014198;" height="26" valign="middle" colspan="5"><b>中国民间药方搜索</b></td></tr><tr><td align="center" valign="middle" height="60"><form action="./" method="get" name="f1">搜索药方：<input name="q" id="q" type="text" size="18" delay="0" value="" style="width:200px;height:22px;font-size:16px;font-family: Geneva, Arial, Helvetica, sans-serif;" /> <input type="submit" value=" 搜索 " /></form></td></tr><tr><td align="center" height="30" style="font-size:14px;">药方分类：<a href="./?q=%E5%86%85%E7%A7%91">内科</a> <a href="./?q=%E5%A4%96%E7%A7%91">外科</a> <a href="./?q=%E8%82%BF%E7%98%A4">肿瘤</a> <a href="./?q=%E7%9A%AE%E8%82%A4">皮肤</a> <a href="./?q=%E4%BA%94%E5%AE%98">五官</a> <a href="./?q=%E5%A6%87%E7%A7%91">妇科</a> <a href="./?q=%E7%94%B7%E7%A7%91">男科</a> <a href="./?q=%E5%84%BF%E7%A7%91">儿科</a> <a href="./?q=%E4%BF%9D%E5%81%A5">保健</a> <a href="./?q=%E8%8D%AF%E9%85%92">药酒</a> <a href="./?q=%E5%85%B6%E4%BB%96">其他</a></td></tr></table>
<br />

<?
if($prescription!=""){
    //echo $pf_l.$pf;
    echo $pf_l;
}elseif($id>0 && $id<=$count){
    echo $pf;
}else{
    echo '<table width="700" cellpadding="2" cellspacing="0" style="border:1px solid #B2D0EA;"><tr><td style="background:#EDF7FF;padding:0 5px;color:#014198;" height="26" valign="middle" colspan="5"><b>民间药方偏方秘说明</b></td></tr><tr><td><p style="line-height:150%">　　所谓民间药方偏方秘，是指药味的多少，对某些病症具有独特疗效的方剂。数千年来，在我国民间流传着非常丰富、简单而又疗效神奇的治疗疑难杂症的偏方、秘方、验方，方书著作浩如烟海。本站特将流传于民间的偏方加以收集整理，汇集成这一《民间偏方大全》，共收录了各类偏方、验方、秘方7000余条。<br />　　此《民间药方大全》之食疗、土方精选，所用方材均以民间土方、偏方为主，不仅易找、易买、易用，而且疗效神奇，又无副作用。它汇集了古今诸多名方、妙方、秘方，最适合家庭使用。当您患有疑难病久治未愈时，不妨试一试这些民间偏方，或许能起到意想不到的疗效。这些民间偏方不但适合家庭进行自我治疗，对医院的一些中医以及西医专业医生来讲，也是很有参考价值的。<br />　　注意：药方疗效会因时令、地域和各人的身体状况不同而异，请采用本站的药方方剂时，要根据地域和自己的身体情况有选择地选用合适的方剂，适时地进行疗补。</p></td></tr></table><br>';
    echo $pf_l;
}
?>
</div>
<link href="i/common.css" rel="stylesheet" type="text/css" />
<div id="footer">&copy; 2008-2025 <a href="http://www.dkewl.com/">民间药方实用查询</a> <a href="https://beian.miit.gov.cn/" target="_blank">皖ICP备202866666666号</a></div>
<center>
</center>
</body>
</html>    