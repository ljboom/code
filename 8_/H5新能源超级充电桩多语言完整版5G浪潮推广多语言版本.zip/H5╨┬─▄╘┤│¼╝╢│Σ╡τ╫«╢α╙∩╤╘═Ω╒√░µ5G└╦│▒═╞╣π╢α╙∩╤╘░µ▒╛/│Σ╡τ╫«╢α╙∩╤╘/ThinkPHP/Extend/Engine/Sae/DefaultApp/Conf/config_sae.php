<?php
return array(
   'TMPL_PARSE_STRING'=>array(
      // __PUBLIC__/upload  -->  /Public/upload -->http://appname-public.stor.sinaapp.com/upload
   '/Public/upload'=>sae_storage_root('Public').'/upload'
    )
);