<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html class="pixel-ratio-3 retina android android-5 android-5-0 watch-active-state"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <title><?php if($language == 1 ): ?>Team<?php endif; ?>  
				    <?php if($language == 2 ): ?>ทีม<?php endif; ?> 
				    <?php if($language == 3 ): ?>टीम<?php endif; ?> 
				    <?php if($language == 4 ): ?>단체.<?php endif; ?> 
				    <?php if($language == 5 ): ?>チーム<?php endif; ?>  </title>
    <link rel="stylesheet" href="/Public/dianyun/css/app.css">
    <link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">
    <style type="text/css">
    	*{
    		margin: 0;
    		padding: 0;
    		text-decoration: none;
    		list-style: none;
    	}
    </style>

  </head>
<body style="background: url(/Public/dianyun/img/bg.png) no-repeat rgb(220,198,162);background-size:100%;">
  	
  	
  	<div class="yqlbbbb">
  		<p class="sjasxh"><?php if($language == 1 ): ?>First class member<?php endif; ?>  
				    <?php if($language == 2 ): ?>สมาชิกระดับแรก<?php endif; ?> 
				    <?php if($language == 3 ): ?>प्रथम वर्ग सदस्य<?php endif; ?> 
				    <?php if($language == 4 ): ?>일급 회원<?php endif; ?> 
				    <?php if($language == 5 ): ?>一級会員<?php endif; ?> <a href="<?php echo U('Index/Index/zhitui');?>" style="color:#FDB523"><?php if($language == 1 ): ?>See<?php endif; ?>  
				    <?php if($language == 2 ): ?>การตรวจสอบ<?php endif; ?> 
				    <?php if($language == 3 ): ?>देखें<?php endif; ?> 
				    <?php if($language == 4 ): ?>살펴보다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>表示<?php endif; ?></a></p>
  	</div>
  	
  	<div class="yqlbbbb" style="background:#87B92F">
  		<p class="sjasxh"><?php if($language == 1 ): ?>Secondary member<?php endif; ?>  
				    <?php if($language == 2 ): ?>สมาชิกระดับทุติยภูมิ<?php endif; ?> 
				    <?php if($language == 3 ): ?>द्वितीय सदस्य<?php endif; ?> 
				    <?php if($language == 4 ): ?>2 급 회원<?php endif; ?> 
				    <?php if($language == 5 ): ?>二級の会員<?php endif; ?> <a href="javascript:alert(&#39;<?php if($language == 1 ): ?>Suspend viewing of non direct push members<?php endif; ?>  
				    <?php if($language == 2 ): ?>หยุดชั่วคราวเพื่อดูไม่ตรงผลักดันสมาชิก<?php endif; ?> 
				    <?php if($language == 3 ): ?>निर्देशित पूस सदस्यों की दृश्य स्थगित करें<?php endif; ?> 
				    <?php if($language == 4 ): ?>비 직 추 회원 조회 일시 정지<?php endif; ?> 
				    <?php if($language == 5 ): ?>直接会員を押していない場合のチェックを一時停止します。<?php endif; ?>&#39;);" style="color:#87B92F"><?php if($language == 1 ): ?>See<?php endif; ?>  
				    <?php if($language == 2 ): ?>การตรวจสอบ<?php endif; ?> 
				    <?php if($language == 3 ): ?>देखें<?php endif; ?> 
				    <?php if($language == 4 ): ?>살펴보다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>表示<?php endif; ?></a></p>
  	</div>
  	
  	<div class="yqlbbbb"style="background:#FF6565">
  		<p class="sjasxh"><?php if($language == 1 ): ?>Third class member<?php endif; ?>  
				    <?php if($language == 2 ): ?>สมาชิกสามระดับ<?php endif; ?> 
				    <?php if($language == 3 ): ?>तीसरा वर्ग सदस्य<?php endif; ?> 
				    <?php if($language == 4 ): ?>3 급 회원<?php endif; ?> 
				    <?php if($language == 5 ): ?>三級会員<?php endif; ?> <a href="javascript:alert(&#39;<?php if($language == 1 ): ?>Suspend viewing of non direct push members<?php endif; ?>  
				    <?php if($language == 2 ): ?>หยุดชั่วคราวเพื่อดูไม่ตรงผลักดันสมาชิก<?php endif; ?> 
				    <?php if($language == 3 ): ?>निर्देशित पूस सदस्यों की दृश्य स्थगित करें<?php endif; ?> 
				    <?php if($language == 4 ): ?>비 직 추 회원 조회 일시 정지<?php endif; ?> 
				    <?php if($language == 5 ): ?>直接会員を押していない場合のチェックを一時停止します。<?php endif; ?>&#39;);"style="color:#FF6565"><?php if($language == 1 ): ?>See<?php endif; ?>  
				    <?php if($language == 2 ): ?>การตรวจสอบ<?php endif; ?> 
				    <?php if($language == 3 ): ?>देखें<?php endif; ?> 
				    <?php if($language == 4 ): ?>살펴보다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>表示<?php endif; ?></a></p>
  	</div>
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
</body>
</html>