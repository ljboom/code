<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title> 
		<?php if($language == 1 ): ?>Ranking List<?php endif; ?>  
	    <?php if($language == 2 ): ?>แผนภูมิ<?php endif; ?> 
	    <?php if($language == 3 ): ?>रेन्ग सूची<?php endif; ?> 
	    <?php if($language == 4 ): ?>도표 에서<?php endif; ?> 
	    <?php if($language == 5 ): ?>ランキング<?php endif; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
		<link rel="stylesheet" href="/Public/dianyun/css/app.css">
        <link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">
		<style type="text/css">
    	*{
    		margin: 0;
    		padding: 0;
    		text-decoration: none;
    		list-style: none;
    	}
    	body{
    		background: url(/Public/dianyun/img/about-bg.png)no-repeat #151a36;
    		background-size: 100% ;
    		
    	}
    	li{
    		margin-bottom: 1rem;
    	}
    	img{
    		border-radius: 10rem;
    	}
    </style>
	</head>
<body style="background: url(/Public/dianyun/img/bg.png) no-repeat rgb(220,198,162);background-size:100%;">
		
		<div class="help-index-top">
  		<p><?php if($language == 1 ): ?>Ranking List<?php endif; ?>  
	    <?php if($language == 2 ): ?>แผนภูมิ<?php endif; ?> 
	    <?php if($language == 3 ): ?>रेन्ग सूची<?php endif; ?> 
	    <?php if($language == 4 ): ?>도표 에서<?php endif; ?> 
	    <?php if($language == 5 ): ?>ランキング<?php endif; ?></p>
  	    </div>
		
		<div class="paihangbang">
			<ul>
			
				<li style="background:rgba(255, 101, 101, 1);border-radius: 0.5rem;">
					<img src="/Public/dianyun/img/pai1.png"/>
					<p>188****8888</p>
					<a href="#">8634.00</a>
				</li>
				<li style="background:rgba(135, 185, 47, 1);border-radius: 0.5rem;">
					<img src="/Public/dianyun/img/pai2.png"/>
					<p>130****4398</p>
					<a href="#">6417.00</a>
				</li>
				<li style="background:rgba(253, 181, 35, 1);border-radius: 0.5rem;">
					<img src="http://images.liqucn.com/img/h1/h991/img201712091532310_info400X400.jpg"/>
					<p>138****3198</p>
					<a href="#">5642.00</a>
				</li>
				<li style="background:rgba(255, 143, 45, 1);border-radius: 0.5rem;">
					<img src="/Public/dianyun/img/pai3.jpeg"/>
					<p>177****6974</p>
					<a href="#">5163.00</a>
				</li>
				<li style="background:rgba(255, 143, 45, 1);border-radius: 0.5rem;">
					<img src="/Public/dianyun/img/pai4.jpeg"/>
					<p>187****7351</p>
					<a href="#">2984.00</a>
				</li>
				<li class="yisyh"style="background:rgba(255, 143, 45, 1);border-radius: 0.5rem;">
					<p>
					<?php if($language == 1 ): ?>All the above users will be rewarded<?php endif; ?>  
	    <?php if($language == 2 ): ?>ผู้ใช้ทั้งหมดข้างต้นได้รับรางวัล<?php endif; ?> 
	    <?php if($language == 3 ): ?>उप्पर सभी उपयोक्ताओं को बदला दिया जाएगा<?php endif; ?> 
	    <?php if($language == 4 ): ?>이상 모든 유저 보상 획득<?php endif; ?> 
	    <?php if($language == 5 ): ?>以上のすべてのユーザーが奨励を獲得しました。<?php endif; ?></p>
				</li>
			</ul>
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	</body>
</html>