<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html class="pixel-ratio-3 retina android android-5 android-5-0 watch-active-state"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <title><?php if($language == 1 ): ?>Recommend<?php endif; ?>  
				    <?php if($language == 2 ): ?>แนะนำ<?php endif; ?> 
				    <?php if($language == 3 ): ?>सिफारिस करें<?php endif; ?> 
				    <?php if($language == 4 ): ?>추천 하 다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>おすすめ<?php endif; ?>  </title>
    <link rel="stylesheet" href="/Public/dianyun/css/app.css">
    <link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">
    <style type="text/css">
    	*{
    		margin: 0;
    		padding: 0;
    		list-style: none;
    	}
    	.zhitui_img{
    		float: left;
    		width: 20%;
    		margin-right: 0.4rem;
    		margin-left: 1rem;
    	}
    	.tixianlog{
    		height: 4rem;
    		padding-top: 1rem;
    		
    	}
    	.tixianlog_b{
    		color: #fff;
    		font-size: 16px;
    		font-weight: bold;
    		float: left;
    		width: 50%;
    		padding-top: 0.5rem;
    	}
    	.monery_yi{
    		float: right;
    		margin-right: 1rem;
    		color: #fff;
    		font-size: 20px;
    		font-weight: bold;
    		margin-top: -1rem;
    	}
    </style>


</head>
<body style="background: url(/Public/dianyun/img/bg.png) no-repeat rgb(220,198,162);background-size:100%;">

<?php if(is_array($list)): foreach($list as $key=>$v): ?><div class="tixianlog">
		
		
		<!--<p class="tixianlog_b"> <span><?php echo ($v["truename"]); ?></span> <span><?php echo ($v["username"]); ?></span> <span><?php echo ($v["money"]); ?></span> <span><?php echo ($v["zhitui"]); ?></span> </p>-->
		<img src="/Public/dianyun/img/user_tou.png" alt="" width="50" class="zhitui_img"/ >
		<p class="tixianlog_b"><?php echo ($v["truename"]); ?> <span style="color:#FFFFFF;width:100%;text-align: left;"><?php echo ($v["username"]); ?></span></p></p>
		<p class="monery_yi"><?php echo ($v["jinbi"]); ?> </p>
	</div><?php endforeach; endif; ?>


</body>
</html>