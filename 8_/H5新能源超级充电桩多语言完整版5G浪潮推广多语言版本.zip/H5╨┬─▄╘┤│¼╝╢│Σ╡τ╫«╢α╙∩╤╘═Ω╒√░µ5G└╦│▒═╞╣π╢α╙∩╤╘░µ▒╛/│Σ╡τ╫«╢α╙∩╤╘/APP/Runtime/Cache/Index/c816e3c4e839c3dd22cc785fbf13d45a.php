<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html class="pixel-ratio-3 retina android android-5 android-5-0 watch-active-state"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <title><?php if($language == 1 ): ?>Profit<?php endif; ?>  
				    <?php if($language == 2 ): ?>ผลประโยชน์<?php endif; ?> 
				    <?php if($language == 3 ): ?>लाभ<?php endif; ?> 
				    <?php if($language == 4 ): ?>수익.<?php endif; ?> 
				    <?php if($language == 5 ): ?>利益を収める<?php endif; ?>  </title>


    <link rel="stylesheet" href="/Public/dianyun/css/app.css">
    <link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">
    <style type="text/css">
    	*{
    		margin: 0;
    		padding: 0;
    		list-style: none;
    	}
    </style>
  </head>
<body style="background: url(/Public/dianyun/img/bg.png) no-repeat rgb(220,198,162);background-size:100%;">
  	
  	<div class="award-index-t">
   	<p class="award-ysy"><?php if($language == 1 ): ?>Balance<?php endif; ?>  
				    <?php if($language == 2 ): ?>ยอดคงเหลือ<?php endif; ?> 
				    <?php if($language == 3 ): ?>Balance<?php endif; ?> 
				    <?php if($language == 4 ): ?>잔금.<?php endif; ?> 
				    <?php if($language == 5 ): ?>残額<?php endif; ?> </p>
   	<p class="award-sss"><?php echo ($yue); ?></p>
   </div>
   
   <div class="award-index-a">
   	<p class="award-ysy"><?php if($language == 1 ): ?>Total revenue<?php endif; ?>  
				    <?php if($language == 2 ): ?>รายได้รวม<?php endif; ?> 
				    <?php if($language == 3 ): ?>कुल आगत<?php endif; ?> 
				    <?php if($language == 4 ): ?>총 수익<?php endif; ?> 
				    <?php if($language == 5 ): ?>総収益<?php endif; ?></p>
   	<p class="award-sss"><?php echo ($shouyi); ?></p>
   </div>
   
   <div class="award-index-b">
   	<p class="award-ysy"><?php if($language == 1 ): ?>Withdrawn<?php endif; ?>  
				    <?php if($language == 2 ): ?>ถอนเงิน<?php endif; ?> 
				    <?php if($language == 3 ): ?>रेखाचित्र<?php endif; ?> 
				    <?php if($language == 4 ): ?>돈 을 인출 하 다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>引き出し済み<?php endif; ?></p>
   	<p class="award-sss"><?php echo ($yiti); ?></p>
   </div>
   
   <div class="award-index-aaa">
   	<a href="<?php echo U('Index/Wallet/award');?>"><?php if($language == 1 ): ?>Whole<?php endif; ?>  
				    <?php if($language == 2 ): ?>จำนวนทั้งหมด<?php endif; ?> 
				    <?php if($language == 3 ): ?>पूर्ण<?php endif; ?> 
				    <?php if($language == 4 ): ?>전부.<?php endif; ?> 
				    <?php if($language == 5 ): ?>全部<?php endif; ?></a>
   	<a href="<?php echo U('Index/Wallet/llaward');?>" style="background:#FF8F2D"><?php if($language == 1 ): ?>Income<?php endif; ?>  
				    <?php if($language == 2 ): ?>ได้รับ<?php endif; ?> 
				    <?php if($language == 3 ): ?>आयात<?php endif; ?> 
				    <?php if($language == 4 ): ?>수입.<?php endif; ?> 
				    <?php if($language == 5 ): ?>収入<?php endif; ?></a>
   	<a href="<?php echo U('Index/Wallet/tgaward');?>"><?php if($language == 1 ): ?>Extension<?php endif; ?>  
				    <?php if($language == 2 ): ?>แพร่สนั่น<?php endif; ?> 
				    <?php if($language == 3 ): ?>एक्सटेंशन<?php endif; ?> 
				    <?php if($language == 4 ): ?>보급 하 다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>押し広める<?php endif; ?></a>
   </div>
   
   <div class="award-index-ui">
   	<ul>
   		<?php if(is_array($list)): foreach($list as $key=>$v): ?><li>
   			<p> <span style="width:25%"><?php echo (date('Y-m-d',$v["addtime"])); ?></span> <span style="width:45%"><?php echo ($v["desc"]); ?></span>  <span style="width:25%"><?php if($v["adds"] == 0.00): ?>-<?php echo (two_number($v["reduce"])); else: ?>+<?php echo (two_number($v["adds"])); endif; ?></span> </p>
   		</li><?php endforeach; endif; ?>
   	</ul>
   </div>

  	
  	

</body>
</html>