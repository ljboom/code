<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html class="pixel-ratio-3 retina android android-5 android-5-0 watch-active-state"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <title><?php if($language == 1 ): ?>Drawing<?php endif; ?>  
				    <?php if($language == 2 ): ?>ถอนเงิน<?php endif; ?> 
				    <?php if($language == 3 ): ?>रेखाचित्र<?php endif; ?> 
				    <?php if($language == 4 ): ?>돈 을 인출 하 다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>金を引き出す<?php endif; ?>  </title>

    <link rel="stylesheet" href="/Public/dianyun/css/app.css">
    <link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">
    <style type="text/css">
    	*{
    		margin: 0;
    		padding: 0;
    		list-style: none;
    	}
    </style>

  </head>
<body style="background: url(/Public/dianyun/img/bg.png) no-repeat rgb(220,198,162);background-size:100%;">
  	
  	<div class="award-index-t">
   	<p class="award-ysy"><?php if($language == 1 ): ?>Withdrawable<?php endif; ?>  
				    <?php if($language == 2 ): ?>ถอนเงิน<?php endif; ?> 
				    <?php if($language == 3 ): ?>छोड़ना योग्य<?php endif; ?> 
				    <?php if($language == 4 ): ?>인출 가능<?php endif; ?> 
				    <?php if($language == 5 ): ?>引き出しがきく<?php endif; ?></p>
   	<p class="award-sss"><?php echo ($money); ?></p>
   </div>
   
   <div class="award-index-a">
   	<p class="award-ysy"><?php if($language == 1 ): ?>Withdrawn<?php endif; ?>  
				    <?php if($language == 2 ): ?>ถอนเงิน<?php endif; ?> 
				    <?php if($language == 3 ): ?>रेखाचित्र<?php endif; ?> 
				    <?php if($language == 4 ): ?>돈 을 인출 하 다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>引き出し済み<?php endif; ?></p>
   	<p class="award-sss"><?php echo ($yiti); ?></p>
   </div>
   
   <div class="award-index-b">
   	<?php if($language == 1 ): ?><a class="awaredd-ls" href="<?php echo U('Index/Wallet/withdrawn');?>">Drawing</a><?php endif; ?>  
				    <?php if($language == 2 ): ?><a class="awaredd-ls" href="<?php echo U('Index/Wallet/withdrawn');?>">ถอนเงิน</a><?php endif; ?>  
				    <?php if($language == 3 ): ?><a class="awaredd-ls" href="<?php echo U('Index/Wallet/withdrawn');?>">रेखाचित्र</a><?php endif; ?>  
				    <?php if($language == 4 ): ?><a class="awaredd-ls" href="<?php echo U('Index/Wallet/withdrawn');?>" >돈 을 인출 하 다.</a><?php endif; ?> 
				    <?php if($language == 5 ): ?><a class="awaredd-ls" href="<?php echo U('Index/Wallet/withdrawn');?>">金を引き出す</a><?php endif; ?>
   </div>
  	
  	<div class="tixian-index-b">
  		<p class="tixian-iddds">
  			<?php if($language == 1 ): ?>Withdrawal rules<?php endif; ?>  
				    <?php if($language == 2 ): ?>กฎการถอนเงิน<?php endif; ?> 
				    <?php if($language == 3 ): ?>नियमों को छोड़ें<?php endif; ?> 
				    <?php if($language == 4 ): ?>인출 규칙<?php endif; ?> 
				    <?php if($language == 5 ): ?>引き出しルール<?php endif; ?>：<br>
            <?php if($language == 1 ): ?>Cash withdrawal in 5 days * 24 hours on weekdays.<?php endif; ?>  
				    <?php if($language == 2 ): ?>สำหรับวันงาน<?php endif; ?> 
				    <?php if($language == 3 ): ?>5 दिनों में पैसा हप्ताकालों में * 24 घंटे हैं.<?php endif; ?> 
				    <?php if($language == 4 ): ?>근무일 5 일 * 24 시간 현금 인출.<?php endif; ?> 
				    <?php if($language == 5 ): ?>平日は5日間＊24時間です。<?php endif; ?><br>
            
            <?php if($language == 1 ): ?>Remarks<?php endif; ?>  
				    <?php if($language == 2 ): ?>ข้อคิดเห็น<?php endif; ?> 
				    <?php if($language == 3 ): ?>टिप्पणी<?php endif; ?> 
				    <?php if($language == 4 ): ?>비고 하 다<?php endif; ?> 
				    <?php if($language == 5 ): ?>コメント<?php endif; ?>：<?php if($language == 1 ): ?>Your withdrawal wallet must be consistent with your real name when recharging, otherwise it will not pass.<?php endif; ?>  
				    <?php if($language == 2 ): ?>กระเป๋าสตางค์ของคุณจะต้องตรงกับชื่อจริงของคุณเมื่อคุณเติมเงินมิฉะนั้นจะไม่ผ่าน<?php endif; ?> 
				    <?php if($language == 3 ): ?>जब पुनरार्ज किया जाता है, तुम्हारे प्रतिक्रिया वालेट अपने वास्तविक नाम के साथ सहन होना चाहिए, अन्यथा<?php endif; ?>  
				    <?php if($language == 4 ): ?>당신 의 현금 인출 지갑 은 충전 시 실제 이름 과 일치 해 야 합 니 다. 그렇지 않 으 면 통과 하지 않 습 니 다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>現金引き出しはチャージ時の本名と一致しないといけません。<?php endif; ?>
  		</p>
  	</div>
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	

<script type="text/javascript">
    var m_WithdrawalsLimit = "0";
</script>


</body>
</html>