<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="format-detection" content="telephone=no,email=no,adress=no">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>
    <?php if($language == 1 ): ?>Recharge<?php endif; ?>  
	    <?php if($language == 2 ): ?>เติม<?php endif; ?> 
	    <?php if($language == 3 ): ?>फिर चार्ज करें<?php endif; ?> 
	    <?php if($language == 4 ): ?>충전<?php endif; ?> 
	    <?php if($language == 5 ): ?>チャージ<?php endif; ?>	
    </title>
    <link href="/Public/wx/cz/css/swiper.min.css" type="text/css" rel="stylesheet">
    <link href="/Public/wx/cz/css/style.css" type="text/css" rel="stylesheet">
    <script src="/Public/wx/cz/js/jquery.min.js"></script>
    <script src="/Public/wx/cz/js/swiper.min.js"></script>
    <script src="/Public/wx/cz/js/rem.js"></script>
    <script src="/Public/wx/cz/js/safari.js"></script>
</head>
<body style="background: url(/Public/dianyun/img/bg.png) no-repeat rgb(220,198,162);background-size:100%;">
<!-- 头部-->

<!--end-->
<div class="exchange">
            <input name="username" type="hidden" value="<?php echo ($username); ?>">
        <li style="margin-top: 5px;width:100%">
            
            <?php if($language == 1 ): ?><input name="money" type="text" placeholder="Please input recharge amount  " style="height: 50px;line-height: 30px;margin-left:3%;width: 94%;border-radius: 4px;border: none; background:rgba(255, 143, 45, 1);padding-left: 1%;-webkit-appearance:none; color:rgba(253, 214, 150, 1);"><?php endif; ?>        
	    <?php if($language == 2 ): ?><input name="money" type="text" placeholder="กรุณาป้อนค่าใช้จ่าย  " style="height: 50px;line-height: 30px;margin-left:3%;width: 94%;border-radius: 4px;border: none; background:rgba(255, 143, 45, 1);padding-left: 1%;-webkit-appearance:none; color:rgba(253, 214, 150, 1);"><?php endif; ?>	
	    <?php if($language == 3 ): ?><input name="money" type="text" placeholder="कृपया पुनरार्ज मात्रा इनपुट करें  " style="height: 50px;line-height: 30px;margin-left:3%;width: 94%;border-radius: 4px;border: none; background:rgba(255, 143, 45, 1);padding-left: 1%;-webkit-appearance:none; color:rgba(253, 214, 150, 1);"><?php endif; ?>    <?php if($language == 4 ): ?><input name="money" type="text" placeholder="충전 금액 을 입력 하 세 요   " style="height: 50px;line-height: 30px;margin-left:3%;width: 94%;border-radius: 4px;border: none; background:rgba(255, 143, 45, 1);padding-left: 1%;-webkit-appearance:none; color:rgba(253, 214, 150, 1);"><?php endif; ?> 
	   </if>  <?php if($language == 5 ): ?><input name="money" type="text" placeholder="チャージ金額を入力してください " style="height: 50px;line-height: 30px;margin-left:3%;width: 94%;border-radius: 4px;border: none; background:rgba(255, 143, 45, 1);padding-left: 1%;-webkit-appearance:none; color:rgba(253, 214, 150, 1);"><?php endif; ?> 
</li>
        <p style="height: 40px"></p>
    <div class="PaymentTop">
        <ul>
            <li class="fll active" data-type="2">
                <div class="PaymentPrice">
                    <span class="icon"><img src='/Public/wx/cz/img/zhifubao.jpg'></span>
                    <h1>支付宝支付</h1>
                    <p>在线支付即时到账</p>
                </div>
            </li>
            <li class="frr" data-type="1">
                <div class="PaymentPrice"> 
                     <span class="icon"><img src='/Public/wx/cz/img/wechat.jpg'></span> 
                     <h1>微信支付</h1>
                     <p>在线支付即时到账</p> 
                </div> 
             </li> 
        </ul>
    </div>
    <div class="Putforwardbox">
        <p><span><?php if($language == 1 ): ?>Recharge instructions<?php endif; ?>  
	    <?php if($language == 2 ): ?>หมายเหตุค่าใช้จ่าย<?php endif; ?> 
	    <?php if($language == 3 ): ?>सूचना फिर चार्ज करें<?php endif; ?> 
	    <?php if($language == 4 ): ?>충전 설명<?php endif; ?> 
	    <?php if($language == 5 ): ?>チャージの説明<?php endif; ?>	：</span><br /><font color="red" >
	    <?php if($language == 1 ): ?>If the recharge does not arrive, please contact customer service<?php endif; ?>  
	    <?php if($language == 2 ): ?>กรุณาติดต่อฝ่ายบริการลูกค้า<?php endif; ?> 
	    <?php if($language == 3 ): ?>यदि पुनरार्ज नहीं पहुँचे, कृपया ग्राहक सेवा से संपर्क करें<?php endif; ?> 
	    <?php if($language == 4 ): ?>만약 충전 이 채 워 지지 않 으 면 고객 님 께 연락 하 세 요.<?php endif; ?> 
	    <?php if($language == 5 ): ?>チャージが入金されていない場合は、カスタマーサービスに連絡してください。<?php endif; ?>	</font></p>
    </div>
    <div class="Putforwardbtn">
        <button class="btn" style="background:#fff;color:rgba(234, 171, 76, 1)"><?php if($language == 1 ): ?>Recharge<?php endif; ?>  
	    <?php if($language == 2 ): ?>เติม<?php endif; ?> 
	    <?php if($language == 3 ): ?>फिर चार्ज करें<?php endif; ?> 
	    <?php if($language == 4 ): ?>충전<?php endif; ?> 
	    <?php if($language == 5 ): ?>チャージ<?php endif; ?></button>
    </div>

</div>



<!--end-->

<script src="/Public/wx/cz/js/goblak.js"></script>

<script>
    $(function(){
        let type = "1";
        $('.PaymentTop').on('click', 'li', function () {
            type = $(this).attr("data-type");
            $(this).addClass('active').siblings('li').removeClass('active');
        });
        $('.Putforwardbtn').on('click', 'button', function () {
            var money = $("input[name='money']").val();
            var username = $("input[name='username']").val();
            if(money == ''){
                alert("Recharge amount cannot be empty");
                return false;
            }
            if(username == ''){
                alert("非法操作");
                return false;
            }

            window.location.href = '/zpaysdk/zpay.php?user=<?php echo ($username); ?>&money='+money+'&type='+type+'';;
        });
    });
</script>
</body>
</html>