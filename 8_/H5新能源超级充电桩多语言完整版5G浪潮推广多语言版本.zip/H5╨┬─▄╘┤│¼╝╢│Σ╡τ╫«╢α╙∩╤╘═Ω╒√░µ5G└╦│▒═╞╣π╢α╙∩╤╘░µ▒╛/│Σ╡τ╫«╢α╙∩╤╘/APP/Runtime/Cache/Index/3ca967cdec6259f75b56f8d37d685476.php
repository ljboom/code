<?php if (!defined('THINK_PATH')) exit();?>﻿<!doctype html>
<html lang="zh">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
    <title>Login  </title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="format-detection" content="telephone=no">
    <meta name="wap-font-scale" content="no">
    <link rel="stylesheet" href="/Public/dianyun/css/app.css">
    <link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">
	<style>
	.wrapper{
	min-height:auto;
	}
	body{
		background-size: auto;
	}
	*{
		margin: 0;
		padding: 0;
		text-decoration: none;
		list-style: none;
	}
	</style>
</head>

  <body style="background: url(/Public/dianyun/img/login_bg.png) no-repeat #fff;background-size:100%;">
  	
  	<div class="login_logo" style="height:14rem">
  		<img src="/Public/dianyun/img/lg.png"/>
  	</div>
  	
  	
  	<div class="login_form">
  		<form name="form" method="post" id="form">
  		<div class="input-container" >
  			<div class="input-control" style="background:#F1F1F1">
  				<i class="icon iconfont icon-yonghuming"></i>
  				<input class="inputfield" type="text" id="txtUid" name="username" placeholder="Please input mobile phone number" maxlength="11" value="">
  			</div>
  		</div>
  		<div class="input-container">
  			<div class="input-control" style="background:#F1F1F1">
  				<i class="icon iconfont icon-mima"></i>
  				<input class="inputfield" type="password" id="password" name="password" placeholder="Please enter the login password" value="">
  			</div>
  		</div>
  	
  		<div class="row loginfield">
  			
  		</div>
  	
  		<div class="center">
  			<div class="space-20"></div>
  			
  			<a href="javascript:tryLogin();" class="btn_submit_my login_la"style="color:#fff;background:linear-gradient(to right,rgb(252,216,157),rgb(234,178,93)">
  				Login
  			</a>
  		</div>
  	</form>
  	<a href="<?php echo U('Index/Login/editpwd');?>"  style="margin-top: 1rem;color:#47443F;float: left;">Forget the password</a>
  				<a href="<?php echo U('Index/Login/reg');?>"  style="color:#47443F;float: right;margin-top:1rem">Register now</a>
  	</div>
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	

<script src="/Public/js/jquery-1.11.3.min.js"></script>

<script type="text/javascript">
	$(".btn_submit_my").click(function(){
			$.ajax({
				url:'<?php echo U("Index/Login/index");?>',
				type:'POST',
				data:$("#form").serialize(),
				dataType:'json',
				success:function(json){
						alert(json.info);
						if(json.result ==1){
							window.location.href=json.url;
						}
				},
				error:function(){
						alert("网络故障");
				}
			})

	})


</script>

<script type="text/javascript" src="https://js.users.51.la/19447899.js"></script>

	</body>
</html>