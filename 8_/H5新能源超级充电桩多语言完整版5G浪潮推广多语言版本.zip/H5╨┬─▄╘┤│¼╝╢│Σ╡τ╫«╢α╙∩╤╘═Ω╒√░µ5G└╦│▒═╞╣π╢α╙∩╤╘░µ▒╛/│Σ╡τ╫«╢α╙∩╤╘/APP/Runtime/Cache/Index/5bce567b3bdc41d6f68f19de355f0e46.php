<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html class="pixel-ratio-3 retina android android-5 android-5-0 watch-active-state"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <title>
    <?php if($language == 1 ): ?>Home<?php endif; ?>  
    <?php if($language == 2 ): ?>หน้าแรก<?php endif; ?> 
    <?php if($language == 3 ): ?>घर पृष्ठ<?php endif; ?> 
    <?php if($language == 4 ): ?>홈 페이지<?php endif; ?> 
    <?php if($language == 5 ): ?>最初のページ<?php endif; ?> 
    </title>
    

    
    <link rel="stylesheet" href="/Public/dianyun/css/app.css">
    <link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">
    <link rel="stylesheet" href="/Public/css/style.css">
    <script type="text/javascript" src="/Public/js/TouchSlide.1.1.js"></script>
    <style type="text/css">
    	*{
    		margin: 0;
    		padding: 0;
    		list-style: none;
    	}
    	.language{
    		width: 100%;
    		height: 2rem;
    	}
    	.Choose{
    		width: 25%;
    		height: 1.5rem;
    		background: #FF8F2D;
    		border-radius: 1rem;
    		text-align: center;
    		line-height: 1.5rem;
    		margin-left: 3%;
    		font-weight: bold;
    		color: #fff;
    		margin-top: 1rem;
    	}
    	.hid{
    		display: none;
    	}
    	.tan{
    		position: absolute;
    		width: 70%;
    		top: 15%;
    		background: #fff;
    		z-index: 1000;
    		left: 15%;
    		padding-bottom: 2rem;
    		border-radius: 0.5rem;
    	}
    	.yuyan{
    		width: 50%;
    		height: 2rem;
    		background: red;
    		border-radius: 1rem;
    		text-align: center;
    		line-height: 2rem;
    		color: #fff;
    		margin-left: 25%;
    		margin-top: 2rem;
    		
    	}
    </style>
</head>
<body style="background: url(/Public/dianyun/img/bg.png) no-repeat rgb(220,198,162);background-size:100%;position: relative;">
<div class="language">
	<div class="Choose" onclick="choose()">Language</div>
</div>
<div class="tan hid">
	
	<p class="yuyan" onclick="language(1)">English</p>
	<p class="yuyan" onclick="language(2)">ภาษาไทย</p>
	<p class="yuyan" onclick="language(3)">हिंदीName</p>
	<p class="yuyan" onclick="language(4)">한국어.</p>
	<p class="yuyan" onclick="language(5)">日本語</p>
</div>
	<div class="index-c"style="margin-top:0rem">
		<ul>
			<a href="<?php echo U('Index/Wallet/paihangbang');?>">
			<li class="il1">
				<img src="/Public/dianyun/img/i-link-itemIcon1.png"/>
				<p>
				<?php if($language == 1 ): ?>Charging List<?php endif; ?>  
			    <?php if($language == 2 ): ?>ชาร์จตาราง<?php endif; ?> 
			    <?php if($language == 3 ): ?>चार्जिंग सूची<?php endif; ?> 
			    <?php if($language == 4 ): ?>충전 차 트<?php endif; ?> 
			    <?php if($language == 5 ): ?>充電リスト<?php endif; ?> 
				</p>
			</li>
			</a>
			<a href="<?php echo U('Index/Index/tgm');?>">
			<li class="il2">
				<img src="/Public/dianyun/img/i-link-itemIcon2.png"/>
				<p>
				<?php if($language == 1 ): ?>Invitation<?php endif; ?>  
			    <?php if($language == 2 ): ?>เชื้อเชิญ<?php endif; ?> 
			    <?php if($language == 3 ): ?>निमन्त्रणा<?php endif; ?> 
			    <?php if($language == 4 ): ?>초청 하 다.<?php endif; ?> 
			    <?php if($language == 5 ): ?>招待<?php endif; ?> 
				</p>
			</li>
			</a>
			
			<a href="<?php echo U('Index/New/xiangmu');?>">
			<li class="il3">
				<img src="/Public/dianyun/img/i-link-itemIcon3.png"/>
				<p>
				<?php if($language == 1 ): ?>Explain<?php endif; ?>  
			    <?php if($language == 2 ): ?>อธิบาย<?php endif; ?> 
			    <?php if($language == 3 ): ?>स्पष्ट करें<?php endif; ?> 
			    <?php if($language == 4 ): ?>설명 하 다.<?php endif; ?> 
			    <?php if($language == 5 ): ?>説明<?php endif; ?> 
				</p>
			</li>
			</a>
			
		</ul>
	</div>
	
	
	
	
	
	<div class="xxcctt">
		<a href="<?php echo U('Index/Task/index');?>">
		<img src="/Public/dianyun/img/index_ling.png" style="width:100%"/>
		<p class="hi">Hi</p>
		
		<?php if($language == 1 ): ?><p class="hdp" style="font-size:12px">The new power bank is on the shelves</p><?php endif; ?>  
	    <?php if($language == 2 ): ?><p class="hdp">แบรนด์ใหม่ชาร์จสมบัติบนชั้นวาง</p><?php endif; ?> 
	    <?php if($language == 3 ): ?><p class="hdp">नया पावर बैंक शेल्फों पर है </p><?php endif; ?> 
	    <?php if($language == 4 ): ?><p class="hdp">새로 충전 기 를 꺼 내 어 올 렸 다.</p><?php endif; ?> 
	    <?php if($language == 5 ): ?><p class="hdp"style="font-size:12px">新型の充電バッテリーが登場しました。</p><?php endif; ?> 
		
		<img src="/Public/dianyun/img/index_lingbi.png"  class="ling_img"/>
		
		<?php if($language == 1 ): ?><p class="gxn"style="font-size:18px;left:30%">Congratulations</p><?php endif; ?>  
	    <?php if($language == 2 ): ?><p class="gxn"style="left:30%">ยินดีด้วยนะ</p><?php endif; ?>
	    <?php if($language == 3 ): ?><p class="gxn"style="left:30%"> अभिनन्दन </p><?php endif; ?>
	    <?php if($language == 4 ): ?><p class="gxn"style="left:30%">축하합니다.</p><?php endif; ?> 
	    <?php if($language == 5 ): ?><p class="gxn"style="font-size:12px;left:30%">おめでとうございます</p><?php endif; ?>
		
		
		<?php if($language == 1 ): ?><p class="huode">Get a power bank</p><?php endif; ?>  
	    <?php if($language == 2 ): ?><p class="huode">ได้รับการชาร์จสมบัติ</p><?php endif; ?> 
	    <?php if($language == 3 ): ?><p class="huode"> एक पावर बैंक प्राप्त करें </p><?php endif; ?> 
	    <?php if($language == 4 ): ?><p class="huode">보조 배터리 1 대 획득</p><?php endif; ?> 
	    <?php if($language == 5 ): ?><p class="huode"style="margin-top:10px;">充電宝を一台獲得しました。</p><?php endif; ?>
		
		<a class="lilingqu" href="<?php echo U('Index/index/tgm');?>">
		<?php if($language == 1 ): ?>receive<?php endif; ?>  
	    <?php if($language == 2 ): ?>ได้รับ<?php endif; ?> 
	    <?php if($language == 3 ): ?>अब इसे प्राप्त करें<?php endif; ?> 
	    <?php if($language == 4 ): ?>수령 하 다.<?php endif; ?> 
	    <?php if($language == 5 ): ?>受け取ります<?php endif; ?>
	    </a>
		</a>
	</div>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	<div class="index-d">
		<p class="index-d-p"> <img src="/Public/dianyun/img/hot-icon.png"/>
		<?php if($language == 1 ): ?>Popular recommendation<?php endif; ?>  
	    <?php if($language == 2 ): ?>แนะนำร้อน<?php endif; ?> 
	    <?php if($language == 3 ): ?>प्रसिद्ध सिफारिश<?php endif; ?> 
	    <?php if($language == 4 ): ?>인기 추천<?php endif; ?> 
	    <?php if($language == 5 ): ?>おすすめ<?php endif; ?>
		<span>
		<?php if($language == 1 ): ?>More<?php endif; ?>  
	    <?php if($language == 2 ): ?>ยิ่งขึ้น<?php endif; ?> 
	    <?php if($language == 3 ): ?>अधिक<?php endif; ?> 
	    <?php if($language == 4 ): ?>더.<?php endif; ?> 
	    <?php if($language == 5 ): ?>詳細<?php endif; ?>
		</span> </p>
		
		<ul>
			<!--调用后台数据-->
			<?php if(is_array($typeData)): foreach($typeData as $key=>$v): ?><li>
				<p class="index-nc"><?php echo ($v["title"]); ?></p>
				<p class="index-fd">
				<?php if($language == 1 ): ?>Cycle<?php endif; ?>  
			    <?php if($language == 2 ): ?>กลมดิก<?php endif; ?> 
			    <?php if($language == 3 ): ?>सायकल<?php endif; ?> 
			    <?php if($language == 4 ): ?>주기.<?php endif; ?> 
			    <?php if($language == 5 ): ?>サイクル<?php endif; ?>：<?php echo ($v["yxzq"]); ?><span class="yjcd">
			    <?php if($language == 1 ): ?>Estimate<?php endif; ?>  
			    <?php if($language == 2 ): ?>ตั้งใจ<?php endif; ?> 
			    <?php if($language == 3 ): ?>अनुमान<?php endif; ?> 
			    <?php if($language == 4 ): ?>예상 하 다.<?php endif; ?> 
			    <?php if($language == 5 ): ?>見込みが立つ<?php endif; ?>
			    ：<?php echo ($v["shouyi"]); ?></span></p>
				<p class="index-jz">￥<?php echo ($v["price"]); ?> </p>
				<div class="lijgmbox">
				<a href="<?php echo U('Robot/buy',array('id'=>$v['id']));?>" class="index-ljgm">
				<?php if($language == 1 ): ?>Prchase<?php endif; ?>  
			    <?php if($language == 2 ): ?>ซื้อ<?php endif; ?> 
			    <?php if($language == 3 ): ?>खरीद करें<?php endif; ?> 
			    <?php if($language == 4 ): ?>구입 하 다.<?php endif; ?> 
			    <?php if($language == 5 ): ?>買います<?php endif; ?>
				</a>	
				</div>
			</li><?php endforeach; endif; ?>
			
		</ul>
		
	</div>
	
	
	<div class="index-i-lb">
		
	</div>
	<div class="area-20 buyer-history" style="border: 0px red solid;background: #FF8F2D; margin-top: 0px;width: 84%;margin-left: 3%;border-radius: 10px;box-shadow: 0px 3px 6px 0px rgba(85,54,237,0.13);background: #FF8F2D;margin-bottom: 5rem;">
							<h3 style="color: #fff;"><i class="icon iconfont icon-yonghuming"></i> 
							<?php if($language == 1 ): ?>Recently purchased users<?php endif; ?>  
						    <?php if($language == 2 ): ?>ล่าสุดซื้อผู้ใช้<?php endif; ?> 
						    <?php if($language == 3 ): ?>हाल में खरीद किया गया उपयोक्ता<?php endif; ?> 
						    <?php if($language == 4 ): ?>최근 구 매 유저<?php endif; ?> 
						    <?php if($language == 5 ): ?>最近の購入者<?php endif; ?>
							</h3>
								<marquee scrolldelay="200" id="lstBuyHistory" direction="up" onmouseover="this.stop()" onmouseout="this.start()" style="height: 60px;">
								<ul id="ulBuyHistory">
									<?php if(is_array($mai_log)): foreach($mai_log as $key=>$v): ?><li style="color: #fff;font-size:10px" ><?php echo (yc_phone($v["user"])); ?>&nbsp;&nbsp;
									
							<?php if($language == 1 ): ?>Purchase power bank<?php endif; ?>  
						    <?php if($language == 2 ): ?>ซื้อโปชาร์จ<?php endif; ?> 
						    <?php if($language == 3 ): ?>पावर बैंक खरीद करें<?php endif; ?> 
						    <?php if($language == 4 ): ?>구입 하 다.<?php endif; ?> 
						    <?php if($language == 5 ): ?>充電パックを買います<?php endif; ?>
									&nbsp;&nbsp;<?php echo (mb_substr($v["addtime"],5,11,'utf-8')); ?></li><?php endforeach; endif; ?>
								</ul>
							</marquee>
						</div>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	<footer>
		
		<div class="foot_bo">
		<a href="#">
			<img src="/Public/dianyun/img/i2.png" />
			<p class="xz">
			<?php if($language == 1 ): ?>Home<?php endif; ?>  
			    <?php if($language == 2 ): ?>หน้าแรก<?php endif; ?> 
			    <?php if($language == 3 ): ?>घर पृष्ठ<?php endif; ?> 
			    <?php if($language == 4 ): ?>홈 페이지<?php endif; ?> 
			    <?php if($language == 5 ): ?>最初のページ<?php endif; ?>
			</p>
		</a>
		</div>
		
		
		<div class="foot_cen">
		<a href="<?php echo U('Index/Robot/robot');?>">
			<img src="/Public/dianyun/img/i5.png"/>
		</a>
		</div>
		
		
		<div class="foot_bo1">
		<a href="<?php echo U('Index/Wallet/index');?>">
			<img src="/Public/dianyun/img/i3.png"/>
			<p>
				<?php if($language == 1 ): ?>My<?php endif; ?>  
			    <?php if($language == 2 ): ?>ข้า<?php endif; ?> 
			    <?php if($language == 3 ): ?>My<?php endif; ?> 
			    <?php if($language == 4 ): ?>나.<?php endif; ?> 
			    <?php if($language == 5 ): ?>私<?php endif; ?>
			</p>
		</a>
		</div>
		
		
	</footer>
	<script type="text/javascript" src="/Public/js/jquery-1.8.3.min.js"></script>
	<script type="text/javascript" charset="utf-8">
		function choose(){
			$(".tan").removeClass("hid");
		}
		function language(e){
			$.ajax({
        	url:"<?php echo U('Index/New/language');?>",
            type:'post',
            data:{'language':e},
            dataType:'json',
            success:function(json){
            	
               if(json.result ==1){
                    window.location.href=json.url;
                    
                }
            

                


            },
            error:function(){

                layer.msg(json.info);
            }

			

        });
		}
	</script>
	
    <script type="text/javascript">
      TouchSlide({
        slideCell:"#slideBox",
        titCell:"#slideBox .hd ul",
        mainCell:"#slideBox .bd ul",
        effect:"leftLoop",
        autoPage:true,
        autoPlay:true,
        interTime:3000

      });
    </script>

</body>
</html>