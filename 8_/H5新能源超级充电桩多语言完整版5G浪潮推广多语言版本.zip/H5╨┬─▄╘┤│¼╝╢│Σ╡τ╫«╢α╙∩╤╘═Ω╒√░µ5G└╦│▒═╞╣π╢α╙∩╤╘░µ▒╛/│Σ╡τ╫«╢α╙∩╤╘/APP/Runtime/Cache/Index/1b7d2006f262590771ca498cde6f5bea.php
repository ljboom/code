<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!-- saved from url=(0050)https://robot.paif.shop/m/accountbankmodify?type=2 -->
<html class="pixel-ratio-3 retina android android-5 android-5-0 watch-active-state"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta http-equiv="pragma" content="no-cache">
	<meta http-equiv="cache-control" content="no-cache">
	<meta http-equiv="expires" content="0">

	<title> <?php if($language == 1 ): ?>Edit<?php endif; ?>  
				    <?php if($language == 2 ): ?>ตัดต่อ<?php endif; ?> 
				    <?php if($language == 3 ): ?>संपादन<?php endif; ?> 
				    <?php if($language == 4 ): ?>편집 하 다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>編集<?php endif; ?> </title>


	<link rel="stylesheet" href="/Public/dianyun/css/app.css">
	<link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">
	<script src="/Public/js/jquery-1.8.3.min.js"></script>
	<script src="/Public/js/layer/layer.js"></script>

</head>
<body style="background: url(/Public/dianyun/img/bg.png) no-repeat rgb(220,198,162);background-size:100%;">

<form action="" method="POST" style="font-size:14px"  id="myform1">
<div class="pe-index-t">
  		<p class="pe-index-t-c"><?php if($language == 1 ): ?>Name<?php endif; ?>  
				    <?php if($language == 2 ): ?>นาม<?php endif; ?> 
				    <?php if($language == 3 ): ?>नाम<?php endif; ?> 
				    <?php if($language == 4 ): ?>명칭.<?php endif; ?> 
				    <?php if($language == 5 ): ?>名前<?php endif; ?> <span><input class="card-yy" id="truename" name="truename" type="text" maxlength="10" value="<?php echo ($name); ?>"></span> </p>
  		
  		<p class="pe-index-t-c"><?php if($language == 1 ): ?>Bank Name<?php endif; ?>  
				    <?php if($language == 2 ): ?>ชื่อธนาคาร<?php endif; ?> 
				    <?php if($language == 3 ): ?>बैंक नाम<?php endif; ?> 
				    <?php if($language == 4 ): ?>은행 명<?php endif; ?> 
				    <?php if($language == 5 ): ?>銀行の名前<?php endif; ?> <span><input class="card-yy" id="name" name="name" type="text" value="<?php echo ($list["name"]); ?>"></span> </p>
  		
  		<p class="pe-index-t-c"><?php if($language == 1 ): ?>Bank Name<?php endif; ?>  
				    <?php if($language == 2 ): ?>ชื่อธนาคาร<?php endif; ?> 
				    <?php if($language == 3 ): ?>बैंक नाम<?php endif; ?> 
				    <?php if($language == 4 ): ?>은행 명<?php endif; ?> 
				    <?php if($language == 5 ): ?>銀行の名前<?php endif; ?> 
  			<span style="width: 60%;">
  				
  				<select id="name" name="name" maxlength="50" style="width: 80%;float: right;display: inline-block;height: 2rem;margin-top: 0.5rem;border: none;border-radius: 1rem;">
													<option value="" selected="selected"><?php if($language == 1 ): ?>Please select<?php endif; ?>  
				    <?php if($language == 2 ): ?>โปรดเลือก<?php endif; ?> 
				    <?php if($language == 3 ): ?>कृपया चुनें<?php endif; ?> 
				    <?php if($language == 4 ): ?>선택 하 세 요.<?php endif; ?> 
				    <?php if($language == 5 ): ?>選択してください<?php endif; ?></option>
													<option value="中国工商银行">中国工商银行</option>
													
												</select>
  				
  			</span>
  		</p>
  		
  		<p class="pe-index-t-c">开户支行 <span><input class="card-yy"  id="kaihuhang" name="kaihuhang" type="text" maxlength="50" value="<?php echo ($list["kaihuhang"]); ?>"></span></p>
  		
  		<p class="pe-index-t-c">银行卡号 <span><input class="card-yy"  id="card" name="card" type="text" maxlength="20" value="<?php echo ($list["card"]); ?>"></span></p>
  		
  		
  	</div>

   <a href="javascript:bank_modify_commit()" class="r_but xgwdxx" idtype="myform1">
   	<?php if($language == 1 ): ?>Preservation<?php endif; ?>  
				    <?php if($language == 2 ): ?>เก็บรักษา<?php endif; ?> 
				    <?php if($language == 3 ): ?>संरक्षण<?php endif; ?> 
				    <?php if($language == 4 ): ?>보존 하 다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>保存<?php endif; ?> 
							</a>


</form>

















<script type="text/javascript">
    $(".r_but").click(function(){
        var idtype=$(this).attr("idtype");
        $.ajax({
            url:'<?php echo U("Index/index/addcardpost");?>',
            type:'POST',
            data:$("#"+idtype).serialize(),
            dataType:'json',
            success:function(json){
                layer.msg(json.info);
                if(json.result ==1){
                    window.location.href=json.url;
                }


            },
            error:function(){

                layer.msg("网络故障");
            }



        })

    })


</script>
</body></html>