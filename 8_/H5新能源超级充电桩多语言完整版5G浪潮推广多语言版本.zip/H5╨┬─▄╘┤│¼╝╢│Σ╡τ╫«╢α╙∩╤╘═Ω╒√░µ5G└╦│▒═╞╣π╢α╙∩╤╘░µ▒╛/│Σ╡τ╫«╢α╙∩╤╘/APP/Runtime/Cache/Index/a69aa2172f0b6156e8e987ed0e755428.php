<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html class="pixel-ratio-3 retina android android-5 android-5-0 watch-active-state"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <title>
    	<?php if($language == 1 ): ?>Member<?php endif; ?>  
				    <?php if($language == 2 ): ?>สมาชิก<?php endif; ?> 
				    <?php if($language == 3 ): ?>सदस्य<?php endif; ?> 
				    <?php if($language == 4 ): ?>회원<?php endif; ?> 
				    <?php if($language == 5 ): ?>会員<?php endif; ?>  </title>
    <link rel="stylesheet" href="/Public/dianyun/css/app.css">
    <link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">
    <style type="text/css">
    	*{
    		margin: 0;
    		padding: 0;
    	}
    </style>

  </head>
  </head>
<body style="background: url(/Public/dianyun/img/bg.png) no-repeat rgb(220,198,162);background-size:100%;">
  	
  	
  	<div class="pe-index-t">
  		<p class="pe-index-t-t"><?php if($language == 1 ): ?>Head Portrait<?php endif; ?>  
				    <?php if($language == 2 ): ?>พระพักตร์<?php endif; ?> 
				    <?php if($language == 3 ): ?>शीर्ष पोर्ट्रेट<?php endif; ?> 
				    <?php if($language == 4 ): ?>두상<?php endif; ?> 
				    <?php if($language == 5 ): ?>顔写真<?php endif; ?> <img src="/Public/dianyun/img/lg.png"/> </p>
  		<p class="pe-index-t-c"><?php if($language == 1 ): ?>Name<?php endif; ?>  
				    <?php if($language == 2 ): ?>นาม<?php endif; ?> 
				    <?php if($language == 3 ): ?>नाम<?php endif; ?> 
				    <?php if($language == 4 ): ?>명칭.<?php endif; ?> 
				    <?php if($language == 5 ): ?>名前<?php endif; ?>  <span><?php echo ($minfo["truename"]); ?></span> </p>
  		<p class="pe-index-t-c">UID <span>XD<?php echo ($minfo["id"]); ?></span> </p>
  		<p class="pe-index-t-c"><?php if($language == 1 ): ?>Cell-phone Number<?php endif; ?>  
				    <?php if($language == 2 ): ?>หมายเลขโทรศัพท์มือถือ<?php endif; ?> 
				    <?php if($language == 3 ): ?>सेल- फोन संख्या<?php endif; ?> 
				    <?php if($language == 4 ): ?>핸드폰 번호<?php endif; ?> 
				    <?php if($language == 5 ): ?>携帯の番号<?php endif; ?> <span><?php echo ($minfo["mobile"]); ?></span> </p>
  		<p class="pe-index-t-c" style="border:none"><?php if($language == 1 ): ?>Bank Card<?php endif; ?>  
				    <?php if($language == 2 ): ?>บัตรธนาคาร<?php endif; ?> 
				    <?php if($language == 3 ): ?>बैंक कार्ड<?php endif; ?> 
				    <?php if($language == 4 ): ?>은행 카드<?php endif; ?> 
				    <?php if($language == 5 ): ?>銀行カード<?php endif; ?> <span><?php echo ($list["card"]); ?></span> </p>
  	</div>
  	
  	<!--<p class="pe-index-zf">绑定收款账户</p>-->
  	
  	<!--<div class="pe-index-pp">-->
  	<!--	<p>提现支付宝</p>-->
  	<!--	<p class="pe-index-pppp"> <?php if(empty($minfo['zhifu'])): ?>-->
   <!--                                 <a style="color: rgba(220, 235, 245, 1);" class="external" href="<?php echo U('Index/Index/zhifu');?>" style="color: #000;">-->
   <!--                                     点击绑定-->
   <!--                                 </a>-->
			<!--						<?php else: ?>已绑定<?php endif; ?></p>-->
  	<!--</div>-->
  	
  	<a class="xgwdxx" href="<?php echo U('Index/Index/card');?>"><?php if($language == 1 ): ?>Modify<?php endif; ?>  
				    <?php if($language == 2 ): ?>ดัดนิสัย<?php endif; ?> 
				    <?php if($language == 3 ): ?>परिवर्धित करें<?php endif; ?> 
				    <?php if($language == 4 ): ?>고치다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>変更<?php endif; ?> </a>
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
<script src="/Public/dianyun/js/dist2.js"></script>
<script src="/Public/dianyun/js/dist.js"></script>

</body>
</html>