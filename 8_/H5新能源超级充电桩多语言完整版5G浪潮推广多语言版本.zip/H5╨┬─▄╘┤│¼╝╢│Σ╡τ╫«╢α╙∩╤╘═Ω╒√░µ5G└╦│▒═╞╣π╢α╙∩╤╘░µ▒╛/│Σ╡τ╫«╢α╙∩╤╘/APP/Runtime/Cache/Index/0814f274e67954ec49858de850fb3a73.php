<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html class="pixel-ratio-3 retina android android-5 android-5-0 watch-active-state"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta http-equiv="pragma" content="no-cache">
	<meta http-equiv="cache-control" content="no-cache">
	<meta http-equiv="expires" content="0">

	<title>reset password  </title>

	<link rel="stylesheet" href="/Public/dianyun/css/framework7.ios.min.css">
	<link rel="stylesheet" href="/Public/dianyun/css/app.css">
	<link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">

</head>

<body style="background: url(/Public/dianyun/img/login_bg.png) no-repeat #fff;background-size:100%;">
<div class="login_logo" style="height:14rem">
  		<img src="/Public/dianyun/img/lg.png"/>
  	</div>


<div class="views" style="margin-top:16rem;width: 92%;margin-left:4%">
	<div class="view view-main" data-page="forgotpwd" >
		<div class="pages">
			<div data-page="forgotpwd" class="page navbar-fixed" isinited="true">
				

				<div class="page-content defaultbg" style="padding:0px;border:none">
					<form action="" id="myform" method="post"style="margin-top:20px">
						<div class="input-container">
                        <div class="input-control" style="background:#F1F1F1">
                            <i class="icon iconfont icon-mobile"></i>
                            <input class="inputfield" type="text" id="mobile" name="mobile" placeholder="phone number" maxlength="11" value="">
                        </div>
                    </div>
                    <div class="input-container" >
                        <div class="input-control"style="background:#F1F1F1">
                            <i class="icon iconfont icon-mima"></i>
                            <input class="inputfield" type="password" id="password" name="password" placeholder="New password" value="">
                        </div>
                    </div>
                    <div class="input-container" >
                        <div class="input-control"style="background:#F1F1F1">
                            <i class="icon iconfont icon-mima"></i>
                            <input class="inputfield" type="password1" id="password1" name="password1" placeholder="Confirm password" value="">
                        </div>
                    </div>

                    

                    <!--<div class="input-container">-->
                    <!--    <div class="row">-->
                    <!--        <div class="col-60">-->
                    <!--            <div class="input-control"style="background:#F1F1F1">-->
                    <!--                <i class="icon iconfont icon-yanzhengma"></i>-->
                    <!--                <input class="inputfield" type="text" name="code"  id="code"  placeholder="短信验证码" value="">-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--        <div class="col-40" style="background: #fdb523;height: 40px;line-height: 40px;border-radius: 10px;text-align: center;">-->
                    <!--            <span id="count_down" onClick="send_sms_reg_code()">-->
                    <!--               <p style="background: rgb(234,178,94);height: 40px;line-height: 40px;border-radius: 10px;text-align: center;color:#fff">获取验证码</p>-->
                    <!--            </span>-->
                    <!--        </div>-->

                    <!--    </div>-->
                    <!--</div>-->

                    <div class="center">
                        <div class="space-10"></div>
                        <a href="javascript:account_reg_commit();" class="btn_submit_my login_la"style="color:#fff;background:linear-gradient(to right,rgb(252,216,157),rgb(234,178,93)">
                            Modify now
                        </a>
                        	
                    </div>
					</form>
				</div>
			</div>

		</div>
	</div>
</div>
<script src="/Public/js/jquery-1.11.3.min.js"></script>
<script src="/Public/js/jquery-weui.min.js"></script>
<script type="text/javascript">
    // 发送手机短信
    function send_sms_reg_code(){
        var mobile = $('#mobile').val();
        if(!checkMobile(mobile)){
            alert('Please enter the correct mobile phone number');
            return;
        }
        var url = "/index.php/index/sem/send_edit_code/mobile/"+mobile;
        $.get(url,function(data){
            obj = $.parseJSON(data);
            if(obj.status == 1)
            {
                $('#count_down').attr("disabled","disabled");
                intAs = 60; // 手机短信超时时间
                jsInnerTimeout('count_down',intAs);
            }
            alert(obj.msg);// alert(obj.msg);

        })
    }
    $('#count_down').removeAttr("disabled");
    //倒计时函数
    function jsInnerTimeout(id,intAs)
    {
        var codeObj=$("#"+id);
        //var intAs = parseInt(codeObj.attr("IntervalTime"));

        intAs--;
        if(intAs<=-1)
        {
            codeObj.removeAttr("disabled");
//            codeObj.attr("IntervalTime",60);
            codeObj.text("Get verification code");
            return true;
        }

        codeObj.text(intAs+'秒');
//        codeObj.attr("IntervalTime",intAs);

        setTimeout("jsInnerTimeout('"+id+"',"+intAs+")",1000);
    };
    function checkMobile(tel) {
        var reg = /(^1[3|4|5|7|8][0-9]{9}$)/;
        if (reg.test(tel)) {
            return true;
        }else{
            return false;
        };
    }
</script>
<script type="text/javascript">
    $(".btn_submit_my").click(function(){

        $.ajax({
            url:'<?php echo U("Index/Login/editPwd");?>',
            type:'POST',
            data:$("#myform").serialize(),
            dataType:'json',
            success:function(json){
                alert(json.info);
                if(json.result ==1){
                    window.location.href='<?php echo U("Index/Login/index");?>';
                }
            },
            error:function(){
                alert("网络故障");
            }
        })
    })

</script>
</body></html>