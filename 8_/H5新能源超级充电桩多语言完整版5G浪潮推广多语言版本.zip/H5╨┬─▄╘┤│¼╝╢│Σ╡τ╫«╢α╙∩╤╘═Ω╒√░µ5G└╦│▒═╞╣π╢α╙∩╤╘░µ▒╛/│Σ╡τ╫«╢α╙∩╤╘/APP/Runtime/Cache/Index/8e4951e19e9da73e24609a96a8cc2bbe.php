<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html class="pixel-ratio-3 retina android android-5 android-5-0 watch-active-state"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <title>
    <?php if($language == 1 ): ?>Invitation<?php endif; ?>  
			    <?php if($language == 2 ): ?>เชื้อเชิญ<?php endif; ?> 
			    <?php if($language == 3 ): ?>निमन्त्रणा<?php endif; ?> 
			    <?php if($language == 4 ): ?>초청 하 다.<?php endif; ?> 
			    <?php if($language == 5 ): ?>招待<?php endif; ?>
    </title>
    <link rel="stylesheet" href="/Public/dianyun/css/app.css">
    <link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">
    <style type="text/css">
    	*{
    		margin: 0;
    		padding: 0;
    		text-decoration: none;
    		list-style: none;
    	}
    	.navbar-fixed .page-content, .navbar-through .page-content{
    		margin-top: 0px;
    		padding-top: 0px;
    	}
    	.bcemw{
    		width: 90%;
    		height: 3rem;
    		background: #ecbf54;
    		position: fixed;
    		bottom: 5rem;
    		left: 5%;
    		border-radius: 4rem;
    		text-align: center;
    		line-height: 3rem;
    		font-size: 18px;
    		color: #fff;
    	}
    	.box{
    		width: 94%;
    		height: 30rem;
    		margin-left: 3%;
    		background: linear-gradient(rgba(253, 214, 150, 1), rgba(234, 171, 76, 1));
    		margin-top: 5rem;
    		border-radius: 0.5rem;
    	}
    	.yao_title{
    		width: 100%;
    		height: 2rem;
    		font-size: 20px;
    		font-weight: bold;
    		color: #fff;
    		padding-top: 1rem;
    		text-align: center;
    		border-bottom: 1px solid #fff;
    		padding-bottom:1rem;
    		
    	}
    	.tgm{
    		width: 94%;
    		margin-left: 3%;
    		margin-top: 1rem;
    	}
    </style>

</head>
<body style="background: url(/Public/dianyun/img/bg.png) no-repeat rgb(220,198,162);background-size:100%;">
<div class="box">
	<p class="yao_title">
		<?php if($language == 1 ): ?>Portable Battery<?php endif; ?>  
			    <?php if($language == 2 ): ?>สมบัติชาร์จ<?php endif; ?> 
			    <?php if($language == 3 ): ?>पोर्टेबल बैटरी<?php endif; ?> 
			    <?php if($language == 4 ): ?>보조 배터리<?php endif; ?> 
			    <?php if($language == 5 ): ?>充電パック<?php endif; ?>
	</p>
	<img src="<?php echo ($erwei); ?>" alt="" class="tgm"/>
</div> 

<a class="bcemw" href="#"><?php if($language == 1 ): ?>Save QR code<?php endif; ?>  
			    <?php if($language == 2 ): ?>บันทึกรหัส 2D<?php endif; ?> 
			    <?php if($language == 3 ): ?>QR कोड सहेजें<?php endif; ?> 
			    <?php if($language == 4 ): ?>QR 코드 저장<?php endif; ?> 
			    <?php if($language == 5 ): ?>二次元コードを保存<?php endif; ?></a>

</body></html>