<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html class="pixel-ratio-3 retina android android-5 android-5-0 watch-active-state"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <title><?php if($language == 1 ): ?>Withdrawal<?php endif; ?>  
				    <?php if($language == 2 ): ?>ถอนเงิน<?php endif; ?> 
				    <?php if($language == 3 ): ?>रेखाचित्र<?php endif; ?> 
				    <?php if($language == 4 ): ?>현금 을 인출 하 다<?php endif; ?>  
				    <?php if($language == 5 ): ?>現金で出す<?php endif; ?>  </title>

    <link rel="stylesheet" href="/Public/dianyun/css/framework7.ios.min.css">
    <link rel="stylesheet" href="/Public/dianyun/css/app.css">
    <link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">
    <script src="/Public/js/jquery-1.8.3.min.js"></script>
    <script src="/Public/js/layer/layer.js"></script>
    <style type="text/css">
    	*{
    		margin: 0;
    		padding: 0;
    		list-style: none;
    	}
    	.layui-layer-hui{
    		color: red;
    		background-color: rgb(220, 235, 245);
    		
    	}
    </style>

</head>
<body style="background: url(/Public/dianyun/img/bg.png) no-repeat rgb(220,198,162);background-size:100%;">
	
	<form action="" method="POST" style="font-size:14px"  id="myform1">
	<div class="wi-tix">
		<p class="wi-tix-ktx"><?php if($language == 1 ): ?>Withdrawal<?php endif; ?>  
				    <?php if($language == 2 ): ?>ถอนเงิน<?php endif; ?> 
				    <?php if($language == 3 ): ?>रेखाचित्र<?php endif; ?> 
				    <?php if($language == 4 ): ?>현금 을 인출 하 다<?php endif; ?>  
				    <?php if($language == 5 ): ?>現金で出す<?php endif; ?> <span><a href="<?php echo U('Index/Wallet/withdrawnlog');?>" style="color: #FEB620;border: 1px solid #fff;border-radius: 10rem;padding:0.2rem 0.5rem"><?php if($language == 1 ): ?>Record<?php endif; ?>  
				    <?php if($language == 2 ): ?>อัดแผ่นเสียง<?php endif; ?> 
				    <?php if($language == 3 ): ?>रिकार्ड<?php endif; ?> 
				    <?php if($language == 4 ): ?>기록 하 다.<?php endif; ?>  
				    <?php if($language == 5 ): ?>記録<?php endif; ?> </a></span> </p>
		<p class="wi-tix-sss"><span style="color:#fff">¥</span> <input style="color: #fff;" id="money" name="money" type="text" maxlength="10" value=""> </p>
		
		<p class="wi-tix-oo"><?php if($language == 1 ): ?>Warm tips: 5% service charge for each withdrawal<?php endif; ?>  
				    <?php if($language == 2 ): ?>คิดค่าบริการต่อห้าเปอร์เซ็นต์<?php endif; ?> 
				    <?php if($language == 3 ): ?>वार्म टिप्स: हर घटना के लिए 5% सेवा चार्ज<?php endif; ?> 
				    <?php if($language == 4 ): ?>팁: 현금 을 인출 할 때마다 5% 의 수수 료 를 받 습 니 다.<?php endif; ?>  
				    <?php if($language == 5 ): ?>提示：提示は一つにつき5%の手数料をいただきます。<?php endif; ?> </p>
	</div>
	<div class="item-content" style="width:94%;height:4rem;margin-top:2rem;margin-left:3%;border-radius: 0.3rem;background:rgba(255, 143, 45, 1)">
                                            <div class="item-inner">
                                                <div class="item-input">
                                                    <select id="type" name="type" maxlength="50" style="color: rgba(220, 235, 245, 1);width: 100%;margin-top:1rem;height: 2rem;border: 0.3rem;background: rgba(255, 143, 45, 1);padding: 0 1rem;">
                                                        <option value="" selected="selected">币种请选择</option>
                                                        <option value="2">支付宝</option>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
	
	<a href="javascript:bank_modify_commit()" class="r_but wi-tix-ttxx" idtype="myform1"><?php if($language == 1 ): ?>Withdrawal<?php endif; ?>  
				    <?php if($language == 2 ): ?>ถอนเงิน<?php endif; ?> 
				    <?php if($language == 3 ): ?>रेखाचित्र<?php endif; ?> 
				    <?php if($language == 4 ): ?>현금 을 인출 하 다<?php endif; ?>  
				    <?php if($language == 5 ): ?>現金で出す<?php endif; ?></a>
	
	</form>
	
	
	
	
	
	
	
	<div class="layui-layer layui-anim layui-layer-dialog layui-layer-border layui-layer-msg layui-layer-hui" id="layui-layer1" type="dialog" times="1" showtime="3000" contype="string" style="z-index: 19891015; top: 400px; left: 15px;"><div class="layui-layer-content"><?php if($language == 1 ): ?>Please fill in the withdrawal amount correctly<?php endif; ?>  
				    <?php if($language == 2 ): ?>กรุณากรอกข้อมูลในการถอนเงินอย่างถูกต้อง<?php endif; ?> 
				    <?php if($language == 3 ): ?>कृपया प्रतिलिपि मात्रा सही रूप से भरें<?php endif; ?> 
				    <?php if($language == 4 ): ?>현금 인출 금액 을 정확히 기입 하 세 요.<?php endif; ?>  
				    <?php if($language == 5 ): ?>現金引き出し金額を正確に記入してください。<?php endif; ?>！</div><span class="layui-layer-setwin"></span></div>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

<script type="text/javascript">
    $(".r_but").click(function(){
        var idtype=$(this).attr("idtype");
        $.ajax({
            url:'<?php echo U("Index/Wallet/withpost");?>',
            type:'POST',
            data:$("#"+idtype).serialize(),
            dataType:'json',
            success:function(json){
                layer.msg(json.info);
                if(json.result ==1){
                    window.location.href=json.url;
                }


            },
            error:function(){

                layer.msg("网络故障");
            }



        })

    })


</script>
</body></html>