<?php if (!defined('THINK_PATH')) exit();?>
     
<!DOCTYPE html>

<html class="pixel-ratio-3 retina android android-5 android-5-0 watch-active-state"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="expires" content="0">

    <title> 
    <?php if($language == 1 ): ?>My<?php endif; ?>  
	    <?php if($language == 2 ): ?>ข้า<?php endif; ?> 
	    <?php if($language == 3 ): ?>My<?php endif; ?> 
	    <?php if($language == 4 ): ?>나.<?php endif; ?> 
	    <?php if($language == 5 ): ?>私<?php endif; ?>
    </title>

    <link rel="stylesheet" href="/Public/dianyun/css/app.css">
    <link rel="stylesheet" href="/Public/dianyun/css/iconfont.css">
    <style type="text/css">
    	*{
    		margin: 0;
    		padding: 0;
    		text-decoration: none;
    		list-style: none;
    	}
    </style>
  </head>
<body style="background: url(/Public/dianyun/img/bg.png) no-repeat rgb(220,198,162);background-size:100%;">
   
     <div class="me-index-top">
     	
     	<div class="me-index-top-t">
     		<img src="/Public/dianyun/img/lg.png"/>
     		
     		<?php if($language == 1 ): ?><p class="me-index-top-s" style="font-size:15px">Recommendation code</p><?php endif; ?>  
	    <?php if($language == 2 ): ?><p class="me-index-top-s">รหัสแนะนำ</p><?php endif; ?> 
	    <?php if($language == 3 ): ?><p class="me-index-top-s">सिफारिसेंटेशन कोड</p><?php endif; ?> 
	    <?php if($language == 4 ): ?><p class="me-index-top-s">추천 코드</p><?php endif; ?> 
	    <?php if($language == 5 ): ?><p class="me-index-top-s">推奨コード</p><?php endif; ?>
     		
     		<p class="me-index-top-k"> XD<?php echo ($minfo["id"]); ?><a href="<?php echo U('/Wallet/onlinerecharge');?>" class="me-index-top-chonghzi">
     		<?php if($language == 1 ): ?>Recharge<?php endif; ?>  
	    <?php if($language == 2 ): ?>เติม<?php endif; ?> 
	    <?php if($language == 3 ): ?>फिर चार्ज करें<?php endif; ?> 
	    <?php if($language == 4 ): ?>충전<?php endif; ?> 
	    <?php if($language == 5 ): ?>チャージ<?php endif; ?>	
     		</a></p>
     		
     			
     		
     		
     	</div>
     	
     	<div class="me-index-top-b">
     		<div class="me-index-top-ab">
     			<p class="me-index-top-uyy"><?php echo ($minfo["jinbi"]); ?> </p>
     			<p>
     				<?php if($language == 1 ): ?>Profit<?php endif; ?>  
				    <?php if($language == 2 ): ?>ผลประโยชน์<?php endif; ?> 
				    <?php if($language == 3 ): ?>लाभ<?php endif; ?> 
				    <?php if($language == 4 ): ?>수익.<?php endif; ?> 
				    <?php if($language == 5 ): ?>利益を収める<?php endif; ?>	
     				</p>
     		</div>
     		
     		<div class="me-index-top-ab">
     			<p class="me-index-top-uyy"><?php echo ($count); ?></p>
     			
     			<?php if($language == 1 ): ?><p style="font-size:10px">Portable Battery</p><?php endif; ?>  
				    <?php if($language == 2 ): ?><p>สมบัติชาร์จ</p><?php endif; ?> 
				    <?php if($language == 3 ): ?><p>पोर्टेबल बैटरी</p><?php endif; ?> 
				    <?php if($language == 4 ): ?><p >보조 배터리</p><?php endif; ?> 
				    <?php if($language == 5 ): ?><p>充電パック</p><?php endif; ?>
     			
     		</div>
     		
     		<div class="me-index-top-ab">
     			<p class="me-index-top-uyy"><?php echo ($minfo["gamecount"]); ?> </p>
     			<p>
     				<?php if($language == 1 ): ?>Team<?php endif; ?>  
				    <?php if($language == 2 ): ?>ทีม<?php endif; ?> 
				    <?php if($language == 3 ): ?>टीम<?php endif; ?> 
				    <?php if($language == 4 ): ?>단체.<?php endif; ?> 
				    <?php if($language == 5 ): ?>チーム<?php endif; ?></p>
     		</div>
     		
     	</div>
     	
     	
     </div>
     
     
     <div class="me-index-cccc">
     	
     	<ul>
     		
     		
     		<li class="user_ziliao">
     			<a href="<?php echo U('Index/Index/personal');?>"> <img src="/Public/dianyun/img/userLink-icon1.png"/></a>
     			<p>
     			<?php if($language == 1 ): ?>Member<?php endif; ?>  
				    <?php if($language == 2 ): ?>สมาชิก<?php endif; ?> 
				    <?php if($language == 3 ): ?>सदस्य<?php endif; ?> 
				    <?php if($language == 4 ): ?>회원<?php endif; ?> 
				    <?php if($language == 5 ): ?>会員<?php endif; ?>
     			</p>
     		</li>
     		
     		
     		
     		<li style="margin-left:5%" class="user_chong">
     			<a href="<?php echo U('/Wallet/onlinerecharge');?>"> <img src="/Public/dianyun/img/userLink-icon7.png"/></a>
     			<p>
     				<?php if($language == 1 ): ?>Recharge<?php endif; ?>  
				    <?php if($language == 2 ): ?>เติม<?php endif; ?> 
				    <?php if($language == 3 ): ?>फिर चार्ज करें<?php endif; ?> 
				    <?php if($language == 4 ): ?>충전<?php endif; ?> 
				    <?php if($language == 5 ): ?>チャージ<?php endif; ?>
     			</p>
     		</li>
     		
     		<li style="float: right;"class="user_shou">
     			<a href="<?php echo U('Wallet/award');?>"> <img src="/Public/dianyun/img/userLink-icon9.png"/></a>
     			<p>
     				<?php if($language == 1 ): ?>Profit<?php endif; ?>  
				    <?php if($language == 2 ): ?>ผลประโยชน์<?php endif; ?> 
				    <?php if($language == 3 ): ?>लाभ<?php endif; ?> 
				    <?php if($language == 4 ): ?>수익<?php endif; ?> 
				    <?php if($language == 5 ): ?>利益を収める<?php endif; ?>
     			</p>
     		</li>
     		
     		
     		
     		<li class="user_tixian">
     			<a href="<?php echo U('Wallet/tixian');?>"> <img src="/Public/dianyun/img/userLink-icon4.png"/></a>
     			
     				<?php if($language == 1 ): ?><p>Withdrawal</p><?php endif; ?>  
				    <?php if($language == 2 ): ?><p>ถอนเงิน</p><?php endif; ?>
				    <?php if($language == 3 ): ?><p>रेखाचित्र</p><?php endif; ?>
				    <?php if($language == 4 ): ?><p style="font-size:12px">현금 을 인출 하 다</p><?php endif; ?> 
				    <?php if($language == 5 ): ?><p>現金で出す</p><?php endif; ?>
     			
     		</li>
     		
     		<li style="margin-left:5%" class="user_xiaji">
     			<a href="<?php echo U('Index/Index/team');?>"> <img src="/Public/dianyun/img/userLink-icon5.png"/></a>
     			<p>
     				<?php if($language == 1 ): ?>Subordinate<?php endif; ?>  
				    <?php if($language == 2 ): ?>ความหยาบช้า<?php endif; ?> 
				    <?php if($language == 3 ): ?>उपनिर्धारित<?php endif; ?> 
				    <?php if($language == 4 ): ?>하급<?php endif; ?> 
				    <?php if($language == 5 ): ?>下の者<?php endif; ?>
     			</p>
     		</li>
     		
     		
     		
     		<li style="float: right;" class="user_tui">
     			<a href="<?php echo U('Index/Index/tgm');?>"> <img src="/Public/dianyun/img/userLink-icon6.png"/></a>
     			<p>
     				<?php if($language == 1 ): ?>Recommend<?php endif; ?>  
				    <?php if($language == 2 ): ?>แนะนำ<?php endif; ?> 
				    <?php if($language == 3 ): ?>सिफारिस करें<?php endif; ?> 
				    <?php if($language == 4 ): ?>추천 하 다<?php endif; ?> 
				    <?php if($language == 5 ): ?>おすすめ<?php endif; ?>
     			</p>
     		</li>
     		
     		<li  class="user_xiazai">
     			<a href="<?php echo ($appxia); ?>"> <img src="/Public/dianyun/img/userLink-icon3.png"/></a>
     			<p>
     				<?php if($language == 1 ): ?>Download<?php endif; ?>  
				    <?php if($language == 2 ): ?>ดาวน์โหลด<?php endif; ?> 
				    <?php if($language == 3 ): ?>डाउनलोड<?php endif; ?> 
				    <?php if($language == 4 ): ?>다운로드 하 다<?php endif; ?> 
				    <?php if($language == 5 ): ?>ダウンロード<?php endif; ?>
     			</p>
     		</li>
     		<li style="margin-left:5%"  class="user_guanyu">
     			<a href="<?php echo U('Index/New/xiangmu');?>"> <img src="/Public/dianyun/img/userLink-icon8.png"/></a>
     			<p>
     				<?php if($language == 1 ): ?>Explain<?php endif; ?>  
				    <?php if($language == 2 ): ?>อธิบาย<?php endif; ?> 
				    <?php if($language == 3 ): ?>स्पष्ट करें<?php endif; ?> 
				    <?php if($language == 4 ): ?>설명 하 다<?php endif; ?> 
				    <?php if($language == 5 ): ?>説明<?php endif; ?>
     			</p>
     		</li>
     		<li style="float: right;" class="user_jieshao">
     			<a href="<?php echo U('Index/New/help');?>"> <img src="/Public/dianyun/img/userLink-icon10.png"/></a>
     			
     				<?php if($language == 1 ): ?><p>Help</p><?php endif; ?>  
				    <?php if($language == 2 ): ?><p style="font-size:12px">ช่วยเหลือเจือจาน</p><?php endif; ?>  
				    <?php if($language == 3 ): ?><p>मदद</p><?php endif; ?>  
				    <?php if($language == 4 ): ?><p>돕다</p><?php endif; ?> 
				    <?php if($language == 5 ): ?><p>ヘルプ</p><?php endif; ?>
     			
     		</li>
     		
     		
     		
     		
     	
     	
     	<a class="me-index-tc" style="color:#EAAB4C;font-weight: bold;" href="<?php echo U('Index/Index/logout');?>" onclick="if(confirm('<?php if($language == 1 ): ?>Are you sure to exit the current account<?php endif; ?>  
				    <?php if($language == 2 ): ?>ยืนยันการออกจากบัญชีปัจจุบันของคุณ<?php endif; ?> 
				    <?php if($language == 3 ): ?>क्या आप मौजूदा खाता से बाहर होने के लिए निश्चित हैं<?php endif; ?> 
				    <?php if($language == 4 ): ?>현재 계 정 탈퇴 하 시 겠 습 니까<?php endif; ?> 
				    <?php if($language == 5 ): ?>現在のアカウントから退出することを確認しますか<?php endif; ?>？')==false)return false;">
     	<?php if($language == 1 ): ?>Out<?php endif; ?>  
				    <?php if($language == 2 ): ?>ถอนตัว<?php endif; ?> 
				    <?php if($language == 3 ): ?>हस्ताक्षर करें<?php endif; ?> 
				    <?php if($language == 4 ): ?>탈퇴 하 다.<?php endif; ?> 
				    <?php if($language == 5 ): ?>終了<?php endif; ?></a>
     	
     	
     </div>
























  	<footer>
  	
  		<div class="foot_bo">
  			<a href="<?php echo U('Index/New/index');?>">
  				<img src="/Public/dianyun/img/i1.png" />
  				<p style="color:#fff">
  				<?php if($language == 1 ): ?>Home<?php endif; ?>  
			    <?php if($language == 2 ): ?>หน้าแรก<?php endif; ?> 
			    <?php if($language == 3 ): ?>घर पृष्ठ<?php endif; ?> 
			    <?php if($language == 4 ): ?>홈 페이지<?php endif; ?> 
			    <?php if($language == 5 ): ?>最初のページ<?php endif; ?>
  				</p>
  			</a>
  		</div>
  	
  		<div class="foot_cen">
  			<a href="<?php echo U('Index/Robot/robot');?>">
  				<img src="/Public/dianyun/img/i5.png" />
  			</a>
  		</div>
  	
  		<div class="foot_bo1">
  			<a href="<?php echo U('Index/Wallet/index');?>">
  				<img src="/Public/dianyun/img/i4.png" />
  				<p class="xz">
  					<?php if($language == 1 ): ?>My<?php endif; ?>  
			    <?php if($language == 2 ): ?>ข้า<?php endif; ?> 
			    <?php if($language == 3 ): ?>My<?php endif; ?> 
			    <?php if($language == 4 ): ?>나.<?php endif; ?> 
			    <?php if($language == 5 ): ?>私<?php endif; ?>
  				</p>
  			</a>
  		</div>
  	
  	</footer>





</body>
</html>