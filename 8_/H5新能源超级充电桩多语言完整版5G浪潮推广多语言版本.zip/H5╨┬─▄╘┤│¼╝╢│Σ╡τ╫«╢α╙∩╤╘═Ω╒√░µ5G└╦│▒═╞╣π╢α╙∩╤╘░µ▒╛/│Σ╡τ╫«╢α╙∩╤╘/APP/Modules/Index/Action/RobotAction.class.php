<?php  
	//消息相关控制器
	Class RobotAction extends CommonAction{


		public function index(){
            $user_id=session('mid');
            $count = M('order') ->where(array('user_id'=>$user_id,'zt'=>1))->count();
            $minfo = M('member')->where(array('id'=>$user_id))->find();
            $this -> assign('minfo',$minfo);
            $this -> assign('count',$count);
			$this->display();
		}
		//商品详情
		public function pcontent(){

            $product = M("product");
            $typeData = $product -> where("is_on = 0") ->order("id asc") -> select();
            $this->assign("typeData",$typeData);


            $this->display();
		}

        //订单提交
        public function buy(){
			$username = session('username');
            $id =  I('get.id',0,'intval');
            $product = M("product");
			$language = M('member')->where(array('username'=>$username))->getField('language');
            
            //查询机器人信息
            $data = $product -> find($id);
            if(empty($data)){
            	if($language==1){
            		alert('Power bank does not exist',U('Robot/index'));
            	}else if($language==2){
            		alert('ชาร์จสมบัติไม่มีอยู่จริง',U('Robot/index'));
            	}else if($language==3){
            		alert('पावर बैंक मौजूद नहीं है',U('Robot/index'));
            	}else if($language==4){
            		alert('보조 배터리 가 존재 하지 않 습 니 다',U('Robot/index'));
            	}else if($language==5){
            		alert('充電パックは存在しません',U('Robot/index'));
            	}
            	
                
            }

            $letter = M('type')->where(array('id'=>$data['tid']))->getField('name');
            //判断 是否已经达到限购数量
            $my_gounum=M("order")->where(array("user"=>session('username'),"sid"=>$id))->count();
            if($my_gounum >=$data['xiangou']){
            	if($language==1){
            		echo '<script>alert("It has reached the online level of the current power bank！");window.history.back(-1);</script>';
                die;
            	}else if($language==2){
            		echo '<script>alert("ถึงปัจจุบันชาร์จสมบัติออนไลน์！");window.history.back(-1);</script>';
                die;
            	}else if($language==3){
            		echo '<script>alert("यह मौजूदा पावर बैंक का ऑनलाइन स्तर पहुँचा है！");window.history.back(-1);</script>';
                die;
            	}else if($language==4){
            		echo '<script>alert("이미 현재 충전 보물 의 온라인 상태 에 도달 하 였 습 니 다");window.history.back(-1);</script>';
                die;
            	}else if($language==5){
            		echo '<script>alert("現在の充電宝のオンラインに達しました！");window.history.back(-1);</script>';
                die;
            	}
                
            }
            if($data['stock'] < 1){
            	if($language==1){
            		echo '<script>alert("The power bank is sold out！");window.history.back(-1);</script>';
                die;
            	}else if($language==2){
            		echo '<script>alert("ชาร์จสมบัติขายออก");window.history.back(-1);</script>';
                die;
            	}else if($language==3){
            	echo '<script>alert("पावर बैंक बेचा गया है！");window.history.back(-1);</script>';
                die;
            	}else if($language==4){
            		echo '<script>alert("보조 배터리 가 매진 되 었 습 니 다");window.history.back(-1);</script>';
                die;
            	}else if($language==5){
            		echo '<script>alert("充電パックはもう売り切れました。");window.history.back(-1);</script>';
                die;
            	}
                
            }
            $faquan = C('faquan');

            
            $tuijian = M('member')->where(array('username'=>$username))->getField('parent');
            if($id == $faquan) {
                $jifen = M('member')->where(array('username' => $username))->getField('jifen');
                if ($jifen < $data['price']) {
                	if($language==1){
            		alert('Insufficient gold coins in the account',U('task/index'));
            	}else if($language==2){
            		alert('เหรียญทองในบัญชีไม่เพียงพอ',U('task/index'));
            	}else if($language==3){
            		alert('खाता में अपर्याप्त सोने कोना！', U('task/index'));
            	}else if($language==4){
            		alert('계 정 금화 부족',U('task/index'));
            	}else if($language==5){
            		alert('口座金貨が足りません',U('task/index'));
            	}
                    
                }

                M("member")->where(array('username' => session('username')))->setDec('jifen', $data['price']);
                $map = array();
                $map['kjbh'] = $letter . date('d') . substr(time(), -5) . sprintf('%02d', rand(0, 99));
                $map['user'] = $username;
                $map['user_id'] = session('mid');
                $map['project'] = $data['title'];
                $map['sid'] = $data['id'];
                $map['yxzq'] = $data['yxzq'];
                $map['shouyi'] = $data['shouyi'];
                $map['sumprice'] = $data['price'];
                $map['addtime'] = date('Y-m-d H:i:s');
                $map['imagepath'] = $data['thumb'];
                $map['zt'] = 1;
                $map['UG_getTime'] = time();
                if (M('order')->add($map)) {
                    M('member')->where(array('username' => $username))->setInc('robotcount');
                }
            }else {

                $jinbi = M('member')->where(array('username' => $username))->getField('jinbi');
                if ($jinbi < $data['price']) {
                	if($language==1){
            		alert('Account balance is insufficient, please recharge first',U('wallet/onlinerecharge'));
            	}else if($language==2){
            		alert('ยอดคงเหลือในบัญชีไม่เพียงพอกรุณาเติมเงินก่อน', U('wallet/onlinerecharge'));
            	}else if($language==3){
            		alert('खाता बैलेन्स अपर्याप्त है, कृपया पहले फिर चार्ज करें', U('wallet/onlinerecharge'));
            	}else if($language==4){
            		alert('계좌 잔액 부족, 우선 충전 하 세 요', U('wallet/onlinerecharge'));
            	}else if($language==5){
            		alert('口座の残高が足りないので、先にチャージしてください', U('wallet/onlinerecharge'));
            	}
                    
                }

                M("member")->where(array('username' => session('username')))->setDec('jinbi', $data['price']);
                account_log(session('username'), $data['price'], 'purchase' . $data['title'], 0);
                $map = array();
                $map['kjbh'] = $letter . date('d') . substr(time(), -5) . sprintf('%02d', rand(0, 99));
                $map['user'] = $username;
                $map['tuijian'] = $tuijian;
                $map['user_id'] = session('mid');
                $map['project'] = $data['title'];
                $map['sid'] = $data['id'];
                $map['yxzq'] = $data['yxzq'];
                $map['shouyi'] = $data['shouyi'];
                $map['sumprice'] = $data['price'];
                $map['addtime'] = date('Y-m-d H:i:s');
                $map['imagepath'] = $data['thumb'];
                $map['zt'] = 1;
                $map['UG_getTime'] = time();
                $price=$data['price'];
                if (M('order')->add($map)) {
                    M('member')->where(array('username' => $username))->setInc('robotcount');
                   
                    M('member')->where(array('username' => $username))->setDec('jinbi',$price);
                    $first = M('member')->where(array('username' => $username))->getField('first');
                    if($first == 0){
                    	$shouci = C('shouci');
                    	M("member")->where(array('username' => $username))->setInc('jinbi', $shouci);
                    	account_log($username, $shouci, 'First time purchase', 1, 2, 1, 0, $username);
                    	M('member')->where(array('username' => $username))->save(['first' => 1]);
                    }
                    $parent = getMemberField('parent');
                    M('member')->where(array('username' => $parent))->setInc('shuliang', 1);
                    M('member')->where(array('username' => $username))->setInc('consumption', $price);
                    $shuliang = M('member')->where(array('username' => $parent))->getField('shuliang');
                    $consumption = M('member')->where(array('username' => $username))->getField('consumption');
                    $number1=M('levels')->where(array('id' => 1))->getField('number');
                    $number2=M('levels')->where(array('id' => 2))->getField('number');
                    $number3=M('levels')->where(array('id' => 3))->getField('number');
                    $number4=M('levels')->where(array('id' => 4))->getField('number');
                    $number5=M('levels')->where(array('id' => 5))->getField('number');
                    $buy1=M('levels')->where(array('id' => 1))->getField('buy');
                    $buy2=M('levels')->where(array('id' => 2))->getField('buy');
                    $buy3=M('levels')->where(array('id' => 3))->getField('buy');
                    $buy4=M('levels')->where(array('id' => 4))->getField('buy');
                    $buy5=M('levels')->where(array('id' => 5))->getField('buy');
                    $levelss = M('member')->where(array('username' => $username))->getField('levels');
                    if($levelss==0){
                    	if($consumption>=$buy1 and $consumption<$buy2){
	                    	M('member')->where(array('username' => $username))->save(['levels' => 1]);
	                    }
                    }
                    if($levelss==1){
                    	if($consumption>=$buy2 and $consumption<$buy3){
	                    	M('member')->where(array('username' => $username))->save(['levels' => 2]);
	                    }
                    }
                    if($levelss==2){
                    	if($consumption>=$buy3 and $consumption<$buy4){
	                    	M('member')->where(array('username' => $username))->save(['levels' => 3]);
	                    }
                    }
                    if($levelss==3){
	                    if($consumption>=$buy4 and $consumption<$buy5){
	                    	M('member')->where(array('username' => $username))->save(['levels' => 4]);
	                    }	
                    }
                     if($levelss==4){
                     	if($consumption>=$buy5 ){
	                    	M('member')->where(array('username' => $username))->save(['levels' => 5]);
	                    }
                     }
                     $parentlevel = M('member')->where(array('username' => $parent))->getField('levels');
                     if($parentlevel==0){
                     	if($shuliang>=$number1 and $shuliang<$number2){
	                		M('member')->where(array('username' => $parent))->save(['levels' => 1]);
	                	}
                     }
                	
                	if($parentlevel==1){
                		if($shuliang>=$number2 and $shuliang<$number3){
	                		M('member')->where(array('username' => $parent))->save(['levels' => 2]);
	                	}
                	}
                	
                	if($parentlevel==2){
                		if($shuliang>=$number3 and $shuliang<$number4){
	                		M('member')->where(array('username' => $parent))->save(['levels' => 3]);
	                	}
                	}
                	if($parentlevel==3){
                		if($shuliang>=$number4 and $shuliang<$number5){
	                		M('member')->where(array('username' => $parent))->save(['levels' => 4]);
	                	}
                	}
                	if($parentlevel==4){
                		if($shuliang>=$number5 ){
	                		M('member')->where(array('username' => $parent))->save(['levels' => 5]);
	                	}
                	}
                		
                    $parent1 = M('member')->where(array('username' => $parent))->getField('parent');
                    $parent2 = M('member')->where(array('username' => $parent1))->getField('parent');
					$parent3 = M('member')->where(array('username' => $parent2))->getField('parent');
                    
					$levels = M('member')->where(array('username' => $parent))->getField('levels');
					$levels1 = M('member')->where(array('username' => $parent1))->getField('levels');
					$levels2 = M('member')->where(array('username' => $parent2))->getField('levels');
					$levels3 = M('member')->where(array('username' => $parent3))->getField('levels');
                    if ($levels == 0) {
                    	$level = M('level')->where(array('level' => 0))->getField('a');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent))->setInc('jinbi', $yq);
                        account_log($parent, $yq, 'Level 1 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels == 1) {
                    	$level = M('level')->where(array('level' => 1))->getField('a');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent))->setInc('jinbi', $yq);
                        account_log($parent, $yq, 'Level 1 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels1 == 1) {
                    	$level = M('level')->where(array('level' => 1))->getField('b');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent1))->setInc('jinbi', $yq);
                        account_log($parent1, $yq, 'Level 2 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels == 2) {
                    	$level = M('level')->where(array('level' => 2))->getField('a');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent))->setInc('jinbi', $yq);
                        account_log($parent, $yq, 'Level 1 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels1 == 2) {
                    	$level = M('level')->where(array('level' => 2))->getField('b');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent1))->setInc('jinbi', $yq);
                        account_log($parent1, $yq, 'Level 2 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels2 == 2) {
                    	$level = M('level')->where(array('level' => 2))->getField('c');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent2))->setInc('jinbi', $yq);
                        account_log($parent2, $yq, 'Level 3 Invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels == 3) {
                    	$level = M('level')->where(array('level' => 3))->getField('a');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent))->setInc('jinbi', $yq);
                        account_log($parent, $yq, 'Level 1 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels1 == 3) {
                    	$level = M('level')->where(array('level' => 3))->getField('b');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent1))->setInc('jinbi', $yq);
                        account_log($parent1, $yq, 'Level 2 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels2 == 3) {
                    	$level = M('level')->where(array('level' => 3))->getField('c');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent2))->setInc('jinbi', $yq);
                        account_log($parent2, $yq, 'Level 3 Invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels3 == 3) {
                    	$level = M('level')->where(array('level' => 3))->getField('c');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent3))->setInc('jinbi', $yq);
                        account_log($parent3, $yq, 'Level 4 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels == 4) {
                    	$level = M('level')->where(array('level' => 4))->getField('a');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent))->setInc('jinbi', $yq);
                        account_log($parent, $yq, 'Level 1 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels1 == 4) {
                    	$level = M('level')->where(array('level' => 4))->getField('b');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent1))->setInc('jinbi', $yq);
                        account_log($parent1, $yq, 'Level 2 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels2 == 4) {
                    	$level = M('level')->where(array('level' => 4))->getField('c');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent2))->setInc('jinbi', $yq);
                        account_log($parent2, $yq, 'Level 3 Invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels3 == 4) {
                    	$level = M('level')->where(array('level' => 4))->getField('c');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent3))->setInc('jinbi', $yq);
                        account_log($parent3, $yq, 'Level 4 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels == 5) {
                    	$level = M('level')->where(array('level' => 5))->getField('a');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent))->setInc('jinbi', $yq);
                        account_log($parent, $yq, 'Level 1 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels1 == 5) {
                    	$level = M('level')->where(array('level' => 5))->getField('b');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent1))->setInc('jinbi', $yq);
                        account_log($parent1, $yq, 'Level 2 invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels2 == 5) {
                    	$level = M('level')->where(array('level' => 5))->getField('c');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent2))->setInc('jinbi', $yq);
                        account_log($parent2, $yq, 'Level 3 Invitation Award', 1, 2, 1, 0, $username);

                    }
                    if ($levels3 == 5) {
                    	$level = M('level')->where(array('level' => 5))->getField('c');
						$yq=$price*$level/100;
                        M("member")->where(array('username' => $parent3))->setInc('jinbi', $yq);
                        account_log($parent3, $yq, 'Level 4 invitation Award', 1, 2, 1, 0, $username);

                    }
                    
                }
              

                

            }
            $product->where(array("id" => $id))->setDec("stock");
            if($language==1){
            		alert('Successful purchase of power bank', U('Robot/robot'));
            	}else if($language==2){
            		 alert('ซื้อสมบัติชาร์จเรียบร้อยแล้ว', U('Robot/robot'));
            	}else if($language==3){
            		alert('पावर बैंक का खरीद सफलतापूर्वक', U('Robot/robot'));
            	}else if($language==4){
            		alert('보조 배터리 구 매 성공', U('Robot/robot'));
            	}else if($language==5){
            		 alert('充電パックの購入に成功しました。', U('Robot/robot'));
            	}
           
        }
		public function rank(){
			$list = M('member')->order('robotcount desc')->limit(3)->select();

			$lists = M('member')->order('robotcount desc')->limit(3,27)->select();
			$this->assign('list',$list);
			$this->assign('lists',$lists);
			$this->display();
		}

		public function robot(){

            $zt=I('get.zt',1,'intval');
            $user_id=session('mid');
            $order = M("order");
            import("ORG.Util.Page");
            $count = $order ->where("user_id = {$user_id} and zt = {$zt}")->count();
            $count1 = $order ->where(array('user_id'=>$user_id,'zt'=>$zt))->count();
            $Page       = new Page($count,8);
            $Page->setConfig('theme', '%first% %upPage% %linkPage% %downPage% %end%');
            $show = $Page -> show();
            $jiesuan_time = C('jiesuan_time');
            $orders = $order->where("user_id = {$user_id} and zt = {$zt}") -> limit($Page ->firstRow.','.$Page -> listRows)->order('id desc') -> select();
            foreach($orders as $k=>$v){

                $a_time = (time()-strtotime($v['addtime']))/3600;

                $orders[$k]['a_time']=round($a_time,2);
                if(time()-$v['UG_getTime'] < $jiesuan_time*3600){
                    $orders[$k]['is_jiesuan']=0;
                }else{
                    $orders[$k]['is_jiesuan']=1;//可以结算
                }
            }
            $sum = $order ->where(array('user_id'=>$user_id))->sum('already_profit');
            $rwsm = C('rwsm');

            $mrkd = C('mrkd');
            $time = time();
            $username = session('username');
			$language = M('member')->where(array('username'=>$username))->getField('language');
			$this->assign('language',$language);
            $this -> assign("jiesuan_time",$jiesuan_time);
            
            $this -> assign("count1",$count1);
            $this -> assign("sum",$sum);
            $this->assign('time',$time);
            $this->assign('mrkd',$mrkd);
            $this->assign('rwsm',$rwsm);
            $this -> assign("page",$show);
            $this -> assign("zt",$zt);
            $this -> assign("orders",$orders);
            $this -> display();


		}


        public function jiesuan(){

            $id=I('get.id',0,'intval');

            $user_id=session('mid');
            $username=session('username');
            $language = M('member')->where(array('username'=>$username))->getField('language');
            if(empty($id)){
            	if($language==1){
            		alert('Parameter missing',U('Robot/robot'));
            	}else if($language==2){
            		alert('การสูญเสียพารามิเตอร์！',U('Robot/robot'));
            	}else if($language==3){
            		alert('पैरामीटर गुम है！',U('Robot/robot'));
            	}else if($language==4){
            		alert('매개 변수 손실！',U('Robot/robot'));
            	}else if($language==5){
            		alert('パラメータが無くなりました！',U('Robot/robot'));
            	}
                
            }

            $order=M('order')->where("id = {$id} and zt = 1 and user_id = {$user_id}")->find();

            if(empty($order)){
            	if($language==1){
            		$this->ajaxReturn(array('result'=>0,'info'=>'The power bank does not exist！'));
            	}else if($language==2){
            		$this->ajaxReturn(array('result'=>0,'info'=>'สมบัติที่ไม่มีอยู่จริง！'));
            	}else if($language==3){
            		$this->ajaxReturn(array('result'=>0,'info'=>'पावर बैंक मौजूद नहीं है！'));
            	}else if($language==4){
            		$this->ajaxReturn(array('result'=>0,'info'=>'이 보조 배터리 가 존재 하지 않 습 니 다！'));
            	}else if($language==5){
            		$this->ajaxReturn(array('result'=>0,'info'=>'この充電バッテリーは存在しません。！'));
            	}
                
            }
            //判断与上次结算时间有没有达到24小时
            $jiesuan_time=C('jiesuan_time');
            if(empty($jiesuan_time)){
                $jiesuan_time=24;
            }
            if(time()-$order['UG_getTime'] < $jiesuan_time*3600){
            	if($language==1){
            		alert('Income collection interval is less than'.$jiesuan_time.'hour！',U('Robot/robot'));
            	}else if($language==2){
            		alert('ไม่มีช่องว่างระหว่างรายได้'.$jiesuan_time.'ชั่วโมง！',U('Robot/robot'));
            	}else if($language==3){
            		alert('इनकम संग्रह अंतराल से कम है'.$jiesuan_time.'घंटा！',U('Robot/robot'));
            	}else if($language==4){
            		alert('수령 수익 간격 부족'.$jiesuan_time.'시간.！',U('Robot/robot'));
            	}else if($language==5){
            		alert('収益の受取間隔が足りない'.$jiesuan_time.'時間！',U('Robot/robot'));
            	}
                
            }
            //算出已经结算的时间
            $a_time=$order['UG_getTime']-strtotime($order['addtime']);
            //本次将要结算的时间
            $n_time=time()-$order['UG_getTime'];
            $time=0;//参加计算的时间；
            $data=array();
            $data['UG_getTime']=time();
            $is_over=1;
            if($a_time+$n_time > $order['yxzq']*3600){
                $time=($order['yxzq']*3600)-$a_time;
                $data['zt']=2;
                $is_over=0;
            }else{
                $time=$n_time;
            }

            $shouyi=$time/3600*$order['shouyi'];//本次收益

            M('order')->where("id = {$id} and zt = 1 and user_id = {$user_id}")->setInc('already_profit',$shouyi);
            M('order')->where("id = {$id} and zt = 1 and user_id = {$user_id}")->save($data);

            M('member')->where("id = {$user_id}")->setInc("jinbi",$shouyi);
            account_log($username,$shouyi,'Income of power bank',1,1,1,$order['id']);
             $parent = M('levels')->where(array('username' => $username))->getField('parent');
            	$levels =M('member')->where(array('username' => $username))->getField('levels');
	            if($levels!=0){
	            	$profit = M('levels')->where(array('id' => $levels))->getField('profit');
		            $shou1 = $shouyi * $profit / 100;
		            M("member")->where(array('username' => $parent))->setInc('jinbi', $shou1);
	        		 account_log($parent, $shou1, 'Level 1 invitation Award', 1, 2, 1, 0, $username);
	            }
            if($language==1){
            		alert('Successful collection of income of power bank！',U('Robot/robot'));
            	}else if($language==2){
            		alert('เรียกเก็บเงินโบนัสสำหรับความสำเร็จ！',U('Robot/robot'));
            	}else if($language==3){
            		alert('पावर बैंक के आगमन के सफलतापूर्वक संग्रह！',U('Robot/robot'));
            	}else if($language==4){
            		alert('보조 배터리 수익 수령 성공！',U('Robot/robot'));
            	}else if($language==5){
            		alert('充電宝収益の受取に成功しました。！',U('Robot/robot'));
            	}
            
        }

	}
?>