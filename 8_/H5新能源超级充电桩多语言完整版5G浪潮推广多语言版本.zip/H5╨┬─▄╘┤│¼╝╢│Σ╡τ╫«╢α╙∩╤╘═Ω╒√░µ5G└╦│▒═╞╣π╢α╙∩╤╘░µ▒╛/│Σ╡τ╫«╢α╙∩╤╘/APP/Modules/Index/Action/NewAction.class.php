<?php  
	
	Class NewAction extends Action{

		//资讯详细页
		public function index(){
		    $gonggao = C('gonggao');
			$banner = M('banner')->order('addtime desc')->select();
            $mai_log=M('order')->field('user,addtime')->order('id desc')->select();
			
			$username = session('username');
			$language = M('member')->where(array('username'=>$username))->getField('language');
			if(empty($language)){
				$language=1;
			}
			if($username == ""){
				
					$status = 0;
				}else{
					$status = 1;
					$shouyi = M('jinbidetail')->where(array('member'=>$username))->sum('adds');
					$liuliang = M('jinbidetail')->where(array('member'=>$username,'type'=>1))->sum('adds');
					$tuiguang = M('jinbidetail')->where(array('member'=>$username,'type'=>2))->sum('adds');
					 $shouyi = sprintf('%.2f',$shouyi);
					$liuliang = sprintf('%.2f',$liuliang);
					$tuiguang = sprintf('%.2f',$tuiguang);
					$this->assign('shouyi',$shouyi);
					$this->assign('tuiguang',$tuiguang);
					$this->assign('liuliang',$liuliang);
				
			}
			
			$product = M("product");
            $typeData = $product -> where("is_on = 0") ->order("id asc") -> select();
            $this->assign("typeData",$typeData);
			$this->assign('language',$language);
            $this->assign('status',$status);
            $this->assign('mai_log',$mai_log);
			$this->assign('banner',$banner);
			$this->assign('gonggao',$gonggao);
			$this->display();
		}

        public function xiangmu(){
			$username = session('username');
            $language=M('member')->where(array('username'=>$username))->getField('language');
            if(empty($language)){
            	$language=1;
            }
            if($language==1){
            	$new=M('announce')->where(array('id'=>160))->find();
            }else if($language==2){
            	$new=M('announce')->where(array('id'=>161))->find();
            }else if($language==3){
            	$new=M('announce')->where(array('id'=>162))->find();
            }else if($language==4){
            	$new=M('announce')->where(array('id'=>163))->find();
            }else if($language==5){
            	$new=M('announce')->where(array('id'=>164))->find();
            }
            
            $this->assign('new',$new);

            $this->display();

        }
        public function language(){
			$data['language']=I('language');
			$username = session('username');
            $language=M('member')->where(array('username'=>$username))->save($data);
            if(!$language){
            	$this->ajaxReturn(array('result'=>1,'url'=>U('Index/Login/index')));
            }
            $this->ajaxReturn(array('result'=>1,'url'=>U('Index/New/index')));
        }

		public function help(){
			$username = session('username');
            $language=M('member')->where(array('username'=>$username))->getField('language');
            if(empty($language)){
            	$language=1;
            }
            if($language==1){
            	$new=M('announce')->where(array('id'=>155))->find();
            }else if($language==2){
            	$new=M('announce')->where(array('id'=>156))->find();
            }else if($language==3){
            	$new=M('announce')->where(array('id'=>157))->find();
            }else if($language==4){
            	$new=M('announce')->where(array('id'=>158))->find();
            }else if($language==5){
            	$new=M('announce')->where(array('id'=>159))->find();
            }
           
            $this->assign('new',$new);
			$this->display();

		}
        public function video(){

            $this->display();

        }
        public function gonggao(){
		    $gonggao = C('gonggao');
            $this->assign('gonggao',$gonggao);
            $this->display();

        }
		public function xiangqing(){
            $id=I('get.id',0,'intval');

            if(empty($id)){
                $this->error('页面不存在！');
            }
            $new=M('announce')->where(array('id'=>$id))->find();
            $this->assign('new',$new);

			$this->display();

		}


	}