/**
 * Created by Administrator on 2018/6/26.
 */
$('#goblack').on('click', function () {
    window.history.go(-1);
    return false
});