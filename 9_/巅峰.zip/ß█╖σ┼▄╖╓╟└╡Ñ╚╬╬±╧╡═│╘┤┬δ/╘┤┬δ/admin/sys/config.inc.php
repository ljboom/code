<?php
defined('ACC')||exit('ACC Denied');
$_CFG = array();

$_CFG['host'] = 'localhost';
$_CFG['user'] = 'baye_paofen';
$_CFG['pwd'] = 'baye_paofen';
$_CFG['db'] = 'baye_paofen';
$_CFG['char'] = 'utf8';
