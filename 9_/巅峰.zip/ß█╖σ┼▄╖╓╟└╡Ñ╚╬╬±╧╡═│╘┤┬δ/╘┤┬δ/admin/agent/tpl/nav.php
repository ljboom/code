

            <div class="sidebar-menu">
                <header class="logo1">
                    <a href="#" class="sidebar-icon">
                        <span class="fa fa-bars">
                        </span>
                    </a>
                </header>
                <div style="border-top:1px ridge rgba(255, 255, 255, 0.15)">
                </div>
                <div class="menu">
                    <ul id="menu">
                        <li>
                            <a href="home.php">
                                <i class="fa fa-tachometer">
                                </i>
                                <span>
                                    管理首页
                                </span>
                                <div class="clearfix">
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="link.php">
                                <i class="fa fa-bar-chart">
                                </i>
                                <span>
                                    提款列表
                                </span>
                                <div class="clearfix">
                                </div>
                            </a>
                        </li>
                        <li id="menu-academico">
                            <a href="pay.php">
                                <i class="fa fa-check-square-o nav_icon">
                                </i>
                                <span>
                                    支付列表
                                </span>
                                <div class="clearfix">
                                </div>
                            </a>
                        </li>
                        <li id="menu-academico">
                            <a href="log.php">
                                <i class="fa fa-file-text-o">
                                </i>
                                <span>
                                    登录日志
                                </span>
                                <div class="clearfix">
                                </div>
                            </a>
                        </li>
                       <li id="menu-academico">
                            <a href="bank.php">
                                <i class="fa fa-check-square-o nav_icon">
                                </i>
                                <span>
                                    个人信息
                                </span>
                                <div class="clearfix">
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="pwd.php">
                                <i class="fa fa-cogs" aria-hidden="true"></i>
                                <span>
                                    安全设置
                                </span>
                                <div class="clearfix">
                                </div>
                            </a>
                        </li>
                        <li id="menu-academico">
                            <a href="paojiekouwendang.pdf">
                                <i class="fa fa-file-text-o">
                                </i>
                                <span>
                                    支付文档
                                </span>
                                <div class="clearfix">
                                </div>
                            </a>
                        </li>
                        <li >
                            <a href="out.php">
                                <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                                <span>
                                    退出登录
                                </span>
                                <span class="fa fa-angle-right" style="float: right">
                                </span>
                                <div class="clearfix">
                                </div>
                            </a>
                            
                        </li>
                      
                    </ul>
                </div>
            </div>
            <div class="clearfix">
            </div>