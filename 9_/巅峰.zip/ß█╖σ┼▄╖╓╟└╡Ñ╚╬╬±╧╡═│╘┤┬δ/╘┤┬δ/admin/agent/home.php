<?php 

define('ACC',true);

include('../sys/init.php');

if ($_SESSION['agent_id'] == '') {
	header("location: index.php");
}
$agent  = $_SESSION['agent_name'];

if (ajaxs()) {

  

} else {
    $a = $_SESSION['agent_id'];

	  $agent = $_SESSION['agent_name'];

   $list = $mysql->select_all('z_log','*','agent='."'$agent'" .' order by id desc');

   if ($where == '') {
   
      $where = ' status = 3 and  shanghu_name='."'$agent'";
   }


   $wheres = ' status = 3 and  shanghu_name='."'$agent'";
   
   $lists = $mysql->select_all('ysk_roborder','*',$where.' order by id desc');
   
   $sum = $mysql->count('ysk_roborder', $where );

   $agent_info = $mysql->select('ysk_agent','*','id='.$_SESSION['agent_id']);
   

 	 include('./tpl/index.html');
}



?>