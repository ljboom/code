<?php 

define('ACC',true);

include('../sys/init.php');
if ($_SESSION['agent_id'] == '') {
	header("location: index.php");
}

$agent = $_SESSION['agent_name'];

$list = $mysql->select_all('z_log','*','agent='."'$agent'" .' order by id desc');
include('./tpl/log.html');


?>