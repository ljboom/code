<?php 

define('ACC',true);

include('../sys/init.php');
if ($_SESSION['agent_id'] == '') {
	header("location: index.php");
}

$agent = $_SESSION['agent_name'];

$list = $mysql->select_all('ysk_tixian','*','shanghu_name='."'$agent'" .' order by id desc');

include('./tpl/link.html');


?>