<?php
namespace Admin\Controller;

use Think\Page;

/**
 * 用户控制器
 * 
 */
class LyController extends AdminController
{







public function ly_list() {
	//////////////////----------
	$User = M ( 'message' ); // 實例化User對象
	
	if(I('post.user')==''){
		$map['zt']='0';
	}else{
		$map['MA_userName']=I('post.user');
	}
	

	if(I('get.type')=='1'){
		$map['zt']='1';
	}
	if(I('get.type')=='3'){
		$map['zt']='3';
	}

if(I('get.type')=='2'){
		$map['zt']='2';
	}
		if(!I('get.type')){
		$map='1';
	}
		if(I('get.type')=='0'){
		$map['zt']='0';
	}
	$count = $User->where ( $map )->count (); // 查詢滿足要求的總記錄數)
	$p = getpage1($count,100);
	$list = $User->where ( $map )->order ( 'MA_ID DESC' )->limit ( $p->firstRow, $p->listRows )->select ();
	$this->assign ( 'list', $list ); // 賦值數據集
	$this->assign ( 'page', $p->show() ); // 賦值分頁輸出
	$userData = M ( 'user' )->where ( array ('UE_ID' => $_SESSION ['uid']) )->find ();
	$this->userData = $userData;
	$this->display ( 'ly_list' );
}
	 

	
public function ly_list_cl() {
	$caution = M ( 'message' )->where ( array ('MA_ID'=> I('get.id') ,) )->find ();
	$this->caution=$caution;


	$User = M ( 'message' ); // 实例化User对象
session('uname998',$caution['ma_username']);

 
  $count = $User->where(array('MA_userName'=>$_SESSION['uname998']))->count (); // 查询满足要求的总记录数
  $page = new \Think\Page ( $count, 10 ); // 实例化分页类 传入总记录数和每页显示的记录数(25)
  $page->setConfig ( 'header', '<li class="rows">共<b>%TOTAL_ROW%</b>条记录    第<b>%NOW_PAGE%</b>页/共<b>%TOTAL_PAGE%</b>页</li>' );
  $page->setConfig ( 'prev', '上一页' );
  $page->setConfig ( 'next', '下一页' );
  $page->setConfig ( 'last', '末页' );
  $page->setConfig ( 'first', '首页' );
  $page->setConfig ( 'theme', '%FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END% %HEADER%' );
  $show = $page->show (); 
  // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
  $list = $User->where(array('MA_userName'=>$_SESSION['uname998']))->order ( 'MA_ID DESC' )->limit ( $page->firstRow . ',' . $page->listRows )->select ();

  $this->assign ( 'list', $list ); // 赋值数据集
  $this->assign ( 'page', $show ); // 赋值分页输出
	
	
	
	
	
	
	$this->display ( 'ly_list_cl' );
}
	public function ly_list_cl1() {

	$userData = M ( 'user' )->where ( array ('UE_account' => I('get.user')) )->find ();
	$this->userData = $userData;
	
	
	  $User = M ( 'message' ); // 实例化User对象

  $map['_string']="(MA_userName ={$_SESSION['uname']} )";
  $count = $User->where ( $map )->count (); // 查询满足要求的总记录数
  $page = new \Think\Page ( $count, 10 ); // 实例化分页类 传入总记录数和每页显示的记录数(25)
  $page->setConfig ( 'header', '<li class="rows">共<b>%TOTAL_ROW%</b>条记录    第<b>%NOW_PAGE%</b>页/共<b>%TOTAL_PAGE%</b>页</li>' );
  $page->setConfig ( 'prev', '上一页' );
  $page->setConfig ( 'next', '下一页' );
  $page->setConfig ( 'last', '末页' );
  $page->setConfig ( 'first', '首页' );
  $page->setConfig ( 'theme', '%FIRST% %UP_PAGE% %LINK_PAGE% %DOWN_PAGE% %END% %HEADER%' );
  $show = $page->show (); 
  // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
  $list = $User->where ( $map )->order ( 'MA_ID DESC' )->limit ( $page->firstRow . ',' . $page->listRows )->select ();
  //dump($list);die;
  $this->assign ( 'list', $list ); // 赋值数据集
  $this->assign ( 'page', $show ); // 赋值分页输出

	
	
	
	
	
	
	
	$this->display ( 'ly_list_cl1' );
}
	
    

	
public function ly_list_xgcl2() {
	
		$data['MA_type']=$_SESSION['adminuser'];
		$data['MA_reply']=$_POST['content'];
		$data['MA_replyTime']=date ( 'Y-m-d H:i:s', time () );
		$data['zt']='1';

		if(M('message')->where(array('MA_ID'=>I('post.id')))->save($data)){
			$this->success('处理成功！','ly_list/type/0/');
		}else{
			$this->success('处理失敗！');
		}
		//$this->success('成功！');
	
}

public function ly_list_xgcl21() {
	
		
		
		if (IS_POST) {
		$data_P = I ( 'post.' );
/*
		if (strlen($data_P['lybt']) > 190 || strlen($data_P['lybt']) < 1) {
			die("<script>alert('留言标题不能为空！');history.back(-1);</script>");
			
		} 
		*/
		
		if ( strlen($data_P['lynr']) < 1) {
			die("<script>alert('留言内容不能为空！');history.back(-1);</script>");
			
		}else {
			$data['MA_type']=$_session["adminuser"];
				$record['zt']		= '2'; 
			$record['MA_type']		= $_SESSION['adminuser'];
			$record['MA_userName']	= $data_P['yonghu'];
			$record['pic']	= $data_P['face180'];
			$record['MA_otherInfo']	= '重要通知';
			$record['MA_theme']		= '系统通知';
			$record['MA_note']		= $data_P['lynr'];
			$record['MA_time']		= date ( 'Y-m-d H:i:s', time () );;
					
			$reg = M ( 'message' )->add ( $record );
				
				if ($reg) {
					die("<script>alert('留言成功！');window.close(); </script>");
					
				} else {
					die("<script>alert('留言失败！');history.back(-1);</script>");
					
				}
		
		}
		}

}



	
public function ly_list_del() {
	
	$caution = M ( 'message' )->where ( array ('MA_ID'=> I('get.id'),) )->delete();
	if($caution){$this->success('刪除成功!');}else{$this->error('刪除失敗!');}
}

















}
