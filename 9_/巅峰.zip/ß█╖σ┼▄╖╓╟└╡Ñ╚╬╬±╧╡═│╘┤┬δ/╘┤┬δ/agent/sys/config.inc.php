<?php
defined('ACC')||exit('ACC Denied');
$_CFG = array();

$_CFG['host'] = 'localhost';
$_CFG['user'] = 'baye_paofen';
$_CFG['pwd'] = 'baye_paofen';
$_CFG['db'] = 'baye_paofen';
$_CFG['char'] = 'utf8';

$_CFG['act'] = $_SERVER['DOCUMENT_ROOT'].'/act/';

$_CFG['tpl'] = $_SERVER['DOCUMENT_ROOT'].'/tpl/';

$_CFG['act_ext'] = '.php';
$_CFG['tpl_ext'] = '.php';