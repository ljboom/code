<?php 



if ($us_info['zname']!='') {
	
	header("location: bangding.php");
}


?>