<?php 
defined('ACC')||exit('ACC Denied');

?>