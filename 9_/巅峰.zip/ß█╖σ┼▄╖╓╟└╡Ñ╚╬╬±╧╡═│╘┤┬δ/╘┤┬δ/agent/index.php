<?php
header('content-type:text/html;charset=utf-8');
$url='';
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

 
    <title>skip... - 8ye.net 八爷源码网</title>
</head>

 