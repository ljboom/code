<?php /*%%SmartyHeaderCode:11076976995efd4b479abe02-62291452%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e9ad3514c0460b3db33c943f8f2d7fcb477398e9' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/admin/view/Default/default.html',
      1 => 1578476498,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11076976995efd4b479abe02-62291452',
  'variables' => 
  array (
    'user' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5efd4b479d7827_15736056',
  'cache_lifetime' => 300,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5efd4b479d7827_15736056')) {function content_5efd4b479d7827_15736056($_smarty_tpl) {?><div class="layui-card">
  <div class="layui-card-header">版本信息</div>
  <div class="layui-card-body layui-text">
    <table class="layui-table">
      <colgroup>
        <col width="100">
        <col>
      </colgroup>
      <tbody>
        <tr>
          <td>当前版本</td>
          <td>
            <script type="text/html" template>
              v5.0.21
            </script>
          </td>
        </tr>
        <tr>
          <td>基于框架</td>
          <td>
            <script type="text/html" template>
              layui-v{{ layui.v }}
            </script>
          </td>
        </tr>
        <tr>
          <td>主要特点</td>
          <td>单页面 / 响应式 / 清爽 / 极简 / 仅供学习参考使用</td>
        </tr>
		        <tr>
          <td style="width:160px;">前台测试地址</td>
          <td><a href="http://xh.66blm.cn/?c=Pay&a=test&v=v5.0.21" target="_blank">http://xh.66blm.cn/?c=Pay&a=test&v=v5.0.21</a></td>
        </tr>
		        <!--
        <tr>
          <td>获取渠道</td>
          <td style="padding-bottom: 0;">
            <div class="layui-btn-container">
              <a href="" target="_blank" class="layui-btn layui-btn-danger">获取授权</a>
              <a href="" target="_blank" class="layui-btn">立即下载</a>
            </div>
          </td>
        </tr>
        -->
      </tbody>
    </table>
  </div>
</div><?php }} ?>
