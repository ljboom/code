<?php /* Smarty version Smarty-3.1.21-dev, created on 2020-06-18 18:55:39
         compiled from "/www/wwwroot/121.36.134.31/home/view/User/team.html" */ ?>
<?php /*%%SmartyHeaderCode:11310722335eeb482b832770-24613032%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '58efa94a3d8ed30aaed841a62156a65a16939dbd' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/User/team.html',
      1 => 1578476498,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11310722335eeb482b832770-24613032',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'level_arr' => 0,
    'vo' => 0,
    's' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5eeb482b85a120_02561838',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5eeb482b85a120_02561838')) {function content_5eeb482b85a120_02561838($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("head.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<style>
select{padding:10px 5px;}
.myTeamList table td{line-height:1.4rem;}
</style>
<div class="myTeam">
	<div class="HeadTop">
		<p class="Tit">我的团队</p>
		<a href="/?c=User" class="backBtn"></a>
	</div>
	<div class="myTeamTop">
		<div class="cengji">
			<select id="level">
				<option value="0">选择层级</option>
				<?php  $_smarty_tpl->tpl_vars['vo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['vo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['level_arr']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['vo']->key => $_smarty_tpl->tpl_vars['vo']->value) {
$_smarty_tpl->tpl_vars['vo']->_loop = true;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['vo']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['vo']->value;?>
层</option>
				<?php } ?>
			</select>
		</div>
		<div class="searchbox" style="width:60%;">
			<input type="text" id="keyword" value="<?php echo $_smarty_tpl->tpl_vars['s']->value['keyword'];?>
" style="width:10rem;" placeholder="请输入关键词">
			<a href="javascript:;" class="serachBtn">查询</a>
		</div>
	</div>
	<div class="myTeamList" style="top:9rem;">
		<table cellspacing="0" cellpadding="0">
			<thead>
				<tr>
					<th>账号/昵称</th>
					<th>层级</th>
					<th>注册时间</th>
					<th>状态</th>
					<th>收益率</th>
				</tr>
			</thead>
			<tbody id="listBox">
				<!--
				<tr>
					<td>13536920159</td>
					<td>1层</td>
					<td>7-19 16:08</td>
					<td>在线</td>
					<td><a href="javascript:;" class="setBtn">设置</a></td>
				</tr>
				-->
			</tbody>
		</table>
		<div class="moreBtn" style="text-align:center;">点击加载更多</div>
	</div>
	
</div>
<?php echo $_smarty_tpl->getSubTemplate ("js.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<?php echo '<script'; ?>
>
$(function(){

	$('#level').val('<?php echo $_smarty_tpl->tpl_vars['s']->value['level'];?>
');
	
	$('.serachBtn').on('click',function(){
		var keyword=$.trim($('#keyword').val());
		var level=$('#level').val();
		var url='/?c=User&a=team';
		if(level>0){
			url+='&level='+level;
		}
		if(keyword){
			url+='&keyword='+keyword;
		}
		location.href=url;
	});

    $('.moreBtn').on('click',function(){
        var level='<?php echo $_smarty_tpl->tpl_vars['s']->value['level'];?>
';
        var keyword='<?php echo $_smarty_tpl->tpl_vars['s']->value['keyword'];?>
';
        dataPage({
            url:global.appurl+'c=User&a=team_list',
            data:{level:level,keyword:keyword},
            success:function(json){
                var html='';
                for(var i in json.data.list){
                    var item=json.data.list[i];
                    html+='<tr>';
                        html+='<td>'+item.account+'<br>'+item.nickname+'</td>';
                        html+='<td>'+item.agent_level+'</td>';
                        html+='<td>'+item.reg_time+'</td>';
                        html+='<td>'+item.is_online_flag+'</td>';
						if(item.agent_level==1){
							html+='<td><a href="/?c=User&a=teamInfo&uid='+item.id+'&level='+item.agent_level+'" class="setBtn">查看</a></td>';
						}else{
							html+='<td>/</td>';
						}
                    html+='</tr>';
                }
                $('#listBox').append(html);
            }
        });
    });

    $('.moreBtn').trigger('click');
    
});
<?php echo '</script'; ?>
>
<?php echo $_smarty_tpl->getSubTemplate ("foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>
<?php }} ?>
