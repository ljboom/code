<?php /* Smarty version Smarty-3.1.21-dev, created on 2020-07-16 22:13:42
         compiled from "/www/wwwroot/121.36.134.31/home/view/js.html" */ ?>
<?php /*%%SmartyHeaderCode:17021434585f106096032131-70370717%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bd3e272f8e82dd8f1f0d60befb3fe1f0b00c32e2' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/js.html',
      1 => 1578476498,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17021434585f106096032131-70370717',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5f106096032f97_33404328',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5f106096032f97_33404328')) {function content_5f106096032f97_33404328($_smarty_tpl) {?><?php echo '<script'; ?>
 type="text/javascript" src="public/js/jquery2.1.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="public/layer/layer.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="public/js/md5.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="public/js/func.js?v=0.41"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="public/home/js/func.js?v=0.41"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="public/js/global.js?v=0.41"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
global.appurl='/?';
<?php echo '</script'; ?>
><?php }} ?>
