<?php /* Smarty version Smarty-3.1.21-dev, created on 2020-06-18 18:54:50
         compiled from "/www/wwwroot/121.36.134.31/home/view/Finance/yong.html" */ ?>
<?php /*%%SmartyHeaderCode:19076877885eeb47fad3e0f1-08980803%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a97d6a9d3087081f872662df0af24d6d7cbda5da' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/Finance/yong.html',
      1 => 1578476498,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19076877885eeb47fad3e0f1-08980803',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5eeb47fad5ab07_86187471',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5eeb47fad5ab07_86187471')) {function content_5eeb47fad5ab07_86187471($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("head.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<style>
.CommissionCon .detailBox tr td{line-height:2rem;padding:4px 8px;}
.viewBtn{padding:2px 8px;border:1px solid #fc744d;color:#fc744d;border-radius:3px;}
</style>

<div class="Commission">
	<div class="HeadTop">
		<p class="Tit">分成记录</p>
		<a href="/?c=User" class="backBtn"></a>
	</div>
	<div class="CommissionCon">
		<div class="detailBox">
			<table cellpadding="0" cellspacing="0">
				<thead>
					<tr>
						<th>时间</th>
						<th>支付方式</th>
						<th>订单金额</th>
						<th>收益率</th>
						<th>分成</th>
					</tr>
				</thead>
				<tbody id="listBox">
					<!--
					<tr>
						<td>DD</td>
						<td>268</td>
						<td>268</td>
						<td>2019-7-18</td>
					</tr>
					-->
				</tbody>
			</table>
			<div class="moreBtn" style="text-align:center;">点击加载更多</div>
		</div>
	</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("js.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<?php echo '<script'; ?>
>

$(function(){
	
	//获取充值记录
    $('.moreBtn').on('click',function(){
        dataPage({
            url:global.appurl+'c=Finance&a=yong_list',
            data:{},
            success:function(json){
                var html='';
                for(var i in json.data.list){
                    var item=json.data.list[i];
                    html+='<tr>';
                        html+='<td>'+item.create_time+'</td>';
                        html+='<td>'+item.mtype_name+'</td>';
                        html+='<td>'+item.order_money+'</td>';
                        html+='<td>'+item.rate+'</td>';
                        html+='<td>'+item.money+'</td>';
                    html+='</tr>';
                }
                $('#listBox').append(html);
            }
        });
    });

    $('.moreBtn').trigger('click');
	
});
<?php echo '</script'; ?>
>
<?php echo $_smarty_tpl->getSubTemplate ("foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>
<?php }} ?>
