<?php /* Smarty version Smarty-3.1.21-dev, created on 2020-04-23 09:59:01
         compiled from "/www/wwwroot/121.36.134.31/home/view/User/teamInfo.html" */ ?>
<?php /*%%SmartyHeaderCode:12782697695ea0f6652884e3-99147747%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bd2f248bed50296ab22ab45d3762fb067f696963' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/User/teamInfo.html',
      1 => 1578476498,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12782697695ea0f6652884e3-99147747',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'user' => 0,
    's' => 0,
    'mtype_arr' => 0,
    'vo' => 0,
    'up_td_switch' => 0,
    'up_user' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5ea0f6652d6151_22298976',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ea0f6652d6151_22298976')) {function content_5ea0f6652d6151_22298976($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("head.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<style>
.HeadTop{z-index:2;}
.myTeamSetCon .insertBox p{width:30%;}
.myTeamSetCon .insertBox .inp input{width:5rem;padding:0 5px;}
</style>

<div class="myTeamSet">
	<div class="HeadTop">
		<p class="Tit">收益率</p>
		<a href="/?c=User&a=team" class="backBtn"></a>
	</div>
	<div class="myTeamSetCon">
		<div class="infoBox">
			<p>下级账号：<?php echo $_smarty_tpl->tpl_vars['user']->value['account'];?>
</p>
			<p>推荐层级：<?php echo $_smarty_tpl->tpl_vars['s']->value['level'];?>
层</p>
			<p>注册时间：<?php echo $_smarty_tpl->tpl_vars['user']->value['reg_time'];?>
</p>
			<p>抢单状态：<?php echo $_smarty_tpl->tpl_vars['user']->value['is_online_flag'];?>
</p>
		</div>
		<div class="insertBox">
			<?php  $_smarty_tpl->tpl_vars['vo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['vo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['mtype_arr']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['vo']->key => $_smarty_tpl->tpl_vars['vo']->value) {
$_smarty_tpl->tpl_vars['vo']->_loop = true;
?>
			<?php if ($_smarty_tpl->tpl_vars['up_td_switch']->value[$_smarty_tpl->tpl_vars['vo']->value['id']]>0) {?>
			<div class="Row">
				<p><?php echo $_smarty_tpl->tpl_vars['vo']->value['name'];?>
</p>
				<div class="inp"><input type="text" class="mtypeItem" value="<?php echo $_smarty_tpl->tpl_vars['user']->value['fy_rate'][$_smarty_tpl->tpl_vars['vo']->value['id']]*100;?>
" data-id="<?php echo $_smarty_tpl->tpl_vars['vo']->value['id'];?>
">%</div>
				<div style="display:inline-block;">上级：<?php echo $_smarty_tpl->tpl_vars['up_user']->value['fy_rate'][$_smarty_tpl->tpl_vars['vo']->value['id']]*100;?>
%</div>
			</div>
			<?php }?>
			<?php } ?>
		</div>
		<a href="javascript:;" class="setBtn">设置</a>
	</div>

</div>
<?php echo $_smarty_tpl->getSubTemplate ("js.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<?php echo '<script'; ?>
>
preventDefault();
$(function(){
    
	$('.setBtn').on('click',function(){
		var obj=$(this);
		var uid='<?php echo $_smarty_tpl->tpl_vars['user']->value['id'];?>
';
		var fy_rate=[];
		$('.mtypeItem').each(function(i,o){
			var fobj=$(o);
			fy_rate[fobj.attr('data-id')]=formatFloat(fobj.val()/100,3);
		});
		var has_click=obj.attr('has-click');
		if(has_click=='1'){
			return;
		}else{
			obj.attr('has-click','1');
		}
		ajax({
			url:global.appurl+'c=User&a=teamSet',
			data:{uid:uid,fy_rate:fy_rate},
			success:function(json){
				obj.attr('has-click','0');
				if(json.code!=1){
					_alert(json.msg);
					return;
				}
				_alert({
					content:json.msg,
					end:function(){
						//
					}
				});
			}
		});
	});
	
	
	function formatFloat(src, pos){
	   return Math.round(src*Math.pow(10, pos))/Math.pow(10, pos);
	}
	
});
<?php echo '</script'; ?>
>
<?php echo $_smarty_tpl->getSubTemplate ("foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>
<?php }} ?>
