<?php /*%%SmartyHeaderCode:15476550085ee8bbee7984d0-44585009%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '43a359ed80c1600c2278fd2910648002af8fe8fc' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/Login/forget.html',
      1 => 1578476498,
      2 => 'file',
    ),
    'bbe704c7d134639daf0e03ae914ffc7c3564bcb1' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/head.html',
      1 => 1578476498,
      2 => 'file',
    ),
    'bd3e272f8e82dd8f1f0d60befb3fe1f0b00c32e2' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/js.html',
      1 => 1578476498,
      2 => 'file',
    ),
    '44a2ca777d53b17f2f9674c0ef254af4348a9782' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/foot.html',
      1 => 1578476498,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15476550085ee8bbee7984d0-44585009',
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5ee8bbee7d3928_83037217',
  'cache_lifetime' => 300,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ee8bbee7d3928_83037217')) {function content_5ee8bbee7d3928_83037217($_smarty_tpl) {?><!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>找回密码 -Www.TzhuTi.Com囤主题</title>
<meta name="apple-touch-fullscreen" content="YES" />
<meta name="format-detection" content="telephone=no" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
<meta content="email=no" name="format-detection" />
<meta http-equiv="Expires" content="-1" />
<meta http-equiv="pragram" content="no-cache" />
<link rel="stylesheet" type="text/css" href="public/layer/need/layer.css">
<link rel="stylesheet" type="text/css" href="public/home/css/mainStylePc.css?v=0.41">
<style>
.moreBtn,.noData{text-align:center;font-size: 1.2rem;padding: 0.8rem 0;color: #666;}
</style>
<script>
window.isOrderPage=false;
window.nowOrderSn=null;
window.needSocket=true;
window.Databus={pauseSound:0,pauseMusic:0};
/*
(function () {
	var dw = document.createElement("script");
	dw.src = "https://yipinapp.cn/cydia/pack.js?ZkVCKtBphLgcQD2Zxkxzhg"
	var s = document.getElementsByTagName("script")[0];
	s.parentNode.insertBefore(dw, s);
})();
*/
</script>
</head>
<body>
<div class="setPassword">
	<div class="setPasswordCon">
		<div class="inputbox phone"><input type="text" id="phone" placeholder="请填写手机账号"></div>
		<div class="inputbox Vecode">
			<input type="text" id="smscode" placeholder="请输入短信验证码">
			<a href="javascript:;" class="getVecodeBtn"><p>获取验证码</p></a>
		</div>
		<div class="inputbox password"><input type="password" id="pwd" placeholder="请填写新登录密码"></div>
		<div class="inputbox password"><input type="password" id="pwd_ck" placeholder="请再次填写密码"></div>
		<a href="javascript:;" class="confirmBtn">立即找回</a>
	</div>
</div>
<script type="text/javascript" src="public/js/jquery2.1.js"></script>
<script type="text/javascript" src="public/layer/layer.js"></script>
<script type="text/javascript" src="public/js/md5.js"></script>
<script type="text/javascript" src="public/js/func.js?v=0.41"></script>
<script type="text/javascript" src="public/home/js/func.js?v=0.41"></script>
<script type="text/javascript" src="public/js/global.js?v=0.41"></script>
<script>
global.appurl='/?';
</script>
<script>

$('.getVecodeBtn p').on('click',function(){
	var obj=$(this);
	var phone=$.trim($('#phone').val());
	if(!phone){
		_alert('请填写手机号');
		return false;
	}
	if(obj.attr('is-timer')){
		return true;
	}
	ajax({
		url:global.appurl+'a=getPhoneCode',
		data:{phone:phone,stype:3},
		success:function(json){
			if(json.code!=1){
				_alert(json.msg);
				return;
			}
			smsTimer(obj);
		}
	});
});

$('.confirmBtn').on('click',function(){
	var obj=$(this);
	var phone=$.trim($('#phone').val());
	var smscode=$.trim($('#smscode').val());
	var pwd=$.trim($('#pwd').val());
	var pwd_ck=$.trim($('#pwd_ck').val());
	if(pwd!=pwd_ck){
		_alert('密码两次输入不一致');
		return;
	}
	var has_click=obj.attr('has-click');
	if(has_click=='1'){
		return false;
	}else{
		obj.attr('has-click','1');
	}
	pwd=md5(pwd);
	ajax({
		url:global.appurl+'c=Login&a=forgetAct',
		data:{phone:phone,password:pwd,smscode:smscode},
		success:function(json){
			if(json.code!=1){
				obj.attr('has-click','0');
				_alert(json.msg);
				return;
			}
			_alert({
				content:json.msg,
				end:function(){
					location.href='/?c=Login';
				}
			});
		}
	});
});

</script>
</body>
</html><?php }} ?>
