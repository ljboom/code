<?php /* Smarty version Smarty-3.1.21-dev, created on 2020-07-21 22:44:20
         compiled from "/www/wwwroot/182.61.40.116/admin/view/Pay/area.html" */ ?>
<?php /*%%SmartyHeaderCode:2990428515f16ff4404d003-54807818%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '63741aaf0a611adbd1f2c86c0b06f874e4b0d75a' => 
    array (
      0 => '/www/wwwroot/182.61.40.116/admin/view/Pay/area.html',
      1 => 1587727608,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2990428515f16ff4404d003-54807818',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'mtype_arr' => 0,
    'vo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5f16ff44085328_61776650',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5f16ff44085328_61776650')) {function content_5f16ff44085328_61776650($_smarty_tpl) {?><div class="layui-col-md12">
    <div class="layui-card">
        <div class="layui-card-header">
            <span>地区分布</span>
        </div>
        <?php echo '<?php'; ?>
 print_r($mtype_arr); <?php echo '?>'; ?>

        <div class="layui-card-body">

            <form class="layui-form" id="searchForm" onsubmit="return false;">
                <div class="layui-form-item" style="margin-bottom:5px;">
                    <div class="layui-inline">
                        <label class="layui-form-label" style="width:60px;">省</label>
                        <div class="layui-input-inline" style="width:120px;">
                            <select id="order_pro" name="order_pro">
                                <option value="0">请选择省</option>
                                <?php  $_smarty_tpl->tpl_vars['vo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['vo']->_loop = false;
 $_smarty_tpl->tpl_vars['skey'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['mtype_arr']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['vo']->key => $_smarty_tpl->tpl_vars['vo']->value) {
$_smarty_tpl->tpl_vars['vo']->_loop = true;
 $_smarty_tpl->tpl_vars['skey']->value = $_smarty_tpl->tpl_vars['vo']->key;
?>
                                <option value="<?php echo $_smarty_tpl->tpl_vars['vo']->value['order_pro'];?>
"><?php echo $_smarty_tpl->tpl_vars['vo']->value['order_pro'];?>
</option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="layui-inline">
                        <label class="layui-form-label" style="width:60px;">市</label>
                        <div class="layui-input-inline" style="width:120px;">
                            <select id="order_city" name="order_city">
                                <option value="0">请选择市</option>
                                <?php  $_smarty_tpl->tpl_vars['vo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['vo']->_loop = false;
 $_smarty_tpl->tpl_vars['skey'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['mtype_arr']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['vo']->key => $_smarty_tpl->tpl_vars['vo']->value) {
$_smarty_tpl->tpl_vars['vo']->_loop = true;
 $_smarty_tpl->tpl_vars['skey']->value = $_smarty_tpl->tpl_vars['vo']->key;
?>
                                <option value="<?php echo $_smarty_tpl->tpl_vars['vo']->value['order_city'];?>
"><?php echo $_smarty_tpl->tpl_vars['vo']->value['order_city'];?>
</option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                    <div class="layui-inline" style="margin-right:0;">
                        <label class="layui-form-label" style="width:30px;">开始</label>
                        <div class="layui-input-inline" style="width:140px;">
                            <input name="s_start_time" id="s_start_time" class="layui-input" placeholder="请选择" />
                        </div>
                    </div>

                    <div class="layui-inline" style="margin-right:0;">
                        <label class="layui-form-label" style="width:30px;">结束</label>
                        <div class="layui-input-inline" style="width:140px;">
                            <input name="s_end_time" id="s_end_time" class="layui-input" placeholder="请选择">
                        </div>
                    </div>

                    <div class="layui-inline" style="margin-right:0;">
                        <input type="hidden" name="is_download" id="is_download"/>
                        <span class="layui-btn" id="searchBtn">查询</span>
                    </div>
                </div>
            </form>

            <table class="layui-hide" id="dataTable" lay-filter="dataTable"></table>
            <!--记录操作工具条-->

        </div>
    </div>
</div>


<?php echo '<script'; ?>
>

        $('#searchBtn').on('click', function () {
            var obj = $(this);
            var pdata = {
                order_pro: $.trim($('#order_pro').val()),
                order_city: $.trim($('#order_city').val()),
                s_start_time: $.trim($('#s_start_time').val()),
                s_end_time: $.trim($('#s_end_time').val())
            };

            dataPage({
                where: pdata,
                url: global.appurl + 'c=Pay&a=area_list',
                cols: [[
                    {field: 'order_pro', title: '省'},
                    {field: 'order_city', title: '市'},
                    {field: 'c_order', title: '总订单'},
                    {field: 's_order', title: '成功订单'},
                    {field: 'order_area', title: '成功率(%)'},
                ]],
            });

        });
        $('#searchBtn').trigger('click');



<?php echo '</script'; ?>
><?php }} ?>
