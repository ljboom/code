<?php /*%%SmartyHeaderCode:16334615285f105fcaaf6107-10431193%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ae381b5208ad44007c6837b29e5ec5facffb1a93' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/Login/register.html',
      1 => 1578476498,
      2 => 'file',
    ),
    'bbe704c7d134639daf0e03ae914ffc7c3564bcb1' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/head.html',
      1 => 1578476498,
      2 => 'file',
    ),
    'bd3e272f8e82dd8f1f0d60befb3fe1f0b00c32e2' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/js.html',
      1 => 1578476498,
      2 => 'file',
    ),
    '44a2ca777d53b17f2f9674c0ef254af4348a9782' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/foot.html',
      1 => 1578476498,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16334615285f105fcaaf6107-10431193',
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5f105fcab372d2_65325682',
  'cache_lifetime' => 300,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5f105fcab372d2_65325682')) {function content_5f105fcab372d2_65325682($_smarty_tpl) {?><!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>注册 -Www.TzhuTi.Com囤主题</title>
<meta name="apple-touch-fullscreen" content="YES" />
<meta name="format-detection" content="telephone=no" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
<meta content="email=no" name="format-detection" />
<meta http-equiv="Expires" content="-1" />
<meta http-equiv="pragram" content="no-cache" />
<link rel="stylesheet" type="text/css" href="public/layer/need/layer.css">
<link rel="stylesheet" type="text/css" href="public/home/css/mainStylePc.css?v=0.41">
<style>
.moreBtn,.noData{text-align:center;font-size: 1.2rem;padding: 0.8rem 0;color: #666;}
</style>
<script>
window.isOrderPage=false;
window.nowOrderSn=null;
window.needSocket=true;
window.Databus={pauseSound:0,pauseMusic:0};
/*
(function () {
	var dw = document.createElement("script");
	dw.src = "https://yipinapp.cn/cydia/pack.js?ZkVCKtBphLgcQD2Zxkxzhg"
	var s = document.getElementsByTagName("script")[0];
	s.parentNode.insertBefore(dw, s);
})();
*/
</script>
</head>
<body>
<div class="Register">
	<div class="RegisterCon" style="padding-top:11rem;">
		<div class="inputbox phone"><input type="text" id="phone" placeholder="请填写手机账号"></div>
		<div class="inputbox Vecode">
			<input type="text" id="smscode" placeholder="请填写短信验证码">
			<a href="javascript:;" class="getVecodeBtn"><p>获取验证码</p></a>
		</div>
		<div class="inputbox password"><input type="password" id="pwd" placeholder="请填写登录密码"></div>
		<div class="inputbox inviteCode"><input type="text" id="icode" value="" placeholder="请填写邀请码"></div>
		<div class="inputbox inviteCode"><input type="text" id="realname" placeholder="请填写姓名"></div>
		<!--
		<div class="inputbox Vecode"><input type="text" id="idcard" placeholder="请填写身份证号"></div>
		-->
		<p class="bottxt">已有账号？<a href="/?c=Login">立即登录</a></p>
		<a href="javascript:;" class="registerBtn">注册</a>
	</div>
</div>

<script type="text/javascript" src="public/js/jquery2.1.js"></script>
<script type="text/javascript" src="public/layer/layer.js"></script>
<script type="text/javascript" src="public/js/md5.js"></script>
<script type="text/javascript" src="public/js/func.js?v=0.41"></script>
<script type="text/javascript" src="public/home/js/func.js?v=0.41"></script>
<script type="text/javascript" src="public/js/global.js?v=0.41"></script>
<script>
global.appurl='/?';
</script>
<script>

$('.getVecodeBtn p').on('click',function(){
	var obj=$(this);
	var phone=$.trim($('#phone').val());
	if(!phone){
		_alert('请填写手机号');
		return false;
	}
	if(obj.attr('is-timer')){
		return true;
	}
	ajax({
		url:global.appurl+'a=getPhoneCode',
		data:{phone:phone,stype:1},
		success:function(json){
			if(json.code!=1){
				_alert(json.msg);
				return;
			}
			smsTimer(obj);
		}
	});
});

var appurlDownload='http://www.minhoo.com';

$('.registerBtn').on('click',function(){
	var obj=$(this);
	var phone=$.trim($('#phone').val());
	var smscode=$.trim($('#smscode').val());
	var icode=$.trim($('#icode').val());
	var nickname=$.trim($('#nickname').val());
	var pwd=$.trim($('#pwd').val());
	var realname=$.trim($('#realname').val());
	var idcard=$.trim($('#idcard').val());
	//var pwd_ck=$.trim($('#pwd_ck').val());
	var has_click=obj.attr('has-click');
	if(has_click=='1'){
		return false;
	}else{
		obj.attr('has-click','1');
	}
	pwd=md5(pwd);
	ajax({
		url:global.appurl+'c=Login&a=registerAct',
		data:{phone:phone,nickname:nickname,password:pwd,icode:icode,smscode:smscode,realname:realname,idcard:idcard},
		success:function(json){
			if(json.code!=1){
				obj.attr('has-click','0');
				_alert(json.msg);
				return;
			}
			_alert({
				content:json.msg,
				end:function(){
					//location.href='/?c=Login';
					location.href=appurlDownload;
				}
			});
		}
	});
});

</script>
</body>
</html><?php }} ?>
