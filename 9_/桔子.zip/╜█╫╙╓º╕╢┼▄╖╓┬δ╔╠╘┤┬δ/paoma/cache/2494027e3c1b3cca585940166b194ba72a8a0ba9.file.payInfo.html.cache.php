<?php /* Smarty version Smarty-3.1.21-dev, created on 2020-06-10 14:49:01
         compiled from "/www/wwwroot/121.36.134.31/home/view/Finance/payInfo.html" */ ?>
<?php /*%%SmartyHeaderCode:6871268425ee0825d12c624-80233050%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2494027e3c1b3cca585940166b194ba72a8a0ba9' => 
    array (
      0 => '/www/wwwroot/121.36.134.31/home/view/Finance/payInfo.html',
      1 => 1578476498,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6871268425ee0825d12c624-80233050',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'paylog' => 0,
    'vo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5ee0825d1741a7_17036769',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ee0825d1741a7_17036769')) {function content_5ee0825d1741a7_17036769($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("head.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<style>
.bannerItem{margin-right:5px;position:relative;}
.bannerItem span{position:absolute;top:0px;right:0px;line-height:20px;font-size:28px;}

.orderDetailCon{line-height:2.2rem;}
</style>
<div class="orderDetail">
	<!-- 顶部 -->
	<div class="HeadTop">
		<p class="Tit">订单详情</p>
		<a href="/?c=Finance&a=pay" class="backBtn"></a>
	</div>
	<div class="orderDetailCon">
		<p>订单号：<?php echo $_smarty_tpl->tpl_vars['paylog']->value['order_sn'];?>
</p>
		<p>订单金额：￥<?php echo $_smarty_tpl->tpl_vars['paylog']->value['money'];?>
</p>
		<p style="font-weight:bold;">所属代理：<?php if ($_smarty_tpl->tpl_vars['paylog']->value['a_account']) {
echo $_smarty_tpl->tpl_vars['paylog']->value['a_account'];?>
-<?php echo $_smarty_tpl->tpl_vars['paylog']->value['a_nickname'];
} else { ?>平台<?php }?></p>
		<p>充值账号：<?php echo $_smarty_tpl->tpl_vars['paylog']->value['account'];?>
</p>
		<p>下单时间：<?php echo $_smarty_tpl->tpl_vars['paylog']->value['create_time'];?>
</p>
		<p>订单状态：<b><?php echo $_smarty_tpl->tpl_vars['paylog']->value['pay_status_flag'];?>
</b></p>
		<p>收款银行：<?php echo $_smarty_tpl->tpl_vars['paylog']->value['skbank']['bank_name'];?>
</p>
		<?php if ($_smarty_tpl->tpl_vars['paylog']->value['skbank']['branch_name']) {?>
		<p>收款支行：<?php echo $_smarty_tpl->tpl_vars['paylog']->value['skbank']['branch_name'];?>
</p>
		<?php }?>
		<p>收款姓名：<?php echo $_smarty_tpl->tpl_vars['paylog']->value['skbank']['bank_realname'];?>
</p>
		<p>收款卡号：<?php echo $_smarty_tpl->tpl_vars['paylog']->value['skbank']['bank_account'];?>
</p>
		<div class="pinzheng">
			<span>付款凭证：</span>
			<ul>
				<?php  $_smarty_tpl->tpl_vars['vo'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['vo']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['paylog']->value['banners']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['vo']->key => $_smarty_tpl->tpl_vars['vo']->value) {
$_smarty_tpl->tpl_vars['vo']->_loop = true;
?>
				<li class="bannerItem"><img src="<?php echo $_smarty_tpl->tpl_vars['vo']->value;?>
"></li>
				<?php } ?>
				<?php if ($_smarty_tpl->tpl_vars['paylog']->value['pay_status']==1) {?>
				<li id="fileUploadH5Btn"><a href="javascript:;"><img src="/public/home/images/add.png"></a></li>
				<?php }?>
			</ul>
			<input type="file" id="fileUploadH5" accept="image/*" style="display:none;" />
		</div>
		<?php if ($_smarty_tpl->tpl_vars['paylog']->value['pay_status']==1) {?>
		<p>付款姓名：<input type="text" id="pay_realname" placeholder="选填" style="line-height:22px;padding:0 5px;"/></p>
		<p style="margin-bottom:10px;">付款账号：<input type="text" id="pay_account" placeholder="选填" style="line-height:22px;padding:0 5px;"/></p>
		<p><span style="position:relative;top:-32px;">付款备注：</span><textarea id="remark" placeholder="选填" style="padding:0 5px;line-height:20px;height:60px;width:171px;"></textarea></p>
		<?php } else { ?>
		<p>付款姓名：<?php echo $_smarty_tpl->tpl_vars['paylog']->value['pay_realname'];?>
</p>
		<p>付款账号：<?php echo $_smarty_tpl->tpl_vars['paylog']->value['pay_account'];?>
</p>
		<p>付款备注：<?php echo $_smarty_tpl->tpl_vars['paylog']->value['remark'];?>
</p>
		<?php }?>
		<?php if ($_smarty_tpl->tpl_vars['paylog']->value['pay_status']==1) {?>
		<a href="javascript:;" class="fillCashBtn" style="margin-top:1rem;">我已付款</a>
		<?php }?>
	</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("js.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<?php echo '<script'; ?>
 src="/public/js/lrz.all.bundle.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
preventDefault();
$(function(){


	$('#fileUploadH5Btn').on('click',function(){
		$('#fileUploadH5').trigger('click');
	});
	

	$('body').on('click','.bannerItem span',function(){
		var obj=$(this);
		obj.parent('.bannerItem').remove();
		if($('.bannerItem').length>=3){
			$('#fileUploadH5Btn').hide();
		}else{
			$('#fileUploadH5Btn').show();
		}
	});
	
	$('body').on('click','.bannerItem img',function(){
		var obj=$(this);
		var src=obj.attr('src');
		layer.open({
			content:'<div style="width:100%;text-align:center;"><img src="'+src+'"/></div>',
			style:'width:80%',
			btn:['关闭'],
			yes:function(idx){
				layer.close(idx);
			}
		});
	});

	document.getElementById('fileUploadH5').addEventListener('change', function () {
		var that = this;
		lrz(that.files[0], {
			width:800,
			height:800
		}).then(function(rst){
			that.value=null;
			ajax({
				url:global.appurl+'a=imgUpload',
				data:{imgdata:rst.base64},
				success:function(json){
					if(json.code!=1){
						_alert(json.msg);
						return;
					}
					var html='<li class="bannerItem"><img src="'+json.data.src+'"><span>×</span></li>';
					$('#fileUploadH5Btn').before(html);
					if($('.bannerItem').length>=3){
						$('#fileUploadH5Btn').hide();
					}
				}
			});
			return rst;
		});
	});
	
	$('.fillCashBtn').on('click',function(){
		var obj=$(this);
		var osn='<?php echo $_smarty_tpl->tpl_vars['paylog']->value['order_sn'];?>
';
		var pay_realname=$.trim($('#pay_realname').val());
		var pay_account=$.trim($('#pay_account').val());
		var remark=$.trim($('#remark').val());
		var banners=[];
		$('.bannerItem').each(function(i,o){
			banners.push($(o).find('img').attr('src'));
		});
		
		layer.open({
			//title:'',
			content:'您确定提交已付款状态么？',
			style:'width:65%',
			btn:['确定','取消'],
			yes:function(idx){
				layer.close(idx);
				ajax({
					url:global.appurl+'c=Finance&a=payUpdate',
					data:{osn:osn,banners:banners,pay_realname:pay_realname,pay_account:pay_account,remark:remark},
					success:function(json){
						if(json.code!=1){
							_alert(json.msg);
							return;
						}
						_alert({
							content:json.msg,
							end:function(){
								location.reload();
							}
						});
					}
				});
			}
		});
	});
	
});
<?php echo '</script'; ?>
>
<?php echo $_smarty_tpl->getSubTemplate ("foot.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>
<?php }} ?>
