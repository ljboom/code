<?php

session_start();

include APP_PATH.'common/app.func.php';

?>