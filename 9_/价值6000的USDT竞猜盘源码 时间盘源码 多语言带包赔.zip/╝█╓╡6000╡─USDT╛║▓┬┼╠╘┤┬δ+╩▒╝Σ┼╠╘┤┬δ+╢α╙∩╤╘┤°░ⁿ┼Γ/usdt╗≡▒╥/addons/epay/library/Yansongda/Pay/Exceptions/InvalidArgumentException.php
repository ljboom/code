<?php

namespace Yansongda\Pay\Exceptions;

class InvalidArgumentException extends \InvalidArgumentException
{
}
