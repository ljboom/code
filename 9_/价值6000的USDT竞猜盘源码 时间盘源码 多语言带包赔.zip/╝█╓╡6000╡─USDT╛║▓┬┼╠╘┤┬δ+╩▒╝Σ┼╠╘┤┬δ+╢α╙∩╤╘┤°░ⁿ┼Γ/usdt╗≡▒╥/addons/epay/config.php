<?php

return array (
  0 => 
  array (
    'name' => 'wechat',
    'title' => '微信',
    'type' => 'array',
    'content' => 
    array (
    ),
    'value' => 
    array (
      'appid' => '',
      'app_id' => '',
      'app_secret' => '',
      'miniapp_id' => '',
      'mch_id' => '',
      'key' => '',
      'notify_url' => '/addons/epay/api/notifyx/type/wechat',
      'cert_client' => '/epay/certs/apiclient_cert.pem',
      'cert_key' => '/epay/certs/apiclient_key.pem',
      'log' => 1,
    ),
    'rule' => '',
    'msg' => '',
    'tip' => '微信参数配置',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'alipay',
    'title' => '支付宝',
    'type' => 'array',
    'content' => 
    array (
    ),
    'value' => 
    array (
      'app_id' => '2016101800711827',
      'notify_url' => '/addons/epay/api/notifyx/type/alipay',
      'return_url' => '/addons/epay/api/returnx/type/alipay',
      'ali_public_key' => 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAklp0Uyo/NJafjCpWKq3eKmHPaj02fqBDxO+h/jzjfrtowccabV1oXv5cFgWasC1z9ogdDA48D9EmUZnUz+sBRVmv1Z2oddWTYm9cdCTKQ9rMJzJDR0k6u1uErSW5lbjqzlFyzzJY3hAsTNYgkOPqgIV9/+h2DSwI+PtqFmVakWQ0V9x36OPfR2jI/pCTr+R8uh4nus6kON2RbsIPMChB63/xQ2wQEPTDClvhWI9ANkT+ugEfbeoefGWgeqk+S/MW3wawE9DtPyoruBuKY5YNDzRFNpVXOETy3T3MIgwLWy9pj6wrnBkUYyJKwXc1EhdEAkw3wUmlqaQrxVUx4yln1QIDAQAB',
      'private_key' => 'MIIEpAIBAAKCAQEA05MiXet0BrBofO7z3leIE7lymKyI08HdMQDKFvFJ3MMilKF8COi6dHY9mZxBA2fabqHk7tWVScjEQraQ6x55bs69fIxRtYMg8UHCvdoDocgb69M9q8axcw3D/fQkuvitot5GNL1JiXfZP17NFHVttlDqAOkMgivvVKbMtPlYeEVPnxPa6P2rgXlaXghZuhzrQThLbQh39hDzemPLJSb8Vw6u6ZxcfCrN7KL2KeepWyydxW8+cKVV6Lw5114iDcp9Zc/mQ0SthS2VPSN6v1mDoXarIhMdTOXG1cPyVNAFlD2oHqxt77PxlcKw0gYJZZ9Mrcuj2F2yxrR+FJ0jyq3y1QIDAQABAoIBAEU1diJ+6N9fSW7Ew6VRwMOjACeNGN0cJ3zmIzVKDL1YX7F6+ZX4ezWpkBD1mhbBHCTgdIDkAQe30ut3yQQAXfyvSDC7vebAVEBXIJr1/AYp7WhBG4VbY6SdNiWWfYVj33jNeO27lZiQSdJ+8lrk5tSit0lA8sSKFqn8Pi5c+mGswgwQ0aVv/4B+4b4IIh+5nWCR3RdEcTXy5XezdYndPdwVR1HkYriC85X9+R1igfnrSmBlaVVpW+FOtahUmcw6mODugK9XfAVA64OWDtxm1p+NGlAjYsJOpA7sIugRZJr8dphkRu+PK4F7a3/Dcbcz8s2Zp7FGLkfjBqBiCLezUwECgYEA9yDLuH2g64H0pxJ392ZTLsSrUgN7iu78PN6NKzM08MkNYmtudDdQaJiykzsrL0ZGiLB6yh2Mr4RndGtghrDiVO1djkjuKLHNrm94FL+dsytnIE1zshlImYwWEWMwXVJe5sN2Z5eh4o4uziFOi0RNcMFddfCFIgZ1FrCtsjsfoCECgYEA2yuWztORO7SLq9tQ8w8UjEntm7Tbzh5dif0N5hK6L77Iuj6PGmNnNTFWi0Ei8RvJKB7F9S+9zuOkuCeKFYmcXVpKP70ZsmjAHcaOu9QOOMC4wPVGLor8CP26wOoe8dX0bAlgyHcwSBoNS0hu3wn3ZA+g0cEuYbmRmjhXXlaYTDUCgYEA5NX7jvTV4/5Mm8CgUfjwoef/dExBRB+UdpDmS9B4/1ZNDIvKldb6oEB1a5xomrgKbFxu92Vxdr22Rrl/gnmcu2OpNC4YSpqKiTIzEZN15gkUz3ao4YxEC9sKPEOK739s3Wa156sjfnSGpt10q8UtqHGFp8Z2oVE1bzNfRCE3YcECgYEAy7u8R2zBz8doIowPtrGo/zPlrV01CmiNuSzD08BK1QE7ZG2s5vHKSdcgRPh6u7iBiEr6543GmmBgiVMv+A9gjCLXbGKjVYYsOEGQAyf/RGBaHfyijbdizBTYmmXH+DRULm2VSyQIfK3C991QOwLvtlMUwocaT3uJztta0/YZQpUCgYBHF2H0lY8xFYE1Rnlb7f3llSLfp2emdKQ+pLjWcWvKtDWUDva0IbanWSoxVgfaBXjPhdWQVKX41EZg0oc0FX4hkzPA3DjTz9Ba7stiF1lkdjyLbNYFxgBsP1nBXl4Pfg1Ca29DuMteBEZfiYjYVvugOzAHPBZc/LATGKfZwJTaIQ==',
      'log' => '1',
    ),
    'rule' => 'required',
    'msg' => '',
    'tip' => '支付宝参数配置',
    'ok' => '',
    'extend' => '',
  ),
  2 => 
  array (
    'name' => '__tips__',
    'title' => '温馨提示',
    'type' => 'array',
    'content' => 
    array (
    ),
    'value' => '请注意微信支付证书路径位于/addons/epay/certs目录下，请替换成你自己的证书<br>appid：APP的appid<br>app_id：公众号的appid<br>app_secret：公众号的secret<br>miniapp_id：小程序ID<br>mch_id：微信商户ID<br>key：微信商户支付的密钥',
    'rule' => '',
    'msg' => '',
    'tip' => '微信参数配置',
    'ok' => '',
    'extend' => '',
  ),
);
