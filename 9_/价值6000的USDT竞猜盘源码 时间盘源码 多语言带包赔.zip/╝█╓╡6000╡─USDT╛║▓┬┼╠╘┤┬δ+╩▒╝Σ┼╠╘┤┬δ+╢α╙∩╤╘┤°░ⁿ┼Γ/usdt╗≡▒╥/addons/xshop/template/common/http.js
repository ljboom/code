import { Http } from './request/index'
export default new Http()