export default {
	'groupon.groups': {
		uri: 'index/getProductGroups'
	},
	'groupon.product.list': {
		uri: 'index/getProducts'
	}
}