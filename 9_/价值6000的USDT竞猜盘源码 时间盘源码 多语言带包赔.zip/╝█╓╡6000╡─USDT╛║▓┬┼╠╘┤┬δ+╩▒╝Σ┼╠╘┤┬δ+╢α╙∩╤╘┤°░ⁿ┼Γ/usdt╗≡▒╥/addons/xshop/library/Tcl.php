<?php

namespace addons\xshop\library;

use fast\Http;
use think\Exception;

/**
 * 对接其他平台操作类
 */

class Tcl
{
    protected $config = [];
    // protected $host = 'http://userapi.baijinguoji.cn/';
    protected $host = 'http://test_userapi.baijinguoji.cn/';
    
    public function __construct($config = [])
    {
        $this->config = $config;
    }

    public static function instance($config = [])
    {
        return new static($config);
    }

    /**
     *  获取用户百金积分信息接口
     *   mobile:   手机号
     *   sign:验证字符串固定（加密格式：MD5(mobile) POST
     */

    public function getUserBj()
    {
        $data['mobile'] = $this->config['mobile'];
        $sign_fields = ['mobile'];
        $data['sign'] = $this->sign($data, $sign_fields);
        $url = $this->host . 'transfer/getuserintegralinfo';
        $res = Http::post($url, $data); 
        return json_decode($res);
         //return $res; 

    }
    /**
     *  增加用户百金积分信息接口
     *   mobile:   手机号 
     *   amount:百金积分金额(最多两位小数不能为0)
     *   sign:验证字符串固定（加密格式：MD5(mobile&amount) POST
     */

    public function addUserBj()
    {
        $data['mobile'] = $this->config['mobile'];
        $data['amount'] = $this->config['amount'];
        $sign_fields = ['mobile', 'amount'];
        $data['sign'] = $this->sign($data, $sign_fields);
        $url = $this->host . 'transfer/emptoaddintegral';
        $res = Http::post($url, $data); 
        return json_decode($res);
         //return $res; 

    }
    /**
     *  减少用户百金积分信息接口
     *   mobile:   手机号 
     *   amount:百金积分金额(最多两位小数不能为0)
     *   sign:验证字符串固定（加密格式：MD5(mobile&amount) POST
     */

    public function subUserBj()
    {
        $data['mobile'] = $this->config['mobile'];
        $data['amount'] = $this->config['amount'];
        $sign_fields = ['mobile', 'amount'];
        $data['sign'] = $this->sign($data, $sign_fields);
        $url = $this->host . 'transfer/emptodeleteintegral';
        $res = Http::post($url, $data); 
        return json_decode($res);
         //return $res; 

    }


    public function sign($data, $sign_fields, $salt = '')
    {
        $new_sign_fields = [];
        foreach ($sign_fields as $v) {
            if (isset($data[$v]) && trim($data[$v]) !== '') {
                $new_sign_fields[] = $v;
            }
        }
        //sort($new_sign_fields);

        $signStrArr = [];
        foreach ($new_sign_fields as $v) {
            $signStrArr[] = $data[$v];
        }
        // 待签名字符串
        $signStr = implode('&', $signStrArr);
        return MD5($signStr . $salt);
    }
}
