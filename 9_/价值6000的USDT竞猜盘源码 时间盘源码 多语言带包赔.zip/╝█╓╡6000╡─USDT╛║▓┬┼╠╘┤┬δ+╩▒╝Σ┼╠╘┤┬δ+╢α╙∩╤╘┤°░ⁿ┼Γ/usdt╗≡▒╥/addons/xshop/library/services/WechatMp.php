<?php

namespace addons\xshop\library\services;

use fast\Http;
use \think\Exception;
use think\Session;

class WechatMp
{    
    const AUTH_URL = 'https://api.weixin.qq.com/sns/jscode2session';
    protected $config = [];

    const OK = 0;
    const IllegalAesKey = -41001;
	const IllegalIv = -41002;
	const IllegalBuffer = -41003;
	const DecodeBase64Error = -41004;

    public function __construct($config = []) 
    {
        $this->setConfig($config);
    }

    public function setConfig($config)
    {
        $this->config = array_merge($this->config, $config);
        return $this;
    }

    public function getAuthUrl()
    {
        $data = [
            'appid' => $this->config['appid'],
            'secret' => $this->config['secret'],
            'js_code' => $this->config['code'],
            'grant_type' => 'authorization_code'
        ];
        return self::AUTH_URL . '?' . http_build_query($data);
    }

    /**
     * code2Session
     */
    public function login()
    {
        $url = $this->getAuthUrl();
        $res = Http::sendRequest($url, [], 'GET');
        if (!$res['ret']) {
            throw new Exception($res['msg']);
        }
        $data = json_decode($res['msg'], 1);
        if (!empty($data['errcode'])) {
            throw new Exception($data['errmsg']);
        }
        $token = [
            'openid' => $data['openid'],
            'session_key' => $data['session_key'],
            'unionid' => $data['unionid'] ?? '',
            'expires_in' => 2 * 24 * 60 * 60
        ];
        $this->token = $token;
        return $token;
    }

    public function getUserInfo()
    {
        $errCode = $this->decryptData($this->config['encryptedData'], $this->config['iv'], $data);
        if ($errCode == 0) {
            return $data;
        } else {
            throw new Exception("解密失败{$errCode}");
        }
    }

    /**
     * 检验数据的真实性，并且获取解密后的明文.
     */
    public function decryptData($encryptedData, $iv, &$data)
    {
        $sessionKey = $this->config['session_key'];
        if (strlen($sessionKey) != 24) {
			return self::IllegalAesKey;
		}
		$aesKey=base64_decode($sessionKey);
        
		if (strlen($iv) != 24) {
			return self::IllegalIv;
		}
		$aesIV=base64_decode($iv);

		$aesCipher=base64_decode($encryptedData);

		$result=openssl_decrypt( $aesCipher, "AES-128-CBC", $aesKey, 1, $aesIV);

		$dataObj=json_decode( $result );
		if( $dataObj  == NULL )
		{
			return self::IllegalBuffer;
		}
		if( $dataObj->watermark->appid != $this->config['appid'] )
		{
			return self::IllegalBuffer;
		}
		$data = [
            'openid' => $dataObj->openId,
            'nickname' => $dataObj->nickName ?? '',
            'sex' => $dataObj->gender ?? 0,
            'province' => $dataObj->province ?? '',
            'city' => $dataObj->city ?? '',
            'headimgurl' => $dataObj->avatarUrl ?? '',
            'unionid' => $dataObj->unionId ?? '',
        ];
		return self::OK;
    }
}