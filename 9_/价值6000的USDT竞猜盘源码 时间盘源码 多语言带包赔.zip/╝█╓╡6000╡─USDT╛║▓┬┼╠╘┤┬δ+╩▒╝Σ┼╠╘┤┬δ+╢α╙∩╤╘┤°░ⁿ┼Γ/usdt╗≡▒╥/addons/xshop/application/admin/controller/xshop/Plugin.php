<?php

namespace app\admin\controller\xshop;

class Plugin extends Base
{
    public function index()
    {
        if ($this->request->isAjax()) {
            $api_url = get_addon_info('xshop')['api_url'];
            $data = \fast\Http::post($api_url . '/addons/xshopplugin/resources');
            $data = (array)json_decode($data, true);
            if ($data['code'] == 1) {
                $result = ['rows' => $data['data']];
            } else {
                $result = [];
            }
            return json($result);
        }
        return $this->view->fetch();
    }
}