<?php

return [
    'Code' => '快递公司编号',
    'Name' => '快递公司名称'
];
