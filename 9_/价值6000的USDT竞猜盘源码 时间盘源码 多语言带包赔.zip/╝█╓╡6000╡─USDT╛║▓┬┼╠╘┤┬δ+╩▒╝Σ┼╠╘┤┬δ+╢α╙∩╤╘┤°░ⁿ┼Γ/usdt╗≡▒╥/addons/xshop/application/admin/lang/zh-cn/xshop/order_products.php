<?php

return [
    'Order_id'       => '订单',
    'Product_id'     => '商品',
    'Shop_id'        => '商家',
    'Title'          => '商品名称',
    'Description'    => '商品描述',
    'Image'          => '商品图片',
    'Attributes'     => '商品规格',
    'Price'          => '销售价',
    'Quantity'       => '数量',
    'Product_price'  => '应付金额',
    'Discount_price' => '优惠金额',
    'Order_price'    => '订单金额'
];
