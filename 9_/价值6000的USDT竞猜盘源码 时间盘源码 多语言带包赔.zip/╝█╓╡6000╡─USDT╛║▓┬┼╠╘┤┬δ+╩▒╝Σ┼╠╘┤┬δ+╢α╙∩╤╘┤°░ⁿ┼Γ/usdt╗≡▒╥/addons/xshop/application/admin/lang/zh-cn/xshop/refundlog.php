<?php

return [
    'Out_trade_no'  => '商户订单号',
    'Out_refund_no' => '商户退款单号',
    'Total_fee'     => '支付金额',
    'Refund_fee'    => '退款金额',
    'Pay_type'      => '付款方式',
    'Status'        => '退款状态',
    'Create_time'   => '创建时间'
];
