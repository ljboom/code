<?php

return [
    'Title'       => '标题',
    'Description' => '描述',
    'Type'        => '跳转类型',
    'Target'      => '跳转目标',
    'Sort'        => '排序',
    'Status'      => '状态',
    'Image'       => '图片',
    'Nav_type'    => '导航类型',
    'NavType'    => '导航类型',
    'Array key'   => '参数名',
    'Array value' => "参数值"
];
