<?php

return [
    'Code'        => '模板标识',
    'Description' => '模板描述',
    'Content'     => '模板内容'
];
