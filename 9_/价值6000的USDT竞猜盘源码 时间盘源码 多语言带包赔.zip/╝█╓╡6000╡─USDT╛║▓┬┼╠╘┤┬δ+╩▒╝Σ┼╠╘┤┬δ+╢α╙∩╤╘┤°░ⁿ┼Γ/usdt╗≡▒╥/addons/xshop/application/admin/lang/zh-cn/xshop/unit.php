<?php

return [
    'Name'       => '单位名称',
    'Code'       => '单位符号',
    'Is_default' => '是否默认'
];
