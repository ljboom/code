<?php

return [
    'Version'     => '版本号',
    'Description' => '更新描述',
    'Platform'    => '平台',
    'Status'      => '状态',
    'Create_time' => '创建时间',
    'Source_file' => '升级文件'
];
