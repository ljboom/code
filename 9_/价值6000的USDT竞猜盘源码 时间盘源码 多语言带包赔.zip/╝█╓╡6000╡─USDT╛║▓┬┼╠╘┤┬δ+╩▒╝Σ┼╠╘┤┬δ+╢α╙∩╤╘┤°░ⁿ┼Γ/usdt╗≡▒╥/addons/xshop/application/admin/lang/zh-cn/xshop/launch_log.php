<?php

return [
    'Platform'      => '来源',
    'User_id'       => '用户',
    'Systeminfo'    => '系统信息',
    'Create_time'   => '创建时间',
    'User.nickname' => '昵称'
];
