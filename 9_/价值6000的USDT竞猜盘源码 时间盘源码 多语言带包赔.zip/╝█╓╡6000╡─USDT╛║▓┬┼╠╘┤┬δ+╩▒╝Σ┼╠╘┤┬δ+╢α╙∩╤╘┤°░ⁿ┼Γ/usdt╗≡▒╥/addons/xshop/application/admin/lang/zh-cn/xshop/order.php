<?php

return [
    'Order_sn'        => '订单编号',
    'User_id'         => '用户',
    'Shop_id'         => '商户',
    'Is_pay'          => '是否已支付',
    'Pay_time'        => '支付时间',
    'Is_delivery'     => '是否发货',
    'Delivery'        => '发货时间',
    'Status'          => '订单状态',
    'Contactor'       => '联系人',
    'Contactor_phone' => '联系电话',
    'Delivery_price'  => '运费',
    'Products_price'  => '商品金额',
    'Order_price'     => '订单金额',
    'Pay_price'       => '应付金额',
    'Discount_price'  => '优惠金额',
    'Payed_price'     => '已付金额',
    'Create_time'     => '创建时间',
    'Update_time'     => '最后更新',
    'Delete_time'     => '删除时间',
    'User.username'   => '用户名',
    'User.nickname'   => '昵称'
];
