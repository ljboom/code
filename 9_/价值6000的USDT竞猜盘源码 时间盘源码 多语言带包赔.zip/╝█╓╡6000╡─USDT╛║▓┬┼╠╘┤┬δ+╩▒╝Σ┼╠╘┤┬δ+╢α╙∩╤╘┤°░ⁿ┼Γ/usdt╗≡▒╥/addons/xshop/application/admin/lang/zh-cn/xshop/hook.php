<?php

return [
    'Group'      => '分组',
    'Hook'       => '钩子名称',
    'Hook_desc'  => '钩子描述',
    'Group_sort' => '分组排序',
    'Hook_sort'  => '钩子排序'
];
