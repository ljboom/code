<?php

return [
    'Title'       => '标题',
    'Description' => '描述',
    'Sort'        => '排序',
    'Is_default'  => '默认'
];
