<?php

return [
    'Name'        => '钩子标识',
    'Description' => '描述',
    'Action'      => '动作',
    'Weigth'      => '排序',
    'Addon_name'  => '插件标识',
    'State'       => '状态'
];
