<?php

namespace addons\xshop\controller;
 
use addons\xshop\model\UserModel;
use addons\xshop\validate\CrossValidate;

/**
 * 跨平台
 */
class Cross extends Base
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];
    /**
     * 获取用户BJ积分
     * post{mobile:13979797879,sign:md5(13979797879)=0f02f82b214805020be8013170ca7578} 
     */
    public function getUserBj()
    { 
        $params = $this->request->post();
        $result = $this->validate($params,CrossValidate::class.'.get');
        if (true !== $result) {
            return $this->error($result);
        }
        $user = UserModel::getByMobile($params['mobile']);
        if(!$user){
            $this->error('user not find','',10000);
        }
        $re['BJ']=$user['wall7'];
        $this->success('', $re); 
    }

     /**
     * 增加用户BJ积分
     * post{mobile:13979797879,amount:1,sign:md5(mobile&amount)=c0ae5ff731034baa81f316620fb37f5e} 
     */
    public function addUserBj()
    { 
        $params = $this->request->post();
        $ip=request()->ip();
        if(!in_array($ip,config('site.b_ip'))){
            $this->error('请求ip:'.$ip.',ip错误');
        }
        $cc = md5(serialize($params));
        if (cache($cc)) {
            $this->error('请稍后再提交');
        } else {
            cache($cc, 1,5); 
        }
        $result = $this->validate($params,CrossValidate::class.'.change');
        if (true !== $result) {
            return $this->error($result);
        }
        $user = UserModel::getByMobile($params['mobile']);
        if(!$user){
            $this->error('user not find','',10000);
        }
       
        caiwu($user['id'],$params['amount'],11,'wall7','百点金划转积分到SSEX');
        $re['BJ']=round($user['wall7']+$params['amount'],2);
        $this->success('操作成功', $re); 
    }

      /**
     * 减少用户BJ积分
     * post{mobile:13979797879,amount:1,sign:md5(mobile&amount)=c0ae5ff731034baa81f316620fb37f5e} 
     */
    public function subUserBj()
    { 
        $params = $this->request->post();
        $ip=request()->ip(); 
        if(!in_array($ip,config('site.b_ip'))){
            $this->error('请求ip:'.$ip.',ip错误');
        }
        $cc = md5(serialize($params));
        if (cache($cc)) {
            $this->error('请稍后再提交');
        } else {
            cache($cc, 1,5); 
        }
        $result = $this->validate($params,CrossValidate::class.'.change');
        if (true !== $result) {
            return $this->error($result);
        }
        $user = UserModel::getByMobile($params['mobile']);
        if(!$user){
            $this->error('user not find','',10000);
        }
        if($user['wall7']<$params['amount']){
            $this->error('账户积分不足','',10000);
        }
        caiwu($user['id'],-$params['amount'],11,'wall7','SSEX划转积分到百点金');
        $re['BJ']=round($user['wall7']-$params['amount'],2);
        $this->success('操作成功', $re); 
    }
     

}
