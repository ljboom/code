<?php

namespace addons\xshop\controller;

use addons\xshop\model\trade\Buy;
use addons\xshop\model\trade\Sale;
use addons\xshop\model\trade\Pp;
use addons\xshop\model\UserModel;
use think\Exception;
use think\Db;

/**
 * 撮合交易
 */
class Trade extends Base
{

    protected $noNeedLogin = ['index', 'buylist'];
    protected $noNeedRight = ['*'];


    /**
     * 获取市场
     */
    public function index()
    {
        $name = input('name');
        $re = db('btc_market')->where('name', $name)->find();
        $this->success('', $re);
        //    $list=db('trade_buy')->select();
        //    foreach($list as $key=>$item){
        //        unset($item['id']);
        //        $tmp[]=$item;
        //    }
        //   echo db('trade_buy')->insertAll($tmp);

        //   $list=db('trade_sale')->select();
        //   foreach($list as $key=>$item){
        //       unset($item['id']);
        //       $tmp[]=$item;
        //   }
        //  echo db('trade_sale')->insertAll($tmp);

        //    $list=db('trade_pp')->select();
        //   foreach($list as $key=>$item){
        //       unset($item['id']);
        //       $tmp[]=$item;
        //   }
        //  echo db('trade_pp')->insertAll($tmp);

        // return $this->success('', Sale::all());
    }

    private function comcheck($user, $btc, $cny, $ptype1, $ptype2, $type)
    {
        $total = $btc * $cny;
        if ($type == 'buy') {
            if ($user[$ptype2] < $total) {
                $this->error('Insufficient account(账户不足)');
            }
        } else {
            if ($user[$ptype1] < $btc) {
                $this->error('Insufficient account(账户不足)');
            }
        }
    }

    /**
     * 买单
     *
     * @param string $btc  数量
     * @param string $cny  单价
     * @param string $ptype1  卖出类型 
     * @param string $ptype2  买入类型  
     */
    public function buy()
    {

        $user = UserModel::getUserInfo();
        $btc = input('num', 0);     //数量
        $cny = input('price', 1);     //单价
        $ptype1 = input('ptype1');     //卖出类型 
        $ptype2 = input('ptype2');     //买入类型  
        // $fee = $this->comcheck($btc, $cny, 'buy');
        // $caiwuarr = config('site.cointype');
        // $ptype1 = array_search($ptype1, $caiwuarr);
        // $ptype2 = array_search($ptype2, $caiwuarr);
        $this->comcheck($user, $btc, $cny, $ptype1, $ptype2, 'buy');
        Db::startTrans();
        try {
            $Ppmx = new Pp();
            $Ppmx->buy($btc, $cny, 0, $user, $ptype1, $ptype2);
            $Ppmx->findSale($Ppmx->btc_buy_id);
            Db::commit();
            $this->success('success', '321');
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }

    /**
     * 卖单
     *
     * @param string $btc  数量
     * @param string $cny  单价
     * @param string $ptype1  卖出类型 
     * @param string $ptype2  买入类型  
     */
    public function sale()
    {

        $user = UserModel::getUserInfo();
        $btc = input('num', 0);     //数量
        $cny = input('price', 1);     //单价
        $ptype1 = input('ptype1');     //卖出类型 
        $ptype2 = input('ptype2');     //买入类型  
        // $fee = $this->comcheck($btc, $cny, 'buy');

        $this->comcheck($user, $btc, $cny, $ptype1, $ptype2, 'sale');
        Db::startTrans();
        try {
            $Ppmx = new Pp();
            $Ppmx->sale($btc, $cny, 0, $user, $ptype1, $ptype2);
            $Ppmx->findBuy($Ppmx->btc_sale_id);
            Db::commit();
            $this->success('success', '321');
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }

    /**
     * 撤销卖单
     * @param string $id 卖单编号
     * @return \think\response\Json
     */
    public function CancelSaleOrder()
    {

        $id = input('id');
        $user = UserModel::getUserInfo();
        Db::startTrans();
        try {
            $Ppmx = new Pp();
            if ($Ppmx->cancelSaleOrder($user['id'], $id)) {
                Db::commit();
                $this->success('success', 321);
            } else {
                $this->success('Failure', '321');
            }
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }

    /**
     * 撤销买单
     * @param string $id 买单编号
     * @return \think\response\Json
     */
    public function cancelBuyOrder()
    {
        $id = input('id');
        $user = UserModel::getUserInfo();
        Db::startTrans();
        try {
            $Ppmx = new Pp();
            if ($Ppmx->cancelBuyOrder($user['id'], $id)) {
                Db::commit();
                $this->success('success', 321);
            } else {
                $this->success('Failure', '321');
            }
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }

    /**
     * 委托单
     */
    public function entrust_buy()
    {

        $user = UserModel::getUserInfo();
        $data = input();
        $map = array_filter(['ptype1' => $data['ptype1'],  'ptype2' => $data['ptype2']]);
        $map['userid'] = $user['id'];
        $map['status'] = '0';

        $buy = Buy::where($map)->order('id desc')->paginate(10, false, ['query' => $map]);

        $this->success('', $buy);
    }

    /**
     * 历史单
     */
    public function history()
    {

        $user = UserModel::getUserInfo();
        $data = input();
        $map = array_filter(['ptype1' => $data['ptype1'],  'ptype2' => $data['ptype2']]);
        $map['userid'] = $user['id'];
        $map['status'] = ['in', '3,5'];

        $buy = Buy::where($map)->order('id desc')->paginate(10, false, ['query' => $map]);

        $this->success('', $buy);
    }

    /**
     * 委托单
     */
    public function buylist()
    {
        $data = input();
        $map = array_filter(['ptype1' => $data['ptype1'],  'ptype2' => $data['ptype2']]);
        $map['status'] = '0';
        $map['type'] = '4';
        $buy = Buy::where($map)->field('sum(number) as num,sum(trade_number) as trade,price')->group('price')->order('price desc')->limit(10)->select();
        if ($buy) {
            foreach ($buy as $key => $item) {
                $buy[$key]['num'] = round($item['num'] - $item['trade'], 4);
            }
        }
        $map2['status'] = '0';
        $map2['type'] = '5';
        $sale = Buy::where($map2)->field('sum(number) as num,sum(trade_number) as trade,price')->group('price')->order('price')->limit(10)->select();
        if ($sale) {
            foreach ($sale as $key => $vo) {
                $sale[$key]['num'] = round($vo['num'] - $vo['trade'], 4);
            }
        }
        $re['buylist'] = $buy;
        $re['salelist'] = array_reverse($sale);
        $this->success('', $re);
    }
}
