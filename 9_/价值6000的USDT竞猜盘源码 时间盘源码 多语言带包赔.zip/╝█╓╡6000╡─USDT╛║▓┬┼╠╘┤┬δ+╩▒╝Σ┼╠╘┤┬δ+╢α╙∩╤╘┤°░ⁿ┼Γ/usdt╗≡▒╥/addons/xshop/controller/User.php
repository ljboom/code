<?php

namespace addons\xshop\controller;

use think\addons\Controller;
use think\Config;
use app\common\library\Auth;
use addons\xshop\validate\UserValidate;
use addons\xshop\validate\ChargeValidate;
use addons\xshop\validate\CashValidate;
use addons\xshop\model\AddressModel;
use addons\xshop\traits\LoginTrait;
use addons\xshop\model\HistoryModel;
use addons\xshop\model\FavoriteModel;
use addons\xshop\model\UserModel;
use addons\xshop\model\Payment;
use addons\xshop\model\Charge;
use addons\xshop\model\Cash;
use think\Exception;
use addons\xshop\model\Caiwu;


/**
 * 用户
 * @ApiWeigh (10)
 */
class User extends Base
{
    protected $beforeActionList = [
        '__NeedLogin'
    ];

    use LoginTrait;
    /**
     * 获取用户信息
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function index()
    {
        $user = UserModel::getUserInfo();
        \think\Hook::listen('xshop_get_userinfo', $user);
        return $this->success('', $user);
    }

    /**
     * 修改资料
     * @ApiMethod (POST)
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function editInfo()
    {
        $this->request->filter(['strip_tags']);
        $params = $this->request->post();
        $params = array_filter($params);
        $result = $this->validate($params, UserValidate::class . '.editInfo');
        if (true !== $result) {
            return $this->error($result);
        }
        return $this->success('', UserModel::editInfo($params));
    }

    /**
     * 检查支付密码 
     */
    public function checkpass()
    {
        $password2 = input('password2', 0);
        if ($password2 && UserModel::checkpass($password2)) {
            $this->success('');
        } else {
            $this->error('密码错误');
        }
    }

    /**
     * 新增或修改地址
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     * @ApiParams (name=address_id, type=integer, required=false, description="address_id")
     * @ApiParams (name=address, type=string, required=true, description="送货地址 省 市 区")
     * @ApiParams (name=street, type=string, required=true, description="街道")
     * @ApiParams (name=is_default, type=integer, required=false, description="是否默认")
     * @ApiParams (name=contactor_name, type=string, required=true, description="联系人")
     * @ApiParams (name=phone, type=string, required=true, description="联系电话")
     */
    public function editAddress()
    {
        $params = $this->request->post();
        $result = $this->validate($params, UserValidate::class . '.edit');
        if (true !== $result) {
            return $this->error($result);
        }
        return $this->success('', AddressModel::edit($params));
    }

    /**
     * 删除地址
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     * @ApiParams (name=address_id, type=integer, required=false, description="地址Id")
     */
    public function delAddress()
    {
        $params = $this->request->post();
        $result = $this->validate($params, UserValidate::class . '.deleteAddress');
        if (true !== $result) {
            return $this->error($result);
        }
        return $this->success('', AddressModel::del($params));
    }

    /**
     * 获取地址信息
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function getAddress()
    {
        return $this->success('', AddressModel::getList());
    }

    /**
     * 新增或修改收款信息
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     
     */
    public function editPayment()
    {
        $params = $this->request->post();
        $result = $this->validate($params, UserValidate::class . '.editPayment');
        if (true !== $result) {
            return $this->error($result);
        }
        return $this->success('', Payment::edit($params));
    }
    /**
     * 新增或修改收款信息
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     
     */
    public function editPayment2()
    {
        $params = $this->request->post();
        $result = $this->validate($params, UserValidate::class . '.editPayment2');
        if (true !== $result) {
            return $this->error($result);
        }
        return $this->success('', Payment::edit2($params));
    }

    /**
     * 获取收款信息
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function getPayment()
    {
        return $this->success('', Payment::getList());
    }

    /**
     * 删除收款信息
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     * @ApiParams (name=address_id, type=integer, required=false, description="地址Id")
     */
    public function delPayment()
    {
        $params = $this->request->post();
        $result = $this->validate($params, UserValidate::class . '.deletePayment');
        if (true !== $result) {
            return $this->error($result);
        }
        return $this->success('', Payment::del($params));
    }

    /**
     * 获取浏览历史
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function viewList()
    {
        return $this->success('', HistoryModel::getList());
    }
    /**
     * 获取收藏
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function favorite()
    {
        return $this->success('', FavoriteModel::getList());
    }
     
    /**
     * 新增或修改充值信息
     * @ApiHeaders (name=Token, type=string, required=true, description="请求的Token") 
     */
    public function editCharge()
    {
        $params = $this->request->post();
        $cc = md5(serialize($params));
        if (cache($cc)) {
            $this->error('请稍后再提交');
        } else {
            cache($cc, 1,5); 
        }
        $result = $this->validate($params, ChargeValidate::class . '.add');
        if (true !== $result) {
            return $this->error($result);
        }
        return $this->success('', Charge::edit($params));
    }
    /**
     * 新增或修改提现信息
     * @ApiHeaders (name=Token, type=string, required=true, description="请求的Token") 
     */
    public function editCash()
    {
        $params = $this->request->post();
        $cc = md5(serialize($params));
        if (cache($cc)) {
            $this->error('请稍后再提交');
        } else {
            cache($cc, 1,5); 
        }
        $result = $this->validate($params, CashValidate::class . '.add');
        if (true !== $result) {
            return $this->error($result);
        }
        $this->success('', Cash::edit($params));
    }

    /**
     * 用户财务记录
     */
    public function caiwu()
    {
        $user = UserModel::getUserInfo();
        $data = input();
        $map = array_filter(['ptype' => $data['ptype'], 'type' => $data['type']]);
        if (isset($data['rank'])) {
            if ($data['rank'] > 0) {
                //支出
                $map['price'] = ['<', 0];
            } else {
                //收入
                $map['price'] = ['>', 0];
            }
        }
        if (isset($data['start']) && isset($data['end'])) {
            if ($data['end'] < $data['start']) {
                $this->error("End time cannot be earlier than start time(结束时间不能小于开始时间)");
            }
            $map['addtime'] = ['between', [strtotime($data['start']), strtotime($data['end'])+86400]];
        }
        $map['userid'] = $user['id'];
        $buy = Caiwu::where($map)->order('id desc')->paginate(10, false, ['query' => $map]);

        $sum = Caiwu::where($map)->sum('price');
        $re['list']=$buy;
        $re['sum']=$sum;
        $this->success('', $re);
    }
}
