<?php

namespace addons\xshop\controller;

use addons\xshop\model\trade2\Buymx;
use addons\xshop\model\trade2\Ppmx;
use addons\xshop\model\UserModel;
use think\Exception;
use addons\xshop\validate\PpmxValidate;
use addons\xshop\model\Payment;
use think\Db;

/**
 * c2c交易
 */
class Trade2 extends Base
{

    protected $noNeedLogin = ['index', 'entrust_buy'];
    protected $noNeedRight = ['*'];


    /**
     * 获取市场
     */
    public function index()
    {
        $name = input('name');
        $re = db('btc_market')->where('name', $name)->find();
        $this->success('', $re);
        //    $list=db('trade_buy')->select();
        //    foreach($list as $key=>$item){
        //        unset($item['id']);
        //        $tmp[]=$item;
        //    }
        //   echo db('trade_buy')->insertAll($tmp);

        //   $list=db('trade_sale')->select();
        //   foreach($list as $key=>$item){
        //       unset($item['id']);
        //       $tmp[]=$item;
        //   }
        //  echo db('trade_sale')->insertAll($tmp);

        //    $list=db('trade_pp')->select();
        //   foreach($list as $key=>$item){
        //       unset($item['id']);
        //       $tmp[]=$item;
        //   }
        //  echo db('trade_pp')->insertAll($tmp);

        // return $this->success('', Sale::all());
    }

    private function comcheck($user, $params, $type)
    {
        $pay = Payment::where(['user_id' => $user['id'], 'is_default' => 1])->find();
        if (!$pay) {
            $this->error('请先完善收款方式');
        }
        $trading = Ppmx::where(['userid|userid1' => $user['id'], 'status' => ['in', '0,1']])->count();
        if ($trading) {
            $this->error('您有未完成订单，请点击右上角查看我的订单');
        }
        $btc = $params['number'];     //数量
        // $cny =$params['price'];     //单价
        $ptype1 = $params['ptype1'];     //卖出类型 
        // $ptype2 =$params['ptype2'];      //买入类型  
        // $total = $btc * $cny;
        if ($type == 'buy') {
            // if ($user[$ptype2] < $total) {
            //     $this->error('账户不足');
            // }
        } else {
            if ($user[$ptype1] < $btc) {
                $this->error('账户不足');
            }
        }
    }

    /**
     * 买单
     *
     * @param string $btc  数量
     * @param string $cny  单价
     * @param string $ptype1  卖出类型 
     * @param string $ptype2  买入类型  
     */
    public function buy()
    {

        $user = UserModel::getUserInfo();
        $params = $this->request->post();
        // $fee = $this->comcheck($btc, $cny, 'buy');
        // $caiwuarr = config('site.cointype');
        // $ptype1 = array_search($ptype1, $caiwuarr);
        // $ptype2 = array_search($ptype2, $caiwuarr);
        $this->comcheck($user, $params, 'buy');
        Db::startTrans();
        try {
            $Ppmx = new Ppmx();
            $Ppmx->buy($params, $user);
            Db::commit();
            // $Ppmx->findSale($Ppmx->btc_buy_id);
            $this->success('提交成功', '321');
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }

    /**
     * 卖单
     *
     * @param string $btc  数量
     * @param string $cny  单价
     * @param string $ptype1  卖出类型 
     * @param string $ptype2  买入类型  
     */
    public function sale()
    {

        $user = UserModel::getUserInfo();
        $params = $this->request->post();

        $this->comcheck($user, $params, 'sale');
        Db::startTrans();
        try {
            $Ppmx = new Ppmx();
            $Ppmx->sale($params, $user);
            // $Ppmx->findBuy($Ppmx->btc_sale_id);
            Db::commit();
            $this->success('提交成功', '321');
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }

    /**
     * 撤销卖单
     * @param string $id 卖单编号
     * @return \think\response\Json
     */
    public function CancelSaleOrder()
    {

        $id = input('id');
        $user = UserModel::getUserInfo();
        Db::startTrans();
        try {
            $Ppmx = new Ppmx();
            if ($Ppmx->cancelSaleOrder($user['id'], $id)) {
                Db::commit();
                $this->success('撤单成功', 321);
            } else {
                $this->success('撤单失败', 321);
            }
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }

    /**
     * 撤销买单
     * @param string $id 买单编号
     * @return \think\response\Json
     */
    public function cancelBuyOrder()
    {
        $id = input('id');
        $user = UserModel::getUserInfo();
        Db::startTrans();
        try {
            $Ppmx = new Ppmx();
            if ($Ppmx->cancelBuyOrder($user['id'], $id)) {
                Db::commit();
                $this->success('撤单成功', 321);
            } else {
                $this->success('撤单失败', 321);
            }
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }

    /**
     * 撤销匹配
     * @param string $id 买单编号
     * @return \think\response\Json
     */
    public function cancelPpOrder()
    {
        $id = input('id');
        Db::startTrans();
        try {
            $Ppmx = new Ppmx();
            if ($Ppmx->cancelpp($id)) {
                Db::commit();
                $this->success('撤单成功', 321);
            } else {
                $this->success('撤单失败', 321);
            }
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }



    /**
     * 所有商户委托单
     */
    public function entrust_buy()
    {
        $data = input();
        $map = array_filter(['ptype1' => $data['ptype1'],  'type' => $data['type']]);
        $map['status'] = '0';
        $buy = Buymx::with('User')->where($map)->paginate(10, false, ['query' => $map]);

        $this->success('', $buy);
    }

    /**
     * 用户历史单
     */
    public function history()
    {

        $user = UserModel::getUserInfo();
        $data = input();
        $map = array_filter(['ptype1' => $data['ptype1'], 'status' => ['in', $data['status']]]);
        $map['userid|userid1'] = $user['id'];
        $buy = Ppmx::where($map)->order('id desc')->paginate(10, false, ['query' => $map]);

        $this->success('', $buy);
    }


    /**
     *  商户个人委托单
     */
    public function entrust()
    {

        $user = UserModel::getUserInfo();
        $data = input();
        $map = array_filter(['ptype1' => $data['ptype1'], 'status' => ['in', $data['status']]]);
        $map['userid'] = $user['id'];

        $buy = Buymx::where($map)->order('id desc')->paginate(10, false, ['query' => $map]);

        $this->success('', $buy);
    }

    /**
     * 指定匹配
     * price: this.price,
     * number: this.number,
     * id: this.pp.id,
     * ptype1: this.pp.ptype1,
     * ptype2: this.pp.ptype1,
     */
    public function clickbuy()
    {
        $user = UserModel::getUserInfo();
        $params = input();
        extract($params);
        $Buymx = new Buymx();
        $Ppmx = new Ppmx();

        $sale = $Buymx->where(['id' => $id, 'status' => 0])->find();
        if (!$sale) {
            $this->error('订单不存在');
        }
        if ($sale['userid'] ==  $user['id']) {
            $this->error('不能跟自己交易');
        }
        $left = $sale['number'] - $sale['trade_number'];
        if ($number > ($left)) {
            $this->error('对方币数量不足，剩余：' . $left);
        }
        $this->comcheck($user, $params, 'buy');
        unset($params['id']);
        //增加购买记录
        $params['status'] = '5'; // 交易完成
        $Ppmx->buy($params, $user);
        $buyid = $Ppmx->btc_buy_id;
        $buy = $Buymx->where(['id' => $buyid])->find();
        //增加匹配记录
        $dd = $Ppmx->trade($buy['number'], $sale, $buy, '4');
        if ($dd) {
            $saleuser = db('user')->find($sale['userid']);
            $ptype = config('site.cointype');
            $btc = $ptype[$buy['ptype1']];
            //短信通知 
            // sendsms($user['id'], '您正向 ' . $saleuser['nickname'] . ' 购买 ' . $number . $btc . '，总价 ' . $dd['total'] . ' CNY，请及时完成支付并上传凭证。');
            // sendsms($sale['userid'], '您正向 ' . $user['nickname'] . ' 出售 ' . $number . $btc . '，总价 ' . $dd['total'] . ' CNY，确认收款后，请点击”确认收到“按钮完成支付。');
            $this->success('提交成功', $dd);
        } else {
            $this->error('提交失败，请稍后再试');
        }
    }

    /**
     * 指定匹配
     * price: this.price,
     * number: this.number,
     * id: this.pp.id,
     * ptype1: this.pp.ptype1,
     * ptype2: this.pp.ptype1,
     */
    public function clicksale()
    {
        $user = UserModel::getUserInfo();
        $params = input();
        extract($params);
        $Buymx = new Buymx();
        $Ppmx = new Ppmx();

        $buy = $Buymx->where(['id' => $id, 'status' => 0])->find();
        if (!$buy) {
            $this->error('订单不存在');
        }
        if ($buy['userid'] ==  $user['id']) {
            $this->error('不能跟自己交易');
        }
        $left = $buy['number'] - $buy['trade_number'];
        if ($number > ($left)) {
            $this->error('对方币数量不足，剩余：' . $left);
        }
        $this->comcheck($user, $params, 'sale');
        unset($params['id']);

        //增加卖出记录
        $params['status'] = '5'; // 交易完成
        $Ppmx->sale($params, $user);
        $saleid = $Ppmx->btc_sale_id;
        $sale = $Buymx->where(['id' => $saleid])->find();
        //增加匹配记录
        $dd = $Ppmx->trade($sale['number'], $sale, $buy, '5');
        if ($dd) {
            $buyuser = db('user')->find($buy['userid']);
            $ptype = config('site.cointype');
            $btc = $ptype[$buy['ptype1']];
            //短信通知 
            // sendsms($buy['userid'], '您正向 ' . $user['nickname'] . ' 购买 ' . $number . $btc . '，总价 ' . $dd['total'] . ' CNY，请及时完成支付并上传凭证。');
            // sendsms($user['id'], '您正向 ' . $buyuser['nickname'] . ' 出售 ' . $number . $btc . '，总价 ' . $dd['total'] . ' CNY，确认收款后，请点击”确认收到“按钮完成支付。');
            // sendsms($buy['userid'],'您有一笔未支付订单，请及时登录支付并上传凭证。');
            sendsms($buy['userid'],'SMS_196643673','买家');
            $this->success('提交成功', $dd);
        } else {
            $this->error('提交失败，请稍后再试');
        }
    }

    /**
     * 获得买家卖家支付方式
     */
    public function getpayinfo()
    {
        $id = input('id/d');
        if (!$id) {
            $this->error('订单不存在');
        }
        $payinfo = db('user_payment')->where(['user_id' => $id, 'is_default' => 1])->find();
        $this->success('', $payinfo);
    }
    /**
     * 上传凭证
     */
    public function uploadcert()
    {
        $params = $this->request->post();
        $result = $this->validate($params, PpmxValidate::class . '.upload');
        if (true !== $result) {
            return $this->error($result);
        }
        $model = new Ppmx();
        $order = $model::get($params['id']);
        if (!$order) {
            $this->error('订单不存在');
        }
        $params['paytime'] = time();
        $params['status'] = '1';
        $re = $model->allowField(true)->save($params, ['id' => $params['id']]);
        if ($re) {
            //短信通知卖家
            // sendsms($order['userid1'], '买家将订单标记为‘已付款’状态，确认收款后，请点击”确认收到“按钮完成交易。');
            sendsms($order['userid1'], 'SMS_196643680','买家');

            $this->success('上传成功');
        } else {
            $this->error('上传失败');
        }
    }
    /**
     * 投诉
     */
    public function complaint()
    {
        $params = $this->request->post();
        $result = $this->validate($params, PpmxValidate::class . '.complaint');
        if (true !== $result) {
            return $this->error($result);
        }
        $model = new Ppmx();
        $params['tstime'] = time();
        $params['status'] = '4';
        $re = $model->allowField(true)->save($params, ['id' => $params['id']]);
        if ($re) {
            $this->success('提交成功');
        } else {
            $this->error('提交失败');
        }
    }

    /**
     * 用户匹配单
     * ->id
     */
    public function pporder()
    {
        $user = UserModel::getUserInfo();
        $map['id'] = input('id/d', 0);
        $map['userid|userid1'] = $user['id'];
        $pp = Ppmx::where($map)->find();
        $this->success('', $pp);
    }

    /**
     * 卖家确认收货
     * ->id
     */
    public function confirm()
    {
        $ppid = input('id/d', 0);
        $ppmx = new Ppmx();
        Db::startTrans();
        try {
            if ($ppmx->confirm($ppid)) {
                Db::commit();
                $this->success('操作成功');
            } else {
                $this->error('操作失败');
            }
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }
}
