<?php

namespace addons\xshop\controller;

use addons\xshop\model\Message as MessageModel; 
use addons\xshop\model\UserModel;
use addons\xshop\validate\ChargeValidate;
/**
 * 留言板
 */
class Message extends Base
{
    protected $noNeedLogin = ['index'];
    protected $noNeedRight = ['*'];
    
    /**
     * 新增或修改留言信息 
     * title:标题  content:内容  pimg:图片  
     */
    public function add()
    {
        $params = $this->request->post();
        $result = $this->validate($params, ChargeValidate::class . '.msg');
        if (true !== $result) {
            return $this->error($result);
        }
        return $this->success('', MessageModel::edit($params));
    }
    /**
     * 留言列表  
     * @param string page 分页:第一页传1  (需要)
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function list()
    {
        $user = UserModel::getUserInfo();
        $map['user_id'] =$user['id']; 
        $map = array_filter($map);
        $list = MessageModel::where($map)
            // ->field('id,category_id,title,author,images,videoSrc,time,type,weigh')
            ->order('id desc')
            ->paginate(10, false, ['query' => $map]); 
        return $this->success('', $list);
    }
    /**
     * 留言内容 
     * @param string page 分页:第一页传1  (需要)
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function detail()
    {
        $id = input('id/d');
        if (!$id) {
            $this->error('请输入文章id');
        }
        $info = MessageModel::get($id);
        return $this->success('', $info->toArray());
    } 

}
