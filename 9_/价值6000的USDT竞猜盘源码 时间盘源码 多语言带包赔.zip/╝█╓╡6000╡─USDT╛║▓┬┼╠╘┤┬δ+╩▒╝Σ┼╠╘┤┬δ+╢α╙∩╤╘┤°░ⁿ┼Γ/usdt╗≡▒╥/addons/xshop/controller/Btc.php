<?php

namespace addons\xshop\controller;

use addons\xshop\model\Coin;

/**
 * 数字货币
 */
class Btc extends Base
{

    /**
     * 所有行情 
     */
    public function coinlist()
    {
        $maplist = Coin::getList();
        $relist = Coin::relist($maplist);
        if ($relist) {
            return $this->success('', $relist);
        } else {
            return $this->error('');
        }
    }

    /**
     * 行情三联
     */
    public function top3()
    {
        // $maplist = Coin::all('1,7,23,9,10,45'); 
        Coin::updatebinfo2();
        $maplist = Coin::getList2(); 
        $relist = Coin::relist4($maplist);
        
        if ($relist) {
            return $this->success('', $relist);
        } else {
            return $this->error('');
        }
    }

    /**
     * 期权行情
     */
    public function qi()
    {
        // $maplist = Coin::all('1,7,23,9,10,45'); 
        $maplist = Coin::getList2();
        $relist = Coin::relist($maplist);
        if ($relist) {
            return $this->success('', $relist);
        } else {
            return $this->error('');
        }
    }

    /**
     * $binfo
     */
    public function binfo()
    {
        $maplist = Coin::getList();
        $relist = Coin::relist2($maplist);
        if ($relist) {
            return $this->success('', $relist);
        } else {
            return $this->error('');
        }
    }

    /**
     * 更新币信息
     */
    public function updatebinfo()
    {
        for ($i = 0; $i < 5; $i++) {
            Coin::updatebinfo();
            
            sleep(10);
            echo date('H:i:s') . PHP_EOL;
        }
    }

    /**
     * 更新币信息
     */
    public function updatebinfo2()
    {

        Coin::updatebinfo2();
        // return $this->success('',   Coin::updatebinfo2()); 
        $maplist = Coin::getList();
        $binfo = Coin::relist3($maplist);

        return $this->success('', $binfo);
    }

    /**
     * 获取平台币K线行情
     */
    public function bk()
    {
        $type = input('type');
        $gid = input('gid', 1);
        return $this->success('',  Coin::local($type, $gid));
    }

    public function bk_now()
    { 
        $gid = input('gid', 1);
        return $this->success('',  Coin::dayprice($gid));
    }

    public function bk_now2()
    {
        $type = input('type',1);
        $gid = input('gid', 1);
        return $this->success('',  Coin::nowprice($type,$gid));
    }

    
}
