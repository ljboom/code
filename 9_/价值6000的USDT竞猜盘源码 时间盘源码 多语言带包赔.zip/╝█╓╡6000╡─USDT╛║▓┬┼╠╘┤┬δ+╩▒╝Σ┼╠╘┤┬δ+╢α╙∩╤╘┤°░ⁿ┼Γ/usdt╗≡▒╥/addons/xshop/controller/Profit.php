<?php

namespace addons\xshop\controller;
 
use addons\xshop\model\Profit as Profitmodel;
use addons\xshop\validate\TransferValidate;
/**
 *  锁仓
 */
class Profit extends Base
{
    protected $noNeedLogin = ['index'];
    protected $noNeedRight = ['*']; 
     
    /**
     * 申请锁仓
     * @param string level  级别id （1,2,3）
     * @param string ptype1 类型
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function add()
    {
        $params = $this->request->post();
        $result = $this->validate($params, TransferValidate::class . '.profit');
        if (true !== $result) {
            return $this->error($result);
        }
        $re=Profitmodel::add($params);
        $this->success('申请成功',$re);
    } 

     /**
     * 获取锁仓 
     * @ApiHeaders (name=Xshop-Token, type=string, required=true, description="请求的Token")
     */
    public function list()
    { 
        $this->success('',Profitmodel::list());
    } 



}
