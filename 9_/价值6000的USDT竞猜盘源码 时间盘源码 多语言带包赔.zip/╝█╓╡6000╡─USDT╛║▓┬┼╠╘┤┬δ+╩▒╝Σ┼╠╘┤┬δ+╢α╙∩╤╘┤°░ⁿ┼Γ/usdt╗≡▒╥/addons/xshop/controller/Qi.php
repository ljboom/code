<?php

namespace addons\xshop\controller;

use addons\xshop\model\Qxorder;
use addons\xshop\model\UserModel;
use addons\xshop\validate\QiValidate;
use think\Exception;
use think\Db;
use addons\xshop\model\Coin;

/**
 * 期权
 */
class Qi extends Base
{

    protected $noNeedLogin = ['index', 'sim', 'd', 'kk', 'suan', 'ping'];
    protected $noNeedRight = ['*'];


    /**
     * 下单 
     */
    public function submit()
    {
        $params = $this->request->post();
        $result = $this->validate($params, QiValidate::class . '.add');
        if (true !== $result) {
            return $this->error($result);
        }
        Db::startTrans();
        try {
            Qxorder::edit($params);

            Db::commit();
            $this->success('success');
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }


    /**
     * 订单
     */
    public function weituo()
    {

        $user = UserModel::getUserInfo();
        // $data = input();
        // $map = array_filter(['order_state' => $data['order_state']]);
        $map['user_id'] = $user['id'];
        $map['order_state'] = '1';
        $buy = Qxorder::where($map)->order('id desc')->paginate(10, false, ['query' => $map]);
        $this->success('', ['list' => $buy]);
    }

    /**
     * 订单
     */
    public function history()
    {

        $user = UserModel::getUserInfo();
        $data = input();
        if (isset($data['order_sn'])) {
            $map['order_sn'] = $data['order_sn'];
        }
        if (isset($data['sim'])) {
            $map['sim'] = $data['sim'];
        }
        if (isset($data['rank'])) {
            if ($data['rank'] > 0) {
                //亏
                $map['profit'] = ['<', 0];
            } else {
                //盈利
                $map['profit'] = ['>', 0];
            }
        }
        if (isset($data['start']) && isset($data['end'])) {
            if ($data['end'] < $data['start']) {
                $this->error("End time cannot be earlier than start time(结束时间不能小于开始时间)");
            }
            $map['addtime'] = ['between', [strtotime($data['start']), strtotime($data['end']) + 86400]];
        }
        $map['user_id'] = $user['id'];
        $map['order_state'] = '2';
        $buy = Qxorder::where($map)->order('id desc')->paginate(10, false, ['query' => $map]);
        $sum = Qxorder::where($map)->sum('profit');
        $sum2 = Qxorder::where($map)->sum('hand');
        $re['list'] = $buy;
        $re['sum'] = $sum;
        $re['sum2'] = $sum2;
        $this->success('', $re);
        // $this->success('', $buy);
    }


    /**
     * 系统平仓
     */
    public function index()
    {
        for ($i = 0; $i < 5; $i++) {
            $this->pp();
            sleep(20);
            echo date('H:i:s') . PHP_EOL;
        }
    }

    private function pp()
    {
        $cc = md5(time() . 'ping');
        if (cache($cc)) {
            return 1;
        } else {
            cache($cc, 1, 3);
        }
        $map['order_state'] = '1';
        $map['pingtime'] = ['<', time()];
        $orders = Db::name('qx_order')
            ->alias('a')
            ->join('fa_user b', 'a.user_id=b.id')
            ->field('a.*,b.total_real,b.win')
            ->where($map)->select();
        if (!$orders) {
            return '0';
        }
        $myset = config('site');
        $win = isset($myset['qx_win']) ? $myset['qx_win'] : 60;
        $tmp = [];
        $tmp2 = [];
        Db::name('qx_order')->where($map)->setField('order_state', '2');
        Coin::updatebinfo2();
        $maplist = Coin::getList();
        $binfo = Coin::relist3($maplist);
        foreach ($orders as $item) {
            $nowpirce =  $binfo[$item['product_id']]['price'];
            $bouse = 0;
            if ($item['admin'] == '0') {
                if ($item['total_real'] > 0) {
                    //盈概率
                    $winrate = (int)($item['win'] / $item['total_real'] * 100);
                    if ($winrate > $win) {
                        //关
                        $bouse = -$item['hand'];
                        if ($item['rise_fall'] == '1') {

                            if ($nowpirce > $item['price']) {
                                $nowpirce = round($item['price'] - rand(1, 99) / 10000, 4);
                            }
                        } else {
                            if ($nowpirce < $item['price']) {
                                $nowpirce = round($item['price'] + rand(1, 99) / 10000, 4);
                            }
                        }
                    } else {
                        //随机
                        if ($item['rise_fall'] == '1') {
                            if ($nowpirce > $item['price']) {
                                $bouse = $item['rate'] / 100 * $item['hand'];
                            } else {
                                $bouse = -$item['hand'];
                            }
                        } else {
                            if ($nowpirce > $item['price']) {
                                $bouse = -$item['hand'];
                            } else {
                                $bouse = $item['rate'] / 100 * $item['hand'];
                            }
                        }
                    }
                } else {
                    //随机
                    if ($item['rise_fall'] == '1') {
                        if ($nowpirce > $item['price']) {
                            $bouse = $item['rate'] / 100 * $item['hand'];
                        } else {
                            $bouse = -$item['hand'];
                        }
                    } else {
                        if ($nowpirce > $item['price']) {
                            $bouse = -$item['hand'];
                        } else {
                            $bouse = $item['rate'] / 100 * $item['hand'];
                        }
                    }
                }
            } else if ($item['admin'] == '1') {
                //盈
                $bouse = $item['rate'] / 100 * $item['hand'];
                if ($item['rise_fall'] == '1') {

                    if ($nowpirce < $item['price']) {
                        $nowpirce = round($item['price'] + rand(1, 99) / 10000, 4);
                    }
                } else {
                    if ($nowpirce > $item['price']) {
                        $nowpirce = round($item['price'] - rand(1, 99) / 10000, 4);
                    }
                }
            } else {
                //关
                $bouse = -$item['hand'];
                if ($item['rise_fall'] == '1') {

                    if ($nowpirce > $item['price']) {
                        $nowpirce = round($item['price'] - rand(1, 99) / 10000, 4);
                    }
                } else {
                    if ($nowpirce < $item['price']) {
                        $nowpirce = round($item['price'] + rand(1, 99) / 10000, 4);
                    }
                }
            }

            if ($item['sim'] == '1') {
                db('user')->where('id', $item['user_id'])->setInc('total_real', 1);
            }

            if ($item['sim'] == '1' && $bouse > 0) {
                db('user')->where('id', $item['user_id'])->setInc('win', 1);
                //实盘结算
                $tmp2[] = ['user_id' => $item['user_id'], 'profit' => $bouse, 'hand' => $item['hand'], 'order_id' => $item['id']];
            }

            $tmp[] = [
                'id' => $item['id'],
                'sell_price' => $nowpirce,
                // 'pingtime' => time(),
                'order_state' => '2',
                'profit' => $bouse,
            ];
        }
        $re = saveAll($tmp, 'fa_qx_order');
        if ($tmp2) {
            //实盘结算
            foreach ($tmp2 as $key => $value) {
                caiwu($value['user_id'], $value['profit'] + $value['hand'], 14, 'wall1', '普通场期权收益,订单id:' . $value['order_id']);
            }
        }
        return $re;
    }

    /**
     * 系统平仓
     */
    public function ping()
    {
        $re =  $this->pp();
        $this->success('', $re);
        //   $this->success('', 0);
    }

    /**
     * 模拟结算 
     */
    public function sim()
    {
        $map['order_state'] = '2';
        $map['sim'] = '2';
        $map['js'] = 0;
        $myset = config('site');
        $orders = Db::name('qx_order')->where($map)->whereTime('pingtime', 'today')->field('sum(profit) as cha,user_id')->group('user_id')->select();
        if ($orders) {
            foreach ($orders as $item) {
                if ($item['cha'] > 0) {
                    caiwu($item['user_id'], $item['cha'] * $myset['qx_bprate'], 14, 'wall1', '包赔场期权收益');
                }
            }
        }


        $orders2 = Db::name('qx_order')->where($map)->whereTime('pingtime', 'today')->field('sum(hand) as fan,user_id')->group('user_id')->select();
        if ($orders2) {
            foreach ($orders2 as $item) {
                if ($item['fan'] > 0) {
                    caiwu($item['user_id'], $item['fan'], 16, 'wall1', '包赔场返还');
                }
            }
        }

        Db::name('qx_order')->where($map)->whereTime('pingtime', 'today')->setField('js', 1);  //结算状态
        $re['orders'] = $orders;
        $re['orders2'] = $orders2;
        // 普通返结算 
        $this->realback();
        $this->success('', $re);
    }

    /**
     * 普通返结算 
     */
    public function realback()
    {
        $map['order_state'] = '2';
        $map['sim'] = '1';
        $map['js'] = 0;
        $myset = config('site');
        $frate = isset($myset['realback']) ? $myset['realback'] : 0;
        if ($frate) {
            $orders = Db::name('qx_order')->where($map)->whereTime('pingtime', 'today')->field('sum(hand) as cha,user_id')->group('user_id')->select();
            if ($orders) {
                foreach ($orders as $item) {
                    if ($item['cha'] > 0) {
                        caiwu($item['user_id'], $item['cha'] * $frate, 16, 'wall1', '普通场返还');
                    }
                }
            }
            Db::name('qx_order')->where($map)->whereTime('pingtime', 'today')->setField('js', 1);  //结算状态
            $re['orders'] = $orders;
            return 1;
        } else {
            return 1;
        }
    }

    //排序
    private function com_sort($sort, $updatekey)
    {
        $list = db('user')->where($sort, '>', 0)->order($sort)->select();
        $data = [];
        $rule = [
            'S1' => 'B1yest',
            'S2' => 'B2yest',
        ];
        if (!$list) {
            return 1;
        }

        $pai = 1;
        $tmp = 0;
        $sum = 0;
        foreach ($list as $key => $item) {
            if ($item[$sort] > $tmp) {
                $pai =  $key + 1;
            }
            $data[] = ['id' => $item['id'], $updatekey => $pai, 'is_fa' => 1];
            $tmp = $item[$sort];
            $sum += $pai;
        }
        $myset = config('site');
        $fa = $myset['qk_month'];
        $yue = $myset['qk_date'];
        $rate = $myset['qk_rate'];
        $w = (int) ($fa * $rate ** ($yue - 1)) / 30;
        if ($data) {
            foreach ($data as $key => $item) {
                $data[$key][$rule[$updatekey]] = round($item[$updatekey] / $sum * $w / 2, 4);
            }
        }
        saveAll($data, 'fa_user');
        $re['data'] = $data;
        $re['sum'] = $sum;


        return $re;
    }

    /**
     * 挖矿结算 1
     */
    public function d()
    {
        $pass = input();
        if ($pass !== 'fe32d21111111ssssss3') {
            $myset = config('site');
            $times = $myset['qx_limit'];   //模拟场每日参与次数
            db()->execute("update fa_user set kzwall2=wall2,kzwall3=wall3,kzgryj=gryj,B1yest=0,B2yest=0,B3yest=0,S1=0,S2=0,times=" . $times . ";");

            $re['a'] =  $this->com_sort('wall3', 'S1');    //持币 
            $re['b'] = $this->com_sort('gryj', 'S2');      //交易 
            $re['c'] = $this->suan();                      //推广 
            $this->kk();    //挖矿结算 
            $this->success('', $re);
        }
    }

    /**
     * 挖矿结算 
     */
    private function kk()
    {
        $list = db('user')->where('is_fa=1')->select();
        if (!$list) {
            return 1;
        }
        foreach ($list as $key => $item) {

            if ($item['B1yest'] > 0) {
                caiwu($item['id'], $item['B1yest'], 8, 'wall2', '持币挖矿收益');
            }
            if ($item['B2yest'] > 0) {
                caiwu($item['id'], $item['B2yest'], 13, 'wall2', '交易挖矿收益');
            }
            if ($item['B3yest'] > 0) {
                caiwu($item['id'], $item['B3yest'], 3, 'wall2', '推广算力收益');
            }

            $data[] = [
                'id' => $item['id'],
                'B1total' => $item['B1total'] + $item['B1yest'],
                'B2total' => $item['B2total'] + $item['B2yest'],
                'B3total' => $item['B3total'] + $item['B3yest'],
                'is_fa' => 0
            ];
        }
        saveAll($data, 'fa_user');
        $this->success('', $data);
    }

    //算力统计
    public function suan()
    {

        $list = db('user')->where('ztnum', '>', 0)->select();
        $sum = 0;
        $data = [];
        foreach ($list as $key => $vo) {
            $uid = $vo['id'];
            $suan = 0;
            $xia_map['tjid'] = $uid;
            $xia_map['wall2'] = ['>', 0];
            $xia = db('user')->where($xia_map)->order('wall2 desc')->select(); //直推下级
            if ($xia) {
                foreach ($xia as $key => $item) {
                    $base = (float)$item['wall2'];
                    if ($key == 0) {
                        $suan +=  sqrt($base);
                    } else {
                        if ($base <= 10000) {
                            $suan += $base * 10;
                        } else {
                            $suan += 90000 + $base;
                        }
                    }
                }
            }
            $sum += $suan;
            $data[] = ['id' => $vo['id'], 'suan' => $suan, 'is_fa' => 1];
        }

        $myset = config('site');
        $fa = $myset['qk_month'];
        $yue = $myset['qk_date'];
        $rate = $myset['qk_rate'];
        $w = (int) ($fa * $rate ** ($yue - 1)) / 30;
        if ($data) {
            foreach ($data as $key => $item) {
                $data[$key]['B3yest'] = round($item['suan'] / $sum * $w / 2, 4);
            }
            saveAll($data, 'fa_user');
        }
        return $data;
    }
}
