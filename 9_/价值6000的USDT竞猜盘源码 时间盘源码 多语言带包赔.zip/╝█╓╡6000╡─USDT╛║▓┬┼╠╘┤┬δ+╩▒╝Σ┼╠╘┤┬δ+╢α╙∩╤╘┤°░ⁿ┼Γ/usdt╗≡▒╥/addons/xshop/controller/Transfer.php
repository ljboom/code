<?php

namespace addons\xshop\controller;

use addons\xshop\model\UserModel;
use addons\xshop\library\Tcl;
use addons\xshop\validate\TransferValidate;

/**
 * 划转
 */
class Transfer extends Base
{
    protected $noNeedLogin = ['index'];
    protected $noNeedRight = ['*'];

    /**
     * 获取其他平台数据
     */
    public function getUserBj()
    {
        $user = UserModel::getUserInfo();
        $data = ['mobile' => $user['mobile']];
        $app = new Tcl($data);
        $re = $app->getUserBj();
        $this->success('', $re);
    }

    /**
     * 跨平台划转 
     */
    public function app2coin()
    {

        $data = input();
        $cc = md5(serialize($data));
        if (cache($cc)) {
            $this->error('请稍后再提交');
        } else {
            cache($cc, 1,5); 
        }

        $rule = config('site.app2app');
        $type1 = input('type1', 0);
        $type2 = input('type2', 0);
        $nums = input('nums', 0);
        $app1 = array_search($type1, $rule);
        $wall1 = 0;
        $user = UserModel::getUserInfo();
        $app = new Tcl(['mobile' => $user['mobile'], 'amount' => $nums]);
        if ($app1 == 'a') {
            //外平台 查询金额    
            $re = $app->getUserBj();
            if ($re->status == 1) {
                $wall1 = $re->data->BjNum;
            } else {
                $this->error($re->message);
            }
            if ($wall1 < $nums) {
                $this->error('金额不足');
            }
            //减少外平台金额
            $re2 = $app->subUserBj();
            if ($re2->status == 1) {
                 //增加本平台金额
                 caiwu($user['id'], $nums, 10, 'wall7', $rule['a'] . '划转' .  $rule['b']);
                 return $this->success('划转成功');
            } else {
                $this->error($re2->message);
            } 
           
        } else {
            $wall1 = $user['wall7'];
            if ($wall1 < $nums) {
                $this->error('金额不足');
            }
            //增加外平台金额
            $re = $app->addUserBj();
            if ($re->status == 1) {
                 //减少本平台金额
                 caiwu($user['id'], -$nums, 10, 'wall7', $rule['b'] . '划转' .  $rule['a']);
                 return $this->success('划转成功');
            } else {
                $this->error($re->message);
            } 
        }
    }
    /**
     * 划转 
     */
    public function coin2coin()
    {

        $rule = config('site.transfers');
        $feerule = config('site.tranfee');
        $type1 = input('type1', 0);
        $type2 = input('type2', 0);
        $nums = input('nums', 0);
        if ($type1 == $type2) {
            $this->error('Same currency cannot be transferred(相同币种不可划转)');
        }
        $coin1 = array_search($type1, $rule);
        $coin2 = array_search($type2, $rule);
        if (!$coin1 || !$coin2) {
            $this->error('Wallet type does not exist(钱包类型不存在)');
        }
        $user = UserModel::getUserInfo();
        if ($user[$type1] < $nums) {
            $this->error('Insufficient account (金额不足)');
        }
        $rate = input($coin1 . '2' . $coin2, 1);
        $fee = isset($feerule[$type1]) ? $feerule[$type1] : 0;
        if ($fee > 0) {
            $fee = $fee * $nums;
            $nums = $nums - $fee;
            caiwu($user['id'], -$fee, 10, $type1, $coin1 . '划转' . $coin2 . '手续费');
        }

        caiwu($user['id'], $nums * $rate, 10, $type2, $coin1 . '划转' . $coin2);
        if (caiwu($user['id'], -$nums, 10, $type1, $coin1 . '划转' . $coin2)) {
            return $this->success('success');
        } else {
            return $this->error('Failure');
        }
    }

    /**
     * 本平台账号互转
     */
    public function user2user(){
        $params = $this->request->post();
        $result = $this->validate($params, TransferValidate::class . '.user2user');
        if (true !== $result) {
            return $this->error($result);
        }
        $user = UserModel::getUserInfo();
        if ($user[$params['ptype1']] < $params['number']) {
            $this->error('金额不足');
        }
        if($user['mobile']== $params['mobile']){
            $this->error('不能跟自己转账');
        }
        $touser = db('user')->where('mobile', $params['mobile'])->find();
        caiwu($touser['id'], $params['number'], 10,$params['ptype1'], '收到'.$user['username'].'转账');
        if (caiwu($user['id'], -$params['number'], 10, $params['ptype1'],  '转账给'.$touser['username'])) {
            return $this->success('划转成功');
        } else {
            return $this->error('划转失败');
        }

    }
}
