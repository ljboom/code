<?php

namespace addons\xshop\model;

use think\Model;


class Words extends Model
{

    

    

    // 表名
    protected $name = 'words';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    

    protected static function init()
    {
        self::afterInsert(function ($row) {
            $pk = $row->getPk();
            $row->getQuery()->where($pk, $row[$pk])->update(['weigh' => $row[$pk]]);
        });
    }

    public static function getList($key,$limit=3)
    { 
        $list=self::where('keyword','like', '%'.$key.'%')->order('weigh', 'DESC')->limit($limit)->select();
        if($list){
            foreach($list as $key=>$item){
                $re[]=[
                    'id'=> $key,
						'uid'=> 0,
						'username'=>"专家",
						// face: "/static/img/face.jpg",
						// time: "12:56",
						'type'=> $item['type'],
						'msg'=> ['content'=>$item['content'],'url'=>$item['image']]
						 
                ];
            }
        }
        return $re;
    }

    







}
