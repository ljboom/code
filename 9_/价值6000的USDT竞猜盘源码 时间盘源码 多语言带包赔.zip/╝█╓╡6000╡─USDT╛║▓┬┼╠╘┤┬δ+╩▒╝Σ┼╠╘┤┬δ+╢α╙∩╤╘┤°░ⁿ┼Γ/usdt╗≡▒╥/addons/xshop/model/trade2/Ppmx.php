<?php

namespace addons\xshop\model\trade2;

use think\Model;
use think\Exception;
use addons\xshop\model\trade2\Buymx;


class Ppmx extends Model
{


    // 表名
    protected $name = 'trade2_ppmx';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'addtime_text',
        'paytime_text',
        'confirmtime_text',
        'tstime_text',
        'type_text',
        'status_text',
        'ptype1_text',
        'ptype2_text'
    ];



    public function getTypeList()
    {
        return ['4' => '买入', '5' => '卖出'];
    }

    public function getStatusList()
    {
        // 0=待打款,1=已付款,2=已完成,3=已取消,4=投诉
        return ['0' => '待打款', '1' => '已付款', '2' => '已完成', '3' => '已取消', '4' => '投诉'];
    }

    public function getPtype1List()
    {
        return config('site.cointype');
    }

    public function getPtype2List()
    {
        return config('site.cointype');
    }


    public function getAddtimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['addtime']) ? $data['addtime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getPaytimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['paytime']) ? $data['paytime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getConfirmtimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['confirmtime']) ? $data['confirmtime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getTstimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['tstime']) ? $data['tstime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['type']) ? $data['type'] : '');
        $list = $this->getTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getPtype1TextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['ptype1']) ? $data['ptype1'] : '');
        $list = $this->getPtype1List();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getPtype2TextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['ptype2']) ? $data['ptype2'] : '');
        $list = $this->getPtype2List();
        return isset($list[$value]) ? $list[$value] : '';
    }

    protected function setAddtimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setPaytimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setConfirmtimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setTstimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }





    protected $cstate = [
        'sale' => 4,
        'buy' => 5,
        'cancle' => 6,
        'trade' => 7,
    ];

    protected $ptype1 = 'wall2';  //卖出类型
    protected $ptype2 = 'wall1';  //买入类型

    /**
     * 卖BTC
     * @param $btc
     * @param $cny
     * @param $fee
     * @return bool
     */
    function sale($params, $user = array())
    {

        extract($params);
        if (!isset($user['id'])) {
            throw new Exception('用户不存在');
        }
        $this->ptype1 = $ptype1;
        $this->ptype2 = $ptype2;
        //交易额
        $trade = $number;
        //手续费
        $rule = config('site.vip_c2c_sale_fee');
        $rate= isset( $rule[$user['level']]) ? $rule[$user['level']] : 0;
        $fee = round($rate * $trade, 2);
        if ($fee > 0) {
            caiwu($user['id'], -$fee, $this->cstate['sale'], $ptype1, "卖出手续费", 1);
            $trade = $trade - $fee;
        }
        //减少余额
        caiwu($user['id'], -$trade, $this->cstate['sale'], $ptype1, '委托卖出', 1);

        //增加销售记录
        $Buy = new Buymx();
        $params['number'] = $trade;
        $params['type'] = '5';
        $params['fee'] = $fee;
        $params['addtime'] = time();
        $params['total'] = round($price * $trade, 2);
        $params['userid'] = $user['id'];
        $params['account'] = $user['username'];
        $Buy->data($params);
        $Buy->allowField(true)->save();
        $this->btc_sale_id = $Buy->id;
        return $Buy->id;
    }

    /**
     * 买BTC
     * @param $btc
     * @param $cny
     * @param $fee
     * @return bool
     */
    function buy($params, $user = array())
    {
        extract($params);
        if (!isset($user['id'])) {
            throw new Exception('用户不存在');
        }
        $this->ptype1 = $ptype1;
        $this->ptype2 = $ptype2;
        //减少余额
        // caiwu($user['id'], -$btc * $cny, $this->cstate['buy'], $ptype2, '委托买入',1);
        //扣除手续费
        // if ($fee > 0) caiwu($user['id'], -$fee, 4, $ptype, "买入手续费"); //放到交易
        //增加购买记录
        $Buy = new Buymx();
        $params['type'] = '4';
        // $params['fee']=$fee;
        $params['addtime'] = time();
        $params['total'] = round($price * $number, 2);
        $params['userid'] = $user['id'];
        $params['account'] = $user['username'];
        $Buy->data($params);
        $Buy->allowField(true)->save();
        $this->btc_buy_id = $Buy->id;
        return $Buy->id;
    }


    //撤销卖单
    function cancelSaleOrder($uid, $id)
    {
        $one = Buymx::get($id);
        //剩余 btc
        $left = $one['number'] - $one['trade_number'];
        if ($one['userid'] != $uid) {
            throw new Exception('用户不存在');
        }
        if ($one['status'] == 3) {
            throw new Exception('已经撤单');
        }
        if ($left <= 0) {
            throw new Exception('已经成交完');
        }
        $data['status'] = 3;
        caiwu($uid, $left, $this->cstate['cancle'], $one['ptype1'], '撤销卖单', 1);

        //手续费 
        $fee = $left / $one['number'] * $one['fee'];
        if ($fee > 0) {
            caiwu($uid, $fee, $this->cstate['cancle'], $one['ptype1'], "撤销卖单手续费退回", 1);
        }

        return  $one->data(['status' => 3])->save();
        // $myset = config('site');
        // $fee = ceil($left * $myset['salefee'] * 0.01); 
        // if ($fee > 0) caiwu($uid, $fee, 6, 'wall2', '撤销卖单手续费退回', 1); 
    }

    //撤销买单
    function cancelBuyOrder($uid, $id)
    {
        $one = Buymx::get($id);
        //剩余 btc
        $left = $one['number'] - $one['trade_number'];
        if ($one['userid'] != $uid) {
            throw new Exception('用户不存在');
        }
        if ($one['status'] == 3) {
            throw new Exception('已经撤单');
        }
        if ($left <= 0) {
            throw new Exception('已经成交完');
        }
        $data['status'] = 3;
        // caiwu($uid, $left * $one['price'], $this->cstate['cancle'], $one['ptype2'], '撤销买单', 1);

        return  $one->data(['status' => 3])->save();
    }

    //找到卖价交易 挂单 buy的时候执行 
    /**
     * @param $btc_buy_id
     * @return bool
     */
    function findSale($btc_buy_id)
    {
        $buy = Buymx::get($btc_buy_id);
        //找到卖价不高于买家最低的
        $map['status'] = '0';
        $map['userid'] = ['neq', $buy['userid']];
        $map['price'] = array('elt', $buy['price']);
        $map['ptype1'] = $this->ptype1;
        $map['ptype2'] = $this->ptype2;
        $map['type'] = '5';
        $sale = Buymx::where($map)->find();
        if (!$sale) {
            return false;
        }
        //还要买的量  
        $leftBuy = $buy['number'] - $buy['trade_number'];
        //还要卖的量
        $leftSale = $sale['number'] - $sale['trade_number'];
        //交易数量
        $number = min($leftSale, $leftBuy);
        if (!$number) {
            return false;
        }
        $this->trade($number, $sale, $buy, 4);
        if ($leftBuy - $number > 0) {
            $this->findSale($btc_buy_id);
        }
    }

    //找到买家 挂单sale时候执行
    function findBuy($btc_sale_id)
    {
        $sale = Buymx::get($btc_sale_id);
        //找到买价高于卖价最高的
        $map['status'] = '0';
        $map['userid'] = ['neq', $sale['userid']];
        $map['price'] = array('egt', $sale['price']);
        $map['ptype1'] = $this->ptype1;
        $map['ptype2'] = $this->ptype2;
        $map['type'] = '4';
        $buy = Buymx::where($map)->find();
        if (!$buy) {
            return false;
        }
        //还要买的量  
        $leftBuy = $buy['number'] - $buy['trade_number'];
        //还要卖的量
        $leftSale = $sale['number'] - $sale['trade_number'];
        //交易数量
        $number = min($leftSale, $leftBuy);
        if (!$number) {
            return false;
        }
        $this->trade($number, $sale, $buy, 5);
        if ($leftSale - $number > 0) {
            $this->findBuy($btc_sale_id);
        }
    }

    /**
     * 交易
     * @param $number
     * @param $sale
     * @param $buy
     * @param $type
     * @return bool
     * @throws \think\exception\PDOException
     */
    function trade($number, $sale, $buy, $type)
    {
        $sale_id = (int) $sale['userid'];
        $buy_id = (int) $buy['userid'];
        Buymx::where(array('id' => $sale['id']))->setInc('trade_number', $number);
        Buymx::where(array('id' => $buy['id']))->setInc('trade_number', $number);
        //记录
        $data['status'] = 0;   //待打款
        $data['tgid'] = $buy['id'];
        $data['xyid'] = $sale['id'];
        $data['account'] = $buy['account'];
        $data['account1'] = $sale['account'];
        $data['userid'] = $buy_id;
        $data['userid1'] = $sale_id;
        $data['type'] = $type;
        $data['price'] = $buy['price'];
        $data['number'] = $number;
        $data['total'] = round($number * $buy['price'], 2);
        $data['addtime'] = time();
        $data['ptype1'] = $buy['ptype1'];
        $data['ptype2'] = $buy['ptype2'];
        $this->data($data)->save();
        //短信通知
        //            smscode($buy_id, 1, $buy['account']);
        //            smscode($sale_id, 1, $sale['account']); 
        //线上交易结算
        // caiwu($buy_id, $number, $this->cstate['trade'], $buy['ptype1'], '购买' . $number . $buy['ptype1_text']);

        // Buymx::where('id', $buy['id'])->update(['deal' =>  $data['price']]);
        // Buymx::where('id', $sale['id'])->update(['deal' =>  $data['price']]); 

        //判断买卖状态
        if ($sale['number'] == $number + $sale['trade_number']) {
            Buymx::where('id', $sale['id'])->update(['status' => '5']);
        }
        if ($buy['number'] == $number + $buy['trade_number']) {
            Buymx::where('id', $buy['id'])->update(['status' => '5']);
        }
        $data['id'] = $this->id;
        return $data;
    }


    //手动匹配

    /**
     * @param $btc_buy_id
     * @return bool
     */
    function findSale2($buy_id, $sale_id, $number)
    {
        $buy =  Buymx::get($buy_id);
        $sale = Buymx::get($sale_id);
        //还要买的量
        $leftBuy = $buy['number'] - $buy['trade_number'];
        //还要卖的量
        $leftSale = $sale['number'] - $sale['trade_number'];
        //交易数量
        $num = min($leftSale, $leftBuy);
        if ($number == 0 || $number > $num) {
            return false;
        }
        return $this->trade($number, $sale, $buy, 4);
    }

    /**
     * 卖家确认收货
     * $ppid 匹配id
     */
    function confirm($ppid)
    {
        $map['id'] = $ppid;
        $map['status'] = ['in', '1,4'];
        $pp = self::where($map)->find();
        if (!$pp) {
            throw new Exception('订单不存在或已经确认');
        }
        $buy_uid = $pp['userid'];
        $sale_uid = $pp['userid1'];
        // $saleuser=db('user')->find($sale_uid); //卖家 
        $buyuser = db('user')->find($buy_uid);  //买家 

        //增加买家币量
        caiwu($buy_uid, $pp['number'], 5, $pp['ptype1'], 'C2C购买');
        //增加卖家卖出
        Buymx::where('id', $pp['xyid'])->setInc('deal', $pp['number']);
        $sale = Buymx::where('id', $pp['xyid'])->find();
        //减少卖家冻结
        $salefee = $pp['number'] / $sale['number'] * $sale['fee'];
        $freesale = $pp['number'] + $salefee;
        db('user')->where('id', $sale_uid)->setDec($pp['ptype1'] . 'freeze', $freesale);
        if ($buyuser['level'] > 1 && $salefee > 0) {
            //商户买入分红 获得手续费奖励
            caiwu($buy_uid, $salefee, 3, $pp['ptype1'], 'C2C交易商户买入奖励分红');
        }
        //短信通知买家
        sendsms($buy_uid, 'SMS_197435077', '卖家');

        return $pp->data(['status' => '2'])->save();
    }

    /**
     * 撤销匹配 
     */
    function cancelpp($id)
    {
        $PP = Ppmx::get($id);
        $sale = Buymx::get($PP['xyid']);
        $buy = Buymx::get($PP['tgid']);
        //交易数量
        $left = $PP['number'];

        if ($PP['status'] == 3) {
            throw new Exception('已经撤单');
        }
        // if ($sale['status'] == 3) {
        //     throw new Exception('已经撤单');
        // }
        if ($buy['status'] == 0) {
            $buy->data(['trade_number' => $buy['trade_number'] - $left])->save();
        }

        caiwu($PP['userid1'], $left, $this->cstate['cancle'], $sale['ptype1'], '撤销匹配', 1);
        //手续费

        $fee =  round($left / $sale['number'] * $sale['fee'], 2);
        if ($fee > 0) {
            caiwu($PP['userid1'],  $fee, $this->cstate['cancle'], $sale['ptype1'], "撤销匹配手续费退回", 1);
        }

        // if ($sale['number'] == $sale['trade_number']) {
        //     caiwu($PP['userid1'], $left, $this->cstate['cancle'], $sale['ptype1'], '撤销匹配', 1);
        //     $sale->data(['status' => 3])->save();
        // } else {
        //     $sale->data(['trade_number' => $sale['trade_number'] - $left])->save();
        // }
        // if ($buy['number'] == $buy['trade_number']) {
        //     $buy->data(['status' => 3])->save();
        // } else {
        //     $buy->data(['trade_number' => $buy['trade_number'] - $left])->save();
        // }

        return  $PP->data(['status' => 3])->save();
    }
}
