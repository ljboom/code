<?php

namespace addons\xshop\model;

use app\common\library\Auth;
use app\common\library\Sms;
use app\common\library\Ems;
use addons\xshop\exception\Exception;
use addons\xshop\exception\NotFoundExceptionException;

class UserModel extends Model
{
    protected $name = "user";
    protected $visible = [
        'username', 'nickname', 'avatar', 'mobile', 'ztnum', 'tdnum', 'tdyj', 'todayzt', 'level', 'id','gryj','kzgryj'
    ];
    protected $append = [
        'avatar', 'level_text'
    ];

    public function getLevelTextAttr($value, $data)
    {
        $vip_level = config('site.vip_level');
        return $vip_level[$data['level']];
    }

    public static function info()
    {
        return Auth::instance();
    }

    public static function getUserInfo()
    {
        $userinfo = self::info()->getUserInfo();
        if (empty($userinfo['avatar'])) $userinfo['avatar'] = letter_avatar($userinfo['nickname']);
        $userinfo['avatar'] = cdnurl($userinfo['avatar'], true);
        return $userinfo;
    }

    /**
     * 编辑用户资料
     */
    public static function editInfo($attributes)
    {
        $user = self::info();
        $allowEditFields = ['password', 'password2', 'nickname', 'avatar', 'imtoken', 'mobile', 'email', 'realname', 'idcard', 'card1', 'card2', 'card3', 'is_sm'];
        $data = [];
        foreach ($attributes as $k => $v) {
            if (in_array($k, $allowEditFields)) $data[$k] = $v;
        }
        if (empty($data)) throw new Exception("Without any modification(没有任何修改)");
        $userModel = $user->getUser();
        foreach ($data as $k => $v) {
            switch ($k) {
                case 'mobile': {
                        if ($attributes['mobile'] != $user->mobile) {
                            if (!Sms::check($attributes['mobile'], $attributes['code'], 'editinfo')) {
                                throw new Exception("Wrong verification code(验证码错误)");
                            }
                            if (empty($v)) throw new Exception("手机不能为空");

                            if (self::getByMobile($attributes['mobile'])) {
                                throw new Exception("Mobile phone already exists(手机已存在)");
                                return false;
                            }
                            $userModel->$k = $v;
                        }

                        break;
                    }
                case 'email': {
                        if ($attributes['email'] != $user->email) {
                            if (!Ems::check($attributes['email'], $attributes['code'], 'editinfo')) {
                                throw new Exception("Wrong verification code(验证码错误)");
                            }
                            if (empty($v)) throw new Exception("Mailbox cannot be empty(邮箱不能为空)");

                            if (self::getByEmail($attributes['email'])) {
                                throw new Exception("Mailbox already exists(邮箱已存在)");
                                return false;
                            }

                            $userModel->$k = $v;
                        }
                        break;
                    }
                case 'password': {
                        // if (!Sms::check($attributes['mobile'], $attributes['code'], 'editinfo')) {
                        //    throw new Exception("Wrong verification code(验证码错误)");
                        // }
                        if (!Ems::check($attributes['email'], $attributes['code'], 'editinfo')) {
                            throw new Exception("Wrong verification code(验证码错误)");
                        }
                        if (empty($v)) throw new Exception("Password cannot be empty(密码不能为空)");
                        $userData = $userModel->getData();
                        $userModel->$k = $user->getEncryptPassword($v, $userData['salt']);
                        break;
                    }
                case 'password2': {
                        // if (!Sms::check($attributes['mobile'], $attributes['code'], 'editinfo')) {
                        //    throw new Exception("Wrong verification code(验证码错误)");
                        // }
                        if (!Ems::check($attributes['email'], $attributes['code'], 'editinfo')) {
                            throw new Exception("Wrong verification code(验证码错误)");
                        }
                        if (empty($v)) throw new Exception("密码不能为空");
                        $userData = $userModel->getData();
                        $userModel->$k = $user->getEncryptPassword($v, $userData['salt']);
                        break;
                    }
                default: {
                        // if (empty($v)) throw new Exception("昵称不能为空");
                        $userModel->$k = $v;
                        break;
                    }
            }
        }
        $userModel->save();
        return self::getUserInfo();
    }

    /**
     * 检查支付密码
     */
    public static function checkpass($password2)
    {
        $user = self::info();
        $userModel = $user->getUser();
        $userData = $userModel->getData();
        if ($userData['password2'] != $user->getEncryptPassword($password2, $userData['salt'])) {
            throw new Exception("Incorrect password(密码不正确)");
        }
        return true;
    }


    /**
     * 手机验证码注册或登录
     */
    public static function registerOrLogin($attributes)
    {
        extract($attributes);
        if (!config('site.base_reg_mobile')) {
            throw new Exception("mobile reg closed");
        }
        if ($code == 'AKAK') {
            //'用户同步';
            $attributes['is_b'] = 1;
        } else {
            if (!Sms::check($mobile, $code, 'register')) {
                throw new Exception("Wrong verification code(验证码错误)");
            }
        }

        $auth = Auth::instance();
        $user = self::where('mobile', $mobile)->find();
        if (empty($user)) { // 注册

            if ($auth->register($mobile, $password, '', $mobile, $attributes)) {
                $payload = [
                    'user' => $auth->getUser()
                ];
                \think\Hook::listen('xshop_user_register_successed', $payload);
                $auth->direct($auth->id);
                return self::getUserInfo();
            } else {
                throw new Exception($auth->getError());
            }
        } else { // 登录
            if ($user['switch'] == 1) {
                $auth->direct($user->id);
                return self::getUserInfo();
            } else {
                throw new Exception("Account freeze(账户冻结)");
            }
        }
    }

    /**
     * 邮箱验证码注册或登录
     */
    public static function registerOrLogin2($attributes)
    {
        extract($attributes);
        if (!config('site.base_reg_email')) {
            throw new Exception("email reg closed");
        }
        if ($code == 'AKAK') {
            //'用户同步';
            $attributes['is_b'] = 1;
        } else {
            if (!Ems::check($email, $code, 'register')) {
                throw new Exception("Wrong verification code(验证码错误)");
            }
        }

        $auth = Auth::instance();
        $user = self::where('email', $email)->find();
        if (empty($user)) { // 注册

            if ($auth->register($email, $password, $email, '', $attributes)) {
                $payload = [
                    'user' => $auth->getUser()
                ];
                \think\Hook::listen('xshop_user_register_successed', $payload);
                $auth->direct($auth->id);
                return self::getUserInfo();
            } else {
                throw new Exception($auth->getError());
            }
        } else { // 登录
            if ($user['switch'] == 1) {
                $auth->direct($user->id);
                return self::getUserInfo();
            } else {
                throw new Exception("Account freeze(账户冻结)");
            }
        }
    }

    /**
     * 账号注册或登录
     */
    public static function registerOrLogin3($attributes)
    {
        extract($attributes);  
        $auth = Auth::instance();
        $user = self::where('username', $username)->find();
        if (empty($user)) { // 注册

            if ($auth->register($username, $password, '', '', $attributes)) {
                $payload = [
                    'user' => $auth->getUser()
                ];
                \think\Hook::listen('xshop_user_register_successed', $payload);
                $auth->direct($auth->id);
                return self::getUserInfo();
            } else {
                throw new Exception($auth->getError());
            }
        } else { 
            throw new Exception("Account already in existence(账户已存在)");
        }
    }

    /**
     * 重置密码
     */
    public static function reset($attributes)
    {
        extract($attributes);
        $username = null;
        if ($code == 'AKAK') {
            //'用户同步';
            $attributes['is_b'] = 1;
        } else {
            if (isset($mobile)) {
                if (!Sms::check($mobile, $code, 'reset')) {
                    throw new Exception("Wrong verification code(验证码错误)");
                }
                $username = $mobile;
            }

            if (isset($email)) {
                if (!Ems::check($email, $code, 'reset')) {
                    throw new Exception("Wrong verification code(验证码错误)");
                }
                $username = $email;
            }
        }
        if (!$username) {
            throw new Exception("Account number does not exist(账户不存在)");
        }
        $auth = Auth::instance();
        $userData = self::where('mobile|email', $username)->find();
        if (empty($userData)) {
            throw new Exception("Account number does not exist(账户不存在)");
        } else { // 更新信息 
            $password =  self::info()->getEncryptPassword($password, $userData['salt']);
            if (self::where('mobile|email', $username)->update(['password' => $password])) {
                $auth->direct($userData['id']);
                return self::getUserInfo();
            } else {
                throw new Exception("Password has been reset(密码已重置)");
            }
        }
    }

    /**
     * 自动升级
     * @param int $pid 上级ID
     */
    public static function upgradeLevel($pid)
    {
        $myset = config('site');
        $rule_yj = $myset['vip_yj'];
        $rule_team = $myset['vip_team'];
        $vip_cang = $myset['vip_cang'];
        $user = self::where('id', $pid)->find();
        $currentLevel = $user['level'];
        $nextLevel  = $currentLevel + 1;
        $directCount = self::where('tjid', $pid)->where('level', $currentLevel)->count();
        // if ($directCount >= $rule_team[$nextLevel] && $user['gryj'] >= $rule_yj[$nextLevel] && $user['wall2'] >= $vip_cang[$nextLevel]) {
           
        if (isset($vip_cang[$nextLevel]) &&$directCount >= $rule_team[$nextLevel] && $user['tdyj'] >= $rule_yj[$nextLevel] && $user['ztnum'] >= $vip_cang[$nextLevel]) {
            self::where('id', $pid)->update(['level' => $nextLevel]);
        }
        return 1;
    }

    public function getAvatarAttr($value, $data)
    {
        if (empty($value)) {
            return letter_avatar($data['nickname']);
        }
        return cdnurl($value, true);
    }
}
