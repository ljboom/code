<?php

namespace addons\xshop\model;

use think\Model;
use addons\xshop\exception\Exception;


class Qxorder extends Model
{

    //期权  
    // 表名
    protected $name = 'qx_order';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'addtime_text',
        'pingtime_text',
        'sim_text',
        'rise_fall_text',
        'order_state_text',
    ];



    public function getSimList()
    {
        return ['1' => '实盘', '2' => '模拟'];
    }

    public function getRiseFallList()
    {
        return ['1' => '买涨', '2' => '买跌'];
    }

    public function getOrderStateList()
    {
        return ['1' => '持仓', '2' => '平仓'];
    }

    // public function getAdminList()
    // {
    //     return ['0' => '0','1' => '1', '2' => '2'];
    // }


    public function getAddtimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['addtime']) ? $data['addtime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getPingtimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['pingtime']) ? $data['pingtime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getSimTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['sim']) ? $data['sim'] : '');
        $list = $this->getSimList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getRiseFallTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['rise_fall']) ? $data['rise_fall'] : '');
        $list = $this->getRiseFallList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getOrderStateTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['order_state']) ? $data['order_state'] : '');
        $list = $this->getOrderStateList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    // public function getAdminTextAttr($value, $data)
    // {
    //     $value = $value ? $value : (isset($data['admin']) ? $data['admin'] : '');
    //     $list = $this->getAdminList();
    //     return isset($list[$value]) ? $list[$value] : '';
    // }

    protected function setAddtimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setPingtimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }


    public function user()
    {
        return $this->belongsTo('app\admin\model\User', 'user_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }

    public static function edit($attributes)
    {
        extract($attributes);
        $user = UserModel::info();
        $myset = config('site');

        $attributes['user_id'] = $user->id;
        $attributes['addtime'] = time();
        $attributes['pingtime'] = time() + $time * 60;
        $attributes['sec'] = $time * 60;
        $attributes['deposit'] = $hand;
        $attributes['rate'] = $myset['qx_rate'][$time];
        $attributes['order_sn'] =date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
 
        if ($hand > $user->wall1) {
            throw new Exception("Insufficient balance(余额不足)");
        }
        if ($sim == '2') {
            //模拟 
            if (date('H:i:s') < $myset['qx_open'] || date('H:i:s') >= $myset['qx_end']) {
                throw new Exception("Open time(开放时间){$myset['qx_open']}--{$myset['qx_end']}");
            }
            if ($user->times < 1) {
                throw new Exception("There are not enough times today(今日次数不足)");
            }
            if ($hand < $myset['qx_min_sim']) {
                throw new Exception("Minimum order amount(最低下单金额)".$myset['qx_min_sim']);
            }
        }else{
            if(isset($myset['qx_real_start'])){
                if (date('H:i:s') < $myset['qx_real_start'] || date('H:i:s') >= $myset['qx_real_end']) {
                    throw new Exception("Open time(开放时间){$myset['qx_real_start']}--{$myset['qx_real_end']}");
                }
            }
            
            if ($hand < $myset['qx_min_real']) {
                throw new Exception("Minimum order amount(最低下单金额)".$myset['qx_min_real']);
            }
        }
        
        $count = db('qx_order')->where([
            'user_id' => $user->id,
            'order_state' => '1',
            'product_id' =>  $product_id,
        ])->count();
        if ($count > 0) {
            throw new Exception("You have unfinished orders, please operate later(您有未完成订单，请稍后再操作)");
        }

        $rule=$myset['qx_risk'];
        
        $max=0;
        foreach ($rule as $key => $value) {
           if($user->wall1<$key){ 
               $max=$value;
                break;
           }
           $max=$value;
        }
        if ($hand >$max) {
            throw new Exception("Single transaction cannot exceed(单笔不能超过)" .$max . 'USDT');
        }
        caiwu($user->id, -$hand, 12, 'wall1', '期权下单');
        if ($sim == '2') {
            //模拟 
            db('user')->where('id', $user->id)->setDec('times', 1);  //减少次数
        }
        //增加上级业绩
        db('user')->where('id', 'in', $user->tpath)->setInc('tdyj', $hand);
        db('user')->where('id', $user->id)->setInc('gryj', $hand);

        $model = new self();
        $model->data($attributes);
        return $model->allowField(true)->save();
    }

    public static function getList()
    {
        $user = UserModel::info();
        $model = self::where('user_id', $user->id);
        $list = $model->select();
        return $list;
    }
}
