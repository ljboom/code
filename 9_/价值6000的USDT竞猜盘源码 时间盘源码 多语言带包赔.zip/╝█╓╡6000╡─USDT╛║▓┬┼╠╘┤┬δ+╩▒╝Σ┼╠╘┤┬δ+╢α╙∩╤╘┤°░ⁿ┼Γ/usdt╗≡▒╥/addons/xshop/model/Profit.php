<?php

namespace addons\xshop\model;

use think\Model;
use addons\xshop\exception\Exception;


class Profit extends Model
{





    // 表名
    protected $name = 'profit';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'addtime_text',
        'endtime_text',
        'ptype1_text'
    ];



    public function getPtype1List()
    {
        return config('site.cointype');
    }


    public function getAddtimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['addtime']) ? $data['addtime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getEndtimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['endtime']) ? $data['endtime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getPtype1TextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['ptype1']) ? $data['ptype1'] : '');
        $list = $this->getPtype1List();
        return isset($list[$value]) ? $list[$value] : '';
    }

    protected function setAddtimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setEndtimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }


    public function user()
    {
        return $this->belongsTo('User', 'user_id', 'id', [], 'LEFT')->setEagerlyType(0);
    }

    public static function add($attributes)
    {
        extract($attributes);
        $user = UserModel::getUserInfo();
        $attributes['user_id'] = $user['id'];
        $rule = config('site.vip_freeze');
        if (isset($rule[$level]) && $rule[$level] > 0) {
            if ($user[$ptype1] < $rule[$level]) {
                throw new Exception("账户不足");
            }
            //查询是否已经锁仓
            $suo = self::where('user_id', $user['id'])->find();
            if ($suo) {
                //解锁
                self::unfreeze($suo['id']);
            }
            //财务记录
            caiwu($user['id'], -$rule[$level], 9, $ptype1, '锁仓', 1);
            //更新会员级别
            db('user')->where('id', $user['id'])->setField('level', $level);
            //锁仓时间
            $rule2 =  config('site.vip_freeze_time');
            $attributes['money'] = $rule[$level];
            $attributes['addtime'] = time();
            $attributes['endtime'] = time() + $rule2[$level] * 86400;
            $model = new self();
            $model->data($attributes);
            return $model->allowField(true)->save();
        } else {
            throw new Exception("参数有误");
        }
    }

    public static function list()
    {
        $user = UserModel::getUserInfo();
        $map['user_id'] = $user['id'];
        return self::where($map)->select();
    }

    public static function edit($attributes)
    {
        extract($attributes);
        $user = UserModel::getUserInfo();
        $attributes['user_id'] = $user['id'];
        $model = new self();
        if (isset($id)) {
            return $model->allowField(true)->save($attributes, ['id' => $id]);
        }
    }
    /**
     * 解锁
     * 订单id
     */
    public static function unfreeze($id)
    {
        $info = self::get($id);
        caiwu($info['user_id'], $info['money'], 9, $info['ptype1'], '锁仓释放', 1);
        self::destroy($id);
        return true;
    }
    /**
     * 批量解锁
     */
    public static function findfree()
    {
        $map['endtime'] = ['<', time()];
        $list = self::where($map)->select();
        if ($list) {
            foreach ($list as $item) {
                self::unfreeze($item['id']);
            }
        }
        return 666;
    }
}
