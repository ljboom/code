<?php

namespace addons\xshop\model;

use think\Model; 
use app\common\library\Sms;
use addons\xshop\exception\Exception;


class Payment extends Model
{





    // 表名
    protected $name = 'user_payment';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = true;

    protected $hidden = [
        'create_time', 'update_time', 'delete_time'
    ];


    // 追加属性
    protected $append = [
        'type_text',
        'create_time_text',
        'update_time_text',
        'delete_time_text'
    ];



    public function getTypeList()
    {
        // 类型:1=支付宝,2=微信,3=银行卡
        return config('site.tx_ways');
    }


    public function getTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['type']) ? $data['type'] : '');
        $list = $this->getTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getCreateTimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['create_time']) ? $data['create_time'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getUpdateTimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['update_time']) ? $data['update_time'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getDeleteTimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['delete_time']) ? $data['delete_time'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }

    protected function setCreateTimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setUpdateTimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setDeleteTimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    public static function getList()
    {
        $user = UserModel::info();
        $tx_ways = array_keys(config('site.tx_ways'));
        return self::where('user_id', $user->id)->where('type', 'in', $tx_ways)->select();
    }

    public static function edit($attributes)
    {
        extract($attributes);
        // if (!Sms::check($mobile, $code, 'addpay')) {
        //     throw new Exception("验证码错误");
        // }
        $user = UserModel::info();
        if ($is_default) {
            self::where('user_id', $user->id)->update(['is_default' => 0]);
        }
        $attributes['user_id'] = $user->id;
        $model = new self();
        if (isset($id)) {
            return $model->allowField(true)->save($attributes, ['id' => $id]);
        } else {
            $model->data($attributes);
            return $model->allowField(true)->save();
        }
    }

    public static function edit2($attributes)
    {
        extract($attributes); 
        $user = UserModel::info();
        self::where('user_id', $user->id)->update(['is_default' => 0]);
        $model = new self();
        return $model->allowField(true)->save($attributes, ['id' => $id]);
    }

    /**
     * 删除
     */
    public static function del($attributes)
    {
        extract($attributes);
        $user = UserModel::info();
        return self::where('user_id', $user->id)->where('id', $payment_id)->delete();
    }
}
