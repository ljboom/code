<?php

namespace addons\xshop\model;

use think\Model;
use think\Exception;
use think\Db;

class Coin extends Model
{





    // 表名
    protected $name = 'btc_coin';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [];

    // protected static function init()
    // {
    //     self::afterInsert(function ($row) {
    //         $pk = $row->getPk();
    //         $row->getQuery()->where($pk, $row[$pk])->update(['weigh' => $row[$pk]]);
    //     });
    // }

    public static function getList()
    {
        $list = self::where('switch', 1)->order('weigh desc')->cache(true, 60)->select();
        return $list;
    }

    public static function getList2()
    {
        $list = self::where('switch', 1)->where('id', 'not in', '65')->order('weigh desc')->cache(true, 60)->select();
        return $list;
    }

    public static function binfo()
    {
        $binfo = [];
        $binfo = Cache('binfo');
        if (!$binfo) {
            self::updatebinfo();
        }
        foreach ($binfo as $key => $value) {
            $binfo[$key]['close'] = round($value['close'] + rand(1, 9) / 10000, 4);
        }
        return $binfo;
    }

    public static function updatebinfo()
    {
        $binfo = [];
        try {
            $row = json_decode(file_get_contents('https://api.cqdssl.com/api/xn/v1/markets'), true);
            if (isset($row['data'][0]['asset_pairs'])) {
                foreach ($row['data'][0]['asset_pairs'] as $item) {
                    $item['ticker']['daily_change_perc'] = round($item['ticker']['daily_change_perc'], 2);
                    $item['ticker']['logo'] = $item['base_asset']['logo'];
                    $binfo[$item['name']] = $item['ticker'];
                }
            }
            Cache('binfo', $binfo, 86400);
        } catch (Exception $e) {
            // echo $e->getMessage();
            return false;
        }
        return true;
    }

    public static function updatebinfo2()
    {
        $binfo = [];
        if(Cache('binfo2')){
            $binfo=Cache('binfo2');
        }else{
            try {
                $row = json_decode(file_get_contents('http://api.huobiasia.vip/market/tickers'), true);
                if ($row['status'] == 'ok') {
                    foreach ($row['data'] as $item) {
    
                        $binfo[$item['symbol']] = $item;
                    }
                }
                Cache('binfo2', $binfo, 2);
            } catch (Exception $e) {
                // echo $e->getMessage();
                return false;
            }
        }
      
        return true;
    }

    public static function relist($maplist)
    {
        $binfo = self::binfo();
        $myset = config('site');
        $PNAME = $myset['c_pname'];
        $CNY2USDT = $myset['rate_cny2usdt'];
        $USDT2USD = $myset['rate_usdt2usd'];
        if ($binfo) {
            foreach ($maplist as $key => $vo) {
                $symbol = $vo['name'] . '-USDT';
                $buycoin = 'USDT';
                $info = isset($binfo[$symbol]) ? $binfo[$symbol] : 0;
                $rand = rand(1, 9999) / 1000;
                if ($info) {
                    $maplist[$key]['symbol'] = strtolower($vo['name'] . $buycoin);
                    $maplist[$key]['price'] = $binfo[$symbol]['close'];
                    $maplist[$key]['priceUnit'] = $buycoin;
                    $maplist[$key]['cnyPrice'] = round($binfo[$symbol]['close'] * $CNY2USDT, 4);
                    $maplist[$key]['usdPrice'] = round($binfo[$symbol]['close'] * $USDT2USD, 4);
                    $maplist[$key]['open'] = $binfo[$symbol]['open'];
                    $maplist[$key]['high'] = $binfo[$symbol]['high'];
                    $maplist[$key]['low'] = $binfo[$symbol]['low'];
                    $maplist[$key]['change'] = $binfo[$symbol]['daily_change_perc'];
                    $maplist[$key]['volume'] =  round($binfo[$symbol]['volume'] + $rand, 2);
                } else {
                    if ($vo['name'] == $PNAME) {
                        $emp = self::dayprice();
                        $maplist[$key]['symbol'] = strtolower($vo['name'] . $buycoin);
                        $maplist[$key]['price'] = $emp['close'];
                        $maplist[$key]['priceUnit'] = $buycoin;
                        $maplist[$key]['cnyPrice'] = round($maplist[$key]['price'] * $CNY2USDT, 4);
                        $maplist[$key]['usdPrice'] = round($maplist[$key]['price'] * $USDT2USD, 4);
                        $maplist[$key]['high'] = $emp['high'];
                        $maplist[$key]['low'] = $emp['low'];
                        $maplist[$key]['change'] = $emp['change'];
                        $maplist[$key]['volume'] = $emp['vol'];
                    } else {
                        unset($maplist[$key]);
                    }
                }
            }
            return $maplist;
        } else {
            return false;
        }
    }

    public static function relist2($maplist)
    {
        $binfo = self::binfo();
        $PNAME = config('site.c_pname');
        if ($binfo) {
            foreach ($maplist as $key => $vo) {
                $symbol = $vo['name'] . '-USDT';
                $info = isset($binfo[$symbol]) ? $binfo[$symbol] : 0;
                $rand = rand(1, 9999) / 1000;
                if ($info) {
                    $tmp[$vo['name']] = [
                        'price' => $binfo[$symbol]['close'],
                        'open' => $binfo[$symbol]['open'],
                        'high' => $binfo[$symbol]['high'],
                        'low' => $binfo[$symbol]['low'],
                        'change' => $binfo[$symbol]['daily_change_perc'],
                        'volume' => round($binfo[$symbol]['volume'] + $rand, 2),
                        'logo' => $vo['logo'],
                    ];
                } else if ($vo['name'] == $PNAME) {
                    $symbol= 'EOS-USDT';
                    $emp = self::dayprice();
                    $tmp[$PNAME] = [
                        // 'price' => $binfo[$symbol]['close'],
                        // 'open' => $binfo[$symbol]['open'],
                        // 'high' => $binfo[$symbol]['high'],
                        // 'low' => $binfo[$symbol]['low'],
                        // 'change' => $binfo[$symbol]['daily_change_perc'],
                        // 'volume' => round($binfo[$symbol]['volume'] + $rand, 2),
                        // 'logo' => $vo['logo'],
                        'price' => $emp['close'],
                        'open' => $emp['open'],
                        'high' => $emp['high'],
                        'low' => $emp['low'],
                        'change' => $emp['change'],
                        'volume' => $emp['vol'],
                        'logo' => $vo['logo'],
                    ];
                } else if ($vo['name'] == 'USDT') {

                    $tmp['USDT'] = [
                        'open' => 1,
                        'price' => 1,
                        'high' => 1,
                        'low' => 1,
                        'change' => 1,
                        'volume' => 0,
                        'logo' => $vo['logo'],
                    ];
                }
            }
            return $tmp;
        } else {
            return false;
        }
    }

    public static function relist3($maplist)
    {
        $binfo =   Cache('binfo2');
        $tmp = [];
        if ($binfo) {
            foreach ($maplist as $key => $vo) {
                $symbol = strtolower($vo['name']) . 'usdt';
                $info = isset($binfo[$symbol]) ? $binfo[$symbol] : 0;
                $rand = rand(1, 9999) / 1000;
                if ($info) {
                    $tmp[$vo['name']] = [

                        // 'price' => $binfo[$symbol]['close'],
                        'price' => round($binfo[$symbol]['close'] + rand(1, 9) / 10000, 4),
                        'open' => $binfo[$symbol]['open'],
                        'high' => $binfo[$symbol]['high'],
                        'low' => $binfo[$symbol]['low'],
                        'change' => round(($binfo[$symbol]['close'] - $binfo[$symbol]['open']) / $binfo[$symbol]['open'], 2),
                        'volume' => round($binfo[$symbol]['vol'] + $rand, 2),
                        'logo' => $vo['logo'],
                    ];
                }
            }
            return $tmp;
        } else {
            return false;
        }
    }

    public static function relist4($maplist)
    {
        $binfo =   Cache('binfo2');

        $myset = config('site');
        $PNAME = $myset['c_pname'];
        $CNY2USDT = $myset['rate_cny2usdt'];
        $USDT2USD = $myset['rate_usdt2usd'];
        if ($binfo) {
            foreach ($maplist as $key => $vo) {
                $symbol = strtolower($vo['name']) . 'usdt';
                $info = isset($binfo[$symbol]) ? $binfo[$symbol] : 0;
                $rand = rand(1, 9999) / 1000;
                $buycoin = 'USDT';
              
                if ($info) {
                    $maplist[$key]['symbol'] = strtolower($vo['name'] . $buycoin);
                    $maplist[$key]['price'] = $binfo[$symbol]['close'];
                    $maplist[$key]['priceUnit'] = $buycoin;
                    $maplist[$key]['cnyPrice'] = round($binfo[$symbol]['close'] * $CNY2USDT, 4);
                    $maplist[$key]['usdPrice'] = round($binfo[$symbol]['close'] * $USDT2USD, 4);
                    $maplist[$key]['open'] = $binfo[$symbol]['open'];
                    $maplist[$key]['high'] = $binfo[$symbol]['high'];
                    $maplist[$key]['low'] = $binfo[$symbol]['low'];
                    $maplist[$key]['change'] = round(($binfo[$symbol]['close'] - $binfo[$symbol]['open'])/$binfo[$symbol]['open']*100,2);
                    $maplist[$key]['volume'] =  round($binfo[$symbol]['vol'] + $rand, 2);
                } else {
                    if ($vo['name'] == $PNAME) {
                        // $symbol='eosusdt';    
                        // $maplist[$key]['symbol'] = $symbol;
                        // $maplist[$key]['price'] = $binfo[$symbol]['close'];
                        // $maplist[$key]['priceUnit'] = $buycoin;
                        // $maplist[$key]['cnyPrice'] = round($binfo[$symbol]['close'] * $CNY2USDT, 4);
                        // $maplist[$key]['usdPrice'] = round($binfo[$symbol]['close'] * $USDT2USD, 4);
                        // $maplist[$key]['open'] = $binfo[$symbol]['open'];
                        // $maplist[$key]['high'] = $binfo[$symbol]['high'];
                        // $maplist[$key]['low'] = $binfo[$symbol]['low'];
                        // $maplist[$key]['change'] = round(($binfo[$symbol]['close'] - $binfo[$symbol]['open'])/$binfo[$symbol]['open']*100,2);
                        // $maplist[$key]['volume'] =  round($binfo[$symbol]['vol'] + $rand, 2);

                        $emp = self::dayprice();
                        $maplist[$key]['symbol'] = strtolower($vo['name'] . $buycoin);
                        $maplist[$key]['price'] = $emp['close'];
                        $maplist[$key]['priceUnit'] = $buycoin;
                        $maplist[$key]['cnyPrice'] = round($maplist[$key]['price'] * $CNY2USDT, 4);
                        $maplist[$key]['usdPrice'] = round($maplist[$key]['price'] * $USDT2USD, 4);
                        $maplist[$key]['high'] = $emp['high'];
                        $maplist[$key]['low'] = $emp['low'];
                        $maplist[$key]['change'] = $emp['change'];
                        $maplist[$key]['volume'] = $emp['vol'];
                    } else {
                        unset($maplist[$key]);
                    }
                }
            }
            return $maplist;
        } else {
            return false;
        } 
        
    }






    public static function local($type, $gid = 1)
    {
        $limit = 400;
        switch ($type) {
            case '1':
                $kline = Db::name('min1_' . $gid)->order('id desc')->limit($limit)->cache(true, 10)->select();
                break;
            case '5':
                $kline = Db::name('min5_' . $gid)->order('id desc')->limit($limit)->cache(true, 60)->select();
                break;
            case '30':
                $kline = Db::name('min30_' . $gid)->order('id desc')->limit($limit)->cache(true, 60)->select();
                break;
            case '60':
                $kline = Db::name('min60_' . $gid)->order('id desc')->limit($limit)->cache(true, 60)->select();
                break;
            case '240':
                $kline = Db::name('min240_' . $gid)->order('id desc')->limit($limit)->cache(true, 60)->select();
                break;
            case '1440':
                $kline = Db::name('min1440_' . $gid)->order('id desc')->limit($limit)->cache(true, 60)->select();
                break;
            default:
                $kline = Db::name('min1_' . $gid)->order('id desc')->limit($limit)->select();
        }
        $kline = array_reverse($kline);
        $data = [];
        if ($kline) {
            // amount:292.12791751994376
            // close:9457.68
            // count:3882
            // high:9464.15
            // id:1592402700
            // isBarClosed:true
            // isLastBar:false
            // low:9426.68
            // open:9436.23
            // time:1592402700000
            // vol:2758974.54002486
            // volume:2758974.54002486
            foreach ($kline as $item) {

                $data[] = array(
                    'amount' => (float) $item['value'],
                    'close' => (float) $item['close'],
                    'count' => 3882,
                    'high' => (float) $item['high'],
                    'id' => $item['addtime'],
                    'isBarClosed' => true,
                    'isLastBar' => true,
                    'low' => (float) $item['low'],
                    'open' => (float) $item['open'],
                    'time' => $item['addtime'] * 1000,
                    'vol' => $item['value'],
                    'volume' => (float) $item['value'],
                );
            }
        }
        
        return $data;
    }

    public static function nowprice($type, $gid = 1)
    { 
        $info = Db::name('min1_' . $gid)->order('id desc')->find();
        $nowprice = $info['close'];
        switch ($type) {
            case '1':
                $kline = Db::name('min1_' . $gid)->order('id desc')->cache(true, 10)->find();
                break;
            case '5':
                $kline = Db::name('min5_' . $gid)->order('id desc')->cache(true, 60)->find();
                break;
            case '30':
                $kline = Db::name('min30_' . $gid)->order('id desc')->cache(true, 60)->find();
                break;
            case '60':
                $kline = Db::name('min60_' . $gid)->order('id desc')->cache(true, 60)->find();
                break;
            case '240':
                $kline = Db::name('min240_' . $gid)->order('id desc')->cache(true, 60)->find();
                break;
            case '1440':
                $kline = Db::name('min1440_' . $gid)->order('id desc')->cache(true, 60)->find();
                break;
            default:
                $kline = Db::name('min1_' . $gid)->order('id desc')->cache(true, 60)->find();
        }
        
        $data=[];
        if ($kline) { 
            $kline['open'] = $kline['open']>0? $kline['open'] : 0.1;
            $change = round(($nowprice- $kline['open']) / $kline['open'] * 100, 2);
            $data = array(
                'amount' => (float) $kline['value'],
                'close' => (float) $nowprice,
                'count' => 3882,
                'high' => (float) $kline['high'],
                'id' => $kline['addtime'],
                'isBarClosed' => true,
                'isLastBar' => true,
                'low' => (float) $kline['low'],
                'open' => (float) $kline['open'],
                'time' => $kline['addtime'] * 1000,
                'vol' => 0,
                'volume' =>0,
                'change' => $change,
            );
        }
        
        return $data;
    }

    public static function dayprice($gid = 1)
    {
        $day = Db::name('min0_' . $gid)->order('id desc')->find();

        $now = $day['close'];
        $day['open'] = $day['open'] > 0 ? $day['open'] : 0.01;
        $change = round(($now - $day['open']) / $day['open'] * 100, 2);
        $re = array(
            'amount' => $now,
            'close' => $now,
            'count' => 3882,
            'high' => (float) $day['high'],
            'id' => $day['addtime'],
            'isBarClosed' => true,
            'isLastBar' => true,
            'low' => (float) $day['low'],
            'open' => (float) $day['open'],
            'time' => $day['addtime'] * 1000,
            // 'vol' =>  $day['value'],
            // 'volume' =>  $day['value'],
            'vol' => 0,
            'volume' =>  0,
            'change' => $change,
            'local'=>1
        );
        return $re;
    }
}
