<?php

namespace addons\xshop\model;

use think\Model;
use addons\xshop\exception\Exception;
use addons\voicenotice\library\Voicenotice as voice;


class Cash extends Model
{





    // 表名
    protected $name = 'tx_cash';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'addtime_text',
        'comtime_text',
        'status_text',
        'ptype1_text'
    ];



    public function getStatusList()
    {
        return ['0' => '待充值', '1' => '已充值', '2' => '失败'];
    }

    public function getPtype1List()
    {
        return config('site.cointype');
    }


    public function getAddtimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['addtime']) ? $data['addtime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getComtimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['comtime']) ? $data['comtime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getPtype1TextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['ptype1']) ? $data['ptype1'] : '');
        $list = $this->getPtype1List();
        return isset($list[$value]) ? $list[$value] : '';
    }

    protected function setAddtimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    protected function setComtimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }

    public static function edit($attributes)
    {
        extract($attributes);
        $user = UserModel::getUserInfo();
        $attributes['user_id'] = $user['id'];
        $attributes['account'] = $user['username'];
        $attributes['addtime'] = time();
        if ($user[$ptype1] < $number) {
            throw new Exception('账户金额不足');
        }
        $model = new self();
        if (isset($id)) {
            return $model->allowField(true)->save($attributes, ['id' => $id]);
        } else {
             //交易额
            $total = $number;
            //手续费
            $rule = config('site.vip_cash_fee');
            $rate= isset($rule[$user['level']]) ? $rule[$user['level']] : 0;
            $fee = $rate * $total;
            if ($fee > 0) { 
                $total = $total - $fee;
                caiwu($user['id'], -$fee, 2, $ptype1, '提现手续费', 1);
                $attributes['service']=$fee;
            }
            //冻结提现金额
            caiwu($user['id'], -$total, 2, $ptype1, '提现', 1); 
            $attributes['number']=$total;
            $model->data($attributes);
            $worker = voice::addNotice('您有新提现订单', false, ['1','2'],false,'','');
            return $model->allowField(true)->save();
        }
    }
}
