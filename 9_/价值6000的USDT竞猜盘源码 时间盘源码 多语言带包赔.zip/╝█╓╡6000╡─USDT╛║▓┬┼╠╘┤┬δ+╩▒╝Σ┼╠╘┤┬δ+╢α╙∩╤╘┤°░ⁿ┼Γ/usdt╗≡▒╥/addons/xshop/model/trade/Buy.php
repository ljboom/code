<?php

namespace addons\xshop\model\trade;

use think\Model;


class Buy extends Model
{

    

    

     // 表名
     protected $name = 'trade_buy';
    
     // 自动写入时间戳字段
     protected $autoWriteTimestamp = false;
 
     // 定义时间戳字段名
     protected $createTime = false;
     protected $updateTime = false;
     protected $deleteTime = false;
 
     // 追加属性
     protected $append = [
        'addtime_text',
        'comtime_text',
        'status_text',
        'ptype1_text',
        'ptype2_text',
        'type_text'
    ];
    
     
 
     
     public function getStatusList()
     {
        // 状态:0=委托中,3=已取消,4=冻结,5=交易完成
         return ['0' => '委托中', '3' => '已取消', '4' =>'冻结', '5' =>'已完成'];
     }
 
     public function getPtype1List()
     {
         return config('site.cointype');
     }
 
     public function getPtype2List()
     {
         return config('site.cointype');
     }

     public function getTypeList()
     {
         return ['4' => '买入', '5' => '卖出'];
     }
 
 
     public function getAddtimeTextAttr($value, $data)
     {
         $value = $value ? $value : (isset($data['addtime']) ? $data['addtime'] : '');
         return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
     }
 
 
     public function getComtimeTextAttr($value, $data)
     {
         $value = $value ? $value : (isset($data['comtime']) ? $data['comtime'] : '');
         return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
     }
 
 
     public function getStatusTextAttr($value, $data)
     {
         $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
         $list = $this->getStatusList();
         return isset($list[$value]) ? $list[$value] : '';
     }
 
 
     public function getPtype1TextAttr($value, $data)
     {
         $value = $value ? $value : (isset($data['ptype1']) ? $data['ptype1'] : '');
         $list = $this->getPtype1List();
         return isset($list[$value]) ? $list[$value] : '';
     }
 
 
     public function getPtype2TextAttr($value, $data)
     {
         $value = $value ? $value : (isset($data['ptype2']) ? $data['ptype2'] : '');
         $list = $this->getPtype2List();
         return isset($list[$value]) ? $list[$value] : '';
     }
 
     protected function setAddtimeAttr($value)
     {
         return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
     }
 
     protected function setComtimeAttr($value)
     {
         return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
     }

     public function getTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['type']) ? $data['type'] : '');
        $list = $this->getTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


}
