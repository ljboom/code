<?php

namespace addons\xshop\model\trade;

use think\Model;
use think\Exception;
use addons\xshop\model\trade\Buy;
use addons\xshop\model\trade\Sale;


class Pp extends Model
{


    // 表名
    protected $name = 'trade_pp';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'addtime_text',
        'type_text',
        'status_text',
        'ptype1_text',
        'ptype2_text'
    ];



    public function getTypeList()
    {
        return ['4' => '买入', '5' => '卖出'];
    }

    public function getStatusList()
    {
        return ['2' => '已完成', '3' => '已取消'];
    }

    public function getPtype1List()
    {
        return config('site.cointype');
    }

    public function getPtype2List()
    {
        return config('site.cointype');
    }


    public function getAddtimeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['addtime']) ? $data['addtime'] : '');
        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }


    public function getTypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['type']) ? $data['type'] : '');
        $list = $this->getTypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getStatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['status']) ? $data['status'] : '');
        $list = $this->getStatusList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getPtype1TextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['ptype1']) ? $data['ptype1'] : '');
        $list = $this->getPtype1List();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getPtype2TextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['ptype2']) ? $data['ptype2'] : '');
        $list = $this->getPtype2List();
        return isset($list[$value]) ? $list[$value] : '';
    }

    protected function setAddtimeAttr($value)
    {
        return $value === '' ? null : ($value && !is_numeric($value) ? strtotime($value) : $value);
    }




    protected $cstate = [
        'sale' => 4,
        'buy' => 5,
        'cancle' => 6,
        'trade' => 7,
    ];

    protected $ptype1 = 'wall2';  //卖出类型
    protected $ptype2 = 'wall1';  //买入类型

    /**
     * 卖BTC
     * @param $btc
     * @param $cny
     * @param $fee
     * @return bool
     */
    function sale($btc, $cny, $fee, $user = array(), $ptype1, $ptype2)
    {

        $btc = floatval($btc);
        $cny = floatval($cny);
        $fee = floatval($fee);
        if (!isset($user['id'])) {
            throw new Exception('用户不存在');
        }
        $this->ptype1 = $ptype1;
        $this->ptype2 = $ptype2;
        //交易额
        $number = $btc;
        //手续费
        $rule = config('site.vip_btc_fee');
        $rate= isset( $rule[$user['level']]) ? $rule[$user['level']] : 0;
        $fee = $rate * $number;
        // if ($fee > 0) {
        //     caiwu($user['id'], -$fee, $this->cstate['sale'], $ptype1, "卖出手续费", 1);
        //     $number = $number - $fee;
        // }
        //减少余额
        caiwu($user['id'], -$number, $this->cstate['sale'], $ptype1, '委托卖出', 1);
        //增加销售记录
        $row = array(
            'userid'  => $user['id'],
            'account' => $user['username'],
            'number'  => $number,
            'price'   => $cny,
            'fee'     => $fee,
            'total'   => $cny * $btc,
            'ptype1'  =>  $ptype1,
            'ptype2'  =>  $ptype2,
            'status'  => 0,
            'type'  => '5',
            'addtime' => time()
        );
        $Sale = new Buy($row);
        $Sale->save();
        $this->btc_sale_id = $Sale->id;
        return $Sale->id;
    }

    /**
     * 买BTC
     * @param $btc
     * @param $cny
     * @param $fee
     * @return bool
     */
    function buy($btc, $cny, $fee, $user = array(), $ptype1, $ptype2)
    {


        $btc = floatval($btc);
        $cny = floatval($cny);
        $fee = floatval($fee);
        if (!isset($user['id'])) {
            throw new Exception('用户不存在');
        }
        $this->ptype1 = $ptype1;
        $this->ptype2 = $ptype2;
        //交易额
        $total = $btc * $cny;
        //手续费
        $rule = config('site.vip_btc_fee');
        $rate= isset( $rule[$user['level']]) ? $rule[$user['level']] : 0;
        $fee = $rate * $total;
        // if ($fee > 0) {
        //     caiwu($user['id'], -$fee, $this->cstate['buy'], $ptype2, "买入手续费", 1);
        //     $total = $total - $fee;
        // }
        //减少余额
        caiwu($user['id'], -$total, $this->cstate['buy'], $ptype2, '委托买入', 1);

        //增加购买记录
        $row = array(
            'userid'  => $user['id'],
            'account' => $user['username'],
            'number'  => $total / $cny,
            'price'   => $cny,
            'fee'     => $fee,
            'total'   => $total,
            'status'  => 0,
            'ptype1'  =>  $ptype1,
            'ptype2'  =>  $ptype2,
            'type'  => '4',
            'addtime' => time(),
        );
        $Buy = new Buy($row);
        $Buy->save();
        $this->btc_buy_id = $Buy->id;
        return $Buy->id;
    }


    //撤销卖单
    function cancelSaleOrder($uid, $id)
    {
        $one = Buy::get($id);
        //剩余 btc
        $left = $one['number'] - $one['trade_number'];
        if ($one['userid'] != $uid) {
            throw new Exception('用户不存在');
        }
        if ($one['status'] == 3) {
            throw new Exception('已经撤单');
        }
        if ($left <= 0) {
            throw new Exception('已经成交完');
        }
        $data['status'] = 3;
        caiwu($uid, $left, $this->cstate['cancle'], $one['ptype1'], '撤销卖单', 1);
        //手续费 
        // $fee = $left / $one['number'] * $one['fee'];
        // if ($fee > 0) {
        //     caiwu($uid, $fee, $this->cstate['cancle'], $one['ptype1'], "撤销卖单手续费退回", 1);
        // }

        return  $one->data(['status' => 3])->save();
        // $myset = config('site');
        // $fee = ceil($left * $myset['salefee'] * 0.01); 
        // if ($fee > 0) caiwu($uid, $fee, 6, 'wall2', '撤销卖单手续费退回', 1); 
    }

    //撤销买单
    function cancelBuyOrder($uid, $id)
    {
        $one = Buy::get($id);
        //剩余 btc
        $left = $one['number'] - $one['trade_number'];
        if ($one['userid'] != $uid) {
            throw new Exception('用户不存在');
        }
        if ($one['status'] == 3) {
            throw new Exception('已经撤单');
        }
        if ($left <= 0) {
            throw new Exception('已经成交完');
        }
        $data['status'] = 3;
        caiwu($uid, $left * $one['price'], $this->cstate['cancle'], $one['ptype2'], '撤销买单', 1);
        //手续费 
        // $fee = $left / $one['number'] * $one['fee'];
        // if ($fee > 0) {
        //     caiwu($uid, $fee, $this->cstate['cancle'], $one['ptype2'], "撤销买单手续费退回", 1);
        // }

        return  $one->data(['status' => 3])->save();
    }


    //找到卖价交易 挂单 buy的时候执行 
    /**
     * @param $btc_buy_id
     * @return bool
     */
    function findSale($btc_buy_id)
    {
        $buy = Buy::get($btc_buy_id);
        //找到卖价不高于买家最低的
        $map['status'] = '0';
        $map['userid'] = ['neq', $buy['userid']];
        $map['price'] = array('elt', $buy['price']);
        $map['ptype1'] = $buy['ptype1'];
        $map['ptype2'] = $buy['ptype2'];
        $map['type'] = '5';
        $sale = Buy::where($map)->order('price')->find();
        if (!$sale) {
            return false;
        }
        //还要买的量  
        $leftBuy = $buy['number'] - $buy['trade_number'];
        //还要卖的量
        $leftSale = $sale['number'] - $sale['trade_number'];
        //交易数量
        $number = min($leftSale, $leftBuy);
        if (!$number) {
            return $leftBuy;
        }
        $this->trade($number, $sale, $buy, 4);
        if ($leftBuy - $number > 0) {
            $this->findSale($btc_buy_id);
        }
    }

    //找到买家 挂单sale时候执行
    function findBuy($btc_sale_id)
    {
        $sale = Buy::get($btc_sale_id);
        //找到买价高于卖价最高的
        $map['status'] = '0';
        $map['userid'] = ['neq', $sale['userid']];
        $map['price'] = array('egt', $sale['price']);
        $map['ptype1'] = $sale['ptype1'];
        $map['ptype2'] = $sale['ptype2'];
        $map['type'] = '4';
        $buy = Buy::where($map)->order('price desc')->find();
        if (!$buy) {
            return false;
        }
        //还要买的量  
        $leftBuy = $buy['number'] - $buy['trade_number'];
        //还要卖的量
        $leftSale = $sale['number'] - $sale['trade_number'];
        //交易数量
        $number = min($leftSale, $leftBuy);
        if (!$number) {
            return false;
        }
        $this->trade($number, $sale, $buy, 5);
        if ($leftSale - $number > 0) {
            $this->findBuy($btc_sale_id);
        }
    }

    /**
     * 交易
     * @param $number
     * @param $sale
     * @param $buy
     * @param $type
     * @return bool
     * @throws \think\exception\PDOException
     */
    function trade($number, $sale, $buy, $type)
    {
        $sale_id = (int) $sale['userid'];
        $buy_id = (int) $buy['userid'];
        Buy::where(array('id' => $sale['id']))->setInc('trade_number', $number);
        Buy::where(array('id' => $buy['id']))->setInc('trade_number', $number);
        //记录
        $data['status'] = 2;   //已完成
        $data['tgid'] = $buy['id'];
        $data['xyid'] = $sale['id'];
        $data['account'] = $buy['account'];
        $data['account1'] = $sale['account'];
        $data['userid'] = $buy_id;
        $data['userid1'] = $sale_id;
        $data['type'] = $type;
        if ($type == 4) {
            $data['price'] = min($buy['price'], $sale['price']);
        } else {
            $data['price'] = max($buy['price'], $sale['price']);
        } 
        $data['number'] = $number;
        $data['total'] = $number * $data['price'];
        $data['addtime'] = time();
        $data['ptype1'] = $buy['ptype1'];
        $data['ptype2'] = $buy['ptype2'];
        // $this->data($data)->save();
        db('trade_pp')->insert($data);
        //短信通知
        //            smscode($buy_id, 1, $buy['account']);
        //            smscode($sale_id, 1, $sale['account']); 

        //减少卖家冻结 成交额+手续费
        $salefee = $number / $sale['number'] * $sale['fee'];
        $freesale = $number;

        //减少买家冻结 成交额+手续费
        $buyfee = $data['total'] / $buy['total'] * $buy['fee'];
        $freebuy = $data['total'];
        db('user')->where('id', $sale_id)->setDec($buy['ptype1'] . 'freeze', $freesale);
        db('user')->where('id', $buy_id)->setDec($buy['ptype2'] . 'freeze', $freebuy);

        Buy::where('id', $buy['id'])->update(['deal' =>  $data['price']]);
        Buy::where('id', $sale['id'])->update(['deal' =>  $data['price']]);

        //线上交易结算
        caiwu($buy_id, $number, $this->cstate['trade'], $buy['ptype1'], '购买' . $number . $buy['ptype1_text']);
        if($salefee>0){
            caiwu($buy_id, -$salefee, $this->cstate['trade'], $buy['ptype1'], '购买' . $number . $buy['ptype1_text'] . '手续费');
        }
        
        caiwu($sale_id, $data['total'], $this->cstate['trade'], $buy['ptype2'], '出售' . $number . $buy['ptype1_text']);
        if($salefee>0){
            caiwu($sale_id, -$buyfee, $this->cstate['trade'], $buy['ptype2'], '出售' . $number . $buy['ptype1_text'] . '手续费');
        }
        

        //推荐奖励 
        // $info =  db('user')->find($buy_id);
        // if ($info && $info['tjid']) {
        //     $tjuser = db('user')->find($info['tjid']);
        //     $rule = config('site.vip_profit');
        //     $bouse = $rule[$tjuser['level']] * $number;
        //     if ($bouse > 0) {
        //         caiwu($info['tjid'], $bouse, 3, $data['ptype1'], '币币交易手续费为：' . $salefee . ',下级交易分红');
        //     }
        // }
        // $info2 =  db('user')->find($sale_id);
        // if ($info2 && $info2['tjid']) {
        //     $tjuser = db('user')->find($info2['tjid']);
        //     $rule = config('site.vip_profit');
        //     $bouse = $rule[$tjuser['level']] * $number;
        //     if ($bouse > 0) {
        //         caiwu($info2['tjid'], $bouse, 3, $data['ptype1'], '币币交易手续费为：' . $salefee . ',下级交易分红');
        //     }
        // }


        //判断买卖状态
        if ($sale['number'] == $number + $sale['trade_number']) {
            Buy::where('id', $sale['id'])->update(['status' => '5', 'comtime' => time()]);
        }
        if ($buy['number'] == $number + $buy['trade_number']) {
            Buy::where('id', $buy['id'])->update(['status' => '5', 'comtime' => time()]);
        }

        $list = db('min0_1')->order('id desc')->find();
        db('min0_1')->where('id', $list['id'])->setField('close', $data['price']);
        return true;
    }


    //手动匹配

    /**
     * @param $btc_buy_id
     * @return bool
     */
    function findSale2($buy_id, $sale_id, $number)
    {
        $buy =  Buy::get($buy_id);
        $sale = Sale::get($sale_id);
        //还要买的量
        $leftBuy = $buy['number'] - $buy['trade_number'];
        //还要卖的量
        $leftSale = $sale['number'] - $sale['trade_number'];
        //交易数量
        $num = min($leftSale, $leftBuy);
        if ($number == 0 || $number > $num) {
            return false;
        }
        return $this->trade($number, $sale, $buy, 4);
    }
}
