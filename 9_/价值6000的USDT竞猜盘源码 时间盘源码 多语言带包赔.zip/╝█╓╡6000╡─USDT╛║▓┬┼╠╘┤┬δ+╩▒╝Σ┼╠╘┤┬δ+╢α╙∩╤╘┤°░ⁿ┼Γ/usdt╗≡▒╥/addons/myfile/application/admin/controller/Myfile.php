<?php

namespace app\admin\controller;

use app\common\controller\Backend;
 
/**
 * 文件管理
 *
 * @icon fa fa-folder
 * @remark 用于管理文件
 */
class Myfile extends Backend
{ 
    
    public function index(){ 
        require_once(ROOT_PATH.'/addons/myfile/library/file.php');
    } 

}
