<?php

return array (
  0 => 
  array (
    'name' => 'username',
    'title' => '用户名',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'admin',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'password',
    'title' => '密码',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '123456',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  2 => 
  array (
    'name' => 'path',
    'title' => '默认路径',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '/assets',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
);
