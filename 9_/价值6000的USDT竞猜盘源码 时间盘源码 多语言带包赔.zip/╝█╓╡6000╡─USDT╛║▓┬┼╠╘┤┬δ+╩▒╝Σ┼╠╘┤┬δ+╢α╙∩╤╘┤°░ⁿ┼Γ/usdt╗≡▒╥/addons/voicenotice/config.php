<?php

return array(
    0 =>
        array(
            'name'    => 'appKey',
            'title'   => '百度appKey ',
            'type'    => 'string',
            'content' =>
                array(),
            'value'   => '4E1BG9lTnlSeIf1NQFlrSq6h',
            'rule'    => 'required',
            'msg'     => '',
            'tip'     => '',
            'ok'      => '',
            'extend'  => '',
        ),
    1 =>
        array(
            'name'    => 'secretKey',
            'title'   => '百度secretKey',
            'type'    => 'string',
            'content' =>
                array(),
            'value'   => '544ca4657ba8002e3dea3ac2f5fdd241',
            'rule'    => 'required',
            'msg'     => '',
            'tip'     => '',
            'ok'      => '',
            'extend'  => '',
        ),
    2 =>
        array(
            'name'    => 'state',
            'title'   => '是否开启',
            'type'    => 'radio',
            'content' =>
                array(
                    0 => '否',
                    1 => '是',
                ),
            'value'   => '1',
            'rule'    => 'required',
            'msg'     => '',
            'tip'     => '',
            'ok'      => '',
            'extend'  => '',
        ),
);
