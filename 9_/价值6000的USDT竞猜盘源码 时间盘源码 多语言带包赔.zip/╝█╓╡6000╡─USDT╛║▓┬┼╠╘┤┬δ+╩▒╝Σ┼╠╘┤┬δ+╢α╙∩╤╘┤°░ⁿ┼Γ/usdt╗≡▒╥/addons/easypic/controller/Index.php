<?php

namespace addons\easypic\controller;

use think\addons\Controller;

class Index extends Controller
{

    public function index()
    {
        return $this->view->fetch();
    }
    public function build()
    {
        $text = $this->request->get('text', 'hello world'); 
        $type = $this->request->get('logo'); 
        $positon = $this->request->get('labelhalign');  

        $in=[
            'imgSrc'=>ROOT_PATH . 'public/assets/addons/easypic/img/1.jpg',
            'logo'=>ROOT_PATH . 'public/assets/addons/easypic/img/2.jpg',
            'out'=>ROOT_PATH .  'public/out.jpg',
            'type'=>$type,//1代表以图片方式，2代表以文字方式添加水印
            'positon'=>$positon,//取值范围：0~9  0：随机位置，在1~8之间随机选取一个位置 1：顶部居左 2：顶部居中 3：顶部居右 4：左边居中 5：图片中心 6：右边居中 7：底部居左 8：底部居中 9：底部居右
            'text'=>$text,
            'fontSize'=>18 
        ];
        $this->setWater($in);
        echo  "/out.jpg";
    }



    public function test()
    {
        $text = '';
        $text .= '日期：' . date('Y-m-d H:i:s') . PHP_EOL;
        $text .= '类型：测试' . PHP_EOL;
        $text .= '备注：你好啊' . date('Y-m-d H:i:s') . PHP_EOL;
        $text .= '--------------------------------' . PHP_EOL; 

        $in=[
            'imgSrc'=>ROOT_PATH . 'public/assets/addons/easypic/img/1.jpg',
            'out'=>ROOT_PATH .  'public/out.jpg',
            'type'=>2,//1代表以图片方式，2代表以文字方式添加水印
            'positon'=>0,//取值范围：0~9  0：随机位置，在1~8之间随机选取一个位置 1：顶部居左 2：顶部居中 3：顶部居右 4：左边居中 5：图片中心 6：右边居中 7：底部居左 8：底部居中 9：底部居右
            'text'=>$text,
            'fontSize'=>18 
        ];
        $re =  $this->setWater($in);
        dump($re);
        // $this->redirect('/out.jpg?v='.time());
    }

    /**
     * 设置水印  zst
     * @param $imgSrc           待处理图片全路径
     * @param $logo             水印图片全路径
     * @param $out              处理完毕水印图片路径
     * @param $type             图片添加水印的方式，1代表以图片方式，2代表以文字方式添加水印
     * @param int $positon      图片水印添加的位置默认为0，取值范围：0~9  0：随机位置，在1~8之间随机选取一个位置 1：顶部居左 2：顶部居中 3：顶部居右 4：左边居中 5：图片中心 6：右边居中 7：底部居左 8：底部居中 9：底部居右
     * @param $text             给图片添加的水印文字 
     * @param int $fontSize     水印文字大小 
     */
    public function setWater($in)
    {    
        if(!isset($in['imgSrc'])||!isset($in['type'])) return false;
        $imgSrc=$in['imgSrc'];
        $type=$in['type'];
        if($type==1&&!isset($in['logo'])) return false;
        if($type==2&&!isset($in['text'])) return false;
        $positon=!isset($in['positon']) ? 7 : $in['positon'];
        // , $logo, $out, $type, $positon, $text
        $out = !isset($in['out']) ?  $imgSrc : $in['out']; //合成水印路径为空就覆盖原图
        $fontType = ROOT_PATH . 'public/assets/addons/easypic/fonts/fzltxh.ttf';
        $srcInfo = @getimagesize($imgSrc);
        $srcImg_w  = $srcInfo[0];
        $srcImg_h  = $srcInfo[1];

        switch ($srcInfo[2]) {
            case 1:
                $srcim = imagecreatefromgif($imgSrc);
                break;
            case 2:
                $srcim = imagecreatefromjpeg($imgSrc);
                break;
            case 3:
                $srcim = imagecreatefrompng($imgSrc);
                break;
            default:
                return false;
        } 

        if ($type==1) {
            $logo=$in['logo']; 
            $logoInfo = @getimagesize($logo);
            $logo_w  = $logoInfo[0];
            $logo_h  = $logoInfo[1];

            if ($srcImg_w < $logo_w || $srcImg_h < $logo_h) {
                return false;
            }

            switch ($logoInfo[2]) {
                case 1:
                    $markim = imagecreatefromgif($logo);
                    break;
                case 2:
                    $markim = imagecreatefromjpeg($logo);
                    break;
                case 3:
                    $markim = imagecreatefrompng($logo);
                    break;
                default:
                return false;
            }

            $logow = $logo_w;
            $logoh = $logo_h;
        }

        if ($type==2) {
            $fontSize =!isset($in['fontSize']) ?16:$in['fontSize'];
            $text=$in['text']; 

            $box = @imagettfbbox($fontSize, 0, $fontType, $text);
            $logow = max($box[2], $box[4]) - min($box[0], $box[6]);
            $logoh = max($box[1], $box[3]) - min($box[5], $box[7]);
        }

        if ($positon == 0) {
            $positon = rand(1, 9);
        }
        $off_x = 10;
        $off_y = 50;
        switch ($positon) {
            case 1:
                $x = +$off_x;
                $y = +$off_y;
                break;
            case 2:
                $x = ($srcImg_w - $logow) / 2;
                $y = +$off_y;
                break;
            case 3:
                $x = $srcImg_w - $logow - $off_x;
                $y = +$off_y;
                break;
            case 4:
                $x = +$off_x;
                $y = ($srcImg_h - $logoh) / 2;
                break;
            case 5:
                $x = ($srcImg_w - $logow) / 2;
                $y = ($srcImg_h - $logoh) / 2;
                break;
            case 6:
                $x = $srcImg_w - $logow - $off_x;
                $y = ($srcImg_h - $logoh) / 2;
                break;
            case 7:
                $x = +$off_x;
                $y = $srcImg_h - $logoh - $off_y;
                break;
            case 8:
                $x = ($srcImg_w - $logow) / 2;
                $y = $srcImg_h - $logoh - $off_y;
                break;
            case 9:
                $x = $srcImg_w - $logow - $off_x;
                $y = $srcImg_h - $logoh - $off_y;
                break;
            default:
            $x = +$off_x;
            $y = $srcImg_h - $logoh - $off_y;
        }

        $dst_img = @imagecreatetruecolor($srcImg_w, $srcImg_h);

        imagecopy($dst_img, $srcim, 0, 0, 0, 0, $srcImg_w, $srcImg_h);

        if ($type==1) {
            imagecopy($dst_img, $markim, $x, $y, 0, 0, $logow, $logoh);
            imagedestroy($markim);
        }

        if ($type==2) {
            //创建目标图像
            $waterpic = @imagecreatetruecolor($logow + 10, $logoh + 30);
            $color = imagecolorallocate($waterpic, 0, 0, 0); //文本颜色
            $colorBg = imagecolorallocatealpha($waterpic, 200, 200, 200, 60);//背景颜色
            @imagefill($waterpic, 0, 0, $colorBg);
            //写入文字水印
            imagettftext($waterpic, $fontSize, 0, 10, 30, $color, $fontType, $text);
            imagecopy($dst_img, $waterpic, $x, $y, 0, 0, $logow + 10, $logoh + 30);
             
        }

        switch ($srcInfo[2]) {
            case 1:
                imagegif($dst_img, $out);
                break;
            case 2:
                imagejpeg($dst_img, $out);
                break;
            case 3:
                imagepng($dst_img, $out);
                break;
            default:
                imagejpeg($dst_img, $out);
        }

        imagedestroy($dst_img);
        imagedestroy($srcim);
        return true;
    }
}
