<?php

return array (
  0 => 
  array (
    'name' => 'background-color',
    'title' => '背景色',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '',
    'rule' => '',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'background-image',
    'title' => '背景图片URL',
    'type' => 'image',
    'content' => 
    array (
    ),
    'value' => 'http://xshopt.weiyunyingxiao.top//uploads/20200602/79c837353c0c37169d4f18a610de36e2.jpg',
    'rule' => '',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  2 => 
  array (
    'name' => 'background-video',
    'title' => '背景视频URL',
    'type' => 'file',
    'content' => 
    array (
    ),
    'value' => '',
    'rule' => '',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
);
