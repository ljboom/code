环境 ngnix+mysql5.5+php7.1+redis
计划任务
//模拟结算  每天 23:55
http://127.0.0.1/addons/xshop/qi/sim      
//挖矿结算b  每天 23:58
http://127.0.0.1/addons/xshop/qi/d?pass=fe32d21111111ssssss3
//期权结算   每2分钟 
http://127.0.0.1/addons/xshop/qi/index
//更新币信息   每1分钟 
http://127.0.0.1/addons/xshop/btc/updatebinfo

后台基于fastadmin 开发 具体手册可百度

前台编译后方到 public 目录下即可
