<?php

namespace App\Models;

use App\Traits\GlobalStatus;
use Illuminate\Database\Eloquent\Model;

class TimeSetting extends Model
{
    use GlobalStatus;
}
