module.exports = {
    version: require('../package.json').version,
    stringifyInfo: require('./stringify-info'),
    stringifyStream: require('./stringify-stream'),
    parseChunked: require('./parse-chunked')
};
