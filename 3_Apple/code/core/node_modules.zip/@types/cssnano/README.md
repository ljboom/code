# Installation
> `npm install --save @types/cssnano`

# Summary
This package contains type definitions for cssnano (https://github.com/cssnano/cssnano).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/cssnano

Additional Details
 * Last updated: Fri, 03 Aug 2018 01:26:21 GMT
 * Dependencies: postcss
 * Global values: none

# Credits
These definitions were written by Armando Meziat <https://github.com/odnamrataizem>.
