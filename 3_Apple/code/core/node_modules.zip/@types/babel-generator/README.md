# Installation
> `npm install --save @types/babel-generator`

# Summary
This package contains type definitions for babel-generator ( https://github.com/babel/babel/tree/master/packages/babel-generator ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel-generator

Additional Details
 * Last updated: Wed, 13 Feb 2019 16:16:46 GMT
 * Dependencies: @types/babel-types
 * Global values: none

# Credits
These definitions were written by Troy Gerwien <https://github.com/yortus>, Johnny Estilles <https://github.com/johnnyestilles>.
