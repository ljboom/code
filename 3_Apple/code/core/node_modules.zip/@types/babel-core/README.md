# Installation
> `npm install --save @types/babel-core`

# Summary
This package contains type definitions for babel-core ( https://github.com/babel/babel/tree/master/packages/babel-core ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel-core

Additional Details
 * Last updated: Wed, 13 Feb 2019 16:16:46 GMT
 * Dependencies: @types/babel-types, @types/babel-template, @types/babel-traverse, @types/babylon, @types/babel-generator
 * Global values: babel

# Credits
These definitions were written by Troy Gerwien <https://github.com/yortus>, Marvin Hagemeister <https://github.com/marvinhagemeister>.
