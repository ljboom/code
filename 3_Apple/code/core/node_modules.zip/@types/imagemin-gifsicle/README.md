# Installation
> `npm install --save @types/imagemin-gifsicle`

# Summary
This package contains type definitions for imagemin-gifsicle (https://github.com/imagemin/imagemin-gifsicle#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/imagemin-gifsicle.

### Additional Details
 * Last updated: Thu, 01 Oct 2020 22:50:49 GMT
 * Dependencies: [@types/imagemin](https://npmjs.com/package/@types/imagemin)
 * Global values: none

# Credits
These definitions were written by [Romain Faust](https://github.com/romain-faust), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
