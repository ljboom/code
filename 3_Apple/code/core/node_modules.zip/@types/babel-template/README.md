# Installation
> `npm install --save @types/babel-template`

# Summary
This package contains type definitions for babel-template ( https://github.com/babel/babel/tree/master/packages/babel-template ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel-template

Additional Details
 * Last updated: Wed, 13 Feb 2019 16:16:46 GMT
 * Dependencies: @types/babylon, @types/babel-types
 * Global values: none

# Credits
These definitions were written by Troy Gerwien <https://github.com/yortus>, Marvin Hagemeister <https://github.com/marvinhagemeister>.
