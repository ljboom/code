# Installation
> `npm install --save @types/imagemin-optipng`

# Summary
This package contains type definitions for imagemin-optipng (https://github.com/imagemin/imagemin-optipng#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/imagemin-optipng

Additional Details
 * Last updated: Sun, 26 Aug 2018 03:30:33 GMT
 * Dependencies: imagemin
 * Global values: none

# Credits
These definitions were written by Romain Faust <https://github.com/romain-faust>.
