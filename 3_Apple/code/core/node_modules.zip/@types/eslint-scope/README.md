# Installation
> `npm install --save @types/eslint-scope`

# Summary
This package contains type definitions for eslint-scope (http://github.com/eslint/eslint-scope).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/eslint-scope

Additional Details
 * Last updated: Sun, 18 Feb 2018 01:53:11 GMT
 * Dependencies: eslint, estree
 * Global values: none

# Credits
These definitions were written by Toru Nagashima <https://github.com/mysticatea>.
