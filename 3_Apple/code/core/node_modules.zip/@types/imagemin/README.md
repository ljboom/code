# Installation
> `npm install --save @types/imagemin`

# Summary
This package contains type definitions for imagemin (https://github.com/imagemin/imagemin#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/imagemin

Additional Details
 * Last updated: Mon, 09 Sep 2019 00:16:32 GMT
 * Dependencies: @types/node
 * Global values: none

# Credits
These definitions were written by Romain Faust <https://github.com/romain-faust>, and Jeff Chan <https://github.com/hkjeffchan>.
