# Installation
> `npm install --save @types/micromatch`

# Summary
This package contains type definitions for micromatch (https://github.com/jonschlinkert/micromatch).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/micromatch/v2

Additional Details
 * Last updated: Thu, 21 Dec 2017 23:28:36 GMT
 * Dependencies: parse-glob
 * Global values: none

# Credits
These definitions were written by glen-84 <https://github.com/glen-84>.
