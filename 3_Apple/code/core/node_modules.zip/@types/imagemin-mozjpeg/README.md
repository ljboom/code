# Installation
> `npm install --save @types/imagemin-mozjpeg`

# Summary
This package contains type definitions for imagemin-mozjpeg (https://github.com/imagemin/imagemin-mozjpeg#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/imagemin-mozjpeg

Additional Details
 * Last updated: Tue, 24 Sep 2019 23:10:52 GMT
 * Dependencies: @types/imagemin
 * Global values: none

# Credits
These definitions were written by Jeff Chan <https://github.com/hkjeffchan>.
